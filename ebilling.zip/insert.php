<?php  
 //insert.php  
 $connect = mysqli_connect("localhost", "root", "", "supermarket");  
 $data = json_decode(file_get_contents("php://input"));  
 if(count($data) > 0)  
 {  
      $cat_name = mysqli_real_escape_string($connect, $data->cat_name);       
      $sub_cat = mysqli_real_escape_string($connect, $data->sub_cat);  
      $query = "INSERT INTO product_category(cat_name,cat_descr,cat_brand,cat_manufact,sub_cat,dat,cat_ref) VALUES ('$cat_name', '$sub_cat')";  
      if(mysqli_query($connect, $query))  
      {  
           echo "Data Inserted...";  
      }  
      else  
      {  
           echo 'Error';  
      }  
 }  
 ?>  