<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');
$today_date = date_create($today);
$sales_rtndate=date_format($today_date,"Y-m-d");

$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $counter=$rows['counter']; } 

$date_set = $today;

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
<title>Sales Return Bill</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-3.2.1.min.js"></script>
<script src="js/auto_js/jquery-ui.min.js"></script>
</head>
<style>
.totalprice {
	font-size: 20px !important;
}
</style>
<body class="fix-header fix-sidebar card-no-border" onload='setFocusToTextBox()'>
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h3 class="text-themecolor">Sales Return- Bill</h3>
        </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
            <li class="breadcrumb-item"><a href="saleshome.php">Sales</a></li>
            <li class="breadcrumb-item active">Sales Bill</li>
          </ol>
        </div>
        <div class="">
          
        </div>
      </div>
      <?php 
			    $result =$db->prepare("SELECT * FROM  sales_rtn_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				if(empty($rows['b_no'])){
				$bill_no='1';	
				}else{
				$bill_no=$rows['b_no'] + 1;	
					
				}
				
				$identification_leter='SR';
				?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <div class="text-right"> <a href="sales-return-bill.php?Billno=<?php echo $bill_no + 1;?>" target="_blank">
                <button type="button" class="btn btn-info btn-sm" style="float:right;"><i class="fa fa-plus"></i> Another Bill</button>
                </a> <a href="javascript:window.open('sales-bill.php','mywindowtitle','width=1000,height=800')" >
                <button type="button"  class="btn btn-info  btn-sm" style="float: right;margin-right:13px;"><i class="fa fa-plus"></i> New Bill OR F4</button>
                </a> </div>
              <div class="clear"></div>
              <hr>
              <form method="post" action="" class="forms" autocomplete="off" name="insert_form" id="insert_form">
                <div class="form-row">
                  <div class="col-md-4 col-sm-6 col-xs-12  mb-1">
                    <div class="row">
                      <div class="col-md-3 col-sm-6 col-xs-12">
                        <label for="" class="control-label">Bill No:</label>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                        <input type="text" class="form-control" id="bill_no" name="bill_no" value="<?php echo strtoupper($identification_leter);  echo $bill_no;?>" readonly>
						 <input type="hidden" class="form-control"  value="<?php echo $counter;?>" name="counter"  id="counter" readonly>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-xs-12"></div>
                  <input type="hidden" class="form-control" id="addby" name="addby" value="<?php echo $userid;?>" readonly>
					 <input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company;?>">
                  <div class="col-md-2 col-sm-6 col-xs-6 mb-1">
                    <input type="date" class="form-control" id="sales_rtndate"  value="<?php echo $date_set;?>"  name="sales_rtndate" >
                  </div>
                  <div class="col-md-2 col-sm-6 col-xs-6 mb-1">
                    <input type="time" class="form-control" id="sales_rtntime" value="<?php echo $current_time;?>" name="sales_rtntime" readonly>
                  </div>
                  <div class="col-md-3 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Sales Bill No</label>
							<select class="select2 form-control sales_invno" name="sales_invno" id="sales_invno" style="width: 100%; height:36px;">
								<option value="">select Bill</option>
								<?php
								$result = $db->prepare( "SELECT * FROM  sales_invoice WHERE company_tkn='$user_company'" );
								$result->execute();
								while ( $row = $result->fetch() ) {
									?>
								<option value="<?php echo $row['sbill_no'];?>">
									<?php echo ucfirst($row['sbill_no']);?> </option>
								<?php } ?>
							</select>
                  </div>
                  <input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty" readonly>
                  <input type="hidden" class="form-control" id="datetym" name="datetym" value="<?php echo $current_date_time;?>">
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                <div class=" col-md-12 col-xs-12 no-padding" id="table_data"> </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="respond"></div>
<script>
		function setFocusToTextBox() {
			$( "#sales_invno" ).focus();
		}
		
	</script> 
<script type="text/javascript">
		$( document ).ready( function () {
			
			
			
				$( document ).on( 'keydown', '.qty', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
				$('.qty' ).keyup( function () {
				var oldqty = parseInt($( '#qtyold_' + index ).val());  
			    var newqty = parseInt($( '#qty_' + index ).val()); 
	        if ( oldqty < newqty )
		     { 
		// $("#submit").hide();
		   document.getElementById('qty_' + index).style.color = "#ff0000";
		  }else{   document.getElementById('qty_' + index).style.color = "#000";} 
				});

				$( '.qty' ).keyup( function () {
					$( '#totalgst_' + index ).val( $( '#gst_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#total_' + index ).val( $( '#unitprice_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total1_' + index ).val( $( '#o_tax_amt1_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total2_' + index ).val( $( '#o_tax_amt2_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total3_' + index ).val( $( '#o_tax_amt3_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total4_' + index ).val( $( '#o_tax_amt4_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total5_' + index ).val( $( '#o_tax_amt5_' + index ).val() * $( '#qty_' + index ).val() );
					/*product other tax total*/
					$( '#totalgstcess_' + index ).val(  parseFloat($( '#o_tax_total1_' + index ).val()) +  parseFloat($( '#o_tax_total2_' + index ).val()) +  parseFloat($( '#o_tax_total3_' + index ).val()) +  parseFloat($( '#o_tax_total4_' + index ).val()) +  parseFloat($( '#o_tax_total5_' + index ).val()) );
					$( '#net_tax_' + index ).val( parseFloat($( '#totalgstcess_' + index ).val()) + parseFloat($( '#totalgst_' + index ).val()) );
					$( '#base_amount_' + index ).val( $( '#total_' + index ).val() - $( '#net_tax_' + index ).val() );
					/*net sum */
					var sum = 0;
					var net_tax_sum = 0;
					var qtysum = 0; var taxtot= 0; var cesstot=0;
					
					$( '.net_tax').each( function () {

						//add only if the value is number
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							net_tax_sum += parseFloat( this.value );
						}

					} );

					
					//iterate through each textboxes and add the values
					$( '.total').each( function () {

						//add only if the value is number
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							sum += parseFloat( this.value);
						}

					} );

					document.getElementById( 'totalprice' ).value = Math.round(net_tax_sum +  sum);
					document.getElementById( 'gtotalprice' ).value = Math.round( sum ); /* net total disc=0*/
					/*qty sum*/
					$( ".qty" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							qtysum += parseFloat( this.value );
						}
					} );
					document.getElementById( 'totalqty' ).value = Math.round( qtysum );
					/* tax total*/
					$( ".totalgst" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							taxtot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'tax_tot' ).value = taxtot;
					/* other tax total*/
					$( ".totalgstcess" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							cesstot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'cesstotal' ).value =  cesstot;
				} );
					$('#paid').keyup(function () {

					$('#balance').val($('#totalprice').val() - $('#paid').val());
				});
			} );
				
			$( '#insert_form' ).on( 'submit', function ( event ) {
				event.preventDefault();
				var error = '';
				var co = document.getElementById( 'countno' ); 
                for (e=0; e <= co; e++){
					var oldqty = parseInt($( '#qtyold_' + e ).val());  
			        var newqty = parseInt($( '#qty_' + e ).val()); 
	               if ( oldqty < newqty ) 
		             { 
                    $.toast( {
					heading: 'Retun Qty Should Be Less Than Or Equal to Sales Qty  ',
					text: '',
					position: 'top-right',
					loaderBg: '#F13109',
					icon: 'error',
					hideAfter: 1500
					} );
		              error += "<p>Enter Item Name at " + e + " Row</p>";
				    } }
				$( '.code' ).each( function () {
					var count = 1;
					if ( $( this ).val() == '' ) {
						error += "<p>Enter Item Name at " + count + " Row</p>";
						return false;
					}
					count = count + 1;
				} );

				$( '.name' ).each( function () {
					var count = 1;
					if ( $( this ).val() == '' ) {
						error += "<p>Enter Item Quantity at " + count + " Row</p>";
						return false;
					}
					count = count + 1;
				} );
				$( '.qty' ).each( function () {
					
					if ( $( this ).val() ==0 ) {
					$( this ).closest( 'tr' ).remove();	
						
					}
				} );
				$( '.sales_invno' ).each( function () {
					var count = 1;
					if ( $( this ).val() == '' ) {
						error += "<p>Select Unit at " + count + " Row</p>";
						return false;
					}
					count = count + 1;
				} );
				$( '.totalprice' ).each( function () {
				     var count = 1;
					if ( $(this).val() == 0){
						error += "<p>Select Unit at " + count + " Row</p>";
						setTimeout(function(){ window.location.reload(1);}, 1500);
						$.toast({
						heading: 'Enter Item Quantity.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1000
					});
						document.getElementById( "table_data" ).remove();
						return false;
					}
					count = count + 1;
				});
				var form_data = $( this ).serialize();
				if ( error == '' ){
					$.ajax({
						url: "creation_actions/sales-return/sales_rtn_bill.php",
						method: "POST",
						data: form_data,
						success: function (data) {
                         $("#respond").html(data);
						 
						}
					});
				} else {
					/*$.toast( {heading: 'Enter Sales Invoice Number.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});*/
				}
			} );


		} );
	</script> 
<script>
/* table data (sales bill)*/
		$( "#sales_invno" ).change( function (){
			
			var sales_invno = $( '#sales_invno' ).val();
			
			$.ajax( {
				type: 'POST',
				url: 'creation_actions/sales-return/sales_bill_data.php',
				data: 'sales_invno=' + sales_invno,
				success: function ( r ) {
					$( "#table_data" ).html( r );

				}
			} );
			
			
		} );

</script>
<div class="right-sidebar">
  <div class="slimscrollright">
    <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
    <div class="r-panel-body">
      <ul id="themecolors" class="m-t-20">
        <li><b>With Light sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
        <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
        <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
        <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
        <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
        <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
      </ul>
      
    </div>
  </div>
</div>
</div>

</div>
</div>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 
<script src="assets/plugins/tiny-editable/numeric-input-example.js"></script>
<?php include ('include/disable_fn.php'); ?> 
<script>
		
		$( function () {

			// For select 2
			$( ".select2" ) . select2();
			$( '.selectpicker' ) . selectpicker();


			$( ".ajax" ) . select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params . term, // search term
							page: params . page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params . page = params . page || 1;
						return {
							results: data . items,
							pagination: {
								more: ( params . page * 30 ) < data . total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
		
		$( document ).keyup( function ( e ) {
			if ( e.keyCode === 115 ) {
				window.open( 'sales-bill.php', 'myNewWinsr', 'width=1000,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no' );
			} //esc
		} );
	</script> 
<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
</body>
</html>