<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid=$_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$date = date_create($today);
date_sub($date,date_interval_create_from_date_string("2 days"));
$date1 = date_format($date,"Y-m-d");

$date2 = date_create($date1);
date_sub($date2,date_interval_create_from_date_string("3 days"));
$date2 = date_format($date2,"Y-m-d");

$date3 = date_create($date2);
date_sub($date3,date_interval_create_from_date_string("3 days"));
$date3 = date_format($date3,"Y-m-d");
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Stock Age Report</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor float-left">Stock</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item"><a href="inventory-home.php">Inventory</a></li>
							<li class="breadcrumb-item active">Stock Report</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<div class="table-responsive m-t-40">
									 <table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%">
										<thead>
											<tr>
												<th>Sl.No</th>
												<th>Item Code</th>
												<th>Item Name</th>
												<th>Last 3 Days</th>
												<th>3-6 Days</th>
												<th>6-9 Days</th>
												<th>More Than 9 Days</th>
											</tr>
										</thead>
										<tbody>
											<?php 
											$result_stock_details = $db->prepare("SELECT * FROM item_pricing WHERE company_tkn='$user_company'");
											$result_stock_details ->execute(); 
											for ($i=0; $rows_stock_details  = $result_stock_details ->fetch(); $i++){
												$prcode = $rows_stock_details['pr_code']; 
											?>
											<tr class='tr_input'>
												<td><?= $i+1; ?></td>
												<td><?php echo  $prcode; ?></td>
												<td><?php echo $rows_stock_details['pr_name']; ?></td>
												<td><?php 
													$result_stock = $db->prepare("SELECT COALESCE(SUM(pr_stock), 0) AS totl FROM item_pricing  WHERE pr_code = '$prcode' AND bill_date >= '$date1' AND bill_date <= '$today' AND company_tkn='$user_company' ");
													$result_stock ->execute(); $rows_stock  = $result_stock ->fetch();
													echo $rows_stock['totl'];
												?></td>
												<td><?php 
													$result_stock = $db->prepare("SELECT COALESCE(SUM(pr_stock), 0) AS totl FROM item_pricing WHERE pr_code = '$prcode' AND bill_date >= '$date2' AND bill_date < '$date1' AND company_tkn='$user_company'");
													$result_stock ->execute(); $rows_stock  = $result_stock ->fetch();
													echo $rows_stock['totl'];
												?></td>
												<td><?php 
													$result_stock = $db->prepare("SELECT COALESCE(SUM(pr_stock), 0) AS totl FROM item_pricing WHERE pr_code = '$prcode' AND bill_date >= '$date3' AND bill_date < '$date2' AND company_tkn='$user_company'");
													$result_stock ->execute(); $rows_stock  = $result_stock ->fetch();
													echo $rows_stock['totl'];
												?></td>
												<td>
												<?php 
												$result_stock = $db->prepare("SELECT COALESCE(SUM(pr_stock), 0) AS totl FROM item_pricing WHERE pr_code = '$prcode' AND bill_date >= '$today' AND bill_date < '$date3' AND company_tkn='$user_company'");
												$result_stock ->execute(); 
												 $rows_stock = $result_stock->fetch(); 
												echo $rows_stock['totl'];
												
												?>	
												</td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
		<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			</script>
			<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
			<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
			<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
			<script src="js/perfect-scrollbar.jquery.min.js"></script>
			<script src="js/waves.js"></script>
			<script src="js/sidebarmenu.js"></script>
			<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
			<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
			<script src="js/custom.min.js"></script>
			<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
			<script src="js/toastr.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
			<?php include ('include/disable_fn.php'); ?>
</body>

</html>