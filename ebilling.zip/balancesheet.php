<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];
//error_reporting(E_ERROR | E_PARSE);

	$date_set = $today;

$result_fin = $db->prepare( "SELECT * FROM  company WHERE c_token='$user_company'  " );
$result_fin->execute();
for ( $i = 0; $rows_fin = $result_fin->fetch(); $i++ ) {
	$start_year = $rows_fin[ 'financial_year_from' ];
}
if ( isset( $_GET[ 'startdate' ], $_GET[ 'enddate' ] ) ) {
	$startdates = date_create( $_GET[ 'startdate' ] );
	$startdates = date_format( $startdates, 'Y-m-d' );
	$enddates = date_create( $_GET[ 'enddate' ] );
	$enddates = date_format( $enddates, 'Y-m-d' );
} else {
	$startdates = date_create( $start_year );
	$startdates = date_format( $startdates, 'Y-m-d' );
	$enddates = date_create( $today );
	$enddates = date_format( $enddates, 'Y-m-d' );
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Balance Sheet</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/auto/all.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">

</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php"); ?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php"); ?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor float-left">Balance sheet</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a>
							</li>
							</li>
							<li class="breadcrumb-item"><a href="accounts-home.php">Accounts</a>
							</li>
							<li class="breadcrumb-item active">Report</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datemask.php'); ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 14px;" value="Submit"/>
											<?php if(isset ($_GET['startdate'])){ ?>
											<a href="balancesheet.php" name="" id="search_id" class="btn btn-danger btn-sm" style="margin-top:30px; font-size: 14px;"/>Clear&nbsp;</a>
											<?php } ?>
										</div>
									</div>
								</form>
								<div class=" col-md-12 text-right" style="margin-top:40px;">
									<a href="#" id="pdf" class="btn btn-info btn-sm"/><i class="fa fa-file-pdf" aria-hidden="true"></i> PDF</a>
									<a href="#" name="b_print" class="btn btn-info btn-sm" onClick="printdiv('div_print');"><i class="fa fa-print" aria-hidden="true"></i> Print</a>
									<!--<a href="#" class="btn btn-info btn-sm" id="csv"><i class="fa fa-file-excel" aria-hidden="true"></i> CSV</a>-->
									<button id="btnExport" class="btn btn-info btn-sm" onclick="fnExcelReport();"><i class="fa fa-file-excel" aria-hidden="true"></i> Excel</button>
								</div>
								<div id='div_print'>
								<div class="table-responsive m-t-40" id="print_pdf">
									<table id="example23" class="table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th colspan="4" style="text-align: center;   border-bottom: 1px dotted #0D0D0D;">
													<img oncontextmenu="return false;" src="assets/images/company_logo/<?php echo $logo; ?>" style="width:85px; height:75px;  "><br>
													<center>
														<strong><?php echo $company_name; ?></strong><br>
														<b>Balance sheet As on
														<?php echo date("d-m-Y",strtotime($startdates)); ?></b>
													</center><br>
												</th>
							     </tr>
									 <tr style="font-family: Times New Roman">
										<th colspan="4"  style="text-align: center; border-top: 1px dotted #000000; border-bottom: 1px dotted black;">
											<b>From Date :   <?php echo date("d-m-Y",strtotime($startdates));?>   </b><b>To Date:  <?php echo date("d-m-Y",strtotime($enddates));?></b>
										</th>
										
									   </tr>
								   	<tr>
									<th style="text-align: center; font-weight: 600px; font-size: 15px; border-bottom: 1px solid black; width: 35%"><strong>Liabilities</strong></th>
									<th style="text-align: right; font-weight: 600px; font-size: 15px; border-bottom: 1px solid black; width: 15%"><strong>Amount</strong></th>
									<th style="text-align: center; font-weight: 600px; font-size: 15px; border-bottom: 1px solid black; width: 35% "><strong>Assets</strong></th>
									<th style="text-align: right; font-weight: 600px; font-size: 15px; border-bottom: 1px solid black; width: 15%"><strong>Amount</strong></th>
								   	</tr>
								   </thead>
									<tbody>
								  <?php  
								$tb_balance = $tb_profit = $tb_loss = $dr_total = $cr_total = $drt = $crt =$op_stock = $closing_stock= $amt11=$amt12= 0;
								 $result_trading = $db->prepare( "SELECT SUM(balance) AS opening_stock FROM account_ledger WHERE account_group='STOCK' AND company_tkn='$user_company'" );
								  $result_trading->execute();
								  $row_count1 = $result_trading->rowCount();
								  $rows_trading = $result_trading->fetch();

								  if ( $rows_trading[ 'opening_stock' ] >= 0 ) {
								  	
								 $op_stock =  $rows_trading['opening_stock'];  }  
																	 
								$result_trading2 = $db->prepare("SELECT SUM(closing_balance) AS closing_stock, SUM(balance) AS balance FROM account_ledger WHERE company_tkn='$user_company' AND account_group='STOCK'");
								$result_trading2 ->execute(); 
								$rows_trading2  = $result_trading2->fetch(); 
								$row_count3 = $result_trading2->rowCount();
																	 
							    if($rows_trading2['closing_stock'] >= 0){ 
									
									if($rows_trading2['closing_stock'] == 0){
									$closing_stock = $rows_trading2['balance'];  
								  }else{											 
								  $closing_stock = $rows_trading2['closing_stock']; 
								  }	} 
								$result_ledger = $db->prepare( "SELECT * FROM account_ledger  WHERE acc_head='tr' AND trans='Dr' AND company_tkn='$user_company' GROUP BY ledger_name " );
															$result_ledger->execute();
															for ( $i = 0; $rows_ledger = $result_ledger->fetch(); $i++ ) {
																$ledger_acc = $rows_ledger[ 'ledger_name' ];
																//$debit_op_balance = $rows_ledger[ 'balance' ];

																$result_trading1 = $db->prepare( "SELECT SUM(debit_amt) as debit,SUM(credit_amt) as credit ,ledger_name as ledger_acc FROM transaction  WHERE company_tkn='$user_company' AND trn_date >= '$startdates' AND trn_date <='$enddates'  AND ledger_name='$ledger_acc' " );
																$result_trading1->execute();
																for ( $i = 0; $rows_trading1 = $result_trading1->fetch(); $i++ ) {
																	$ledger_prch = $rows_trading1[ 'ledger_acc' ];
																	$op_bal_dr = $rows_ledger[ 'balance' ];

																	if ( $ledger_prch == 'purchase return' ) {

																		$debit_am = $rows_trading1[ 'credit' ];

																	}
																	if ( $ledger_prch != 'purchase return' ) {

																		$debit_amount = $rows_trading1[ 'debit' ];

																	}
																	if ( !empty( $debit_am ) ) {

																		$debit_am = $rows_trading1[ 'credit' ];

																		if ( $debit_am > $debit_amount ) {
																			$total_purchase = $debit_am - $debit_amount;
																		} else {
																			$total_purchase = $debit_amount - $debit_am;
																		}
																		//$drt += $debit_amount - $debit_am;
																	}else  {
																		$debit_am = '0';
																		$drt += $debit_amount - $debit_am;
																	}
										}
									}
																	 
											$result_ledgerd = $db->prepare( "SELECT * FROM account_ledger  WHERE acc_head='tr' AND trans='Cr' AND company_tkn='$user_company' GROUP BY ledger_name " );
											$result_ledgerd->execute();
											for ( $a = 0; $rows_ledgerd = $result_ledgerd->fetch(); $a++ ) {
												$ledger_accd = $rows_ledgerd[ 'ledger_name' ];
												//$credit_op_balance = $rows_ledgerd[ 'balance' ];
												$result_trading12 = $db->prepare( "SELECT SUM(credit_amt) as credit,SUM(debit_amt) as debit, ledger_name as ledger_acc FROM transaction  WHERE trn_date >= '$startdates' AND trn_date <='$enddates' AND company_tkn='$user_company'  AND ledger_name='$ledger_accd' " );
												$result_trading12->execute();
												for ( $i = 0; $rows_trading12 = $result_trading12->fetch(); $i++ ) {

													$ledger_cash = $rows_trading12[ 'ledger_acc' ];
													$op_bal_cr = $rows_ledgerd[ 'balance' ];

													if ( $ledger_cash == 'sales return' ) {

														$credit_am = $rows_trading12[ 'debit' ];

													}
													if ( $ledger_cash != 'sales return' ) {

														$credit_amount = $rows_trading12[ 'credit' ];
													}
													if ( !empty( $credit_am ) ) {

														$credit_am = $rows_trading12[ 'debit' ];

														if ( $credit_am > $credit_amount ) {
															$total_sales = $credit_am - $credit_amount;
														} else {
															$total_sales = $credit_amount - $credit_am;
														}
														//$crt += $credit_amount - $credit_am;
													}else {
														$credit_am = '0';
														$crt += $credit_amount - $credit_am;
													}
															
									 		} } 
									 		 $amt11 = round($crt + $closing_stock);
											 $amt12 = round($drt + $op_stock);
											 //Loss	
												//echo $amt12;
											 if($amt12 > $amt11){									 
											 if($amt12 > $amt11){

											 $tb_balance += $amt12 - $amt11;
											 }else{
											 $tb_balance += $amt11 - $amt12;	 
											 }
											 $dr_total +=  $drt + $op_stock;

											 $cr_total +=  $crt + $tb_balance + $closing_stock; 
												
											 }
											 
											if($amt11 > $amt12 ){

											 //Profit
											 if($amt11 > $amt12 ){	

											 $tb_balance +=  $amt11 - $amt12;
											 }else{
											 $tb_balance += $amt12 - $amt11;	 
											 }
											 $dr_total += $amt12 + $tb_balance;

											 $cr_total +=  $amt11;	 
												//echo $amt12;
											 }

											 if($amt11 == $amt12){

											 $dr_total += $drt  + $op_stock;

											 $cr_total +=  $crt + $closing_stock;		 

											 }	
																	 
								    if ($amt12 < $amt11 ) { $tb_profit = abs($tb_balance); } else if($amt12 > $amt11){ $tb_loss = abs($tb_balance);  } 
																	 
									$debit_pl = $credit_pl = $total_debit_pl_amt= $total_credit_pl_amt= $total_pl_balance  = $pl_loss = $asset_balance = $liability_balance = 0;$pl_balance=$credit_pl_tot=$debit_pl_tot=$total_cr= $total_debit_side=$total_credit_side=0;

									$result_trading_cr = $db->prepare("SELECT an.account_group as actgrouphead,db.ledger_name as ledger_name,an.trans as trans,SUM(db.credit_amt) as credit, SUM(db.debit_amt) AS debit from transaction as db inner join  account_ledger as an on db.ledger_name=an.ledger_name WHERE db.trn_date >= '$startdates' AND db.trn_date <='$enddates' AND an.acc_head='pl' AND an.trans='Cr' AND an.company_tkn='$user_company' AND db.company_tkn='$user_company' GROUP BY an.ledger_name ");
									$result_trading_cr ->execute(); 
									for($i=0; $rows_trading_cr  = $result_trading_cr->fetch(); $i++){
									
								    $debit_amount_pl = $rows_trading_cr['debit'];  
									  
								    $trans1=$rows_trading_cr['trans'];
								    $credit_pl=$rows_trading_cr['credit'];
									
								    $total_credit_pl_amt += $credit_pl - $debit_amount_pl; } 
																	 
									$result_trading_dr = $db->prepare("SELECT an.account_group as head,db.ledger_name as ledger_name,an.trans as trans, SUM(db.debit_amt) as debit, SUM(db.credit_amt) AS credit from transaction as db inner join  account_ledger as an on db.ledger_name=an.ledger_name WHERE db.trn_date >= '$startdates' AND db.trn_date <='$enddates' AND an.acc_head='pl' AND an.trans='Dr' AND an.company_tkn='$user_company' AND db.company_tkn='$user_company' GROUP BY an.ledger_name ");
									$result_trading_dr ->execute(); 
									for($i1=0; $rows_trading_dr  = $result_trading_dr->fetch(); $i1++){ 
								
								    $credit_amount_pl = $rows_trading_dr['credit'];	
										
									$trans2=$rows_trading_dr['trans'];
									$debit_pl=$rows_trading_dr['debit'];
								   
								    $total_debit_pl_amt +=$debit_pl - $credit_amount_pl;
								
								   } 
								
								//P&L calculation
									if ( $tb_loss > 0 ) {
   				
										 $total_pl_balance += $total_debit_pl_amt + $tb_balance;

										if ($total_credit_pl_amt > $total_pl_balance ){
											
										  $pl_balance += $total_credit_pl_amt - $total_pl_balance;
											
										} else {
											
											$pl_balance += $total_pl_balance - $total_credit_pl_amt;
										}
										
										$total_debit_side +=$total_debit_pl_amt + $pl_balance;
										
										
										if($total_credit_pl_amt > $total_debit_side){
											
										$debit_pl_tot += $total_debit_pl_amt + $pl_balance + $tb_balance;

										$credit_pl_tot += $total_credit_pl_amt;
											
										}else if($total_debit_side > $total_credit_pl_amt){
											
										$debit_pl_tot += $total_debit_pl_amt + $tb_balance;

										$credit_pl_tot += $total_credit_pl_amt + $pl_balance;	
										}
									}

									//Profit	
									if ( $tb_profit > 0 ) {

										$total_pl_balance += $total_debit_pl_amt - $tb_profit;

										if ( $total_pl_balance > $total_credit_pl_amt ) {


											$pl_balance += $total_pl_balance - $total_credit_pl_amt;

										} else {

										$pl_balance += $total_credit_pl_amt - $total_pl_balance;
										}
										
										 $total_credit_side +=$total_credit_pl_amt + $pl_balance;
										
									
										
										if($total_debit_pl_amt > $total_credit_side){
											
										$debit_pl_tot += $total_debit_pl_amt;

										$credit_pl_tot += $total_credit_pl_amt + $pl_balance + $tb_balance;
											
										}else if($total_credit_side > $total_debit_pl_amt){
											
										$debit_pl_tot += $total_debit_pl_amt + $pl_balance;

										$credit_pl_tot += $total_credit_pl_amt  +  $tb_balance;	
										}
									}
									if ( $tb_loss > 0 ) {
										
										$pl_loss = $pl_balance;
									}

									if ( $tb_profit > 0 ) {
										
										$net_profit = $pl_balance;
									}

									$result_account = $db->prepare( "SELECT * FROM accountgroup " );
									$result_account->execute();
									for ( $i = 0; $rows_account = $result_account->fetch(); $i++ ) {
									$type = $rows_account[ 'group_head' ];
									}
									$grand_tot_asset = $grand_tot_liability = $capital_liability = $capital_asset = 0; 
																	 
								$result_trading2 = $db->prepare("SELECT SUM(closing_balance) AS closing_stock, SUM(balance) AS balance FROM account_ledger WHERE company_tkn='$user_company' AND account_group='STOCK'");
								$result_trading2 ->execute(); 
								$rows_trading2  = $result_trading2->fetch(); 
								$row_count3 = $result_trading2->rowCount();
																	 
							    if($rows_trading2['closing_stock'] >= 0){ ?>
							  <tr>
							  <td></td>
							  <td></td>
							  <td align="right"><strong>Stock</strong></td>
							  <td align="right"><?php
								if($rows_trading2['closing_stock'] == 0){
								$closing_stock = number_format($rows_trading2['balance']);  
								$closing_stock1 = $rows_trading2['balance'];  
							    }else{											 
							    $closing_stock = round($rows_trading2['closing_stock']); 
								$closing_stock1 = $rows_trading2['closing_stock'];
							    }						 
								echo number_format($closing_stock1); 
								?>
							  </td>
							  </tr>
							  <?php } ?>									 
							
								<tr>
										<td colspan="2" style=" width: 100%; padding: 0 !important;margin:0 !important; ">
											<table style="width:100%; padding: 0 !important;margin:0 !important; float: left;">
											<?php 
											$result_balancesheet1 = $db->prepare("SELECT an.account_group as actgrouphead,an.ledger_name as ledger_name,SUM(an.balance) as op_balance,an.trans as trans,an.group_head as group_head, SUM(db.debit_amt) as debit, SUM(db.credit_amt) as credit  from transaction as db inner join  account_ledger as an on db.ledger_token=an.ledger_token WHERE db.trn_date >= '$startdates' AND db.trn_date <='$enddates'  AND an.acc_head='bs' AND an.group_head='liability' AND an.company_tkn='$user_company' AND db.company_tkn='$user_company' GROUP BY an.ledger_name  ");
											$result_balancesheet1 ->execute(); 
											$row_count_balance11 = $result_balancesheet1->rowCount();
											for($i=0; $rows_balancesheet1  = $result_balancesheet1->fetch(); $i++){	
												
											if($rows_balancesheet1['trans'] == 'Cr'){
											$op_balance=$rows_balancesheet1['op_balance']; 	
											}
												
											$debit_amount1=$rows_balancesheet1['debit'];
											
											$credit_amount1=$rows_balancesheet1['credit'];
											$total_liability= $credit_amount1 - $debit_amount1;	
											// Loss(Less Loss)	
											if($tb_loss > 0){
											
											$total_liability= $credit_amount1 -  $debit_amount1;
											
											$liability_balance +=$total_liability;
											// Profit(Add Profit)		
											}else if( $total_debit_pl_amt > $total_credit_side){
											$total_liability= $credit_amount1 -  $debit_amount1;
											
											$liability_balance +=$total_liability;	
											}else if( $total_credit_pl_amt > $total_debit_side){
											$total_liability= $credit_amount1 - $debit_amount1;	
											}else if($tb_profit > 0){
											
											$total_liability= $credit_amount1 - $debit_amount1;
											
											$liability_balance +=$total_liability;	
											}
										  	//No Loss // No profit
											if($tb_loss == '0' && $tb_profit == '0'){
											$total_liability= $credit_amount1 - $debit_amount1;
											
											$liability_balance +=$total_liability;	
											}	
											?>
												<tr>
											<td align="left" style=" width:70%; height:25px; !important;"><a target="_blank" style="color: #0A0A0A; text-decoration:none; cursor: pointer;" href="journal-report.php?ledgername=<?php echo $rows_balancesheet1['ledger_name']; ?>"><?php echo strtoupper($rows_balancesheet1['ledger_name']); ?></a></td>
											<td align="right" style=" width:30%; height:25px; !important;"><?php echo $total_liability;  ?></td>
											
											</tr>
											<?php } ?>		
										</table>
										</td>
									<td colspan="2" style=" width: 100%; padding: 0 !important; margin:0 !important;">
									
											<table style="width:100%; padding: 0 !important;margin:0 !important;   float: right; ">
											<?php $result_balancesheet = $db->prepare("SELECT an.account_group as actgrouphead,an.ledger_name as ledger_name,SUM(an.balance) as op_balance,an.trans as trans,an.group_head as group_head, SUM(db.debit_amt) as debit, SUM(db.credit_amt) as credit  from transaction as db inner join  account_ledger as an on db.ledger_name=an.ledger_name WHERE db.trn_date >= '$startdates' AND db.trn_date <='$enddates'  AND an.acc_head='bs' AND an.group_head='asset' AND an.company_tkn='$user_company' AND db.company_tkn='$user_company'  GROUP BY an.ledger_name  ");
												$result_balancesheet ->execute(); 
												$row_count_balance1 = $result_balancesheet->rowCount();
												for($i=0; $rows_balancesheet  = $result_balancesheet->fetch(); $i++){

												if($rows_balancesheet['trans'] == 'Dr'){
												$op_balance1=$rows_balancesheet['op_balance']; 	
												}
													
												$debit_amount=$rows_balancesheet['debit'];
												
												$credit_amount=$rows_balancesheet['credit'];
												
												$total_asset=$debit_amount - $credit_amount;
												
												$asset_balance = $total_asset; 
												
												$grand_tot_asset +=$asset_balance;
												?>
											
												<tr>
												<td align="left" style=" width:70%; height:25px; !important;"><a target="_blank" style="color: #0A0A0A; text-decoration:none; cursor: pointer;" href="journal-report.php?ledgername=<?php echo $rows_balancesheet['ledger_name']; ?>"><?php echo strtoupper($rows_balancesheet['ledger_name']); ?></a></td>
												<td align="right" style=" width:30%; height:25px; !important;"><?php echo number_format($asset_balance); ?></td>
												</tr>
												<?php  } ?>
											</table>
										</td>
								
							</tr>
								<?php 
								//echo 'L/'.$tb_loss.'P/'.$tb_profit;	
								//loss									 
								if( $total_debit_pl_amt > $total_credit_side && $closing_stock1 ==0){
								if($tb_loss > $liability_balance){
								$capital_liability +=$pl_balance - $liability_balance;
								}else{
								$capital_liability += $liability_balance - $pl_balance;	
								}
								}else if($tb_loss > 0 && $closing_stock1 == 0){
								if($tb_loss > $liability_balance){
								$capital_liability +=$pl_balance - $liability_balance;
								}else{
								$capital_liability +=$liability_balance - $pl_balance;	
								}	
								}
								
										
								if($closing_stock1 > 0 && $total_credit_pl_amt > $total_debit_side && $tb_loss > 0){
								if($liability_balance > $pl_balance){
								$grand_tot_liability += $liability_balance - $pl_balance;
								}else if($pl_balance > $liability_balance){
								$grand_tot_liability +=   $liability_balance - $pl_balance;	
								}
								$total_diff = $closing_stock1;
									
								$capital_liability +=$total_diff + $grand_tot_liability;
								
								}else if($tb_loss > 0 && $closing_stock1 > 0){
									
								
								$grand_tot_liability += $liability_balance - $pl_balance;
								
								$total_diff = $closing_stock1;
									
								$capital_liability +=$total_diff + $grand_tot_liability;
								}
						
								if($closing_stock > 0 && $total_credit_pl_amt > $total_debit_side && $tb_profit > 0){
								
								$grand_tot_liability += $liability_balance + $pl_balance;
								
								$total_diff = $closing_stock1;
									
								$capital_liability +=$total_diff + $grand_tot_liability;
									
								}else if($closing_stock1 > 0 && $tb_profit > 0){
								
								$grand_tot_liability += $liability_balance + $pl_balance;
								
								$total_diff = $closing_stock1;
									
								$capital_liability +=$total_diff + $grand_tot_liability;	
									
								}
								
								//profit									 
							    if( $total_credit_pl_amt > $total_debit_side && $closing_stock1 == 0 ){
								$capital_liability += $liability_balance;
								}else if($tb_profit > 0 && $closing_stock1 == 0 ){
								$capital_liability +=$pl_balance + $liability_balance;	
								}
										
								if($tb_loss == 0 && $tb_profit == 0 && $closing_stock1 == 0){
								$capital_liability += $liability_balance + $closing_stock1;	
								}else if($tb_loss == 0 && $tb_profit == 0 && $closing_stock1 > 0){
								$capital_liability += $liability_balance + $closing_stock1;	
								}
								//echo $liability_balance."/".$tb_profit;
								?>
								    <?php if($closing_stock1 > 0){ ?>		
									<tr>
									<td>Difference In Amount</td>
									<td class="text-right"><?php echo number_format($closing_stock1); ?></td>
									<td></td>
									<td></td>
									</tr>
									<?php } ?>
									<tfoot>
									<tr>
									<td></td>
									<td align="right" style="border-bottom: 1px; solid black; border-top: 1px solid black;"><strong><?php echo number_format($capital_liability, 2); ?></strong></td>
									<td></td>
									<td align="right" style="border-bottom: 1px; solid black; border-top: 1px solid black;"><strong><?php echo number_format($grand_tot_asset + $closing_stock1,2); ?></strong></td>	
									</tr>
									</tfoot>
									
									<?php if( $total_credit_pl_amt > $total_debit_side){ ?>
									<tr>
									<td align="left" style="font-size: 15px;"><strong>Net Profit</strong></td>
									<td align="right"><strong><?php echo number_format($pl_balance,2); ?></strong></td>
									<td></td>
									<td align="right"></td>	
									</tr>
									<?php }else if( $tb_profit > 0 ){ ?>
									<tr>
									<td align="left" style="font-size: 15px;"><strong>Net Profit</strong></td>
									<td align="right"><strong><?php echo number_format($pl_balance,2); ?></strong></td>
									<td></td>
									<td align="right"></td>	
									</tr>
									<?php }if($total_debit_pl_amt > $total_credit_side){ ?>
									<tr>
									<td align="left" style="font-size: 15px;"><strong>Net Loss</strong></td>
									<td align="right"><strong><?php echo number_format($pl_balance,2); ?>(-)</strong></td>
									<td></td>
									<td align="right"></td>	
									</tr>
									<?php }else if($tb_loss > 0 ){ ?>
									<tr>
									<td align="left" style="font-size: 15px;"><strong>Net Loss</strong></td>
									<td align="right"><strong><?php echo number_format($pl_balance,2); ?>(-)</strong></td>
									<td></td>
									<td align="right"></td>	
									</tr>
									<?php } ?>
								</tbody>
							</table>
							</div>
					   </div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
			
		</div>
	</div>
	</div>
	
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<script type="text/javascript" src="assets/convert/pdfmake.min.js"></script>
	<script type="text/javascript" src="assets/convert/html2canvas.min.js"></script>
	<script src="js/table2csv.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
	<script type="text/javascript">
	var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
		/*day detailse pdf*/
		$( "body" ).on( "click", "#pdf", function () {
			//$('.non_pdf').hide(); 
			html2canvas( $( '#print_pdf' )[ 0 ], {
				onrendered: function ( canvas ) {
					var data = canvas.toDataURL();
					var docDefinition = {
						content: [ {
							image: data,
							width: 500
						} ]
					};
					pdfMake.createPdf( docDefinition ).download( "<?php echo $company_name; ?>_<?php echo $startdates; ?>_To_<?php echo $enddates; ?>.pdf" );
				if(data !=''){
				$.toast( { heading: 'PDF Exported..', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 1500} ); 	
				}
				}
			} );
			setTimeout( location.reload.bind( location ), 1200 );
		} ); //$('.non_pdf').show();


		function printdiv( printpage ) {
			var headstr = "<html><head><title></title></head><body>";
			var footstr = "</body>";
			var newstr = document.all.item( printpage ).innerHTML;
			var oldstr = document.body.innerHTML;
			document.body.innerHTML = headstr + newstr + footstr;
			window.print();
			document.body.innerHTML = oldstr;
			return false;
		}

		//excel
		function fnExcelReport() {
			var tab_text = "<table border='2px'><tr bgcolor='#87AFC6'>";
			var textRange;
			var j = 0;
			tab = document.getElementById( 'example23' ); // id of table

			for ( j = 0; j < tab.rows.length; j++ ) {
				tab_text = tab_text + tab.rows[ j ].innerHTML + "</tr>";
				//tab_text=tab_text+"</tr>";
			}

			tab_text = tab_text + "</table>";
			tab_text = tab_text.replace( /<A[^>]*>|<\/A>/g, "" ); //remove if u want links in your table
			tab_text = tab_text.replace( /<img[^>]*>/gi, "" ); // remove if u want images in your table
			tab_text = tab_text.replace( /<input[^>]*>|<\/input>/gi, "" ); // reomves input params

			var ua = window.navigator.userAgent;
			var msie = ua.indexOf( "MSIE " );

			if ( msie > 0 || !!navigator.userAgent.match( /Trident.*rv\:11\./ ) ) // If Internet Explorer
			{
				txtArea1.document.open( "txt/html", "replace" );
				txtArea1.document.write( tab_text );
				txtArea1.document.close();
				txtArea1.focus();
				sa = txtArea1.document.execCommand( "SaveAs", true, "Say Thanks to Sumit.xls" );
			} else //other browser not tested on IE 11
				sa = window.open( 'data:application/vnd.ms-excel,' + encodeURIComponent( tab_text ) );

			return ( sa );
		}


		$( '#csv' ).on( 'click', function () {
			$( '#print_pdf' ).table2csv( {
				file_name: '<?php echo $company_name; ?>_<?php echo $startdates; ?>_To_<?php echo $enddates; ?>.csv',
				header_body_space: 0
			} );
		} )
	</script>
	<script>

		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			searching		: false,
			bSort		: false,
			fixedHeader: true,
			paging: false,
			info: false,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
			
		} );
		 

	</script>
	
	
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>