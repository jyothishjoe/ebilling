<?php 
include ('include/auth.php');
include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php");?>
			
				<div class="col-xs-12 no-padding" style="width:500px;">
			<h3 class="text-center">Add Customer</h3>
		<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
									<div class="form-row">
										<div class="col-md-4 col-sm-6 col-xs-12  mb-3">

											<label for="" class="control-label">Customer Id</label>

											<input type="text" class="form-control" id="cus_id" name="cus_id" value="<?php echo create_token() ; ?>" readonly>
										</div>

										<div class="col-md-4 col-sm-6 col-xs-12  mb-3">

											<label for="" class="control-label">Account Name</label>

											<input type="text" class="form-control" id="acname" name="acname" placeholder="Enter Account Name" required>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Date/Time</label>

											<input type="text" class="form-control" id="dattime" name="dattime" value="<?php echo $current_date_time;?>" readonly>

										</div>

										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Customer Name</label>

											<input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Address</label>

											<textarea class="form-control" id="address" name="address" placeholder="Required address" required></textarea>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Contact No 1</label>

											<input type="text" class="form-control" id="contact_no1" name="contact_no1" placeholder="Enter Contact Number" required>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Contact No 2</label>

											<input type="text" class="form-control" id="contact_no2" name="contact_no2" placeholder="Enter Contact Number" required>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Location</label>

											<input type="text" class="form-control" id="location" name="location" placeholder="Enter Location" required>

										</div>
										<div class="col-md-4 col-sm-6 col-xs-12 mb-3">

											<label for="" class="control-label">Credit Limit</label>

											<input type="text" class="form-control" id="cred_limit" name="cred_limit" placeholder="Enter Credit Limit" required>

										</div>
										
										</div>
										<div class="text-right">
											<a href="javascript: save_customer()" class="btn btn-info">Submit</a> 
										</div>
								</form>
								</div>
							</div>
						</div>
					</div>
					<script>
						function save_customer() {

							var name = $( "#name" ).val();
							var name = $( "#acname" ).val();
							var address = $( "#address" ).val();
							var contact_no1 = $( "#contact_no1" ).val();
							var contact_no2 = $( "#contact_no2" ).val();
							var location = $( "#location" ).val();
							var cred_limit = $( "#cred_limit" ).val();

							if ( $( "#name" ).val() == "" || $( "#acname" ).val() == "" || $( "#address" ).val() == "" || $( "#contact_no1" ).val() == "" || $( "#contact_no2" ).val() == "" || $( "#location" ).val() == "" || $( "#cred_limit" ).val() == "" ) {
								$.toast( {
									heading: 'Fill all required fields.',
									text: '',
									position: 'top-right',
									loaderBg: '#ff6849',
									icon: 'error',
									hideAfter: 4500


								} );
							} else {
								$( ".preloader" ).show();

								//$.ajax({
								//type : 'POST',
								//url  : ',
								//data: "user_typ="+ user_typ + "&name=" + name + "&email=" + email + "&c_no=" + c_no + "&u_name=" + u_name + "&pwd=" + pwd + "&typ=" + typ,
								//success : function(r) {						
								//$("#respond").html(r);
								//	}
								//});
								return false;
							}
						}
					</script>
	
