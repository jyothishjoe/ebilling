<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$ledger_name=trim($_GET['sup_id']);
$user_company = $_SESSION['SESS_COMPANY_ID'];
$result_transaction1 = $db->prepare("select SUM(balance_amt) AS balance FROM transaction WHERE  ledger_name='$ledger_name'  AND company_tkn='$user_company' ");
$result_transaction1->execute();
$row_transaction1 = $result_transaction1->fetch();
$amount_balance = $row_transaction1['balance'];

$result_company = $db->prepare("select * FROM company WHERE  c_token='$user_company' ");
$result_company->execute();
$rows_company = $result_company->fetch();
$company_name = $rows_company['c_company_name'];
$logo = $rows_company['c_logo'];

?>
<!doctype html>
<html>

<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>

				<div class="row">
					<div class="col-12">
						<div class="card">	
							<div class="card-body">
								<div class="col-md-12">
								<a href="supplier-all.php" style="float: right;" class="btn btn-sm btn-info"><i class="fa fa-backward" aria-hidden="true"></i>   Back</a>	
								</div>
								 <div class="table-responsive m-t-0">
 									 <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
									<thead style="font-size: 14px; text-align: center; margin-bottom: 18px;">
									<tr style=" font-size: 15px;  margin-bottom: 18px; border-bottom: 1px 
									#000000">
										<th colspan="6">
											<img src="assets/images/company_logo/<?php echo $logo; ?>" style="width:100px; height:100px; position: absolute; left:28px; margin-bottom: 10px;">
											<center><br>
											<center><h4><b><?php echo $company_name; ?></b></h4></center>
											<h5 style="margin:0px;"><?php echo $rows_company['c_shopaddress']; ?>, <?php echo $rows_company['address_sec']; ?></h5><br>
												<?php echo $rows_company['c_phone']; ?>
										</th>
									</tr>
									</thead>
									<thead style="text-align: right">
									<tr style="font-family: Times New Roman">
										<th colspan="2"  style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px; margin-left: 15px; margin-bottom: 15px;'> Name : <?php echo"".ucwords(strtolower($ledger_name)); ?></b><br>
										</th>
										<th colspan="2"  style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px; margin-left: 15px; margin-bottom: 15px;'> From : <?php echo '10/12/19'; ?></b><br>
										</th>
										<th colspan="2"  style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px; margin-left: 15px; margin-bottom: 15px;'> To : <?php echo '20/12/19'; ?></b><br>
										</th>
										<!--<th colspan="3" align="center" style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px;'>Balance Amount :  <?php echo $amount_balance; ?> ₹</b><br>
										</th>-->
									</tr>
									</thead>
										<thead style="font-weight: 600px; text-align: left">
											<tr>
											    <th style="border-bottom: 1px solid grey; width: 10%"><strong>Voucher No</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Date</strong></th>
												<th style="border-bottom: 1px solid grey; width: 35%"><strong>Purcticulars</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Total Amount</strong></th>
												<!--<th style="border-bottom: 1px solid grey; width: 15%"><strong>Paid</strong></th>-->
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Balance</strong></th>
											</tr>
											</thead>
                                         <tbody>
										<?php
										$total_amt=$paid_amt=$balance_amt=0;		 
										$result_transaction = $db->prepare("select SUM(credit_amt) AS total_price, SUM(paid_amt) AS paid_amt,SUM(balance_amt) AS balance_amt, voucher_no AS voucher_no,trans_type AS trans_type, trn_date AS trn_date, remarks AS remarks, ledger_token AS ledger_token, ledger_name AS ledger_name FROM transaction  WHERE  ledger_name='$ledger_name' AND company_tkn='$user_company' GROUP BY trans_type");
										$result_transaction->execute();
										for($i=0; $row_transaction = $result_transaction->fetch(); $i++){

										$ledger_trans_tkn = $row_transaction['ledger_token'];	
										$ledger_trans_name = $row_transaction['ledger_name'];
										$narration= $row_transaction['remarks'];
										$dat= $row_transaction['trn_date'];
										$trans_type= $row_transaction['trans_type'];
										$voucher_no= $row_transaction['voucher_no'];
											
										$total_amount= $row_transaction['total_price'];	
										$total_amt += $total_amount;

										$total_paid= $row_transaction['paid_amt'];	
										$paid_amt += $total_paid;	 

										$total_balance= $row_transaction['balance_amt'];	
										$balance_amt += $total_balance;	

										?>
								<tr>		
								<td><?php echo $voucher_no; ?></td>
								<td><?php echo date("d-m-Y",strtotime($dat)); ?></td>
							
							<td>
							<?php if($trans_type == 'purchase'){ ?>
							<a href="alter-purchase.php?alter=<?php echo $voucher_no; ?>" ><?php echo strtoupper($trans_type); ?></a><?php }  else if($trans_type == 'purchase return'){ ?>
							<a  href="alter-purchase-return.php?alter=<?php echo $voucher_no; ?>" ><?php echo strtoupper($trans_type); ?></a><?php }else{ ?>
							<a href="alter-journal.php?alter=<?php echo $voucher_no; ?>" class=" simple-ajax-popup-align-top" ><?php echo strtoupper($trans_type); ?></a><?php } ?>		
							<br><?php echo $narration; ?>
							</td>
							<td><?php echo number_format($total_amount); ?></td>	
							<!--<td><?php echo number_format($total_paid); ?></td>-->
							<td><?php echo number_format($total_balance); ?></td>
							</tr>
								<?php } ?>
									<tfoot>
										<tr>
											<td></td>
											<td></td>
											<td style="font-size: 15px;" align="right"><b>Total Amount</b></td>
											<td><b><?php echo number_format($total_amt,2); ?></b></td>
											<!--<td><b><?php echo number_format($paid_amt,2); ?></b></td>-->
											<td><b><?php echo number_format($balance_amt,2); ?></b></td>
										</tr>
									</tfoot>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b> </li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
				</ul>
				
			</div>

	
	
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script>
		$( document ).ready( function () {
			$( '.simple-ajax-popup-align-top' ).magnificPopup({
				type: 'ajax',
				alignTop: true,
				closeOnBgClick: false,
				overflowY: 'scroll'

			} );
			$( '.simple-ajax-popup' ).magnificPopup( {
				type: 'ajax'
			} );
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
	<script>
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
	</script>
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>