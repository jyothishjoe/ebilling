<?php
if(isset($_POST['request']) && file_exists("assets/jquery/dist/data.json")){
	
	$data = array();
	$data1 = file_get_contents( "assets/jquery/dist/data.json" );
	$data1 = json_decode( $data1, true );
	foreach ( $data1 as $row ){
	
 	$data["softwarekey"] = $row['softwarekey'];
	$data["status"] = $row[ "status" ];
	$data["daysleft"] = $row[ "daysleft" ];
	
	echo json_encode($data); 
	}
}else{ $data['notific'] = '5';  echo json_encode($data);  } ?>