<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include('db-connect/db.php');
$token=$_GET['token'];
$result_seasontomer = $db->prepare("SELECT * FROM tax_creation WHERE tax_token='$token' ");
$result_seasontomer->execute();
$rows_seasontomer = $result_seasontomer->fetch(); 
$tax_typ=$rows_seasontomer['tax_type'];
$tax_rate=$rows_seasontomer['tax_rate'];
$purchase=$rows_seasontomer['purchase'];
$sales=$rows_seasontomer['sales'];
if($purchase == 'purchase') {$purchase == 'purchase';
}else{ $purchase == '';}
if($sales == 'sales') {$sales == 'sales';
}else{ $sales == '';}
?>
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php");?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>

<div id="custom-content" class="col-md-3 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #ffffff;">
<br>
	<h3 class="text-center">Update Other Tax</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Tax Type </label>
				<input type="text" class="form-control" id="tax_typ" name="tax_typ" value="<?php echo htmlspecialchars($tax_typ); ?>">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="token" name="token" value="<?php echo $token; ?>">
			</div>
		</div>
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Tax Rate </label>
				<input type="text" class="form-control" id="tax_rate" name="tax_rate" value="<?php echo $tax_rate; ?>" placeholder="Tax Rate">
	    	</div>
		</div>
    	 <!--<div class="form-row">
	       <div class="col-md-12" style="margin-top: 18px; margin-bottom: 12px;">
              <div class="btn-group" data-toggle="buttons">
				<span class="btn btn-sm btn-info">
					<input type="checkbox" id="purchase" class="filled-in chk-col-light-blue" name="purchase" value="purchase" <?php if($purchase == 'purchase') echo 'checked' ?>>
					<label class="" for="md_checkbox_21">Purchase</label>
				</span>
				<label class="btn btn-sm btn-info">
					<input type="checkbox" id="sales" class="filled-in chk-col-light-blue" name="sales"  value="sales" <?php if($sales == 'sales') echo 'checked' ?>>
					<label class="" for="md_checkbox_22">&nbsp;&nbsp;&nbsp;Sales&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				</label>
			</div>
		</div>
                  </div>-->
		<div class="col-md-12" style="margin-bottom:40px;"> 
		<a href="javascript: save_customer()" name="submit" class="btn btn-info btn-sm" id="submit" style="float: right;">Update</a>
		<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close" style="float: right; margin-right: 5px;">Cancel</button>
	</div>
	</form>
</div>
	<script>
		$('#close_fbx').on('click', function (){
			 parent.jQuery.magnificPopup.close();
		});
		function save_customer() {

            /*if( $("input[name='purchase']:checked").val()){
				 var purchase='purchase';
			} else {var purchase='';}
          if( $("input[name='sales']:checked").val()){
				 var sales='sales';
			} else {var sales='';}*/ 
			var tax_typ = $("#tax_typ").val();
			var tax_rate = $("#tax_rate").val();
			var userid = $("#userid").val(); 
			var token = $("#token").val();
			if ( $("#tax_rate").val() == "" ) {
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200} );
			}else{
				$.ajax({
					type: 'POST',
					url: "product-action/othertax_update.php",
					data: "tax_typ=" + tax_typ + "&tax_rate=" + tax_rate + "&userid=" + userid + "&token=" + token,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				 //parent.jQuery.magnificPopup.close();
				setTimeout("location.href = 'othertax-list.php';", 1000);
				return false;
			}
		}
	</script>
	<div id="respond"></div>