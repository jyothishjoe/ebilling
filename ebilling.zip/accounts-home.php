<?php include ('include/auth.php'); 
$userid = $_SESSION['SESS_USERID_AS'];
include( 'db-connect/db.php' );
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type_second where user_tkn = '$user_type_tkn'");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{ $trance_add_cash=$row_user['trance_add_cash']; $trance_add_bank=$row_user['trance_add_bank']; $trance_joural=$row_user['trance_joural']; $add_bank=$row_user['add_bank']; $update_bank=$row_user['update_bank']; $add_ledger=$row_user['add_ledger']; $update_ledger=$row_user['update_ledger']; $add_transactiontype=$row_user['add_transactiontype']; $update_transactiontype=$row_user['update_transactiontype']; $day_closing=$row_user['day_closing']; $general_ledger=$row_user['general_ledger']; $general_daybook=$row_user['general_daybook'];
 $general_cashflow=$row_user['general_cashflow']; $acco_sales=$row_user['acco_sales']; $acco_purchase=$row_user['acco_purchase']; $trail_balance=$row_user['trail_balance']; $profit=$row_user['profit']; $trading_profit_loss=$row_user['trading_profit_loss']; $balance_sheet=$row_user['balance_sheet'];  $account_add_gst=$row_user['account_add_gst']; $account_update_gst=$row_user['account_update_gst']; $account_add_othertax=$row_user['account_add_othertax']; $account_update_othertax=$row_user['account_update_othertax']; }
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />
	<link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
	<title>Accounts Home</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
</head>
<style>ul,li {z-index: 9999 !important};</style>
<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav_home.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor">Accounts</h4>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<i class="breadcrumb-item"><a oncontextmenu="return false;" href="index.php">Home</a>
							</i>
							<i class="breadcrumb-item active">Accounts</i>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-body">
								<form class="needs-validation" novalidate>
									<div class="form-row">
									<?php if($trance_add_cash==0 || $trance_add_bank==0 || $trance_joural==0) { ?>
										<div class="col-lg-3">
										<div class="card  text-white" style="background-color:  #5795C4">
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Transactions <label style="font-size: 13px;"></label></h4>
														<h6 class="text-white"></h6>
														<?php if($trance_add_cash==0) { ?>
														<a oncontextmenu="return false;" href="create-payment.php" id="cashclick" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 simple-ajax-popup-align-top ">Journal (F5)</a>
														<a oncontextmenu="return false;" href="journal-all.php" id="journal-list" class="btn btn-rounded btn-outline btn-light m-t-10 font-14  fancybox fancybox.iframe">Report (F6)</a>
														<?php }  ?>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($add_bank==0) { ?>
									<div class="col-lg-3" style="display: none;">
										<div class="card text-white" style="background-color: #e07281">
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Bank<label style="font-size: 13px;"> ( Alt+B )</label></a></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="create-bank.php" id="bank1" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Create</a>
														<a oncontextmenu="return false;" href="bank-list.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">All Bank List</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($add_ledger==0) { ?>
									<div class="col-lg-3">
										<div class="card  text-white" style="background-color:  #0A4D80" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Ledger <label style="font-size: 13px;"> ( Alt+C )</label></a></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="create-ledger.php" id="ledger1" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Ledger</a>
														<a oncontextmenu="return false;" href="ledger-report.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">All Ledger</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($add_transactiontype==0) { ?>
									<div class="col-lg-3">
										<div class="card  text-white" style="background-color: #873839" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Transaction Types <label style="font-size: 13px;"> ( Alt+T )</label></a></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="add-transaction-types.php" id="transaction1" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Create</a>
														<a oncontextmenu="return false;" href="trans_type_list.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe"> list</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($day_closing==0) { ?>
									
									 <div class="col-lg-3">
									 <div class="card  bg-success text-white">
									 <div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Day Closing <label style="font-size: 13px;"> ( Alt+V )</label></a></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="dayclosing_process.php" id="daycloses" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Day Closing</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
									  </div>
									</div>
									<?php } if($general_ledger==0 || $general_daybook==0 || $general_cashflow==0) { ?>
									<div class="col-lg-4">
										<div class="card bg-primary text-white" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">General Reports</h4>
														<h6 class="text-white"></h6>
														<?php if($general_ledger==0) { ?>
														<a oncontextmenu="return false;" href="general-ledger.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Ledger</a>
														<?php } if($general_daybook==0) { ?>
														<a oncontextmenu="return false;" href="daybook.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Daybook</a>
														<?php } if($general_cashflow==0) { ?>
														<a oncontextmenu="return false;" href="cash-flow-statement.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Cash Flow</a>
														<?php } ?>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($acco_purchase==0) { ?>
									<div class="col-lg-3">
										<div class="card bg text-white" style="background-color: #6C3B73" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Purchase</h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="purchase-tax.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Purchase Report</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($acco_sales==0) { ?>
									<div class="col-lg-2">
										<div class="card bg text-white" style="background-color: #7A7A7A" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Sales</h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="sales_tax.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Sales Report</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($trail_balance==0 || $profit==0 || $trading_profit_loss==0 || $balance_sheet==0) { ?>
									<div class="col-lg-6">
										<div class="card  text-white" style="background-color: #c2a744" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Final Accounts</h4>
														<h6 class="text-white"></h6>
														<?php if($trail_balance==0) { ?>
														<a oncontextmenu="return false;" href="trailbalance.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Trail Balance</a>
														<?php } if($profit==0) { ?>
														<a oncontextmenu="return false;" href="profit.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Profit</a>
														<?php } if($trading_profit_loss==0) { ?>
														<a oncontextmenu="return false;" href="trading_profit_loss_acc.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Trading & Profit & Loss</a>
														<?php } if($balance_sheet==0) { ?>
														<a oncontextmenu="return false;" href="balancesheet.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Balance Sheet</a>
														<?php } ?>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($account_add_gst==0 || $account_add_othertax==0 ) { ?>
									<div class="col-lg-5">
										<div class="card  text-white" style="background-color: #36AAA8" >
										<div class="card-body">
										  <div class="d-flex" style="color: aliceblue;">
											<div class="stats">
											<h4 class="text-white">Tax</h4>
											<?php if($trail_balance==0) { ?>
											<a oncontextmenu="return false;" href="add-gst.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax ">GST</a>
											<?php } if($account_add_othertax==0) { ?>
											<a oncontextmenu="return false;" href="add-tax.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Other Tax</a>
											<?php } if($trail_balance==0) { ?>
											<a oncontextmenu="return false;" href="gst-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">GST List</a>
											<?php } if($account_add_othertax==0) { ?>
											<a oncontextmenu="return false;" href="othertax-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">Other Tax List</a>
											<?php } ?>
											</div>
											<div class="stats-icon text-right"></div>
										  </div>
										</div>
										</div>
									</div>
									<?php } ?>
									
								</form>
								</div>
								<div class="col-md-12">
									<div class="card" style="text-align: center;">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="right-sidebar">
						<div class="slimscrollright">
							<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
							<div class="r-panel-body">
								<ul id="themecolors" class="m-t-20">
									<li><b>With Light sidebar</b>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
									</li>
									<li class="d-block m-t-30"><b>With Dark sidebar</b>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
									</li>
								</ul>
								
							</div>
						</div>
					</div>
				</div></div>
				
			</div>
		</div>
		<script>
			 $( window ).keydown( function ( event ) {
			
			 if ( event.keyCode == 27 ) {
				event.preventDefault();
				//alert(index);
				parent.jQuery.fancybox.close(); 
			}
			 
		 });
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 	
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true,
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
		<script>	
		//Short Cut Keys 
		$( window ) . keydown( function ( event ) {
			
			if ( event . keyCode == 116 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( "#cashclick" ).click();
			}if ( event . keyCode == 117 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( "#journal-list" ).click();
			}
		});
	$(document).keyup(function(e){
	e.preventDefault();
	if(e.altKey && e.which == 67){ $( "#ledger1" ).click();
	} else if(e.altKey && e.which == 66){  $( "#bank1" ).click();
	} else if(e.altKey && e.which == 84){  $( "#transaction1" ).click();
	} else if(e.altKey && e.which == 86){  $( "#daycloses" ).click();
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
<?php if(isset($_COOKIE['NC']) && $_COOKIE['NC'] == true){ ?> 
<script> 
	$(document).ready(function(){
		$("#cashclick").click();
		$.toast({
			heading: 'Payment Saved Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	}); </script><?php } ?>
		<script src="assets/plugins/popper/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="js/perfect-scrollbar.jquery.min.js"></script>
		<script src="js/waves.js"></script>
		<script src="js/sidebarmenu.js"></script>
		<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
		<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
		<script src="js/custom.min.js"></script>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
		<script src="js/mask.init.js"></script>
		<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
		<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
		<?php include ('include/disable_fn.php'); ?>
</body>

</html>