	<?php
include( 'db-connect/db.php' );
include( 'include/today.php' );
$bill = $_POST[ 'bill' ];
$company=$_POST['company'];
$billdate = date_create($_POST['billdate']);
$billdate = date_format($billdate,'Y-m-d');
$result =$db ->prepare("SELECT * FROM purchase_productdetails a LEFT JOIN purchase_invoice b ON a.purch_token=b.purch_token  WHERE b.inv = '$bill' AND a.bill_date = '$billdate' AND status='1' AND a.company_tkn='$company' AND b.company_tkn='$company'");
$sl = 0;
$result->execute();	
$row_count =  $result->rowcount();
if($row_count > 0){
	?>
	<hr/>
		<div class="col-md-12" id='heading'>
			<h4>Product Details</h4>
		</div>
		<hr/>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<form class="form-horizontal" method="post" action="stockbarcode.php"  id="insert_form">
				<div class="col-md-12 col-sm-12 col-xs-12" style="overflow-x: auto; " id='table_content'>
				 <table class="table table-bordered" style="min-width: 1100px;">
					<thead>
						<tr>
							<th>Sl No</th>
							<th>Item code</th>
							<th>Barcode</th>
							<th>Item Name</th>
							<th>Unit</th>
							<th>HSN</th>
							<th>Cost</th>
							<th>Qty</th>
							<th>Sales GST%</th>
							<th>MRP</th>
							<th>Barcode Qty</th>
						</tr>
					</thead>
					<tbody id="hello">
						 <?php 
						 $result =$db ->prepare("SELECT * FROM purchase_productdetails a LEFT JOIN purchase_invoice b ON a.purch_token=b.purch_token  WHERE b.inv = '$bill' AND a.bill_date = '$billdate' AND status='1' AND a.company_tkn='$company' AND b.company_tkn='$company'");
						 $sl = 0;
						 $result->execute();	
						 $row_count =  $result->rowcount();
						 for($i=0; $rows1 = $result->fetch(); $i++){
						  $price = $rows1['total_purchase_cost'];
						  $product_code = $rows1['p_id'];
						  $result1 =$db ->prepare("SELECT * FROM item_pricing WHERE company_tkn='$company'");
						  $result1->execute();	
						  $rows11 = $result1->fetch();
						  $sup_token=$rows1['sup_token'];
						  $result_supplier=$db->prepare("SELECT * FROM supplier WHERE supplier_token='$sup_token' AND company_tkn = '$company' ");
						  $result_supplier->execute();
						  $rows_supplier=$result_supplier->fetch();
						  $priced_product=$rows1['p_id'];
						  $purch_price=$rows1['purch_price'];
						  
						 if($row_count > 0)
						 {
							 $val=1;
						 }else{
							 $val=0;
						 }
						 $result_price1 =$db ->prepare("SELECT * FROM item_pricing  WHERE pr_code='$priced_product' AND company_tkn='$company'  ");
						 $sl = 0;
						 $result_price1->execute();	
						 $row_count_price1 =  $result_price1->rowcount();
						 $rows_price1 = $result_price1->fetch();
							  $priced_barcode1=$rows_price1['pr_code'];
							  $mrp=$rows_price1['pr_saleprice'];
							 
						 $result_price =$db ->prepare("SELECT * FROM item_pricing  WHERE pr_code='$priced_barcode1' AND pr_purch_price = '$purch_price' AND company_tkn='$company'");
						 $sl = 0;
						 $result_price->execute();	
						 $row_count_price =  $result_price->rowcount();
						 $rows_price = $result_price->fetch();
							  $priced_barcode1=$rows_price['pr_barcode'];
						 ?>
						<tr class='tr_input'>
							<td width="70" class="css-serialw"><input type='text' tabindex="-1" class="form-control slno" name="slno" id='slno_1' value="<?php echo ++$sl; ?>" readonly>
							</td>
							<td><input type='text' tabindex="-1" class="form-control code" name="code[]" id='code_<?php echo $i+1; ?>' placeholder='Product Code' value="<?php echo $rows1['p_id']; ?>" readonly>
							<input type='hidden' class="form-control stock_tkn" name="stock_tkn[]" id='stock_tkn_<?php echo $i+1; ?>'  value="<?php echo $rows1['stock_tkn']; ?>" readonly>
							</td>
							<td>
							<input type='text' tabindex="-1" class="form-control prch_barcode" name="prch_barcode[]" id='prch_barcode_<?php echo $i+1; ?>' placeholder='Product barcode' value="<?php if($row_count_price !=0){ echo $priced_barcode1; }else{ echo mt_rand(); } ?> " >
							<input type='hidden' class="form-control newcode" name="newcode[]" id='newcode_<?php echo $i+1; ?>' placeholder='new barcode' value="<?php echo mt_rand(); ?>">
							</td>
							<td><input type='text' class="form-control name" name="name[]" id='name_<?php echo $i+1; ?>' placeholder='Product Name' value="<?php echo $rows1['pr_name'];?>" >
							</td>
							<td><input type='text' tabindex="-1" class="form-control unit" name="unit[]" id='unit_<?php echo $i+1; ?>' placeholder='Product ' value="<?php echo $rows1['unit'];?>" readonly>
							</td>
							<td><input type='text' tabindex="-1" class="form-control hsn" name="hsn[]" id='hsn_<?php echo $i+1; ?>' placeholder='HSN' value="<?php echo $rows1['hsn'];?>" readonly>
							</td>
							<td><input type='text' tabindex="-1" class="form-control purchprice" name="purchprice[]" id='purchprice_<?php echo $i+1; ?>' placeholder='Unit Price' value="<?php echo $rows1['total']/$rows1['qty']; ?>" readonly>
							</td>
							<td><input type='text' tabindex="-1" class="form-control pqty" name="pqty[]" id='pqty_<?php echo $i+1; ?>' placeholder=''  value="<?php echo $rows1['qty'];?>" readonly>
							<input type='hidden' class="form-control totalpurchamount" name="totalpurchamount[]" id='totalpurchamount_<?php echo $i+1; ?>' placeholder='' >
							</td>
							<td><input type='text' tabindex="-1" class="form-control salesgstin" name="salesgstin[]" id='salesgstin_<?php echo $i+1; ?>'  value="<?php echo $rows1['tax'];?>" placeholder='Sales GST' readonly  >
							<input type='hidden' class="form-control gstinamt" name="gstinamt[]" id='gstinamt_<?php echo $i+1; ?>'   placeholder='Sales GST'  >
							<input type='hidden' class="form-control tax_total" name="tax_total[]" id='tax_total_<?php echo $i+1; ?>'   placeholder='Sales GST'  >
							<!--Taxable Non Taxable-->
							<input type='hidden' class="form-control purchase_token" name="purchase_token[]" value="<?php if($gst <= '0'){ echo $rows_ledger1['ledger_token']; } if($gst != '0'){ echo $rows_ledger['ledger_token']; } ?>" id='purchase_token_<?php echo $i+1; ?> ' placeholder='GST%'>
							<input type='hidden' class="form-control ledger_name" name="ledger_name[]" value="<?php if($gst <= '0'){ echo $rows_ledger1['ledger_name']; } if($gst != '0'){ echo $rows_ledger['ledger_name']; } ?>" id='ledger_name_<?php echo $i+1; ?>' placeholder='GST%'>
							 <!--Other Tax Rate-->
							 <?php 
							 $result_other_tax = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' AND company_tkn='$company' ");
							 $result_other_tax->execute();
							 for($i1=0; $rows_other_tax = $result_other_tax->fetch(); $i1++){ ?>
							 <input type='hidden' class="form-control othertax_amt<?php echo $i1+1; ?>" name="othertax_amt<?php echo $i1+1; ?>[]" id='othertax_amt<?php echo $i1+1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_tax['tax_rate']; ?>">
							 <?php } ?>
							 <!--Empty Text Boxes of tax rate-->
							 <?php for($otax=$i1; $otax <=4; $otax++){  ?>
							 <input type='hidden' class="form-control othertax_amt<?php echo $otax+1; ?>" name="othertax_amt<?php echo $otax+1; ?>[]" id='othertax_amt<?php echo $otax+1; ?>_<?php echo $i+1; ?>' value="0">
							 <?php  } ?>
							 <!--===================================-->
							 <!--Other Tax Amounts-->
							 <?php 
							 $result_other_taxamt = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' AND company_tkn='$company' ");
							 $result_other_taxamt->execute();
							 for($i3=0; $rows_other_taxamt = $result_other_taxamt->fetch(); $i3++){ ?>
							 <input type='hidden' class="form-control othertax_amount<?php echo $i3+1; ?>" name="othertax_amount<?php echo $i3+1; ?>[]" id='othertax_amount<?php echo $i3+1; ?>_<?php echo $i+1; ?>' value="0" >
							 <?php } ?>
							 <!--Empty Text Boxes of tax Amount-->
							 <?php for($otax1=$i3; $otax1 <=4; $otax1++){  ?>
							 <input type='hidden' class="form-control othertax_amount<?php echo $otax1+1; ?>" name="othertax_amount<?php echo $otax1+1; ?>[]" id='othertax_amount<?php echo $otax1+1; ?>_<?php echo $i+1; ?>' value="0">
							 <?php  } ?>
							 <!--===================================-->
							 <!--Other Tax Type Names (CESS, etc)-->
							 <?php
							 $result_other_taxtype = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' AND company_tkn='$company' ");
							 $result_other_taxtype->execute();
							 for($i2=0; $rows_other_taxtype = $result_other_taxtype->fetch(); $i2++){ ?>
							 <input type='hidden' class="form-control othertax_typ<?php echo $i2 + 1; ?>" name="othertax_typ<?php echo $i2 + 1; ?>[]" id='othertax_typ<?php echo $i2 + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_taxtype['tax_type']; ?>">
							 <?php } ?>
							 <!--Empty Text Boxes of Tax type Names-->
							 <?php for($type=$i2; $type <=4; $type++){ ?>
							 <input type='hidden' class="form-control othertax_typ<?php echo $type + 1; ?>" name="othertax_typ<?php echo $type + 1; ?>[]" id='othertax_typ<?php echo $type + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_taxtype['tax_type']; ?>">
							 <?php } ?>
							 <!--===================================-->
							</td>
							<td><input type='text' class="form-control mrp" name="mrp[]" id='mrp_<?php echo $i+1; ?>' placeholder='MRP' value="" autocomplete="off">
							<input type='hidden' class="form-control mrprate" name="mrprate[]" id='mrprate_<?php echo $i+1; ?>' placeholder='MRP' value="" autocomplete="off">
							</td>
							<td><input type='text' class="form-control qty" name="qty[]" id='qty_<?php echo $i+1; ?>' placeholder=''  value="<?php echo $rows1['qty'];?>">
							</td>
							<input type="hidden" name="vid[]" value="<?php echo $rows_supplier['supplier_token']; ?>">
							<input type="hidden" name="vendor_name[]" value="<?php echo $rows_supplier['v_name']; ?>">
							<input type="hidden" name="purchinvoice[]" value="<?php echo $rows1['inv']; ?>">
							<input type="hidden" name="phone[]" value="<?php echo $rows_supplier['phone']; ?>">
							<input type="hidden" name="bill[]" value="<?php echo $rows1['bill_no']; ?>">
							<input type="hidden" name="purchbill[]" value="<?php echo $bill; ?>">
							<input type="hidden" name="billdate[]" value="<?php echo $rows1['bill_date']; ?>">
							<input type="hidden" class="form-control" style="width: 155px; display: inline;" name="date" id="date" value="<?php echo $today; ?>">
						</tr>
						<?php } ?>
					</tbody>
				</table>
				</div>
				<div class="col-md-12" >
					<button type="submit" id="submit" class="btn btn-sm btn-info"  style="float: right; margin-top: 15px; margin-bottom: 18px;">Submit</button>
				</div>
			</form>
		</div>
		
		<script>
		var textbox = $('#prch_barcode_' + index ).val(); 
		if(jQuery.trim(textbox).length > 0){
		$( "#prch_barcode_" + index ).prop( "disabled", false );
		}else{
		$('#prch_barcode_' + index ).prop("disabled", true);	
		}	
			var form_data = $( this ).serialize();
			if ( error == '' ) {
				$.ajax( {
					url: "stockbarcode.php",
					method: "POST",
					data: form_data,
					success: function ( data ) {
						if ( data == 'ok' ) {
							document.getElementById( "insert_form" ).reset();
							$( 'tbody' ).find( "tr:gt(0)" ).remove();
							location.reload();
							$.toast( {heading: 'Saved Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 7000,hideMethod: 'fadeOut'});
						} else {
							$.toast( {heading: 'Error',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 4500});
						}
					}
				} );
			}
		</script>
<?php }else{ ?>
<script>
$.toast({
heading: 'Bill Not Found!.',
text: '',
position: 'top-right',
loaderBg: '#F50000',
icon: 'error',
hideAfter: 4500
} );

</script>
<?php } ?>
