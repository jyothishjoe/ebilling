<?php
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$sbill_no=$_GET[ 'billno' ];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');
$user_company = $_SESSION['SESS_COMPANY_ID'];
$result_user_company = $db->prepare("SELECT * FROM company WHERE c_token = '$user_company'");
$result_user_company->execute();	
$rows_user_company = $result_user_company->fetch(); 
$logo=$rows_user_company['c_logo'];

?>
<html>
<title>Supermarket/Pos Bill Print</title>
<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style>
table td {
	height: 15px;
}
 @media print {
.btn {
	display: none;
}
}
.hr {
	border: none;
	border-top: 1px dashed black;
	margin-top:10px;
}
</style>
<?php include("include/print_size.php");?>
</head>
<body>
<div class="col-md-12" style="margin-top: 18px;"><a href="salesof-point.php" class="btn btn-sm btn-danger" style="font-size: 15px; float: left;">Back</a> </div>
<?php
  $result =$db ->prepare("SELECT * FROM sales_invoice where sbill_no='$sbill_no'");
$result->execute();	$row_count =  $result->rowcount();
for($i=0; $rows = $result->fetch(); $i++) {$order_no=$rows["order_no"]; $sales_invono=$rows["sales_invono"];  $datetym=$rows["sales_invodate"]; $cus_name=$rows["cus_name"]; $cus_tkn=$rows["cus_tkn"]; $tax_tot=$rows["tax_tot"]; $tot_qty=$rows["tot_qty"]; $paid_amt=$rows["paid_amt"];  $balance_amt=$rows["balance_amt"]; $cess_total=$rows["o_tax_total"];}
?>
<div class="row">
  <div class=" col-xs-12 printwidth" style="padding:0px 50px;">
    <table style="text-align:center;" width="100%" border="0">
      <tr>
        <th> <h3><?php echo $rows_user_company['c_company_name']; ?></h3></th>
      </tr>
      <tr>
        <td><?php echo $rows_user_company['c_shopaddress']; ?></td>
      </tr>
      <tr>
        <td>Ph: <?php echo $rows_user_company['c_phone']; ?>, Mob: <?php echo $rows_user_company['c_mobile']; ?></td>
      </tr>
      <tr>
	  <?php if($tax_tot!=0){?>
	   <th>Tax Invoice</th>
	  <?php } else {?>
        <th>Sales Invoice</th>
	  <?php } ?>
      </tr>
    </table>
    <table style="text-align:left;float:left;" border="0" id ="address">
      <tr>
        <?php 
            if (!empty($cus_tkn)) {?>
        <div class="col-md-12" style="padding-bottom: 8px;"></div>
        <td><b>Sold To :</b> <?php echo ucfirst($cus_name);?></td>
        <?php
			 $result =$db ->prepare("SELECT * FROM customer where cus_tkn='$cus_tkn'");
				
			$result->execute();	$row_count =  $result->rowcount();
			for($i=0; $rows = $result->fetch(); $i++) { $addres=$rows["addres"];  $contact_no1=$rows["contact_no1"];}
			?>
      </tr>
      <tr>
        <td><?php echo ucfirst($addres);?><br></td>
      </tr>
      <tr>
        <td><?php echo $contact_no1;?></td>
        <?php } else {?>
        <td><p style="display:none"> <?php echo $datetym;?> </p></td>
        <?php } ?>
      </tr>
      <tr> </tr>
    </table>
    <table style="float:right;text-align:left;" border="0" id="datetym">
      <tr>
        <th>Date :</th>
        <td><?php echo $datetym;?></td>
      </tr>
      <tr>
        <th>Bill No :</th>
        <td><?php echo strtoupper($sbill_no);?></td>
      </tr>
      <tr>
        <?php 
           if (!empty($order_no)) {?>
        <?php
			$result =$db ->prepare("SELECT * FROM sales_order_invoice where order_invno='$order_no'");	
			$result->execute();	$row_count =  $result->rowcount();
			for($i=0; $rows3 = $result->fetch(); $i++) { $orderbill_no=$rows3["bill_no"];}
			?>
        <th>Sales Order No:</th>
        <td><?php echo strtoupper($orderbill_no);?></td>
        <?php } else {?>
        <td style="display:none;">Sales Order No: <?php echo $orderbill_no;?></td>
        <?php }?>
      </tr>
     </table>
  
    <?php if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
 <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="40%" style="text-align:left !important;"> Product Name</th>
          <th rowspan="2" width="10%" > Qty</th>
          <th rowspan="2" width="10%" > Rats</th>
          <th rowspan="2" width="10%" >Mrp</th>
          <th rowspan="2" width="10%" >Gst%</th>
		  <th rowspan="2" width="10%" >Cess%</th>
          <th rowspan="2" width="10%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
          <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <?php      
				$result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
                $prdct_tkn = $rows['prdct_tkn'];
                $qty = $rows['qty'];
                $rate = $rows['rate'];
                $net_tot = $rows['net_tot'];
                $sales_tax = $rows['sales_tax'];
                $gst_amt = $rows['gst_amt'];
                $pr_hsn = $rows['pr_hsn'];
                $mrp = $rows['mrp'];
                $prdct_name = $rows['prdct_name'];
                $amount = $rows['amount'];
                $grand_tot = $rows['grand_tot'];
                $disc = $rows['disc'];
                $units = $rows['units'];
				$gstcess_amt = $rows['o_tax_amt'];
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr>
          <td align="left"><?php
        echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax;?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <?php 
    if ( $tax_tot!=0) { ?>
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="5">Gst Included  </td>
        </tr>
	<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono' GROUP By sales_tax");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $sales_taxg=$rows['sales_tax'];
			  if( $sales_taxg !=0) {
			  $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS amount FROM sales_invoice_prdct_detail where sales_tax='$sales_taxg' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $gstsum=$rowret['amount'];}
			  ?>
			  <tr>
			   <td></td>
				  <td  align="left" colspan="2">Sgst <?php echo $sales_taxg/2;?>%</td>
				  <td  align="center"><?php echo $gstsum/2; ?></td>
				  <td  align="center" colspan="2">Cgst <?php echo $sales_taxg/2;?>%</td>
				  <td  align="center"><?php echo $gstsum/2; ?></td>
			  </tr>
				<?php } } ?>
   <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>

    <?php } ?>
       <?php 
    if ( $cess_total!=0) { ?>
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="5">Other Tax Included  </td>
        </tr>
	<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			 <tr>
			     <td></td>
				  <td  align="left" colspan="5"><?php echo $o_tax_typeg;?>%</td>
				  <td  align="center"><?php echo $qty_total;?></td>
			 </tr>
			  <?php  } ?> 
   <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <?php } ?> 
	
	
	 <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	  <tr>
	<?php if ( $tax_tot!=0) { ?>
	
        <td colspan="6">Gst Total  </td><td  align="center"><?php echo  $tax_tot;?></td>
		
      
	<?php } else { ?>
   
        <td colspan="6">Gst Total  </td><td  align="center">0</td>
		
        <?php } ?>
  <?php if ( $cess_total!=0) { ?>	
	
        <td colspan="6">Gst Cess Total  </td><td  align="center"><?php echo  $cess_total;?></td>
      
	<?php }  else { ?>
    
    <tr>
       <td colspan="6">Gst Cess Total  </td><td  align="center">0</td>
		  </tr>	
        <?php } ?>
	<tr>
	  <td colspan="2">Grand Total </td><td  align="center"><?php echo  $grand_tot;?></td>
	  <td></td><td colspan="2">Discount   </td><td  align="center"><?php echo  $disc;?></td>
    </tr>
    <tr>
	  <td colspan="2">Cash Recd  </td><td  align="center"><?php echo  $paid_amt;?></td>
	  <td></td><td colspan="2">Change</td><td  align="center"><?php echo  $balance_amt;?></td>
    </tr>		
    <tr>
        <th> Net Total </th><th></th><td></td><td align="center"><?php echo $e;?></td><td></td><td></td><td   align="center"><b><?php echo  $net_tot;?></b></td>
      </tr>
      <tr>
        <?php
    $results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
        $results->execute();
    for($i=0; $rows = $results->fetch(); $i++)
    { $user_username=$rows['user_username']; $counter=$rows['counter']; } 
    ?>
    <td colspan="6">Counter  #<?php echo $counter;?> / <?php echo $user_username;?> / <?php echo $current_time;?></td>
      </tr>
      <tr>
        <td  colspan="6">E & OE </td>
      </tr>
      <tr>
        <td  colspan="6">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="6">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
<?php } else if( $printer_width == 'b7' || $printer_width == '80mm' || $printer_width == 'a7'  || $printer_width == 'b8') { ?>

    <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="21%" > Rats</th>
          <th rowspan="2" width="16%" >Mrp</th>
          <th rowspan="2" width="21%" >Gst%</th>
		  <th rowspan="2" width="14%" >Cess%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
	  <tr><td></td><td></td><td></td><td></td><td></td></tr>
        <?php      
                            $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
							$result->execute();
							for($e=0; $rows= $result->fetch(); $e++){
								
								$prdct_tkn = $rows['prdct_tkn'];
								$qty = $rows['qty'];
								$rate = $rows['rate'];
								$net_tot = $rows['net_tot'];
								$sales_tax = $rows['sales_tax'];
								$gst_amt = $rows['gst_amt'];
								$pr_hsn = $rows['pr_hsn'];
								$mrp = $rows['mrp'];
								$prdct_name = $rows['prdct_name'];
								$amount = $rows['amount'];
								$grand_tot = $rows['grand_tot'];
								$disc = $rows['disc'];
								$units = $rows['units'];
								$gstcess_amt = $rows['o_tax_amt'];
								  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
								  $resulotax->execute();
								  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
								  $otaxrate=$rowotax['otaxrate'];}
					    ?>
						
        <tr>
          <td colspan="6"><?php

				echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
        </tr>
        <tr>
          <td align="center"><?php echo rtrim($qty,'.0');?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo rtrim($sales_tax,'.0');?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
		<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <?php 
		if ( $tax_tot!=0) { ?>
		<tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="6">Gst Included  </td>
        </tr>
		<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono' GROUP By sales_tax");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $sales_taxg=$rows['sales_tax'];
			  $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS amount FROM sales_invoice_prdct_detail where sales_tax='$sales_taxg' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $gstsum=$rowret['amount'];}
			  ?>
        <tr>
		 <td style="width:30px;"></td>
          <td  align="left" colspan="3">Sgst <?php echo $sales_taxg/2; ?>% - <?php echo $gstsum/2; ?></td>
         
          <td  align="left" colspan="3">Cgst <?php echo $sales_taxg/2; ?>% - <?php echo $gstsum/2; ?></td>
        </tr>
        <?php } } ?>
	 <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
 <?php 
    if ( $cess_total!=0) { ?>
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
	<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			 <tr>
			     <td></td>
				  <td  align="left" colspan="3"><?php echo $o_tax_typeg;?>%</td>
				   <td></td> 
				  <td  align="center" colspan="3"><?php echo $qty_total;?></td>
			 </tr>
			  <?php  } ?> 
   <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <?php } ?> 
	
	
	 <tr class="hr"><td></td><td></td><td></td><td></td><td><td></td></td></tr>
	<?php if ( $tax_tot!=0) { ?>
	 <tr>
        <td colspan="2">Gst Total  </td><td></td><td></td><td></td><td  align="center"><?php echo  $tax_tot;?></td>
      </tr>
	<?php } else { ?>
    <tr>
        <td colspan="2">Gst Total  </td><td></td><td></td><td></td><td  align="center">0</td>
		<tr>
        <?php } ?>
  <?php if ( $cess_total!=0) { ?>	
	<tr>
        <td  colspan="3">Gst Cess Total  </td><td></td><td></td><td  align="center"><?php echo  $cess_total;?></td>
      </tr>
	<?php }  else { ?>
    
    <tr>
         <td  colspan="3">Gst Cess Total  </td><td></td><td></td><td  align="center">0</td>
		  </tr>	
        <?php } ?>
		<tr>
        <td  colspan="3"> Grand Total  </td><td></td><td></td><td  align="center"><?php echo  $grand_tot;?></td>
      </tr>
	  <tr>
        <td  colspan="3">Discount  </td><td></td><td></td><td  align="center"><?php echo  $disc;?></td>
      </tr>
		 <tr>
        <td  colspan="2"> Cash Recd </td><td align="center"><?php echo  $paid_amt;?></td><td></td><td  colspan="">Change</td><td   align="center"><?php echo  $balance_amt;?></td>
	  </tr>
    <tr>
        <th colspan="3"> Net Total </th><td align="center"><?php echo $e;?></td><th></th><td   align="center"><b><?php echo  $net_tot;?></b></td>
      </tr>
      <tr>
        <?php
		$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
        $results->execute();
		for($i=0; $rows = $results->fetch(); $i++)
		{ $user_username=$rows['user_username']; $counter=$rows['counter']; } 
		?>
	  <td  colspan="6">Counter  #<?php echo $counter;?> / <?php echo $user_username;?> / <?php echo $current_time;?></td>
      </tr>
      <tr>
        <td  colspan="6">E & OE </td>
      </tr>
      <tr>
        <td  colspan="6">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="6">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } else if ( $printer_width == 'a8' || $printer_width == 'b9') { ?>
  <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="16%" >Mrp</th>
          <th rowspan="2" width="21%" >Gst%</th>
		  <th rowspan="2" width="14%" >Cess%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
	  <tr><td></td><td></td><td></td><td></td></tr>
        <?php      
                            $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
							$result->execute();
							for($e=0; $rows= $result->fetch(); $e++){
								
								$prdct_tkn = $rows['prdct_tkn'];
								$qty = $rows['qty'];
								$rate = $rows['rate'];
								$net_tot = $rows['net_tot'];
								$sales_tax = $rows['sales_tax'];
								$gst_amt = $rows['gst_amt'];
								$pr_hsn = $rows['pr_hsn'];
								$mrp = $rows['mrp'];
								$prdct_name = $rows['prdct_name'];
								$amount = $rows['amount'];
								$grand_tot = $rows['grand_tot'];
								$disc = $rows['disc'];
								$units = $rows['units'];
								$gstcess_amt = $rows['o_tax_amt'];
								  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
								  $resulotax->execute();
								  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
								  $otaxrate=$rowotax['otaxrate'];}
					    ?>
						
        <tr>
          <td colspan="6"><?php

				echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
        </tr>
        <tr>
           <td align="center"><?php echo rtrim($qty,'.0');?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo rtrim($sales_tax,'.0');?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
		<tr><td></td><td></td><td></td><td></td><td></td></tr>
        <?php 
		if ( $tax_tot!=0) { ?>
		<tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="5">Gst Included  </td>
        </tr>
		<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono' GROUP By sales_tax");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $sales_taxg=$rows['sales_tax'];
			  $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS amount FROM sales_invoice_prdct_detail where sales_tax='$sales_taxg' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $gstsum=$rowret['amount'];}
			  ?>
       <tr>
          <td  align="left" colspan="4">Sgst <?php echo $sales_taxg/2; ?>% </td><td align="center"> <?php echo $gstsum/2; ?></td>
         </tr>
		 <tr>
          <td  align="left" colspan="4">Cgst <?php echo $sales_taxg/2; ?>% </td><td  align="center"> <?php echo $gstsum/2; ?></td>
        </tr>
        <?php } } ?>
	 <tr><td></td><td></td><td></td><td></td><td></td></tr>
 <?php 
    if ( $cess_total!=0) { ?>
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
	<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			 <tr>
			     
				  <td  align="left" colspan="3"><?php echo $o_tax_typeg;?>%</td>
				   <td></td> 
				  <td  align="center" colspan="2"><?php echo $qty_total;?></td>
			 </tr>
			  <?php  } ?> 
   <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <?php } ?> 
	
	
	 <tr class="hr"><td></td><td></td><td></td><td></td><td><td></td></tr>
	<?php if ( $tax_tot!=0) { ?>
	 <tr>
        <td colspan="2">Gst Total  </td><td></td><td></td><td  align="center"><?php echo  $tax_tot;?></td>
      </tr>
	<?php } else { ?>
    <tr>
        <td colspan="2">Gst Total  </td><td></td><td></td><td  align="center">0</td>
		<tr>
        <?php } ?>
  <?php if ( $cess_total!=0) { ?>	
	<tr>
        <td  colspan="3">Gst Cess Total  </td><td></td><td  align="center"><?php echo  $cess_total;?></td>
      </tr>
	<?php }  else { ?>
    
    <tr>
         <td  colspan="2">Gst Cess Total  </td><td></td><td  align="center">0</td>
		  </tr>	
        <?php } ?>
		<tr>
        <td  colspan="3"> Grand Total  </td><td></td><td  align="center"><?php echo  $grand_tot;?></td>
      </tr>
	  <tr>
        <td  colspan="3">Discount  </td><td></td><td  align="center"><?php echo  $disc;?></td>
      </tr>
	    <tr>
        <td  colspan="3">Cash Received</td><td></td><td  align="center"><?php echo  $paid_amt;?></td>
      </tr>
	    <tr>
        <td  colspan="3">Change  </td><td></td><td  align="center"><?php echo  $balance_amt;?></td>
      </tr>
    <tr>
        <th colspan="2"> Net Total </th><td align="center"><?php echo $e;?></td><td></td><td   align="center"><b><?php echo  $net_tot;?></b></td>
      </tr>
      <tr>
        <?php
		$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
        $results->execute();
		for($i=0; $rows = $results->fetch(); $i++)
		{ $user_username=$rows['user_username']; $counter=$rows['counter']; } 
		?>
	  <td  colspan="5">Counter  #<?php echo $counter;?> / <?php echo $user_username;?> / <?php echo $current_time;?></td>
      </tr>
      <tr>
        <td  colspan="5">E & OE </td>
      </tr>
      <tr>
        <td  colspan="5">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="5">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } else { ?>
  <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="16%" >Mrp</th>
		  <th rowspan="2" width="14%" >Tax%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
	  <tr><td></td><td></td><td></td><td></td></tr>
        <?php      
                            $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
							$result->execute();
							for($e=0; $rows= $result->fetch(); $e++){
								
								$prdct_tkn = $rows['prdct_tkn'];
								$qty = $rows['qty'];
								$rate = $rows['rate'];
								$net_tot = $rows['net_tot'];
								$sales_tax = $rows['sales_tax'];
								$gst_amt = $rows['gst_amt'];
								$pr_hsn = $rows['pr_hsn'];
								$mrp = $rows['mrp'];
								$prdct_name = $rows['prdct_name'];
								$amount = $rows['amount'];
								$grand_tot = $rows['grand_tot'];
								$disc = $rows['disc'];
								$units = $rows['units'];
								$gstcess_amt = $rows['o_tax_amt'];
								  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
								  $resulotax->execute();
								  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
								  $otaxrate=$rowotax['otaxrate'];}
					    ?>
						
        <tr>
          <td colspan="6"><?php

				echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
        </tr>
        <tr>
           <td align="center"><?php echo rtrim($qty, '.0');?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax + $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
		<tr><td></td><td></td><td></td><td></td></tr>
        <?php 
		if ( $tax_tot!=0) { ?>
		<tr class="hr"><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="6">Gst Included  </td>
        </tr>
		<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono' GROUP By sales_tax");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $sales_taxg=$rows['sales_tax'];
			  $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS amount FROM sales_invoice_prdct_detail where sales_tax='$sales_taxg' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $gstsum=$rowret['amount'];}
			  ?>
        <tr>
          <td  align="left" colspan="3">Sgst <?php echo $sales_taxg/2; ?>% </td><td align="center"> <?php echo $gstsum/2; ?></td>
         </tr>
		 <tr>
          <td  align="left" colspan="3">Cgst <?php echo $sales_taxg/2; ?>% </td><td  align="center"> <?php echo $gstsum/2; ?></td>
        </tr>
        <?php } } ?>
	 <tr><td></td><td></td><td></td><td></td></tr>
 <?php 
    if ( $cess_total!=0) { ?>
    <tr class="hr"><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
	<?php
	          $result= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			 <tr>
			     
				  <td  align="left" colspan="3"><?php echo $o_tax_typeg;?>%</td>
				  
				  <td  align="center" ><?php echo $qty_total;?></td>
			 </tr>
			  <?php  } ?> 
   <tr><td></td><td></td><td></td><td></td><td></td></tr>
    <?php } ?> 
	
	
	 <tr class="hr"><td></td><td></td><td></td><td></td></tr>
	<?php if ( $tax_tot!=0) { ?>
	 <tr>
        <td colspan="3">Gst Total  </td><td  align="center"><?php echo  $tax_tot;?></td>
      </tr>
	<?php } else { ?>
    <tr>
        <td colspan="3">Gst Total  </td><td  align="center">0</td>
		<tr>
        <?php } ?>
  <?php if ( $cess_total!=0) { ?>	
	<tr>
        <td  colspan="3">Gst Cess Total  </td><td  align="center"><?php echo  $cess_total;?></td>
      </tr>
	<?php }  else { ?>
    
    <tr>
         <td  colspan="3">Gst Cess Total  </td><td  align="center">0</td>
		  </tr>	
        <?php } ?>
    <tr>
	<tr>
        <td  colspan="3"> Grand Total  </td><<td  align="center"><?php echo  $grand_tot;?></td>
      </tr>
	  <tr>
        <td  colspan="3">Discount  </td><<td  align="center"><?php echo  $disc;?></td>
      </tr>
	    <tr>
        <td  colspan="3">Cash Received</td><td  align="center"><?php echo  $paid_amt;?></td>
      </tr>
	    <tr>
        <td  colspan="3">Change  </td><td  align="center"><?php echo  $balance_amt;?></td>
      </tr>
	    <th colspan="3"> Total Items </th><td align="center"><?php echo $e;?></td>
        
      </tr>
	  <tr>
        <th colspan="3"> Net Total </th><td   align="center"><b><?php echo  $net_tot;?></b></td>
      </tr>
      <tr>
        <?php
		$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
        $results->execute();
		for($i=0; $rows = $results->fetch(); $i++)
		{ $user_username=$rows['user_username']; $counter=$rows['counter']; } 
		?>
	  <td  colspan="4">Co  #<?php echo $counter;?> / <?php echo $user_username;?> / <?php echo $current_time;?></td>
      </tr>
      <tr>
        <td  colspan="4">E & OE </td>
      </tr>
      <tr>
        <td  colspan="4">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="4">Thank you for shopping at (<?php echo $rows_user_company['c_company_name']; ?>)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } ?>
  </div>
</div>
<script>window.print();</script>
</body>
</html>