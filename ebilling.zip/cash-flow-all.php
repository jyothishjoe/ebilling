<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include("datetime_creation/datetime_creation.php"); 
$userid = $_SESSION['SESS_USERID_AS'];
if(isset ($_GET['startdate'],$_GET['enddate'])){

$startdates = date_create($_GET['startdate']);
$startdate = date_format($startdates,'Y-m-d');
$enddates = date_create($_GET['enddate']);
$enddate = date_format($enddates,'Y-m-d');
}else{
$startdate = $today;
$enddate = $today;
}
?>
<style>
.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}
</style>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/auto/all.css" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
	<script src="assets/jquery/dist/jquery.js"></script>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
    <link href="assets/plugins/icheck/skins/all.css" rel="stylesheet">
    <link href="css/pages/form-icheck.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<div  style="width:2000px !importent;  padding:20px;">
	<div class="text-right" style="margin-bottom:20px;">
	<i class="fa fa-close" id="close_fbx"  style="font-size:15px;color:red"></i> 
  </div>
	<h3 class="text-center">Cash Flow </h3><br> 
								<form class="" name="addbilldetails" method="get" action="cash-flow-all.php" onsubmit="return false; enctype="multipart/form-data">
								
									<div class="form-row" style="margin-top: 12px;">
									
										<?php include('include/datemask.php');?>
										
										<div class="col-md-3 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 14px;" value="Submit"/>
											<?php if(isset ($_GET['startdate'], $_GET['enddate'])){ ?>
											<a href="cash-flow-all.php" class="btn btn-sm btn-danger" style="margin-top:30px; font-size: 14px;">Clear&nbsp;</a>
												<?php } ?>
										</div>
									</div>
									
								</form>
								 <div class="table-responsive m-t-40">
									 <table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%;">
										<thead>
											<tr>
												<th>Sl.No</th>
												<th>Purcticulars</th>
												<th>Inflow</th>
												<th>Outflow</th>
												<th>Net FLow</th>
											</tr>
										</thead>
										<tbody>
											<?php 
											 $result_sales_gp = $db->prepare("SELECT * FROM transaction  WHERE trn_date >= '$startdate' AND trn_date <= '$enddate' GROUP By trn_date");  
											$result_sales_gp ->execute(); 
											for ($i=0; $rows_sales_gp  = $result_sales_gp ->fetch(); $i++){
											$dat=$rows_sales_gp['trn_date']; ?>
											<tr class='tr_input'>
												<td><?= $i+1; ?></td>
												<td><?php echo $dat; ?></td>
												<?php 
												   $resultret = $db->prepare("SELECT  COALESCE(SUM(credit_amt), 0) AS amount FROM transaction where debit_amt='0' and trn_date='$dat'");
													$resultret->execute();
													for($i=0; $rowret = $resultret->fetch(); $i++){  
													$sumcr=$rowret['amount'];}
													
													$resultret = $db->prepare("SELECT  COALESCE(SUM(disc), 0) AS disc FROM cash_invoice where date_='$dat'");
													$resultret->execute();
													for($i=0; $rowrets = $resultret->fetch(); $i++){  
													$disc=$rowrets['disc'];}
												    ?>
												<td><?php echo $sumcr - $disc;?></td>
												<?php 
												   $resultret = $db->prepare("SELECT  COALESCE(SUM(debit_amt), 0) AS amounts FROM transaction where credit_amt='0' and trn_date='$dat'");
													$resultret->execute();
													for($i=0; $rowret = $resultret->fetch(); $i++){  
													$sumdr=$rowret['amounts'];}
												    ?>
												<td><?php echo $sumdr;?></td>
												<td><?php echo $sumcr - $sumdr; ?></td>
										    </tr>
											<?php	} ?>
										</tbody>
									</table>
								</div>
								 </div>
			<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
			<script src="js/mask.init.js"></script>
			<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
			<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
			<script src="js/perfect-scrollbar.jquery.min.js"></script>
			<script src="js/waves.js"></script>
			<script src="js/sidebarmenu.js"></script>
			<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
			<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
			<script src="assets/bootstrap/dist/js/bootstrap.min.js"></script>
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
			<script src="js/custom.min.js"></script>
			<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
			<script src="js/toastr.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
			<?php include("assets/custom/custom.php");?>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
	<?php include("assets/custom/custom.php");?>
	