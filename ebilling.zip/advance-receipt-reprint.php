
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php"); include('db-connect/db.php');
$adv_recepit_no = $_GET[ 'bill' ];
?>
<html>
<title></title>
<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style>
table {
	border-collapse: collapse;
}
table td {
	height: 15px;
}
 @media print {
.btn {
	display: none;
}
}
.hr {
	border: none;
	border-top: 1px dashed black;
	margin-top:10px;
}
</style>
</head>
<body>
<?php
 $result =$db ->prepare("SELECT * FROM advanced_receipt where adv_receipt_no='$adv_recepit_no'");
	
$result->execute();	$row_count =  $result->rowcount();
for($i=0; $rows = $result->fetch(); $i++) {$cus_name=$rows["cus_name"]; $adv_amt=$rows["adv_amt"];  $counter=$rows["counter"]; $addby=$rows["addby"];  $date_=$rows["date_"];  $currenttime=$rows["currenttime"];}
$bdate= date_create($date_);
$billdate=date_format($bdate,"d-m-Y");
?>
<div class="row">
  <div class="col-md-12" style="padding:0px 50px;">
    <div class="col-md-12" style="margin-top: 18px;"><a href="cashcounter-home.php" class="btn btn-sm btn-danger" style="font-size: 15px; float: left;">Back</a> </div>
    <table style="text-align:center;" width="100%" border="0">
      <tr>
        <th> <h3>Supermarket</h3>
        </th>
      </tr>
      <tr>
        <td>Palakkad</td>
      </tr>
      <tr>
        <td>
      <tr>
        <td>Ph: 8137010256, Mob: 9865320123</td>
      </tr>
      </td>
      
      </tr>
      
      <tr>
        <th>Advance Invoice</th>
      </tr>
    </table>
    <table style="text-align:left;float:left;" width="100%" border="0">
	<tr>
	<td><b>Receipt No: </b><?php echo $adv_recepit_no; ?></td>
	</tr>
	<tr>
	<td><b>Date And Time: </b><?php echo $billdate; ?> <?php echo $currenttime; ?></td>
	</tr>
      <tr>
       <div class="col-md-12" style="padding-bottom: 18px;"></div>
        <td><b>Customer Name: </b> <?php echo ucfirst($cus_name);?></td>
	  </tr>
	   <tr>
        <td><b>Amount: </b> <?php echo $adv_amt;?> ( <?php 
		   $number =   $adv_amt;
		   $no = round($number);
		   $point = round($number - $no, 2) * 100;
		   $hundred = null;
		   $digits_1 = strlen($no);
		   $i = 0;
		   $str = array();
		   $words = array('0' => '', '1' => 'One', '2' => 'Two',
			'3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
			'7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
			'10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
			'13' => 'Thirteen', '14' => 'Fourteen',
			'15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
			'18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
			'30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
			'60' => 'Sixty', '70' => 'Seventy',
			'80' => 'Eighty', '90' => 'Ninety');
		   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
		   while ($i < $digits_1) {
			 $divider = ($i == 2) ? 10 : 100;
			 $number = floor($no % $divider);
			 $no = floor($no / $divider);
			 $i += ($divider == 10) ? 1 : 2;
			 if ($number) {
				$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
				$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
				$str [] = ($number < 21) ? $words[$number] .
					" " . $digits[$counter] . $plural . " " . $hundred
					:
					$words[floor($number / 10) * 10]
					. " " . $words[$number % 10] . " "
					. $digits[$counter] . $plural . " " . $hundred;
			 } else $str[] = null;
		  }
		  $str = array_reverse($str);
		  $result = implode('', $str);
		  $points = ($point) ?
			"." . $words[$point / 10] . " " . 
				  $words[$point = $point % 10] : ''; ?>
          <strong><?php echo $result . "Rupees  " . $points . "only"; ?></strong> )</td>
	  </tr>
	   <tr><td></td></tr>
	   <tr class="hr"><td></td><td></td></tr>
	  <tr>
	  <?php
		$results = $db->prepare("select * from  admin_user where user_tkn = '$addby'");
        $results->execute();
		for($i=0; $rows = $results->fetch(); $i++)
		{ $user_username=$rows['user_username']; $counter=$rows['counter']; } 
		?>
	  <td>Counter: #<?php echo $counter;?> / <?php echo $user_username;?></td>
	  <td class="text-right">Signature</td>
	  </tr>
	  <tr><td></td></tr>
	   <tr>
	  <td colspan="2"><b>Note: </b>The Amount Paid As Token Advance Will Not Be Refundable.</td>
	  </tr>
    </table>
  </div>
</div>
<script>window.print();</script>
</body>
</html>