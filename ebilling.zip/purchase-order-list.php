<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
if(isset ($_GET['startdate'] )){
$startdates = date_create($_GET['startdate']);
$startdates = date_format($startdates,'Y-m-d');

}else{
$startdates = date_create($today);
$startdates = date_format($startdates,'Y-m-d');	
	
}
$result_sum = $db->prepare("SELECT SUM(t_total) AS total FROM purchaseorder_invoice WHERE company_tkn='$user_company'");
$result_sum->execute();
$rows_sum = $result_sum->fetch(); 
$total = $rows_sum['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Purchase Order List</title>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link href="assets/auto/all.css" >
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	
</head>

<body class="fix-header card-no-border fix-sidebar">
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Admin Pro</p>
        </div>
    </div>
    <div id="main-wrapper">
       <?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                     <h3 class="text-themecolor float-left">Purchase Order</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index1.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="purchase-home.php">Purchase</a></li>
                            <li class="breadcrumb-item active">Purchase</li>
                        </ol>
                    </div>
                    <div class="col-md-12">
					</div>
                    <div>
                        
                   </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                               <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datelist.php'); ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 15px;" value="Submit"/>
										</div>
									</div>
								</form>
                                <div class="table-responsive m-t-40">
                                <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl.No</th>
                                                <th>PO#</th>
                                                <th>Date</th>
                                                <th>Supplier Name</th>
                                                <th>Location</th>
                                                <th>GSTIN/UID</th>
                                                <th>Total</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
											$result_order = $db->prepare("SELECT * FROM purchaseorder_invoice a LEFT JOIN supplier b ON a.supplier_id=b.supplier_token WHERE a.date >= '$startdates' AND a.date <= '$startdates' AND a.company_tkn='$user_company' AND  b.company_tkn='$user_company'");
											$result_order ->execute(); 
											$sl = 0;
											for ($i=0; $rows_order=$result_order->fetch(); $i++){
											?>
                                            <tr>
                                                <td><?php echo ++$sl; ?></td>
                                                <td><?php echo $rows_order['po_no']; ?></td>
                                                <td><?php echo $rows_order['date']; ?></td>
                                                <td><?php echo $rows_order['v_name']; ?></td>
                                                <td><?php echo $rows_order['city']; ?></td>
                                                <td><?php echo $rows_order['gstin']; ?></td>
                                                <td><?php echo $rows_order['g_total']; ?></td>
                                                <td><a class="btn btn-sm btn-info" href="purch-order-print.php?bill=<?php echo $rows_order['po_no']; ?>"><i class="fas fa-print">
                                                </i></a></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a></li>
                                <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/perfect-scrollbar.jquery.min.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="assets/plugins/datatables/datatables.min.js"></script>
    <script src="assets/table/js/dataTables.buttons.min.js"></script>
    <script src="assets/table/js/buttons.flash.min.js"></script>
    <script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
    <script>
		$('#example23').DataTable({
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

</body>

</html>