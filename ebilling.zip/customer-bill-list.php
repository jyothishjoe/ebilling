<?php
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( 'db-connect/db.php' );
include("datetime_creation/datetime_creation.php");
$customer = $_GET['cust'];
if(isset ($_GET['startdate'])){
	$startdate = $_GET['startdate'];	
} else { $startdate = $today; }
?>

<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link href="assets/auto/all.css" rel="stylesheet" >
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>


<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>

        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
                <!--<div class="form-row" style="margin-top: 12px;">
                  <?php include("include/datelist.php");?>
                  <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
                    <input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Show"/>
                  </div>
                </div>-->
              </form>
              <div class="table-responsive m-t-40">
                <?php 
				 $date = date_create($startdate);
				 $startdate = date_format($date,'Y-m-d');
				$result_sales = $db->prepare("SELECT SUM(net_tot) AS net_tot FROM sales_invoice  where sales_invodate = '$startdate' AND company_tkn='$user_company'");
				$result_sales->execute();
				$rows_sales = $result_sales->fetch(); 
				$sum = $rows_sales['net_tot'];
				?>
                <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Sales Invoice No</th>
                      <th>Sales Invoice Date</th>
                      <th>Customer Name</th>
                      <th>Sales Order Date</th>
                      <th>Sales Order No</th>
                      <th>Amount</th>
                      <th>Discount</th>
                      <!--<th>GST Amount</th>-->
                      <th>Net Total</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
					$result_sales = $db->prepare("SELECT * FROM sales_invoice a LEFT JOIN customer b ON b.cus_tkn=a.cus_tkn    WHERE  a.company_tkn='$user_company' AND b.company_tkn='$user_company' AND b.acco_tkn='$customer' GROUP  BY a.sbill_no");
					$result_sales ->execute();
					for ($i=0; $rows_sales  = $result_sales ->fetch(); $i++){
					$order_no = $rows_sales['order_no'];
					$norm_date = $rows_sales['sales_invodate'];
					$date = date_create($norm_date);
					$condate = date_format($date,'d-m-Y');
					$result = $db->prepare("select * from  sales_order_invoice where order_invno='$order_no' AND company_tkn='$user_company'");
					$result->execute();
					for ($e=0; $rows  = $result ->fetch(); $e++){
					$order_nos = $rows['bill_no'];}
					?>
                    <tr>
                      <td><?php echo $i+1; ?></td>
                      <td><?php echo strtoupper($rows_sales['sbill_no']); ?></td>
                      <td><?php echo $condate; ?><br>
                      <?php echo $rows_sales['sales_invotime']; ?></td>
                      <td><?php if($rows_sales['cus_name'] != ''){echo ucfirst($rows_sales['cus_name']);}else{echo 'Cash';} ?></td>
                    <?php  if($rows_sales['order_date'] != ''){ ?><td><?php if($rows_sales['order_date'] !=0) {  echo $rows_sales['order_date']; } else{ } ?></td><?php } ?>

                     
                      <?php  if($order_no != ''){ ?><td> <?php if($order_no !=0) {  echo strtoupper($order_nos); } else { } ?></td><?php } ?>
                      <td><?php echo $rows_sales['grand_tot']; ?></td>
                      <td><?php echo $rows_sales['disc']; ?></td>
                      <!--<td><?php echo $rows_sales['tax_tot']; ?></td>-->
                      <td><?php echo $rows_sales['net_tot']; ?></td>
                      <td><a class="btn btn-sm btn-info" href="sales-bill-reprint.php?bill=<?php echo $rows_sales['sbill_no']; ?>"><i class="fas fa-print"></i></a></td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
   
   
<script src="assets/plugins/jquery/jquery.min.js"></script> 
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<script src="assets/plugins/bootstrap/js/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/datatables/datatables.min.js"></script> 
<script src="assets/table/js/dataTables.buttons.min.js"></script> 
<script src="assets/table/js/buttons.flash.min.js"></script> 
<script src="assets/table/js/jszip.min.js"></script> 
<script src="assets/table/js/pdfmake.min.js"></script> 
<script src="assets/table/js/vfs_fonts.js"></script> 
<script src="assets/table/js/buttons.html5.min.js"></script> 
<script src="assets/table/js/buttons.print.min.js"></script> 
<?php include ('include/disable_fn.php'); ?>
	<script>
	$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
	$( window ).keydown( function ( event ) {
				if ( event.keyCode == 27 ) {

					event.preventDefault();		
 parent.jQuery.fancybox.close(); 
					
				}
	});
							
</script>
<script>
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		$( '#tbl' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		
	</script>

<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
