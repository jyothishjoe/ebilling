<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];

$edit = $_GET[ 'id' ];
$result_account = $db->prepare( "SELECT * FROM account_group WHERE id='$edit' " );
$result_account->execute();
$rows_account = $result_account->fetch();
?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>
<div id="custom-content" class="col-md-6 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden; background-color: #f2f2f2;">
	<h3 class="text-center">Account Group</h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Account Group</label>
				<input type="text" class="form-control" id="accname" name="accname" value="<?php echo $rows_account['acc_name']; ?>" placeholder="Account Group">
				<input type="hidden" class="form-control" id="user" name="user" value="<?php echo $userid; ?>" readonly>
				<input type="hidden" class="form-control" id="edit" name="edit" value="<?php echo $edit; ?>" readonly>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Nature Of Group</label>
				<input type="text" class="form-control" id="acc" name="acc" value="<?php echo $rows_account['account']; ?>" placeholder="Nature Of Group">
			</div>
		</div>
		<div class="col-md-12" style="margin-bottom: 18px;">
			<div class="text-right">
				<a href="javascript: save_customer()" class="btn btn-sm  btn-info">Update</a>
				<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close">CANCEL</button>
			</div>
		</div>
	</form>

	<script>
		$( '#close_fbx' ).on( 'click', function () {
			parent.jQuery.magnificPopup.close();
		} );

		function save_customer() {
			var accname = $( "#accname" ).val();
			var acc = $( "#acc" ).val();
			var descr = $( "#descr" ).val();
			var edit = $( "#edit" ).val();

			if ($( "#accname" ).val() == "" || $( "#acc" ).val() == "") {
				$.toast({
					heading: 'Fill all required fields.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 4500});
			}else{
				$.ajax({
					type: 'POST',
					url: "accounts/update_acc_group.php",
					data: "accname=" + accname + "&acc=" + acc + "&edit=" + edit ,
					success: function (r) {
						$("#respond").html(r);
					}
				});
				parent.jQuery.magnificPopup.close();
				$.toast({heading: 'Updated Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 4500});
				setTimeout(location.reload.bind(location), 600);
				return false;
			}
		}
	</script>