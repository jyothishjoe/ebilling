<?php include ('include/auth.php'); 
$userid = $_SESSION['SESS_USERID_AS'];
include( 'db-connect/db.php' );
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type where user_tkn = '$user_type_tkn'");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{ $add_customer=$row_user['add_customer']; $update_customer=$row_user['update_customer']; $sales_order=$row_user['sales_order']; $sales_invo=$row_user['sales_invo']; $pos_invo=$row_user['pos_invo']; $estimate_invo=$row_user['estimate_invo']; $sales_ret_invo=$row_user['sales_ret_invo']; $bill_cancel=$row_user['bill_cancel'];  $sales_order_rept=$row_user['sales_order_rept']; $sales_rept=$row_user['sales_rept']; $sales_ret_rept=$row_user['sales_ret_rept']; } ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
	<title>Sales Home</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Loading..</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav_home.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h4 class="text-themecolor">Sales </h4>
        </div>
        <div class="col-md-7 align-self-center" style="z-index:9 !important;">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a oncontextmenu="return false;" href="index1.php">Home</a> </li>
            <li class="breadcrumb-item active">Sales</li>
          </ol>
        </div>
        <div class="">
          
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <form class="needs-validation" novalidate>
                <div class="form-row">
				<?php if($add_customer==0) { ?>
                <div class="col-lg-3" style="display: none;">
                  <div class="card bg- text-white" style="background-color: #5795C4">
                    <div class="card-body">
                      <div class="d-flex">
                        <div class="stats">
                          <h4 class="text-white">Customer <label style="font-size: 13px;"> ( F1 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="customer-add.php" id="customer" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Customer</a> <a oncontextmenu="return false;" href="customer-all.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">List</a> </div>
                        <div class="stats-icon text-right ml-auto"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($sales_invo==0) { ?>
                <div class="col-lg-3">
                  <div class="card  text-white" style="background-color: #e07281">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Sales Bill <label style="font-size: 13px;"> ( F2 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="sales-bill.php"    class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Sales Bill</a> <a oncontextmenu="return false;" href="sales-bill-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a> </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($pos_invo==0) { ?>
               <!-- <div class="col-lg-3">
                  <div class="card  text-white" style="background-color: #0A4D80">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">POS <label style="font-size: 13px;"> ( F3 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="salesof-point.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">POS</a> <a oncontextmenu="return false;" href="pos-list.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a> </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>-->
				<?php } if($sales_order==0) { ?>
                <div class="col-lg-3" >
                  <div class="card bg- text-white" style="background-color: #873839" >
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Sales Order <label style="font-size: 13px;"> ( F4 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="sales-order.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Sales Order</a> <a oncontextmenu="return false;" href="sales-order-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a> </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($estimate_invo==0) { ?>
                
                <div class="col-lg-3"  >
                  <div class="card bg-success text-white">
                    <div class="card-body">
                      <div class="d-flex">
                        <div class="stats">
                          <h4 class="text-white">Estimate <label style="font-size: 13px;"> ( F5 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="estimate.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Estimate</a> <a oncontextmenu="return false;" href="estimate-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a> </div>
                        <div class="stats-icon text-right ml-auto"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($bill_cancel==0) {  ?>
              
              		<div class="col-lg-3">
						<div class="card bg text-white"  style="background-color: #7A7A7A" >
							<div class="card-body">
								<div class="d-flex">
									<div class="stats">
									<h4 class="text-white">Sales Bill Cancellation <label style="font-size: 13px;"> ( F8 )</label></h4>
									<h6 class="text-white"></h6>
									<a oncontextmenu="return false;" href="sales-bill-cancellation.php" id='cancel-bill'  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 simple-ajax-popup-align-top"> Sales Bill Cancelation</a>
									</div>
								  <div class="stats-icon text-right ml-auto"></div>
							   </div>
							</div>
						</div>
					</div>
				<?php } if($sales_ret_invo==0) { ?>
                <div class="col-lg-4"  >
                  <div class="card bg-primary text-white" >
                    <div class="card-body">
                      <div class="d-flex">
                        <div class="stats">
                          <h4 class="text-white">Sales Return <label style="font-size: 13px;"> ( F6 )</label></h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="sales-return-bill.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Sales Return</a> <a style="display: none;" oncontextmenu="return false;" href="sales-return-barcode.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">With Barcode</a> <a oncontextmenu="return false;" href="sales-return-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a> </div>
                        <div class="stats-icon text-right ml-auto"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($sales_order_rept==0 || $sales_rept==0 || $sales_ret_rept==0 ) { ?>
                <div class="col-lg-5"  >
                  <div class="card bg text-white" style="background-color: #6C3B73" >
                    <div class="card-body">
                      <div class="d-flex">
                        <div class="stats">
                          <h4 class="text-white">Reports</h4>
                          <h6 class="text-white"></h6>
						  <?php  if($sales_order_rept==0) { ?>
                          <a oncontextmenu="return false;" href="sales-order-report.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Sales Order</a> 
						  <?php } if($sales_rept==0) { ?>
						  <a oncontextmenu="return false;" href="sales-bill-report.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Sales</a>
						  <?php } if($sales_ret_rept==0) { ?>
						  <a oncontextmenu="return false;" href="sales_return_report_new.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Sales Return</a>
              <?php } ?>
            
						  </div>
                        <div class="stats-icon text-right ml-auto"></div>
                      </div>
                    </div>
                  </div>
                </div>
				
        <?php } ?>
       
					 <!--<div class="col-lg-3">
						<div class="card bg text-white"  style="background-color: #c2a744" >
							<div class="card-body">
								<div class="d-flex">
									<div class="stats">
									<h4 class="text-white">Season</h4>
									<h6 class="text-white"></h6>
									<a href="create-season.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax"> Create Season</a>
									<a href="season-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">List</a>
				</div>
					<div class="stats-icon text-right ml-auto"></div>
					</div>
					</div>
					</div>
				</div>-->
				</div>
              </form>
            </div>
            <div class="col-md-12">
              <div class="card" style="text-align: center;"> </div>
            </div>
          </div>
        </div>
      </div>
    
      <div class="right-sidebar">
        <div class="slimscrollright">
          <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
          <div class="r-panel-body">
            <ul id="themecolors" class="m-t-20">
              <li><b>With Light sidebar</b> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
              <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
            </ul>
            
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>
	<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
				
			
$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
	

	<script>
	
//Short Cut Keys 
		$( window ) . keydown( function ( event ) {
			
			if ( event . keyCode == 112 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#customer').click();
			}if ( event . keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="sales-bill.php";
			}if ( event . keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="salesof-point.php";
			}if ( event . keyCode == 115 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="sales-order.php";
			}if ( event . keyCode == 116 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="estimate.php";
			}if ( event . keyCode == 117 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="sales-return-bill.php";
			}if ( event . keyCode == 118 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="sales-return-barcode.php";
			}if ( event . keyCode == 119 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( "#cancel-bill" ).click();
			}
		});		
</script>
<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
</script>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<?php include ('include/disable_fn.php'); ?>
</body>
</html>