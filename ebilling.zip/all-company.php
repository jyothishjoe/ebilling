<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Company List</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
</head>
<body class="fix-header card-no-border fix-sidebar">
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Admin Pro</p>
        </div>
    </div>
    <div id="main-wrapper">
       <?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor float-left">All Companies</h3>
                    </div>
                    
                    <div class="col-md-12">
					</div>
                    <div>
                        
                   </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive m-t-40">
                                   <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sl.No</th>
                                                <th>Company ID</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>Phone</th>
                                                <th>Financial Year</th>
                                                <th>Date Added</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
											$result_company = $db->prepare("SELECT * FROM company ORDER  BY company_id ASC");
											$result_company ->execute(); 
											$sl = 0;
											for ($i=0; $rows_company  = $result_company ->fetch(); $i++){
											?>
                                            <tr>
                                                <td><?php echo ++$sl; ?></td>
                                                <td><?php echo $rows_company['company_id']; ?></td>
                                                <td><?php echo $rows_company['c_company_name']; ?></td>
                                                <td><?php echo $rows_company['c_shopaddress']; ?></td>
                                                <td><?php echo $rows_company['c_mobile']; ?></td>
                                                <td><?php echo $rows_company['financial_year_from']; ?></td>
                                                <td><?php echo $rows_company['c_adddate']; ?></td>
												
                                                <td>
													<div class="btn-group" role="group" aria-label="Basic example">
													<a class="btn btn-sm btn-info simple-ajax-popup-align-top" href="edit-company.php?edit=<?php echo $rows_company['c_token']; ?>"><i class="fas fa-pencil-alt"></i></a><a class="btn btn-sm btn-warning simple-ajax-popup-align-top" href="delete_company.php?delete=<?php echo $rows_company['c_token']; ?>"><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
													</div>
												</td>
												
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span></div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a></li>
                                <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
	
	<?php if(isset($_COOKIE['ED']) && $_COOKIE['ED'] == true){ ?> <script> $(document).ready(function(){
		
		$.toast({
			heading: 'Updated Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	});</script>
	<?php } ?>
   <script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});
         	
		</script>
    <script src="assets/plugins/popper/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="js/perfect-scrollbar.jquery.min.js"></script>
		<script src="js/waves.js"></script>
		<script src="js/sidebarmenu.js"></script>
		<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
		<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
		<script src="js/custom.min.js"></script>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
		<script src="js/mask.init.js"></script>
		<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
		<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
		<?php include ('include/disable_fn.php'); ?>
    <script>
		$('#example23').DataTable({
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		});
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

</body>

</html>