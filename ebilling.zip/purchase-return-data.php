<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
//error_reporting(0);
$bill = $_POST[ 'bill' ];
$vendor = $_POST[ 'vendor' ];
$billdate = date_create($_POST['billdate']);
$billdate = date_format($billdate,'Y-m-d');
$result1 = $db->prepare("SELECT * FROM purchase_invoice a LEFT JOIN purchase_productdetails b ON a.purch_token=b.purch_token   WHERE a.inv = '$bill' AND a.bill_date = '$billdate'");
$result1->execute();
$row_count1 = $result1->rowcount();
if($row_count1 > 0){
?>

<div class="col-md-12">
	<h4>Product Details </h4>
</div>
<div class="col-sm-12 col-xs-12 " style="overflow-x: auto; ">
	<table class="table table-bordered" style="min-width: 1100px;">
		<thead>
			<tr>
			<th style="width: 58px;">Sl No</th>
			<th style="width: 100px;">Code</th>
			<th style="width: 135px;">Item Name</th>
			<th style="width: 135px;">Location</th>
			<th style="width: 75px;">Batch</th>
			<th style="width: 55px;">Expairy</th>
			<th style="width: 75px;">HSN</th>
			<th style="width: 100px;">Unit</th>
			<th style="width: 85px;">Rate</th>
			<th style="width: 70px;">GST%</th>
			<th style="width: 75px;">Qty</th>
			<th style="width: 75px;">Ret Qty</th>
			<th style="width: 70px;">Disc%</th>
			<!--<th>Gross</th>
			<th>GST</th>
			<th>Other Tax</th>-->
			<th style="width: 140px;">Total</th>
			</tr>
		</thead>
		<tbody id="purchase">
			<?php
			$k = 0;
			$result = $db->prepare("SELECT * FROM purchase_invoice a LEFT JOIN purchase_productdetails b ON a.purch_token=b.purch_token   WHERE a.inv = '$bill' AND a.bill_date = '$billdate'");
			$sl = 0;
			$result->execute();
			$row_count = $result->rowcount();
			for ($i = 0; $rows_purch = $result->fetch(); $i++){
			$product_code = $rows_purch['p_id'];	
			$gst=$rows_purch['tax'];
			$discount_total=$rows_purch['discount_total'];
			$total_price=$rows_purch['total_price'];
			$grand_total=$rows_purch['grand_total'];
				
			$result_ledger = $db->prepare("SELECT * FROM account_ledger a LEFT JOIN transaction b ON a.ledger_token=b.ledger_token WHERE b.voucher_no = '$bill' AND b.trn_date = '$billdate' AND b.ledger_name='purchase' ");
			$result_ledger->execute();
			$rows_ledger = $result_ledger->fetch();
			$taxable_token=$rows_ledger['ledger_token'];
			$taxable_ledger=$rows_ledger['ledger_name'];
				
			
			//Other Tax Details Fetch
			
			?>
			<tr class='tr_input'>
				<td><input type='text' tabindex="-1" style="width: 40px;" class="form-control code" name="serial" id='serial_1' value="<?= ++$k; ?>" placeholder='Product Code'>
					
					<input type='hidden' class="form-control stock_tkn" name="stock_tkn[]" id='stock_tkn_<?php echo $i+1; ?>'  value="<?php echo $rows_purch['stock_tkn']; ?>">
				</td>
				<td><input type='text' tabindex="-1" class="form-control code" name="code[]" id='code_<?php echo $i+1; ?>' value="<?php echo $rows_purch['p_id']; ?>" placeholder='Product Code' readonly>
				</td>
				<td><input type='text' tabindex="-1" class="form-control name" name="name[]" id='name_<?php echo $i+1; ?>' value="<?php echo $rows_purch['pr_name']; ?>" placeholder='Product Name' readonly>
				</td>
				<td>
					<input type='text' class="form-control location_name" id="location_name_<?php echo $i+1; ?>" name="location_name[]" value="<?php echo $rows_purch['location_name']; ?>" >
					<input type='hidden' class="form-control location_tkn" id="location_tkn_<?php echo $i+1; ?>" name="location_tkn[]"  value="<?php echo $rows_purch['location_tkn']; ?>"></td>
				<td>
					<input type='text' class="form-control batch" name="batch[]" id='batch_<?php echo $i+1; ?>' placeholder='Batch' value="<?php echo $rows_purch['batch_no']; ?>"></td>
				<td>
					<input type='date' class="form-control expairy" name="expairy[]" id='expairy_<?php echo $i+1; ?>' value="<?php echo $rows_purch['expairy_date']; ?>"></td>
				<td><input type='text' tabindex="-1" class="form-control hsn" name="hsn[]" id='hsn_<?php echo $i+1; ?>' value="<?php echo $rows_purch['hsn']; ?>" placeholder='HSN' readonly>
				</td>
				<td><input type='text' tabindex="-1" class="form-control unit" name="unit[]" id='unit_<?php echo $i+1; ?>' value="<?php echo $rows_purch['unit']; ?>" placeholder='Unit' readonly>
				</td>
				<td><input type='text' tabindex="-1" class="form-control purchprice" name="purchprice[]" value="<?php echo $rows_purch['purch_price']; ?>" id='purchprice_<?php echo $i+1; ?>' placeholder='Purchase Price' readonly>
				</td>
				<td><input type='text' tabindex="-1" class="form-control gstin" name="gstin[]" id='gstin_<?php echo $i+1; ?>' value="<?php echo $rows_purch['tax']; ?>" placeholder='GST%' readonly>
					<input type='hidden' class="form-control gstinperc" name="gstinperc[]" id='gstinperc_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstincgst" name="gstincgst[]" id='gstincgst_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstincgstamt" name="gstincgstamt[]" id='gstincgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstinsgstamt" name="gstinsgstamt[]" id='gstinsgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
					<!--Taxable Non Taxable-->
					<input type='hidden' class="form-control purchase_token" name="purchase_token[]" value="<?php  if($gst != '0'){ echo $rows_ledger['ledger_token']; }else{ echo $rows_ledger1['ledger_token']; } ?>" id='purchase_token_<?php echo $i+1; ?> ' >
					
					<input type='hidden' class="form-control ledger_name" name="ledger_name[]" value="<?php  if($gst !='0'){ echo $rows_ledger['ledger_name']; }else{ echo $rows_ledger1['ledger_name']; } ?>" id='ledger_name_<?php echo $i+1; ?>' >
					 <!--===================================-->
					 <!--Other Tax Rate-->
					 <?php 
				   	 $result_other_tax = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' ");
					 $result_other_tax->execute();
					 for($i1=0; $rows_other_tax = $result_other_tax->fetch(); $i1++){ ?>
					 <input type='hidden' class="form-control othertax_amt<?php echo $i1+1; ?>" name="othertax_amt<?php echo $i1+1; ?>[]" id='othertax_amt<?php echo $i1+1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_tax['tax_rate']; ?>">
					 <?php } ?>
					 <!--Empty Text Boxes of tax rate-->
					 <?php for($otax=$i1; $otax <=4; $otax++){  ?>
					 <input type='hidden' class="form-control othertax_amt<?php echo $otax+1; ?>" name="othertax_amt<?php echo $otax+1; ?>[]" id='othertax_amt<?php echo $otax+1; ?>_<?php echo $i+1; ?>' value="0">
					 <?php  } ?>
					 <!--===================================-->
					 <!--Other Tax Amounts-->
					 <?php 
				   	 $result_other_taxamt = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' ");
					 $result_other_taxamt->execute();
					 for($i3=0; $rows_other_taxamt = $result_other_taxamt->fetch(); $i3++){ ?>
					 <input type='hidden' class="form-control othertax_amount<?php echo $i3+1; ?>" name="othertax_amount<?php echo $i3+1; ?>[]" id='othertax_amount<?php echo $i3+1; ?>_<?php echo $i+1; ?>' value="0" >
					 <?php } ?>
					 <!--Empty Text Boxes of tax Amount-->
					 <?php for($otax1=$i3; $otax1 <=4; $otax1++){ ?>
					 <input type='hidden' class="form-control othertax_amount<?php echo $otax1+1; ?>" name="othertax_amount<?php echo $otax1+1; ?>[]" id='othertax_amount<?php echo $otax1+1; ?>_<?php echo $i+1; ?>' value="0">
					 <?php  } ?>
					 <!--===================================-->
					 <!--Other Tax Type Names (CESS, etc)-->
					 <?php
				     $result_other_taxtype = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' AND date='$billdate' ");
					 $result_other_taxtype->execute();
					 for($i2=0; $rows_other_taxtype = $result_other_taxtype->fetch(); $i2++){ ?>
					 <input type='hidden' class="form-control othertax_typ<?php echo $i2 + 1; ?>" name="othertax_typ<?php echo $i2 + 1; ?>[]" id='othertax_typ<?php echo $i2 + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_taxtype['tax_type']; ?>">
					 <?php } ?>
					 <!--Empty Text Boxes of Tax type Names-->
					 <?php for($type=$i2; $type <=4; $type++){ ?>
					 <input type='hidden' class="form-control othertax_typ<?php echo $type + 1; ?>" name="othertax_typ<?php echo $type + 1; ?>[]" id='othertax_typ<?php echo $type + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $rows_other_taxtype['tax_type']; ?>">
					 <?php } ?>
					 <!--===================================-->
				</td>
				<td><input type='text' tabindex="-1" class="form-control retqty" name="retqty[]" value="<?php echo $rows_purch['qty']; ?>" id='retqty_<?php echo $i+1; ?>' placeholder='Qty' readonly>
				</td>
				<td><input type='text' class="form-control qty" name="qty[]" value="" id='qty_<?php echo $i+1; ?>' placeholder='Qty'>
				</td>
				<td>
				<?php if($rows_purch['discount'] == 0){ ?>
				<input type='text' tabindex="-1" class="form-control discount" name="discount[]" value="<?php echo $rows_purch['discount']; ?>" id='discount_<?php echo $i+1; ?>' readonly >
				<?php }else{ ?>
				<input type='text' tabindex="-1"  class="form-control discount" name="discount[]" value="<?php echo $rows_purch['discount']; ?>" id='discount_<?php echo $i+1; ?>' >
				<?php } ?>
					<input type='hidden' class="form-control discounttotal" name="discounttotal" id='discounttotal_<?php echo $i+1; ?>' placeholder='Discount'>
					<input type='hidden' class="form-control totalcost" name="totalcost[]" id='totalcost_<?php echo $i+1; ?>' placeholder=''>
					<input type='hidden' class="form-control unitprice" name="unitprice[]" id='unitprice_<?php echo $i+1; ?>' placeholder=''>
					<!--Gross Amount / other Tax total / gst amt/-->
					<input type='hidden' tabindex="-1" class="form-control gross" name="gross[]" value="" id='gross_<?php echo $i+1; ?>' placeholder='Gross' readonly>
					<input type='hidden' tabindex="-1" class="form-control gst" name="gst[]" value="" id='gst_<?php echo $i+1; ?>' placeholder='GST' readonly>
					<input type='hidden' class="form-control taxrate_amount" name="taxrate_amount[]" value="0" id='taxrate_amount_<?php echo $i+1; ?>'>
				</td>
				<td>
					<input type='text' tabindex="-1" class="form-control total" name="total[]" value="" id='total_<?php echo $i+1; ?>' placeholder='Total' readonly>
					<input type='hidden' class="form-control totalt" name="totalt" id='totalt_<?php echo $i+1; ?>' placeholder='Unit Cost'>
				</td>
				<td></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
</div>
<br>
<div class="col-md-12 col-sm-6 col-xs-12">
	<table class="table">
		<tr>
			<td align="right" class="control-label">Discount:</td>
			<td width="150">			
				<input type="text" tabindex="-1" readonly class="form-control" name="discountt" id="discountt" placeholder="Discount"  value="<?php echo $discount_total;  ?>">
				<input type="hidden" readonly class="form-control" name="discounttt" id="discounttt" placeholder="Discount" value="0" style="width:120px;">
			</td>
			<td align="right" class="control-label">Total Amount:</td>
			<td width="250"><input type="text" tabindex="-1" readonly class="form-control totalprice" value="<?php echo $total_price; ?>" name="totalprice" id="totalprice">
			</td>
			<td align="right" class="control-label">GST Total:</td>
			<td>
			<input type="text" readonly class="form-control totalgst" name="totalgst" id="totalgst">
			</td>
		</tr>
		<tr style="display:none;">
		<td style=" font-stretch:expanded;" align="right" class="control-label">Freight:</td>
			<td width="150">
				<input type="text" value="0" class="form-control" name="coolie" id="coolie" placeholder="Coolie" style="width:120px;">
				<input type="hidden" value="0" class="form-control" name="qtyt" id="qtyt" placeholder="Qtytotal" style="width:120px;">
				<input type="hidden" value="0" class="form-control" name="fright" id="fright" placeholder="frighttotal" style="width:120px;">
			</td>
		</tr>
		<tr id="show1" style="display:none;">
			<td align="right" class="control-label">Old Balance</td>
			<td style="width:150px;"><input type="text" readonly class="form-control" value="0" name="totaldiscount" id="totaldiscount" placeholder="Old Balance" style="width:120px;">
			</td>
		</tr>
		<tr>
		<!--Other Tax  Total -->
			<td align="right" class="control-label">Other Tax Total:</td>
			<td>
			<!--Other Tax  Total SUM-->
			<input type="text" readonly class="form-control other_tax_total_amount" name="other_tax_total_amount" id="other_tax_total_amount">
			</td>
			<td align="right" class="control-label">Grant Total:</td>
			<td width="150"><input type="text" readonly class="form-control" value="<?php echo $grand_total; ?>" name="gtotalprice" id="gtotalprice" placeholder="Grant Total" >
			</td>
			<tr id="show1" style="">
			<td align="right" class="control-label">Balance:</td>
			<td style="width:150"><input type="text" readonly class="form-control"  name="balance_amt" id="balance_amt" placeholder="Balance" style="width:150px;">
			<td align="right" class="control-label">Paid Amount:</td>
			<td width="150"><input type="text" class="form-control" name="paidamount" id="paidamount"  placeholder="Paid Amount" style="width:250px;">
			<td align="right" class="control-label">Pay Mode:</td>
			<td width="100">
			<select class="form-control" id="paymode" name="paymode" style="width: 100%; height:33px;">
			<option value="cash">Cash</option>
			<option value="bank">Bank</option>
			</select>	
			</td>	
			</td>
			</tr>
		</tr>
		<tr>
			<td align="right" class="control-label"></td>
			<td width="150"><input type="hidden" readonly class="form-control " value="0" name="balance" id="balance" placeholder="Balance" style="width:120px;">
			</td>
		</tr>
	</table>
</div> 
</div>
<div class="col-md-12" style="margin-bottom: 25px;">
	<input type="submit" name="submit" id="submit" style="float: right; margin-top: 25px;" class="btn btn-sm btn-info" value="Save & Print"/>
</div> 
</form> 
</div>
<?php }else{ ?>
<script>
	
			$.toast({
				heading: 'No Bills Found!.',
				text: '',
				position: 'top-right',
				loaderBg: '#F50000',
				icon: 'error',
				hideAfter: 4500
			});
</script>
<?php } ?>