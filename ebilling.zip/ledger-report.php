<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); include('db-connect/db.php');
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type where user_tkn = '$user_type_tkn'");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{  $master_update_ledger=$row_user['master_update_ledger']; $master_add_ledger=$row_user['master_add_ledger']; } 
 $results_user_second = $db->prepare("select * from  user_type_second where user_tkn = '$user_type_tkn'");
$results_user_second->execute();
for($i=0; $row_user_second = $results_user_second->fetch(); $i++)
{ 
  $update_ledger=$row_user_second['update_ledger'];  $add_ledger=$row_user_second['add_ledger']; 
}

?>
<title>All Ledgers</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<style>
.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}
</style>
<div class="col-md-12">
	<h3 class="text-center">List Of Ledgers</h3>
	<div class="text-right">
		<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="margin-left:.1em;">Close</button>
	</div>
					<div class="table-responsive m-t-40">
                                <table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%">
                                    <thead>
												<tr>
													<th>#</th>
													<th>Account Name</th>
													<th>Account Group</th>
													<th>GSTIN</th>
													<th>PAN No</th>
													<th>Current Balance</th>
													<?php if( $master_update_ledger==0 && $master_add_ledger==0 || $add_ledger==0 && $update_ledger==0 ) { ?> <th>Action</th><?php } ?>
												</tr>
											</thead>
											<tbody>
											<?php 
											$result_ledger = $db->prepare("SELECT * FROM account_ledger WHERE company_tkn='$user_company' ");
											$result_ledger  -> execute(); 
											$sl = 0;
											for ($i=0; $rows_ledger = $result_ledger  ->fetch(); $i++){
											?>
												<tr>
													<td><?php echo ++$sl; ?></td>
													<td><?php echo strtoupper($rows_ledger ['ledger_name']); ?></td>
													<td><?php echo $rows_ledger ['account_group']; ?></td>
													<td><?php echo $rows_ledger ['gstin']; ?></td>
													<td><?php echo $rows_ledger ['pan']; ?></td>
													<td><?php echo $rows_ledger ['balance']; ?>&nbsp;&nbsp;/&nbsp;&nbsp;<?php echo $rows_ledger ['trans']; ?></td>
													<?php if( $master_update_ledger==0 && $master_add_ledger==0 || $add_ledger==0 && $update_ledger==0 ) { ?> 
													<td><a href="edit-ledger.php?edit=<?php echo $rows_ledger['ledger_token']; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top"><i class="fa fa-pencil-alt"></i></a>&nbsp;<a id="delete" href="delete-ledger.php?delete=<?php echo $rows_ledger['ledger_token']; ?>"  class="btn btn-sm btn-danger simple-ajax-popup-align-top" ><i class="fas fa-trash-alt"></i>
												</a></td>
													<?php } ?>
											</tr>
											<?php } ?>
										</tbody>
                                </table>
                                   </div>
      </div>
		<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
			</script>
			
<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
<script src="js/toastr.js"></script>
<?php include ('include/disable_fn.php'); ?>