
<?php
include('db-connect/db.php');
include('php_fn/basic.php');
include( 'datetime_creation/datetime_creation.php' );

if(isset($_POST['billno']))
{
    for ($i=0; $i<count($_POST['billno']); $i++)
        {
			$checkBox = $_POST['billno'][$i];
            $db->prepare("UPDATE sales_invoice SET status = 'cancel' WHERE sbill_no = '$checkBox'")->execute();
        }
 } ?>


