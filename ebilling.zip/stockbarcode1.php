
<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
	@media print{
.printButtonClass{display:none;}

}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */
    }
</style>
</head>
<a href="product-pricing.php"><button style="float:left;" class="printButtonClass">back</button></a>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		include 'barcode128.php';
		
	
    


   


	for ( $count = 0; $count < count( $_POST[ "code" ] ); $count++ ) {
		$product = $_POST['name'][ $count ];
		$product_id = $_POST['code'][ $count ];
		$rate = $_POST['mrprate'][ $count ];
			

		for($i=1;$i<=$_POST['qty'][ $count ];$i++){
			echo "<p class='inline'><span ><b> $product</b></span>".bar128(stripcslashes($_POST['code'][ $count ]))."<span ><b>Price: ".$rate." </b><span></p>&nbsp&nbsp&nbsp&nbsp";
		
	}
	}
		
		?>
	</div>
</body>
</html>