<?php
	session_start();
	include('db-connect/db.php');
	$current_date_time = date("Y-m-d H:i:s", time());
	
	$log_token_c = $_SESSION['SESS_LOGTOKEN_AS'];	
	$db->prepare("UPDATE admin_user_log SET out_time = '$current_date_time', logout_as = 'btn_click' WHERE log_token = '$log_token_c'")->execute();
	
	unset($_SESSION['SESS_USERID_AS']);
	unset($_SESSION['SESS_USERTYPE_AS']);
	unset($_SESSION['SESS_LOGTOKEN_AS']);

	setcookie('_nhb', "", -1, '/');
	setcookie('_vhb', "", -1, '/');
	setcookie("log_f4", true, time() + (3), "/");
	header("location:index.php");
?>
