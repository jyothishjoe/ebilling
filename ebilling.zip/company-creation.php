<?php
session_start();
//if (!isset($_SERVER['HTTP_REFERER'])){header("Location:pages-error-404.php");}
if(!isset($_SESSION['SESS_USERID']) || (trim($_SESSION['SESS_USERID']) == '')) {
header("location:index.php");
exit();
}
$userid = $_SESSION['SESS_USERID'];
include( 'db-connect/db.php');
include( 'datetime_creation/datetime_creation.php');


	$date_set = $today;

?>
<!doctype html>
<html>
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>New Company Creation</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave_first.php");?>

		<div class="page-wrapper">
			<div class="container-fluid">
			<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor" style="float: left;">Company Creation&nbsp; </h4>
					</div>
					<!--<div class="col-md-7 align-self-center"style="z-index:9 !important;">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item active"><a href="purchase-home.php">Purchase</a></li>
						</ol>
					</div>-->
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<a href="logout.php" class="btn btn-sm btn-danger " style="float:right;" id="openproduct">Logout(ESC)</a>
								<div class="clear"></div>
								
								<div class="row">
									<div class="col-lg-12">
										<div class="card ">
											<!--<div class="card-header bg-info">
												<h4 class="m-b-0 text-white">Company Creation</h4>
											</div>-->
											<div class="card-body">
												<form method="post" action="settings-action/first-time-company-creation.php" class="forms" name="insert_form" id="insert_form" autocomplete="off" enctype="multipart/form-data">
													<div class="form-body">
														<h3 class="box-title">Conpany Info</h3>
														<hr class="m-t-0 m-b-40">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Company Name</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Company Name" name="comp_name" id="comp_name">
																		<input type="hidden" class="form-control"  name="sess_id" id="sess_id" value="<?php echo $userid; ?>">
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Phone</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Phone" name="comp_phone" id="comp_phone">
																	</div>
																</div>
															</div>

														</div>
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Mobile</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Mobile No" name="comp_mobile" id="comp_mobile">
																	</div>
																</div>
															</div>

															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Email</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Mail" name="comp_email" id="comp_email">
																	</div>
																</div>
															</div>
														</div>
														<div class="row">

															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">GSTIN</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="GSTIN No" name="gstin" id="gstin">
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Website</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Website Address" name="website" id="website">
																	</div>
																</div>
															</div>

														</div>
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Fax No</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Fax No" name="fax" id="fax">
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Finacial Year</label>
																	<div class="col-md-9">
																		<input type="date" class="form-control" placeholder="Finacial Year Starts From" name="fisc" id="fisc">
																	</div>
																</div>
															</div>

														</div>

														<h3 class="box-title">Address Info</h3>
														<hr class="m-t-0 m-b-40">
														<!--/row-->
														<div class="row">

															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Address 1</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Address" name="address1" id="address1">
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Address 2</label>
																	<div class="col-md-9">
																		<input type="text" class="form-control" placeholder="Address" name="comp_address" id="comp_address">
																	</div>
																</div>
															</div>
														</div>
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="control-label text-right col-md-3">Country</label>
																	<div class="col-9">
																		<select class=" form-control select2" id="country" name="country" style="width: 100%; height:36px;">
																			<option value=""></option>
																			<?php
																			$result = $db->prepare( "SELECT * FROM countries WHERE status = 1 ORDER BY country_name ASC" );
																			$result->execute();
																			while ( $row = $result->fetch() ) {
																				?>
																			<option value="<?php echo $row['country_id'];?>">
																				<?php echo ucwords($row['country_name']);?>
																			</option>
																			<?php } ?>
																		</select>
																	</div>
																</div>
															</div>
															<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-md-3">State</label>
																	<div class="col-9">
																		<select class=" form-control select2" id="state" name="state" style="width: 100%; height:36px;">
																			<option value=""></option>
																		</select>
																	</div>
																</div>
															</div>
														</div>
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">City</label>
																	<div class="col-9">
																		<select class=" form-control select2" id="city" name="city" style="width: 100%; height:36px;">
																			<option value=""></option>
																		</select>
																	</div>
																</div>
															</div>
															<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">Currency</label>
																	<div class="col-9">
																		<input type="text" class="form-control" name="currency" id="currency" placeholder="Currency" readonly>
																	</div>
																</div>
															</div>
															<!--/span-->
														</div>
														<!--/Bank details-->
														<h3 class="box-title">Bank Info</h3>
														<hr class="m-t-0 m-b-40">
														<div class="row">
														<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">Account No</label>
																	<div class="col-9">
																		<input type="text" class="form-control" name="acc_no" id="acc_no" placeholder="Account No" value="">
																	</div>
																</div>
															</div>
															<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">Bank Name</label>
																	<div class="col-9">
																		<input type="text" class="form-control" name="bank" id="bank" placeholder="Bank" value="">
																	</div>
																</div>
															
															
														</div>
														<!--/row-->
													</div>
														<div class="row">
														<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">Branch</label>
																	<div class="col-9">
																		<input type="text" class="form-control" name="branch" id="branch" placeholder="Branch" value="">
																	</div>
																</div>
															</div>
															<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">IFSC</label>
																	<div class="col-9">
																		<input type="text" class="form-control" name="ifsc" id="ifsc" placeholder="IFSC Code" value="">
																	</div>
																</div>
														</div>
														<!--/row-->
													</div>
													<h3 class="box-title">Company Logo</h3>
													<hr class="m-t-0 m-b-40">
													<div class="row">
														<div class="col-md-6 col-sm-6">
																<div class="form-group row">
																	<label for="validationTooltip01" class="control-label text-right col-3">Logo</label>
																	<div class="col-9">
																		<input type="file" class="form-control" name="logo" id="logo" >
																	</div>
																</div>
															</div>
													</div>
													<hr>
													<div class="form-actions" >
														<div class="row" >
															<div class="col-md-12" >
																<div class="row">
																	<div class="col-md-offset-12 col-md-12" >
																		<input type="submit" class="btn btn-sm btn-success" style="float: right;" value="Submit">
																		<button type="button" class="btn btn-sm btn-inverse" style="float: right; margin-right: 8px;">Cancel</button>
																	</div>
																</div>
															</div>
															<div class="col-md-6"> </div>
														</div>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="successmsg" id="respond"></div>
			<script type="text/javascript">
				$(document).ready(function(){
	
	$('#country').change(function (){
			var country = $("#country").val();
			$.ajax({
				type: 'POST',
				url: 'settings-action/country_fetch.php',
				data: 'country=' + country,
				dataType: "JSON",
				success: function (data) {
					//$('#country_id').val(data.country_id);
					$('#currency').val(data.currency);
					
				}
			});
		});
	
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'settings-action/add_company.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
					
                    $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'settings-action/add_company.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#city').html(html);
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});

				//User details
				$( '#user' ).change( function () {
					var user = $( "#user" ).val();
					$.ajax( {
						type: 'POST',
						url: 'settings-action/user/user_fetch.php',
						data: 'user=' + user,
						dataType: "JSON",
						success: function ( data ) {
							$( '#user_name' ).val( data.user_name );
							$( '#user_password' ).val( data.user_password );


						}
					} );
				} );
			</script>
			<script>
				$( window ).keydown( function ( event ) {

					if ( event.keyCode == 27 ) {
						//parent . jQuery . magnificPopup . close();
						event.preventDefault();
						// $( "#custom-content" ).hide();
						window.location.href = "logout.php";
					}

				});
				
			</script>
				
				

			<div class="right-sidebar">
				<div class="slimscrollright">
					<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
					<div class="r-panel-body">
						<ul id="themecolors" class="m-t-20">
							<li><b>With Light sidebar</b>
							</li>
							<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
							</li>
							<li class="d-block m-t-30"><b>With Dark sidebar</b>
							</li>
							<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
							</li>
							<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
							</li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
		
	</div>
	</div>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<?php include ('include/disable_fn.php'); ?>

	<script>
		//For validation with custom styles
		( function () {
			'use strict';
			window.addEventListener( 'load', function () {
				// Fetch all the forms we want to apply custom Bootstrap validation styles to
				var forms = document.getElementsByClassName( 'needs-validation' );
				// Loop over them and prevent submission
				var validation = Array.prototype.filter.call( forms, function ( form ) {
					form.addEventListener( 'submit', function ( event ) {
						if ( form.checkValidity() === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
						form.classList.add( 'was-validated' );
					}, false );
				} );
			}, false );
		} )();
	</script>
	<!-- This page plugins -->
	<!-- ============================================================== -->
	<!--select-->
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<!--multiple selection-->

	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>

	<script>
		$( function () {
			// Switchery
			var elems = Array.prototype.slice.call( document.querySelectorAll( '.js-switch' ) );
			$( '.js-switch' ).each( function () {
				new Switchery( $( this )[ 0 ], $( this ).data() );
			} );
			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();

			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
	</script>

	<!-- ============================================================== -->
	<!-- Style switcher -->
	<!-- ============================================================== -->
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

</body>

</html>