<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$billid = $_GET[ 'bill' ];
$result_billitem = $db->prepare( "SELECT * FROM purchase_order WHERE bill_no = '$billid' " );
$result_billitem->execute();
$rows_billitem = $result_billitem->fetch();
?>
<html>
 
    <head>
    <title>Invoice</title>
        <style type="text/css">
        body {      
            font-family: Verdana;
        }
         
        div.invoice {
        border:1px solid #ccc;
        padding:10px;
        height:740pt;
        width:570pt;
        }
 
        div.company-address {
            border:1px solid #ccc;
            float:left;
            width:200pt;
        }
         
        div.invoice-details {
            border:1px solid #ccc;
            float:right;
            width:200pt;
        }
         
        div.customer-address {
            border:1px solid #ccc;
            float:right;
            margin-bottom:50px;
            margin-top:100px;
            width:200pt;
        }
         
        div.clear-fix {
            clear:both;
            float:none;
        }
         
        table {
            width:100%;
        }
         
        th {
            text-align: left;
        }
         
        td {
        }
         
        .text-left {
            text-align:left;
        }
         
        .text-center {
            text-align:center;
        }
         
        .text-right {
            text-align:right;
        }
         
        </style>
    </head>
 
    <body>
    <div class="invoice">
        <div class="company-address">
          
            <br />
           
            <br />
           
            <br />
        </div>
     
        <div class="invoice-details">
            Invoice N°: <?php echo $billid; ?>
            <br />
            Date: <?php echo $rows_billitem['date']; ?>
        </div>
         
        <div class="customer-address">
            To:
            <br />
            <?php echo $rows_billitem['company']; ?>
            <br />
             <?php echo $rows_billitem['vaddress']; ?>
            <br />
             <?php echo $rows_billitem['address']; ?>, <?php echo $rows_billitem['v_state']; ?>
            <br />
        </div>
         
        <div class="clear-fix"></div>
            <table border='1' cellspacing='0'>
                <tr>
                    <th width=250>Items</th>
                    <th width=80>Unit</th>
                    <th width=100>Unit price</th>
                     <th width=100>Qty</th>
                    <th width=100>Total price</th>
                </tr>
                   <?php 
                    $result_bill = $db->prepare( "SELECT * FROM purchase_order WHERE bill_no = '$billid' " );
					$result_bill->execute();
					for ($i=0;  $rows_bill= $result_bill->fetch(); $i++ ){
				   ?>
                    <tr>
                    <td><?php $rows_bill['pr_name']; ?></td>
                    <td class='text-center'><?php $rows_bill['pr_name']; ?></td>
					<td class='text-right'><?php $rows_bill['unit']; ?></td>
                    <td class='text-right'><?php $rows_bill['price']; ?></td>
                    <td class='text-right'><?php $rows_bill['total']; ?></td>
                    </tr>
                    <?php } ?>
            <tr>
            <td colspan='3' class='text-right'>Sub total</td>
            <td class='text-right'><?php $rows_bill['t_total']; ?></td>
            </tr>
            <tr>
            <td colspan='3' class='text-right'><b>TOTAL</b></td>
            <td class='text-right'><b><?php $rows_bill['g_total']; ?></b></td>
            </tr>
            </table>
        </div>
    </body>
 
</html>