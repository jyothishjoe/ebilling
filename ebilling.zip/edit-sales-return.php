<?php
include( 'include/auth.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];
include( "php_fn/basic.php" );
include( "datetime_creation/datetime_creation.php" );
include( 'db-connect/db.php' );
$today_date = date_create( $today );
$sales_rtndate = date_format( $today_date, "Y-m-d" );
$sbill_no = $_GET[ "alter" ];
$results = $db->prepare( "select * from  admin_user where user_tkn = '$userid'" );
$results->execute();
for ( $i = 0; $rows = $results->fetch(); $i++ ) {
$counter = $rows['counter'];
}

$date_set = $today;


$result = $db->prepare( "SELECT * FROM sales_rtn_invoice where company_tkn='$user_company' AND bill_no='$sbill_no'" );
$result->execute();
$row_count = $result->rowcount();
$rows = $result->fetch(); 
	$tot_qty = $rows[ "tot_qty" ];
	
	$cus_name = $rows[ "custmr_name" ];
	$tax_tot = $rows[ "tax_tot" ];
	$other_notes = $rows[ "other_notes"];
	$cashtype = $rows[ "cashtype"];
	$o_tax_total = $rows["o_tax_total"];
	$grand_total = $rows["grand_tot"];
	$sales_rtn_no = $rows["sales_rtnno"];
	$sales_invno = $rows["sales_invno"];
$sales_invdate = $rows["sales_invdate"];

$result1 = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company' AND ledger_name='$cus_name'" );
$result1->execute();
$rows1 = $result1->fetch();
$cus_tkno = $rows1[ "ledger_token" ];
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Sales Return Bill | Edit</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
</head>
<style>
	.totalprice {
		font-size: 20px !important;
	}
</style>

<body class="fix-header fix-sidebar card-no-border" onload='setFocusToTextBox()'>
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	

		<?php 
		$result =$db->prepare("SELECT * FROM  sales_rtn_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
		$result->execute();
		$rows=$result->fetch();
		$bill_no=$rows['b_no'] + 1;
		$identification_leter='sr';
		?>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="text-right"><a href="customer-info.php?cus_id=<?php echo $cus_name;?>" class="btn btn-sm btn-info" >Back</a>
							
							</div>
						<div class="clear"></div>
						<hr>
						<form method="post" action="" class="forms" autocomplete="off" name="insert_form" id="insert_form">
							<div class="form-row">
								<div class="col-md-4 col-sm-6 col-xs-12  mb-1">
									<div class="row">
										<div class="col-md-3 col-sm-6 col-xs-12">
											<label for="" class="control-label">Bill No:</label>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12">
											<input type="text" class="form-control" id="bill_no" name="bill_no" value="<?php echo $sbill_no; ?>" readonly>
											<input type="hidden" class="form-control" value="<?php echo $counter;?>" name="counter" id="counter" readonly>
										</div>
									</div>
								</div>
								<div class="col-md-4 col-sm-6 col-xs-12"></div>
								<input type="hidden" class="form-control" id="addby" name="addby" value="<?php echo $userid;?>" readonly>
								<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company;?>">
								<div class="col-md-2 col-sm-6 col-xs-6 mb-1">
									<input type="date" class="form-control" id="sales_rtndate" value="<?php echo $date_set;?>" name="sales_rtndate">
								</div>
								<div class="col-md-2 col-sm-6 col-xs-6 mb-1">
									<input type="time" class="form-control" id="sales_rtntime" value="<?php echo $current_time;?>" name="sales_rtntime" readonly>
								</div>
								<div class="col-md-3 col-sm-6 col-xs-6 mb-1">
									<label for="" class="control-label">Sales Bill No</label>
									<input type="text" class="form-control sales_invno" name="sales_invno" id="sales_invno" value="<?php echo $sbill_no; ?>">
								</div>
								<input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty" readonly>
								<input type="hidden" class="form-control sales_invdate" id="sales_invdate" name="sales_invdate" value="<?php echo $sales_invdate; ?>" readonly>
								<input type="hidden" class="form-control" id="datetym" name="datetym" value="<?php echo $current_date_time;?>">
								<input type="hidden" class="form-control" id="sales_rtnno" name="sales_rtnno" value="<?php echo $sales_rtn_no;?>">
								<input type="hidden" class="form-control" id="sales_inv" name="sales_inv" value="<?php echo $sales_invno;?>">
							</div>
							<div class="col-md-12 col-sm-12 col-xs-12">
								<input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty" value="<?php echo $tot_qty;?>" readonly>
								<input type="hidden" value="<?php echo $cus_name;?>" name="cus_name" id="cus_name">
								<input type="hidden" value="<?php echo $cus_tkno;?>" name="cus_tkn" id="cus_tkn">
								<label for="" class="control-label">Product Details</label>
								<div class="table-responsive col-md-12 col-sm-12 col-xs-12">
									<table border='0' class="table table-bordered table-striped mb-0" style="min-width: 800px;">
										<thead>
											<tr>
												<th>Sl No</th>
												<th>Item code</th>
												<th>Item Name</th>
												<th>Qty</th>
												<th>Sales Qty</th>
												<th>Unit</th>
												<th>Gst %</th>
												<th>Unit Price</th>
												<th>Gst Amount</th>
												<th>Other Tax Amt</th>
												<th>Total</th>
											</tr>
										</thead>
										<tbody id="hello">
										<?php 
										$result =$db ->prepare("SELECT * FROM sales_rtn_prdct_details where company_tkn='$user_company' AND srtn_bill_no='$sbill_no'");	
										$result->execute();	$row_count =  $result->rowcount();
										for($i=0; $rows1 = $result->fetch(); $i++) {  
											$prdct_name=$rows1["prdct_name"]; 
											$prdct_tkn=$rows1["prdct_tkn"];  
											$qty=$rows1["rtn_qty"];
											$rate=$rows1["rtn_rate"];
											$amount=$rows1["rtn_amt"]; 
											$grand_tot=$rows1["rtn_grand_tot"];  
											$sales_tax=$rows1["sales_tax"];  
											$gst_amt=$rows1["gst_amt"];  
											$mrp=$rows1["mrp"];  
											$pr_hsn=$rows1["pr_hsn"];  
											$units=$rows1["units"]; 
											$catname=$rows1["catname"];  
											$subcat=$rows1["subcat"];  
											$o_tax_amt=$rows1["o_tax_amt"];  
											$stock_tkn=$rows1["stock_tkn"];  
											$gst=$gst_amt/ $qty; 
											?>
											<tr class='tr_input'>
												<td width="70" class="css-serialw">
													<input type='text' class="form-control slno" name="slno[]" id='slno_<?php echo $i;?>' value="<?php echo $i +1;?>">
													<input type='hidden' class="form-control data" name="data[]" id='data_<?php echo $i;?>' value="<?php echo $row_count; ?>">
												</td>
												<td><input type='text' class="form-control code" name="code[]" id='code_<?php echo $i;?>' placeholder='Product Code' value="<?php echo $prdct_tkn;?>" readonly>
													<input type='hidden' class="form-control stock_tkn" name="stock_tkn[]" id='stock_tkn_<?php echo $i;?>' placeholder='Product Code' value="<?php echo $stock_tkn; ?>" readonly>
												</td>
												<td><input type='text' class="form-control name" name="name[]" id='name_<?php echo $i;?>' placeholder='Product Name' value="<?php echo $prdct_name;?>" readonly>
												</td>
												<td><input type='text' class="form-control qty" name="qty[]" id='qty_<?php echo $i;?>' placeholder='Qty' value="<?php echo $qty; ?>">
												</td>
												<td><input type='text' class="form-control qtyold" readonly name="qtyold[]" id='qtyold_<?php echo $i;?>' placeholder='Qty Old' value="<?php echo $tot_qty;?>">
												</td>
												<td><input type='text' class="form-control unit" name="unit[]" id='unit_<?php echo $i;?>' placeholder='Unit' value="<?php echo $units;?>" readonly>
												</td>
												<td style=""><input type='text' class="form-control stax" readonly name="stax[]" id='stax_<?php echo $i;?>' placeholder='Gst %' value="<?php echo $sales_tax;?>">
												</td>

												<td style="display:none;">
													<?php 
													$result_otax =$db ->prepare("SELECT * FROM sales_invoice_otax_detail where company_tkn='$user_company' AND sales_invono='$sbill_no' and prdct_tkn='$prdct_tkn'");
													$result_otax->execute();
													for($t=0; $rowstax = $result_otax->fetch(); $t++) {  
													$o_tax_rate=$rowstax["o_tax_rate"]; $o_tax_type=$rowstax["o_tax_type"]; $po_tax_amt=$rate* $o_tax_rate / 100; 
													?>
													<input type='text' class="form-control othertax_amt<?php echo $t+1;?>" name="othertax_amt<?php echo $t+1;?>[]" id='othertax_amt<?php echo $t+1;?>_<?php echo $i;?>' placeholder='Gst Cess %' value="<?php echo $o_tax_rate;?>">
													<!-- other tax amount(one) -->
													<input type='text' class="form-control o_tax_amt<?php echo $t+1;?>" readonly name="o_tax_amt<?php echo $t+1;?>[]" id='o_tax_amt<?php echo $t+1;?>_<?php echo $i;?>' placeholder='other tax  amt' value="<?php echo $po_tax_amt;?>">
													<!-- other tax types -->
													<input type='text' class="form-control o_tax_type<?php echo $t+1;?>" readonly name="o_tax_type<?php echo $t+1;?>[]" id='o_tax_type<?php echo $t+1;?>_<?php echo $i;?>' placeholder='other tax type' value="<?php echo $o_tax_type;?>">
													<?php }  for ($r=$t; $r <= 4; $r++ ) {
													$o_tax_rate=0; $o_tax_type=0; $po_tax_amt=0;?>
													<input type='text' class="form-control othertax_amt<?php echo $r+1;?>" name="othertax_amt<?php echo $r+1;?>[]" id='othertax_amt<?php echo $r+1;?>_<?php echo $i;?>' placeholder='Gst Cess %' value="<?php echo $o_tax_rate;?>">
													<!-- other tax amount(one) -->
													<input type='text' class="form-control o_tax_amt<?php echo $r+1;?>" readonly name="o_tax_amt<?php echo $r+1;?>[]" id='o_tax_amt<?php echo $r+1;?>_<?php echo $i;?>' placeholder='other tax  amt' value="<?php echo $po_tax_amt;?>">
													<!-- other tax types -->
													<input type='text' class="form-control o_tax_type<?php echo $r+1;?>" readonly name="o_tax_type<?php echo $r+1;?>[]" id='o_tax_type<?php echo $r+1;?>_<?php echo $i;?>' placeholder='other tax type' value="<?php echo $o_tax_type;?>">
													<?php } ?>
												</td>


												<td style="display:none;"><input type='text' class="form-control gst" readonly name="gst[]" id='gst_<?php echo $i;?>' placeholder='Gst Rate' value="<?php echo $gst;?>">
												</td>
												<td><input type='text' class="form-control unitprice" name="unitprice[]" id='unitprice_<?php echo $i;?>' placeholder='Unit Price' value="<?php echo $rate;?>" readonly>
												</td>
												<td><input type='text' class="form-control totalgst" readonly name="totalgst[]" id='totalgst_<?php echo $i;?>' placeholder='Gst Amount' value="<?php echo $gst_amt; ?>">
													<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total1[]" id='o_tax_total1_<?php echo $i;?>' placeholder='Other tax Amount' value="0">
													<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total2[]" id='o_tax_total2_<?php echo $i;?>' placeholder='Other tax Amount' value="0">
													<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total3[]" id='o_tax_total3_<?php echo $i;?>' placeholder='Other tax Amount' value="0">
													<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total4[]" id='o_tax_total4_<?php echo $i;?>' placeholder='Other tax Amount' value="0">
													<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total5[]" id='o_tax_total5_<?php echo $i;?>' placeholder='Other tax Amount' value="0">
												</td>
												<td><input type='text' class="form-control totalgstcess" readonly name="totalgstcess[]" id='totalgstcess_<?php echo $i;?>' placeholder='Other Tax Amount' value="<?php echo $o_tax_amt; ?>">
												</td>
												<td><input type='text' class="form-control total" name="total[]" id='total_<?php echo $i;?>' placeholder='Total' value="<?php echo $amount; ?>" readonly>
													<input type='hidden' class="form-control base_amount" readonly name="base_amount[]" id='base_amount_<?php echo $i;?>' placeholder='Total'>
													<input type='hidden' class="form-control net_tax" readonly name="net_tax[]" id='net_tax_<?php echo $i;?>' placeholder='Total'>
												</td>
												<td style="display:none;"><input type='text' class="form-control hsn" readonly name="hsn[]" id='hsn_<?php echo $i;?>' placeholder='hsn' value="<?php echo $pr_hsn;?>">
												</td>
												<td style="display:none;"><input type='text' class="form-control mrp" readonly name="mrp[]" id='mrp_<?php echo $i;?>' placeholder='mrp' value="<?php echo $mrp;?>">
												</td>
												<td style="display:none;"><input type='text' class="form-control catname" readonly name="catname[]" id='catname_1' placeholder='cate' value="<?php echo $catname;?>">
												</td>
												<td style="display:none;"><input type='text' class="form-control subcat" readonly name="subcat[]" id='subcat_1' placeholder='subcate' value="<?php echo $subcat;?>">
												</td>
											</tr>
											<?php }?>
											<input type="hidden" id="countno" value="<?php echo $i;?>">
										</tbody>
									</table>
								</div>
								<br>
								<br>
								<hr>
								<div class="col-md-12 col-sm-12 col-xs-12 form-horizontal">
									<div class="row">
										<div class="col-md-3 col-sm-12 col-xs-12">
											<div class="form-group row">
												<label class="control-label  col-md-4 col-sm-6 col-xs-3">Remark</label>
												<div class="col-md-8 col-sm-6 col-xs-9">
													<textarea class="form-control" id="other_notes" rows="" id="other_notes" name="other_notes">
													  <?php echo $other_notes;?>
													  </textarea>
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-5 col-sm-6 col-xs-9">Tax Total</label>
												<div class="col-md-7 col-sm-6 col-xs-6">
												<input type="text" readonly class="form-control tax_tot" name="tax_tot" id="tax_tot" value="<?php echo $tax_tot; ?>">
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-6 col-sm-6 col-xs-9">Other Tax Total</label>
												<div class="col-md-6 col-sm-6 col-xs-6">
													<input type="text" readonly class="form-control cesstotal" name="cesstotal" id="cesstotal" value="<?php echo $o_tax_total; ?>">
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-5 col-sm-6 col-xs-9">Total Amount</label>
												<div class="col-md-7 col-sm-6 col-xs-6">
													<input type="text" readonly class="form-control totalprice" name="totalprice" id="totalprice" value="<?php echo $grand_total; ?>">
												</div>
											</div>
										</div>
										 <div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-5 col-sm-6 col-xs-9">Balance Amount</label>
												<div class="col-md-7 col-sm-6 col-xs-6">
													<input type="text"  class="form-control balance" name="balance" id="balance">
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-5 col-sm-6 col-xs-9">Paid Anmount</label>
												<div class="col-md-7 col-sm-6 col-xs-6">
													<input type="text"  class="form-control paid" name="paid" id="paid" >
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-12 col-xs-3">
											<div class="form-group row">
												<label class="control-label  col-md-5 col-sm-6 col-xs-9">Pay Mode</label>
												<div class="col-md-7 col-sm-6 col-xs-6">
													<select class="form-control" id="paymode" name="paymode" style=" height:33px;">
													<option value="cash">Cash</option>
													<option value="bank">Bank</option>
													</select>
												</div>
											</div>
										</div>
										<input type="hidden" readonly class="form-control gtotalprice" name="gtotalprice" id="gtotalprice" value="<?php echo $grand_total; ?>">
										<input type="hidden" readonly class="form-control cashtype" name="cashtype" id="cashtype" value="<?php echo $cashtype;?>">
										<div class="col-md-12 col-sm-12 col-xs-12 text-right">
											<div class="form-group row">
												<label class="control-label  col-md-3 col-sm-6 col-xs-3"></label>
												<div class="col-md-9 col-sm-6 col-xs-9" style="position: relative; padding-top: 5px !important;">
													<input type="submit" name="submit" id="submit" class="btn btn-info btn-sm" value="Save & Print"/>
												</div>
											</div>
										</div>
									</div>
								</div>
						   </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
		<script>
			function setFocusToTextBox() {
				$( "#sales_invno" ).focus();
			}
		</script>
		<script type="text/javascript">
			$( document ).ready( function () {



				$( document ).on( 'keydown', '.qty', function () {
					var id = this.id;
					var splitid = id.split( '_' );
					var index = splitid[ 1 ];
					$( '.qty' ).keyup( function () {
						var oldqty = parseInt( $( '#qtyold_' + index ).val() );
						var newqty = parseInt( $( '#qty_' + index ).val() );
						if ( oldqty < newqty ) {
							// $("#submit").hide();
							document.getElementById( 'qty_' + index ).style.color = "#ff0000";
						} else {
							document.getElementById( 'qty_' + index ).style.color = "#000";
						}
					} );

					$( '.qty' ).keyup( function () {
						$( '#totalgst_' + index ).val( $( '#gst_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#total_' + index ).val( $( '#unitprice_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#o_tax_total1_' + index ).val( $( '#o_tax_amt1_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#o_tax_total2_' + index ).val( $( '#o_tax_amt2_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#o_tax_total3_' + index ).val( $( '#o_tax_amt3_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#o_tax_total4_' + index ).val( $( '#o_tax_amt4_' + index ).val() * $( '#qty_' + index ).val() );
						$( '#o_tax_total5_' + index ).val( $( '#o_tax_amt5_' + index ).val() * $( '#qty_' + index ).val() );
						/*product other tax total*/
						$( '#totalgstcess_' + index ).val( parseFloat( $( '#o_tax_total1_' + index ).val() ) + parseFloat( $( '#o_tax_total2_' + index ).val() ) + parseFloat( $( '#o_tax_total3_' + index ).val() ) + parseFloat( $( '#o_tax_total4_' + index ).val() ) + parseFloat( $( '#o_tax_total5_' + index ).val() ) );
						$( '#net_tax_' + index ).val( parseInt( $( '#totalgstcess_' + index ).val() ) + parseInt( $( '#totalgst_' + index ).val() ) );
						$( '#base_amount_' + index ).val( $( '#total_' + index ).val() - $( '#net_tax_' + index ).val() );
						/*net sum */
						var sum = 0;
						var qtysum = 0;
						var taxtot = 0;
						var cesstot = 0;
						//iterate through each textboxes and add the values
						$( '.total' ).each( function () {

							//add only if the value is number
							if ( !isNaN( this.value ) && this.value.length != 0 ) {
								sum += parseFloat( this.value );
							}

						} );

						document.getElementById( 'totalprice' ).value = Math.round( sum );
						document.getElementById( 'gtotalprice' ).value = Math.round( sum ); /* net total disc=0*/
						/*qty sum*/
						$( ".qty" ).each( function () {
							if ( !isNaN( this.value ) && this.value.length != 0 ) {
								qtysum += parseFloat( this.value );
							}
						} );
						document.getElementById( 'totalqty' ).value = Math.round( qtysum );
						/* tax total*/
						$( ".totalgst" ).each( function () {
							if ( !isNaN( this.value ) && this.value.length != 0 ) {
								taxtot += parseFloat( this.value );
							}
						} );
						document.getElementById( 'tax_tot' ).value = Math.round( taxtot );
						/* other tax total*/
						$( ".totalgstcess" ).each( function () {
							if ( !isNaN( this.value ) && this.value.length != 0 ) {
								cesstot += parseFloat( this.value );
							}
						} );
						document.getElementById( 'cesstotal' ).value = Math.round( cesstot );
					} );
				} );
				$( '#insert_form' ).on( 'submit', function ( event ) {
					event.preventDefault();
					var error = '';
					var co = document.getElementById( 'countno' ).value
					for ( e = 0; e <= co; e++ ) {
						var oldqty = parseInt( $( '#qtyold_' + e ).val() );
						var newqty = parseInt( $( '#qty_' + e ).val() );
						if ( oldqty < newqty ) {
							$.toast( {
								heading: 'Retun Qty Should Be Less Than Or Equal to Sales Qty  ',
								text: '',
								position: 'top-right',
								loaderBg: '#F13109',
								icon: 'error',
								hideAfter: 1500
							} );
							error += "<p>Enter Item Name at " + e + " Row</p>";
						}
					}
					$( '.code' ).each( function () {
						var count = 1;
						if ( $( this ).val() == '' ) {
							error += "<p>Enter Item Name at " + count + " Row</p>";
							return false;
						}
						count = count + 1;
					} );

					$( '.name' ).each( function () {
						var count = 1;
						if ( $( this ).val() == '' ) {
							error += "<p>Enter Item Quantity at " + count + " Row</p>";
							return false;
						}
						count = count + 1;
					} );
					$( '.qty' ).each( function () {

						if ( $( this ).val() == 0 ) {
							$( this ).closest( 'tr' ).remove();

						}
					} );
					$( '.sales_invno' ).each( function () {
						var count = 1;
						if ( $( this ).val() == '' ) {
							error += "<p>Select Unit at " + count + " Row</p>";
							return false;
						}
						count = count + 1;
					} );
					$( '.totalprice' ).each( function () {
						var count = 1;
						if ( $( this ).val() == 0 ) {
							error += "<p>Select Unit at " + count + " Row</p>";
							setTimeout( function () {
								window.location.reload( 1 );
							}, 1500 );
							$.toast( {
								heading: 'Enter Item Quantity.',
								text: '',
								position: 'top-right',
								loaderBg: '#ff6849',
								icon: 'error',
								hideAfter: 1000
							} );
							document.getElementById( "table_data" ).remove();
							return false;
						}
						count = count + 1;
					} );
					var form_data = $( this ).serialize();
					if ( error == '' ) {
						$.ajax( {
							url: "creation_actions/sales-return/alter-sales-return.php",
							method: "POST",
							data: form_data,
							success: function ( data ) {
								$( "#respond" ).html( data );
								/* $.toast( {
								heading: 'Inserted Successfully.',
								text: '',
								position: 'top-right',
								loaderBg: '#04F92D',
								icon: 'success',

								hideAfter: 500
							} );
                            window.location="sales-bill-return-print.php";
                            document.getElementById( "insert_form" ).reset();
							$( '#hello' ).find( "tr:gt(0)" ).remove();*/
							}
						} );
					} else {
						/*$.toast( {heading: 'Enter Sales Invoice Number.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});*/
					}
				} );


			} );
		</script>
		<script>
			/* table data (sales bill)*/
			$( "#sales_invno" ).change( function () {

				var sales_invno = $( '#sales_invno' ).val();

				$.ajax( {
					type: 'POST',
					url: 'creation_actions/sales-return/sales_bill_data.php',
					data: 'sales_invno=' + sales_invno,
					success: function ( r ) {
						$( "#table_data" ).html( r );

					}
				} );


			} );
		</script>
		<div class="right-sidebar">
			<div class="slimscrollright">
				<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
				<div class="r-panel-body">
					<ul id="themecolors" class="m-t-20">
						<li><b>With Light sidebar</b> </li>
						<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
						<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
						<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
						<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
						<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
						<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
						<li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
						<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
						<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
						<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
						<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
						<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
						<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
					</ul>
					
				</div>
			</div>
		</div>
	</div>
	
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<script src="assets/plugins/tiny-editable/numeric-input-example.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script>
		$( function () {

			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();


			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );

		$( document ).keyup( function ( e ) {
			if ( e.keyCode === 115 ) {
				window.open( 'sales-bill.php', 'myNewWinsr', 'width=1000,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no' );
			} //esc
		} );
	</script>
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
	<script>
		$( document ).keyup( function ( e ) {
			if ( e.altKey && e.which == 49 ) {
				window.location.href = "creation.php";
			} else if ( e.altKey && e.which == 50 ) {
				window.location.href = "purchase-home.php";
			} else if ( e.altKey && e.which == 51 ) {
				window.location.href = "saleshome.php";
			} else if ( e.altKey && e.which == 52 ) {
				window.location.href = "inventory-home.php";
			} else if ( e.altKey && e.which == 53 ) {
				window.location.href = "accounts-home.php";
			} else if ( e.altKey && e.which == 54 ) {
				window.location.href = "cashcounter-home.php";
			} else if ( e.altKey && e.which == 55 ) {
				window.location.href = "anayisis.php";
			} else if ( e.altKey && e.which == 56 ) {
				window.location.href = "setting-home.php";
			}
			//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
			/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
</body>
</html>