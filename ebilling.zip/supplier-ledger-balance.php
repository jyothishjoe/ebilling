<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$ledger_name=trim($_GET['ledgername']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Customer Ledger</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="assets/auto/all.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">

</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	
				<div class="row page-titles">
					<div class="col-md-12 align-self-center">
					<h3 class="text-themecolor float-left">Supplier Ledger</h3>
						<div class="text-right">
		<!--<a href="supplier-all.php"   class="btn btn-sm btn-danger" style="margin-left:.5em; margin-bottom:5px;">Close</a>-->
	</div>
					</div>
			
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">	
							<div class="card-body">
								 <div class="table-responsive m-t-40">
 									 <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
 									 <?php 
	 									$clsbala = 0;
										$dr_tot = 0;
										$cr_tot = 0;
										$opb = 0;
 						
										$result1 = $db->prepare( "select * from account_ledger WHERE ledger_name='$ledger_name'" );
										$result1->execute();
										$row1 = $result1->fetch();
										$opbalance1 = $row1[ "balance" ];
										$ldgr_tkn = $row1[ "ledger_token" ];
										$account_group=$row1['account_group'];

										$result1 = $db->prepare( "select * FROM account_ledger WHERE ledger_token='$ldgr_tkn'" );
										$result1->execute();
										$row1 = $result1->fetch();
										 $actyp = $row1[ "trans" ];

										if ($actyp == "Dr") {
											$opb = $opb + $opbalance1;
										}else if ( $actyp == "Cr"  ) {
											$opb = $opb + $opbalance1;
										}
										
										$result = $db->prepare( "select * FROM transaction  WHERE ledger_token='$ldgr_tkn' " );
										$result->execute();
										$transaction_count = $result->rowcount();
										for ( $i = 1; $row = $result->fetch(); $i++ ) {

											$dr_amt = $row[ "debit_amt" ];
											$cr_amt = $row[ "credit_amt" ];

											$dr_tot = $dr_tot + $dr_amt;
											$cr_tot = $cr_tot + $cr_amt;

											if ( $actyp == "Dr" ) {
												$opb = $opb;
											}
											if ( $actyp == "Cr" ) {
												$opb = $opb;
											}
										}
										
										$result12 = $db->prepare( "select * from account_ledger" );
										$result12->execute();
										for($i=0; $row12 = $result12->fetch(); $i++){
										$acc_grp = $row12[ "account_group" ];
										} 
										
										?>
										<thead style="font-size: 14px; text-align: center; margin-bottom: 18px;">
									<tr style=" font-size: 15px;  margin-bottom: 18px; border-bottom: 1px 
									#000000">
									<th ></th>
									<th></th>
									
										<th>
											
												
           											<!--<img src="style/img/logo.png" style="width:100px; height:100px; position:absolute;left:10px;top:18px;">
           											<center><br>-->
            										
												
										
										</th>
										<th></th>
										<th></th>
									</tr>
									</thead>
									<thead style="text-align: center">
									<tr style="font-family: Times New Roman">
										<th style="border-bottom: 1px solid grey;"></th>
										<th style="border-bottom: 1px solid grey;">
											<b> Name : <?php echo"".ucwords(strtolower($ledger_name)); ?></b><br>
										</th>
										<th style="border-bottom: 1px solid grey;">
											<b></b><br>
										</th>
										<th style="border-bottom: 1px solid grey;">
											<b></b><br>
										</th>
										<th style="border-bottom: 1px solid grey;"></th>
									</tr>
										 </thead>
										<thead style="font-weight: 600px; text-align: center">
											<tr>
											    <th style="border-bottom: 1px solid grey; width: 10%"><strong>Voucher No</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Date</strong></th>
												<th style="border-bottom: 1px solid grey; width: 35%"><strong>Purcticulars</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Debit</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Credit</strong></th>
											</tr>
											</thead>
										<thead>
										<tr>
										<td ></td>
										<td ></td>
										<td style=" font-size: 15px;"><b>Opening Balance</b></td>
										<td style="text-align: left;">
											<?php if($actyp=="Dr"){ echo number_format($opb,2);  }else { echo ""; } ?>
										</td>
										<td style="text-align: left;">
											<?php if($actyp=="Cr"){ echo number_format($opb,2);  }else { echo ""; }  ?>
										</td>
										</tr>
										</thead>		
                                         <tbody>
										<?php 
	 									
										
	                                    $result_transaction = $db->prepare("select * FROM transaction  WHERE  ledger_name='$ledger_name'   ");
										$result_transaction->execute();
										for($i=0; $row_transaction = $result_transaction->fetch(); $i++){
											
										  $ledger_trans_tkn = $row_transaction['ledger_token'];	
										  $ledger_trans_voucher = $row_transaction['voucher_no'];
										  $ledger_trans_name = $row_transaction['ledger_name'];
											$max_stat= $row_transaction['max_status'];
											$narration= $row_transaction['remarks'];
											
										if($max_stat==2){
					
										$result_max = $db->prepare("select * from transaction WHERE  voucher_no='$ledger_trans_voucher' && max_status='2'");
										$result_max->execute(); 
										$row_max = $result_max->fetch(); 
										$max_cout=$result_max->rowCount();	
										 $max_ldgr=$row_max["ledger_name"];
											
										if($max_ldgr==$ledger_name){
											
										$result1=$db->prepare("select * from transaction WHERE  voucher_no='$ledger_trans_voucher' && ledger_name !='$ledger_name' ");
										$result1->execute();
										for($i1=0; $row1 = $result1->fetch(); $i1++){
							
										$dat=$row1["trn_date"];		 
										$ltkn=$row1['ledger_name'];
										$dr_amt=$row1["debit_amt"]; 
										$cr_amt=$row1["credit_amt"];
										$voucher_no=$row1["voucher_no"];
										$trans_type=$row1["trans_type"];
										?>
								<tr>		
								<td><?php echo $ledger_trans_voucher; ?></td>
								<td><?php echo date("d-m-Y",strtotime($dat)); ?></td>
								<?php 
								$result2 = $db->prepare("select * from account_ledger WHERE  ledger_name='$ltkn'");
								$result2->execute();	for($i2=0; $row2 = $result2->fetch(); $i2++){ if($trans_type != 'purchase return'){  $lname=$row2["ledger_name"];}if($trans_type != 'sales return'){  $lname=$row2["ledger_name"];} if($trans_type =='purchase return'){  $lname='purchase return';}if($trans_type == 'sales return'){  $lname='sales return';} }
								?>
									<td><a href="alter-journal.php?alter=<?php echo $voucher_no; ?>" class=" simple-ajax-popup-align-top" ><?php echo strtoupper($lname); ?></a> <br><?php if($trans_type == 'sales' || $trans_type == 'sales return'){ ?><b>Cash Bill : </b> <?php echo $ledger_trans_voucher; ?> On <?php echo date("d-m-Y",strtotime($dat)); ?><br><?php echo $narration; ?><?php }else{ ?><b>Invoice No : </b><?php echo $ledger_trans_voucher; ?><br><?php echo $narration; ?><?php } ?></td>
								<td data-sortable='true'>
								<?php	
									if($max_cout!=0){
										if($max_ldgr==$ledger_name && $dr_amt==0){ echo $cr_amt; $dr_tot=$dr_tot; }
										//else if($max_ldgr==$ldgr_tkn && $dr_amt!=0){ echo $dr_amt; }
										else if($max_ldgr!=$ledger_name && $dr_amt!=0){ echo $dr_amt; $dr_tot=$dr_tot; }
										else if($max_ldgr!=$ledger_name && $dr_amt==0){ echo $cr_amt; $dr_tot=$dr_tot; }
									}
								?>
							   </td>
								<td>
								   <?php 
									if($max_cout!=0){
											if($max_ldgr==$ledger_name && $cr_amt==0){ echo $dr_amt; $cr_tot=$cr_tot; }
											//else if($max_ldgr==$ldgr_tkn && $cr_amt!=0){ echo $cr_amt; }
											else if($max_ldgr!=$ledger_name && $cr_amt!=0){ echo $cr_amt; $cr_tot=$cr_tot; }
											else if($max_ldgr!=$ledger_name && $cr_amt==0){ echo $dr_amt; $cr_tot=$cr_tot; }
										}
									?>
								</td>
								</tr>
								<?php } } }else{

								$result_max = $db->prepare("select * from transaction where  voucher_no='$ledger_trans_voucher' && max_status='2'");
								$result_max->execute(); $row_max = $result_max->fetch(); 
								$max_cout=$result_max->rowCount();	
								$max_ldgr=$row_max["ledger_name"];

								$ltkn=$max_ldgr;
								$result1=$db->prepare("select * from transaction where  voucher_no='$ledger_trans_voucher' && ledger_name='$ledger_name' ");
								$result1->execute();
								for($i1=0; $row1 = $result1->fetch(); $i1++){

								$dat=$row1["trn_date"];		 //$ltkn=$row1['ldgr_tkn'];
								$dr_amt=$row1["debit_amt"]; $cr_amt=$row1["credit_amt"];
									$trans_type=$row1['trans_type'];
								?>
								<tr>
								<td><?php echo $ledger_trans_voucher; ?></td>
								<td><?php echo date("d-m-Y",strtotime($dat)); ?></td>
								<?php 
								$result2 = $db->prepare("select * from account_ledger where  ledger_name='$ledger_name'");
								$result2->execute();	for($i2=0; $row2 = $result2->fetch(); $i2++){ if($trans_type != 'purchase return'){  $lname=$row2["ledger_name"];}if($trans_type != 'sales return'){  $lname=$row2["ledger_name"];} if($trans_type =='purchase return'){  $lname='purchase return';}if($trans_type == 'sales return'){  $lname='sales return';} }
								?>
									<td><a href="alter-journal.php?alter=<?php echo $row1['voucher_no']; ?>" class=" simple-ajax-popup-align-top" ><?php echo strtoupper($max_ldgr); ?></a><br><?php if($trans_type == 'sales' || $trans_type == 'sales return'){ ?><b>Cash Bill : </b> <?php echo $ledger_trans_voucher; ?> On <?php echo date("d-m-Y",strtotime($dat)); ?><br><?php echo $narration; ?><?php }else{ ?><b>Invoice No : </b><?php echo $ledger_trans_voucher; ?><br><?php echo $narration; ?><?php } ?></td>
								<td>
								<?php	
										if($max_cout!=0){
											if($max_ldgr==$ledger_name && $dr_amt==0){ echo $cr_amt; $dr_tot=$dr_tot; }
											else if($max_ldgr==$ledger_name && $dr_amt!=0){ echo $dr_amt; $dr_tot=$dr_tot; }
											else if($max_ldgr!=$ledger_name && $dr_amt!=0){ echo $dr_amt; $dr_tot=$dr_tot; }
										   //else if($max_ldgr!=$ldgr_tkn && $dr_amt==0){ echo $cr_amt; }
										}
									?>
							   </td>
							   <td>
									<?php 
									if($max_cout!=0){
											if($max_ldgr==$ledger_name && $cr_amt==0){ echo $dr_amt; $cr_tot=$cr_tot; }
											else if($max_ldgr==$ledger_name && $cr_amt!=0){ echo $cr_amt; $cr_tot=$cr_tot; }
											else if($max_ldgr!=$ledger_name && $cr_amt!=0){ echo $cr_amt; $cr_tot=$cr_tot; }
											//else if($max_ldgr!=$ldgr_tkn && $cr_amt==0){ echo $dr_amt; }
										}
									?>
								</td>
								</tr>
								<?php } } } ?>
									<tfoot>
									<tr>
									<td></td>
										<td></td>
										<td style=" font-size: 15px; padding-right: 5px;" align="right"><b>Closing Balance</b>
										</td>
										<?php if($actyp=="Dr"){ $cl_bal=$dr_tot-$cr_tot; }if($actyp=="Cr"){ $cl_bal=$cr_tot-$dr_tot; }?>
										<td><b><?php if($actyp=="Dr"){ echo number_format($cl_bal,2); } else { echo ""; } ?></b></td>
										<td><b><?php if($actyp=="Cr"){ echo number_format($cl_bal,2); } else { echo ""; } ?></b></td>
									</tr>
									</tfoot>
									<tfoot>
									<tr>
										<td></td>
										<td ></td>
										<td style="font-size: 15px;" align="right"><b>Total Amount</b>
										</td>
										<td><b><?php echo number_format($dr_tot,2); ?></b></td>
										<td ><b><?php echo number_format($cr_tot,2); ?></b></td>
									</tr>
									</tfoot>
										</tbody>
									  
									</table>
								</div>
							</div>
						</div>
				
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_COOKIE['NC']) && $_COOKIE['NC'] == true){ ?> 
<script> 
	$(document).ready(function(){
		$("#cashclick").click();
		$.toast({
			heading: 'Payment Saved Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	}); </script><?php } ?>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<!--select-->
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	 <script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
		<?php include ('include/disable_fn.php'); ?>
	<script>
$(document).ready(function() {
$('.simple-ajax-popup-align-top').magnificPopup({
type: 'ajax',
alignTop: false,
closeOnBgClick: false,
openDelay: 800,
overflowY: 'scroll'

});
$('.simple-ajax-popup').magnificPopup({
type: 'ajax'
});

});	
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			bSort: false,
			paging: false,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
			
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
	

	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>