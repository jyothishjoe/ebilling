<?php
include('include/auth.php');
include('db-connect/db.php');
include('include/today.php');
$userid=$_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];

$date_set = $today;

?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Estimate</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id='navbar'>
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor" style="float: left;">Purchase Estimate&nbsp; <strong>(<?php echo $today = date('d-m-Y'); ?>)</strong> </h4>
					</div>
					<div class="col-md-7 align-self-center"style="z-index:9 !important;">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item active"><a href="purchase-home.php">Purchase</a></li>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<a href="add-supplier.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="opensupplier">Add Supplier(F2)</a>
								<a href="add-product.php" class="btn btn-sm btn-info simple-ajax-popup-align-top" id="openproduct">Add Product(F3)</a>
								<a href="add-purchase-order.php" class="btn btn-sm btn-info" id="openpurchaseorder">Purchase Order(F4)</a>
								<a href="vendor-payment.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="vendor-payment">Vendor Payment (F6)</a>
								<?php
								$result_bill = $db->prepare("SELECT * FROM purchase_estimate WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
								$result_bill->execute();
								$rows_bill = $result_bill->fetch();
								$row_count = $result_bill->rowCount();
								$prefix = 'PE';
								if($row_count == 0){
								$invno = 'PE1';
								$invno1 = '1';
								}else{
								$invno =sprintf( "%s%1s", $prefix, $rows_bill['id'] + 1);
								$invno1 =$rows_bill['id'] + 1;
								}
								?>
								<div class="clear"></div>
								<hr/>
								<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
									<div class="form-row">
										<div class="col-md-4 col-sm-6 col-xs-12 mb-1">
											<div class="row">
													<label for="" class="control-label" style="margin-left: 12px;">PE No:</label>
												<div class="col-md-4 col-sm-6 col-xs-12 mb-3">
													<input type="hidden" class="form-control" id="invno" name="invno" value="<?php echo $invno; ?>" readonly>
													<input type="text" class="form-control" id="invno1" name="invno1" value="<?php echo $invno1; ?>" readonly>
													<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>" readonly>
													
												</div>
											</div>
										</div>
										<div class="col-md-4 col-sm-6 col-xs-12"></div>
										<div class="col-md-2 col-sm-6 col-xs-6 mb-3">
											<input type="date" class="form-control" id="date" name="date" value="<?= $date_set; ?>" >
										</div>
										<div class="col-md-2 col-sm-6 col-xs-6 mb-3">
											<input type="time" class="form-control" id="time" name="time" value="<?php echo $current_time;?>" readonly>
										</div>
										</div>
									       <div class="form-row">
										        <div class="col-md-3 col-sm-6 col-xs-12  mb-3">		
													<select class="form-control select2" id="v_name" name="v_name" style="width: 100%; height:16px;">
														<option>Supplier Name</option>
														<?php
														$result_vendor = $db->prepare("SELECT * FROM supplier ");
														$result_vendor->execute();
														for ($i = 0; $rows_vendor = $result_vendor->fetch(); $i++) {
														?>
														<option value="<?php echo $rows_vendor['v_name']; ?>">
															<?php echo $rows_vendor['v_name']; ?>
														</option>
														<?php } ?>
													</select>
												</div>
													<input type="hidden" class="form-control" name="company" id="company" placeholder="Company">
													<input type="hidden" class="form-control" name="state" id="state" placeholder="Company">
													<input type="hidden" class="form-control" name="supgst" id="supgst" placeholder="supgst">
													<input type="hidden" class="form-control" name="phone" id="phone" placeholder="Address">
													<input type="hidden" class="form-control" name="supid" id="supid" placeholder="Supplier Name">
												  	<input type="hidden" class="form-control" name="suptoken" id="suptoken" placeholder="Supplier NTokename">
												  	<input type="hidden" class="form-control" name="token" id="token" placeholder="Supplier NTokename">
												  	<input type="hidden" class="form-control" name="purchase_ledger" id="purchase_ledger" value="" placeholder="Supplier NTokename">
											   <div class="col-md-3 col-sm-6 col-xs-12 mb-3 ">
													<input type="text" class="form-control" name="location" id="location"  placeholder="Location">
											   </div>
											</div>
										   	<div class="form-row">
										       <div class="col-md-3 col-sm-6 col-xs-12 mb-3 ">
													<textarea type="text" class="form-control" name="address" id="address"  placeholder="Address" rows="5"></textarea>
											   </div>
									    	<div class="col-md-3 col-sm-6 col-xs-12 mb-3 ">
												<select class="form-control select2" id="order_no" name="order_no" style="width: 100%; height:16px; margin-bottom:5px; ">
														<option>Purchase Order No</option>
														<?php
														$result_vendor1 = $db->prepare("SELECT * FROM purchaseorder_invoice ");
														$result_vendor1->execute();
														for ($i = 0; $rows_vendor1 = $result_vendor1->fetch(); $i++) {
														?>
														<option value="<?php echo $rows_vendor1['po_no']; ?>">
															<?php echo $rows_vendor1['po_no']; ?>
														</option>
														<?php } ?>
													</select>
												<input type="date" value="<?= $date_set ?>" class="form-control" name="billdate" id="billdate" style="margin-top: 8px;"  placeholder="Invoice Date">
												<input type="text" class="form-control" name="billno" id="billno"  placeholder="Supplier Invoice Number" style="margin-top: 8px;">
												</div>
												<!--<div class="col-md-3">
												<input type="button" name='' id='get_data' class="btn btn-sm btn-info" value="Get Bill"></button>
												</div>-->
										   </div>
										<div class="form-row">
											<div class="col-md-6 col-sm-6 col-xs-12 mb-3 ">
												<textarea type="text" class="form-control" name="remarks" id="remarks"  placeholder="Remarks" rows="2"></textarea>
											  </div>
										</div>
							<hr/>
							<div class="col-md-12">
								<h4>Product Details</h4>		
							</div>
							<hr/>
							<!---Table-->
							<div class="col-sm-12 col-xs-12 " style="overflow-x: auto;" id='bill_data' >
								<table class="table table-bordered" style="min-width: 1100px;" >
									<thead>
										<tr>
											<th style="width: 58px;">Sl No</th>
											<th style="width: 100px;">Code</th>
											<th style="width: 135px;">Item Name</th>
											<th style="width: 135px;">Location</th>
											<th style="width: 75px;">Batch</th>
											<th style="width: 55px;">Expairy</th>
											<th style="width: 75px;">HSN</th>
											<th style="width: 100px;">Unit</th>
											<th style="width: 85px;">Rate</th>
											<th style="width: 70px;">GST%</th>
											<th style="width: 75px;">Qty</th>
											<th style="width: 70px;">Disc%</th>
											<!--<th>Gross</th>
											<th>GST</th>
											<th>Other Tax</th>-->
											<th style="width: 140px;">Total</th>
											<th style="float: right;"><input type="button" id="addmore" name="button" class="btn btn-sm btn-info" value="+">
											</button>
											</th>
										</tr>
									</thead>
									<tbody id="purchase">
										<?php $k = 1; ?>
										<tr class='tr_input'>
											<td><input type='text' style="width: 40px;" tabindex="-1" class="form-control serial" name="serial" id='serial_1' value="<?= $k; ?>" placeholder='Product Code'></td>
											<td><input type='text' class="form-control code" name="code[]" id='code_1' placeholder=' Code'></td>
											<td><input type='text' class="form-control name" name="name[]" id='name_1' placeholder='Product Name'></td>
											<td><input type='text' class="form-control location_name" id="location_name_1" name="location_name[]" ><input type='hidden' class="form-control location_tkn" id="location_tkn_1" name="location_tkn[]" ></td>
											<td><input type='text' class="form-control batch" name="batch[]" id='batch_1' placeholder='Batch'></td>
											<td><input type='date' class="form-control expairy" name="expairy[]" id='expairy_1'></td>
											<td><input type='text' class="form-control hsn" name="hsn[]" id='hsn_1' placeholder='HSN'></td>
											<td><input type='text' class="form-control unit" name="unit[]" id='unit_1' placeholder='Unit'></td>
											<td><input type='text' class="form-control purchprice" name="purchprice[]" id='purchprice_1' placeholder='Purchase Price'></td>
											<td><input type='text' tabindex="-1" class="form-control gstin" name="gstin[]" id='gstin_1' placeholder='GST%' >
												<input type='hidden' class="form-control gstinperc" name="gstinperc[]" id='gstinperc_1' placeholder='GST%'>
												<input type='hidden' class="form-control gstincgst" name="gstincgst[]" id='gstincgst_1' placeholder='GST%'>
												<input type='hidden' class="form-control gstincgstamt" name="gstincgstamt[]" id='gstincgstamt_1' placeholder='GST%'>
												<input type='hidden' class="form-control gstinsgstamt" name="gstinsgstamt[]" id='gstinsgstamt_1' placeholder='GST%'>
										   		<!--Other Tax Amounts-->
										        <input type='hidden' class="form-control othertax_amount1" name="othertax_amount1[]" id='othertax_amount1_1' value="0" >
										        <input type='hidden' class="form-control othertax_amount2" name="othertax_amount2[]" id='othertax_amount2_1' value="0" >
										        <input type='hidden' class="form-control othertax_amount3" name="othertax_amount3[]" id='othertax_amount3_1' value="0" >
										        <input type='hidden' class="form-control othertax_amount4" name="othertax_amount4[]" id='othertax_amount4_1' value="0" >
										        <input type='hidden' class="form-control othertax_amount5" name="othertax_amount5[]" id='othertax_amount5_1' value="0" >
											    <!--IGST-->
												<input type='hidden' class="form-control igstamt" name="igstperc[]" id='igstperc_1' placeholder='GST%'>
												<input type='hidden' class="form-control igstamt" name="igstamt[]" id='igstamt_1' placeholder='GST%'>
												<!--Taxable Non Taxable-->
												<input type='hidden' class="form-control purchase_token" name="purchase_token[]" id='purchase_token_1' placeholder='GST%'>
												<input type='hidden' class="form-control ledger_name" name="ledger_name[]" id='ledger_name_1' placeholder='GST%'>
												<!--Other Tax -->
												<input type='hidden' class="form-control othertax_amt1" name="othertax_amt1[]" id='othertax_amt1_1' value="0">
												<input type='hidden' class="form-control othertax_amt2" name="othertax_amt2[]" id='othertax_amt2_1' value="0" >
												<input type='hidden' class="form-control othertax_amt3" name="othertax_amt3[]" id='othertax_amt3_1' value="0" >
												<input type='hidden' class="form-control othertax_amt4" name="othertax_amt4[]" id='othertax_amt4_1' value="0" >
												<input type='hidden' class="form-control othertax_amt5" name="othertax_amt5[]" id='othertax_amt5_1' value="0" >
												<!--Other Tax Type-->
												<input type='hidden' class="form-control othertax_typ1" name="othertax_typ1[]" id='othertax_typ1_1' value="0">
												<input type='hidden' class="form-control othertax_typ2" name="othertax_typ2[]" id='othertax_typ2_1' value="0" >
												<input type='hidden' class="form-control othertax_typ3" name="othertax_typ3[]" id='othertax_typ3_1' value="0" >
												<input type='hidden' class="form-control othertax_typ4" name="othertax_typ4[]" id='othertax_typ4_1' value="0" >
												<input type='hidden' class="form-control othertax_typ5" name="othertax_typ5[]" id='othertax_typ5_1' value="0" >
											</td>
											<td><input type='text' class="form-control qty" name="qty[]" id='qty_1' placeholder='Qty'></td>
											<td><input type='text' class="form-control discount" name="discount[]" id='discount_1' placeholder='Discount'>
												<input type='hidden' class="form-control discounttotal" name="discounttotal" id='discounttotal_1' placeholder='Discount'>
												<input type='hidden' class="form-control totalcost" name="totalcost[]" id='totalcost_1' placeholder=''>
												<input type='hidden' class="form-control unitprice" name="unitprice[]" id='unitprice_1' placeholder=''>
												<!--Gross Amount / other Tax total / gst amt/ -->
												<input type='hidden' class="form-control gross" name="gross[]" id='gross_1' placeholder='Gross'>
												<input type='hidden' class="form-control gst" name="gst[]" id='gst_1' placeholder='GST'>
												<input type='hidden' class="form-control taxrate_amount" name="taxrate_amount[]" value="0" id='taxrate_amount_1'>
											</td>
											<td>
											    <input type='text' class="form-control total" name="total[]" id='total_1' placeholder='Total'>
												<input type='hidden' class="form-control totalt" name="totalt" id='totalt_1' placeholder='Unit Cost'>
											</td>
											<td></td>
										</tr>
									</tbody>
								</table>
							 
							<table class="table">
								<tr>
									<td align="right" class="control-label">Discount:</td>
									<td width="70">
										<input type="text" readonly class="form-control" name="discountt" id="discountt" placeholder="Discount" style="width:120px;">
										<input type="hidden" readonly class="form-control" name="discounttt" id="discounttt" placeholder="Discount" value="0" style="width:120px;">
									</td>
									<td align="right" class="control-label">GST Total:</td>
									<td width="50"><input type="text" readonly class="form-control totalgst" name="totalgst" id="totalgst"></td>
									
									<td align="right" class="control-label">Grand Total:</td>
									<td width="150"><input type="text" readonly class="form-control totalprice" name="totalprice" id="totalprice">
									</td>
								</tr>
								<tr>
									<td style=" font-stretch:expanded;" align="right" class="control-label">Freight:</td>
									<td width="100">
										<input type="text" value="0" class="form-control" name="coolie" id="coolie" placeholder="Coolie" style="width:120px;">
										<input type="hidden" value="0" class="form-control" name="qtyt" id="qtyt" placeholder="Qtytotal" style="width:120px;">
										<input type="hidden" value="0" class="form-control" name="fright" id="fright" placeholder="frighttotal" style="width:120px;">
									</td>
									<td style=" font-stretch:expanded;" align="right" class="control-label">Other Tax:</td>
									<td width="50">
									<!--Other Tax  Total SUM-->
									<input type="text" readonly class="form-control other_tax_total_amount" name="other_tax_total_amount" id="other_tax_total_amount" value="0">
									<input type="hidden" readonly class="form-control taxable" name="taxable" id="taxable">
									<input type="hidden" readonly class="form-control nontaxable" name="nontaxable" id="nontaxable">
									</td>
									<td align="right" class="control-label">Net Amount:</td>
									<td width="100"><input type="text" readonly class="form-control" value="0" name="gtotalprice" id="gtotalprice" placeholder="Grant Total" style="width:150px;">
									</td>
									<tr id="show1" style="">
									<td align="right" class="control-label">Balance:</td>
									<td style="width:150px;"><input type="text" readonly class="form-control"  name="balance_amt" id="balance_amt" placeholder="Balance" value="0" style="width:120px;">
									<td align="right" class="control-label">Paid Amount:</td>
									<td width="100"><input type="text" class="form-control" name="paidamount" id="paidamount"  placeholder="Paid Amount" value="0" style="width:150px;">
									<td align="right" class="control-label">Pay Mode:</td>
									<td width="100">
									<select class="form-control" id="paymode" name="paymode" style="width: 100%; height:33px;">
									<option value="cash">Cash</option>
									<option value="bank">Bank</option>
									</select>	
									</td>	
									</td>
									</tr>
								</tr>
								<tr>
									<td align="right" class="control-label"></td>
									<td width="100"><input type="hidden" readonly class="form-control" value="0" name="balance" id="balance" placeholder="Balance" style="width:120px;">
									</td>
									<td align="right" class="control-label"></td>
									<td width="150">
									</td>
								</tr>
							</table>
							</div>
							<div class="col-md-12" style="margin-bottom: 25px;">
								<input type="submit" name="submit" id="submit" style="float: right; margin-top: 25px;" class="btn btn-sm btn-info" value="Submit"/>
								<a href="estimate-confirm.php?date=<?php echo $today; ?>&no=<?php echo $invno; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top" id="savedata" style="display: none">Save</a>
								
							</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php  if(isset($_COOKIE['PR']) && $_COOKIE['PR'] == true){ ?> <script> $(document).ready(function(){
						
						//$("#clickadd").click();
						var url = 'add-product.php';
						 $.ajax({
						type: "POST",
						url: url,
						success: function(result) {
							$('.simple-ajax-popup-align-top').magnificPopup({
								 midClick: true,
								  mainClass: 'mfp-fade',
								  closeOnBgClick: false, 
								items: {
									src: result,
									
								}
							}).magnificPopup('open');
						},
					});
						$.toast({heading: 'Product Created Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
						});
						}); </script><?php } ?>
	<div id="sa-success"></div>

	<script>

		$( window ) . keydown( function ( event ){
			
			if ( event . keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "add-supplier.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					});
				}, 200 );
				/*$.fancybox({
				
				href: 'add-supplier.php',
				type: 'ajax'
			});*/
				
		    }
			if ( event . keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#openproduct').click();
				/*var  url = 'add-product.php';

				$.ajax({
					type: "POST",
					url: url,
					success: function(result) {
						$('.simple-ajax-popup-align-top').magnificPopup({
							alignTop: true,
							overflowY: 'scroll',
							items: {
								src: result,
								type: 'inline'
							}
						}).magnificPopup('open');
					},
				});*/
			}
			if ( event . keyCode == 115 ){
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="add-purchase-order.php";
			}
		});
		
		
		
		$(document).ready(function () {
			$( '#get_data' ).hide();
			$('#order_no').keyup(function (){
			var order_no = $( '#order_no' ).val();
			if(order_no == ''){
			$( '#get_data' ).hide();	
			}else if(order_no != ''){
			 $( '#get_data' ).show();	
			}
			});
			 $( '#v_name' ).focus();
			 $( '.qty' ).keyup();
			new Date($.now());
			var dateObj = new Date();
			var time = dateObj.getHours() + ":" + dateObj.getMinutes() + ":" + dateObj.getSeconds();
			var AMorPM = (dateObj.getHours() >= 12) ? "PM" : "AM";
			$('#timer').val(time + AMorPM);
		});
		/*Supplier Details Search */
		$(function () {
			$("#v_name").autocomplete({
				source: "purchase-action/sup_search.php",
				select: function (event, ui) {
					event.preventDefault();
					$("#v_name").val(ui.item.value);
				}
			});
		});
		$('#v_name').change(function (){
			var v_name = $("#v_name").val();
			$.ajax({
				type: 'POST',
				url: 'purchase-action/sup_phone_change.php',
				data: 'v_name=' + v_name,
				dataType: "JSON",
				success: function (data) {
					$('#phone').val(data.phone);
					$('#supid').val(data.sup_id);
					$('#company').val(data.company);
					$('#supgst').val(data.supgst);
					$('#address').val(data.address);
					$('#state').val(data.state);
					$('#suptoken').val(data.sup_tkn);
					$('#location').val(data.city);
					$('#purchase_ledger').val(data.token);
				}
			});
		});
		//addRowCount('.js-serial');
		function setFocusToTextBox() {
			$("#code_1").focus();
		}
		
	</script>
	<script type="text/javascript">
		//=================================================
		/*Product Code Wise Search and Auto fill datas */
		//=================================================
		$(document).ready(function () {
		
			$(document).on('keydown', '.code', function () {
				var id = this.id;
				var splitid = id.split('_');
				var index = splitid[1];

				$('#' + id).autocomplete({
					source: function (request, response) {
						$.ajax({
							url: "purchase-action/autosearch_purchase/purchasefill.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 1
							},
							success: function (data){
								response(data);
							}
						});
					},
					select: function (event, ui) {
						$(this).val(ui.item.label); // display the selected text
						var pr_code = ui.item.value; // selected id to input
						// AJAX
						$.ajax({
							url: 'purchase-action/autosearch_purchase/purchasefill.php',
							type: 'post',
							data: {
								pr_code: pr_code,
								request: 2
							},
							dataType: 'json',
							success: function (response) {
								var len = response.length;
								if (len > 0) {
									if(response[0]['pr_code'] != ''){
									var pr_code = response[0]['pr_code'];
									
									var pr_name = response[0]['pr_name'];
										document.getElementById('name_' + index).value = pr_name;
									
									var pr_hsn = response[0]['pr_hsn'];
										document.getElementById('hsn_' + index).value = pr_hsn;
									
									var tax = response[0]['tax_gst'];
										document.getElementById('gstin_' + index).value = tax;
									
									var pr_unit = response[0]['pr_unit'];
										document.getElementById('unit_' + index).value = pr_unit;
									
										var purchase_price = response[0]['purchase_rate'];
										document.getElementById('purchprice_' + index).value = purchase_price;
										
									var purchase_ledger = response[0]['purch_ledger'];
										document.getElementById('purchase_token_' + index).value = purchase_ledger;
									
									var ledger_name = response[0]['ledger_name'];
										document.getElementById('ledger_name_' + index).value = ledger_name;
										document.getElementById('qty_' + index).focus();
									}
									
									//Other Tax Values
									document.getElementById('othertax_amt1_' + index).value = 0;
									document.getElementById('othertax_amt2_' + index).value = 0;
									document.getElementById('othertax_amt3_' + index).value = 0;
									document.getElementById('othertax_amt4_' + index).value = 0;
									document.getElementById('othertax_amt5_' + index).value = 0;
									document.getElementById('othertax_typ1_' + index).value = 0;
									document.getElementById('othertax_typ2_' + index).value = 0;
									document.getElementById('othertax_typ3_' + index).value = 0;
									document.getElementById('othertax_typ4_' + index).value = 0;
									document.getElementById('othertax_typ5_' + index).value = 0;
								    
									if(response[0]['tax_rate'] != ''){
										var other_tax1 = response[0]['tax_rate'];
										var othertax_typ1 = response[0]['o_tax_type'];
										document.getElementById('othertax_typ1_' + index).value = othertax_typ1;
										document.getElementById('othertax_amt1_' + index).value = other_tax1;
									} 
									if(response[1]['tax_rate'] != ''){
										var other_tax2 = response[1]['tax_rate'];
										var othertax_typ2 = response[1]['o_tax_type'];
										document.getElementById('othertax_typ2_' + index).value = othertax_typ2;
										document.getElementById('othertax_amt2_' + index).value = other_tax2;
									} 
									if(response[2]['tax_rate'] != ''){
										var other_tax3 = response[2]['tax_rate'];
										var othertax_typ3 = response[2]['o_tax_type'];
										document.getElementById('othertax_typ3_' + index).value = othertax_typ3;
										document.getElementById('othertax_amt3_' + index).value = other_tax3;
									} 
									if(response[3]['tax_rate'] != ''){
										var other_tax4 = response[3]['tax_rate'];
										var othertax_typ4 = response[3]['o_tax_type'];
										document.getElementById('othertax_typ4_' + index).value = othertax_typ4;
										document.getElementById('othertax_amt4_' + index).value = other_tax4;
									} 
									if(response[4]['tax_rate'] != ''){
										var other_tax5 = response[4]['tax_rate'];
										var othertax_typ5 = response[4]['o_tax_type'];
										document.getElementById('othertax_typ5_' + index).value = othertax_typ5;
										document.getElementById('othertax_amt5_' + index).value = other_tax5;
									}
								}
							}
						});
						return false;
					}
				});
				
		
				
				
				var state = $('#state').val();
                if(state = 'Kerala'){
					
				$(".qty, purchprice").keyup(function () {
					$('#gross_' + index).val($('#purchprice_' + index).val() * $('#qty_' + index).val());
					$('#gst_' + index).val($('#purchprice_' + index).val() * $('#gstin_' + index).val() / 100 * $('#qty_' + index).val());
					//GST + Other Taxes calculation
					if($('#othertax_amt1_' + index ).val() != 0){
                  	$('#othertax_amount1_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt1_' + index) .val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt2_' + index ).val() != 0){
                  	$('#othertax_amount2_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt3_' + index ).val() != 0){
                  	$('#othertax_amount3_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt4_' + index ).val() != 0){
                  	$('#othertax_amount4_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt5_' + index ).val() != 0){
                  	$('#othertax_amount5_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					//Other Tax product wise Total
					$('#taxrate_amount_' + index ).val(parseFloat($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()));
					//Total Amounts Of products each Row
					$('#total_' + index ).val(parseFloat($('#gross_' + index).val()) + parseFloat($('#gst_' + index).val()) + parseFloat($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()) );
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()));
					//GST SEPARATION CGST, SGST, IGST
					$('#gstinperc_' + index).val(parseInt($('#gstin_' + index).val()) / 2);
					$('#gstincgst_' + index).val(parseInt($('#gstin_' + index).val()) / 2);
					$('#gstincgstamt_' + index).val(parseInt($('#gst_' + index).val()) / 2);
					$('#gstinsgstamt_' + index).val(parseInt($('#gst_' + index).val()) / 2);

					var sum = 0; var qtysum = 0; var gst = 0; var tot = 0; var totgst = 0; var taxable = 0;
					var nontaxable = 0; var gstinvalue = $('#gstin_' + index).val(); var qtygst = $('#qty_' + index).val();
					var other_taxtot =0;
					//taxable
					 if(gstinvalue != 0){
					 $('.total').each(function () {
					 if (!isNaN(this.value) && this.value.length != 0) {
						taxable += parseFloat(this.value);
						}
							});
						document.getElementById('taxable').value = Math.round(taxable); 
					}
					//nontaxable
					  if(gstinvalue == 0){
						  //alert(gstinvalue);
						$('.total' ).each(function () {
						if (!isNaN(this.value) && this.value.length != 0){
							nontaxable += parseFloat(this.value);
						}
					});
					document.getElementById('nontaxable').value = Math.round(nontaxable);	
					}
				
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							sum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(sum);
					
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qtysum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(qtysum);
					
					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseFloat(this.value);
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
					var qttotal = 0;

					$('.qty').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qttotal += parseFloat(this.value);
						}
					});
					document.getElementById('qtyt').value = Math.round(qttotal);
					//=====================================
					//Total GST Amount
					$('.gst').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('totalgst').value = Math.round(totgst);
					//=====================================
					//Other Tax Total amounts
				    $('.taxrate_amount').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							other_taxtot += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total_amount').value = Math.round(other_taxtot);
					//=======================================
					
				});
					
					
				}else{
				$(".qty, .purchprice").keyup(function () {
				/* IGST Calculation */	
					$('#gross_' + index).val($('#purchprice_' + index).val() * $('#qty_' + index).val());
					$('#gst_' + index).val($('#purchprice_' + index).val() * $('#gstin_' + index).val() / 100 * $('#qty_' + index).val());
					//GST + Other Taxes calculation
					if($('#othertax_amt1_' + index ).val() !=0){
                  	$('#othertax_amount1_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt1_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt2_' + index ).val() !=0){
                  	$('#othertax_amount2_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt3_' + index ).val() !=0){
                  	$('#othertax_amount3_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt4_' + index ).val() !=0){
                  	$('#othertax_amount4_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt5_' + index ).val() !=0){
                  	$('#othertax_amount5_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					$('#total_' + index).val(parseInt($('#gross_' + index).val()) + parseInt($('#gst_' + index).val()) + parseInt($('#othertax_amount1_' + index).val()) + parseInt($('#othertax_amount2_' + index).val()) + parseInt($('#othertax_amount3_' + index).val()) + parseInt($('#othertax_amount4_' + index).val()) + parseInt($('#othertax_amount5_' + index).val()) );
					//$( '#gstcesssum_' + index ).val( $( '#purchprice_' + index ).val() * ($( '#gstcess_' + index ).val()) / 100 * $('#qty_' + index).val() );
					//$('#total_' + index).val(parseInt($('#gross_' + index).val()) + parseInt($('#gst_' + index).val()) + parseInt($('#gstcesssum_' + index).val()) );
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()));
					$('#igstperc_' + index).val(parseInt($('#gstin_' + index).val()));
					$('#igstamt_' + index).val(parseInt($('#gst_' + index).val()));
					
					var sum = 0;
					var qtysum = 0;
					var gst = 0;
					var tot = 0;
					var totgst = 0;
					var cesstot = 0;
					var othertaxtot1 = 0; var othertaxtot2 = 0; var othertaxtot3 = 0; var othertaxtot4 = 0; var othertaxtot5 = 0;
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							sum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(sum);
					
						var gstinvalue = $('#gstin_' + index).val();
					//taxable
					 if(gstinvalue != '0')
						 {
							$('#total_' + index).each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							taxable += parseFloat(this.value);
						}
					});
					
						 }
					document.getElementById('taxable').value = Math.round(taxable); 
					//nontaxable
					if(gstinvalue <= '0'){
						$('#total_' + index).each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							nontaxable += parseFloat(this.value);
						}
					});
					}
					
					document.getElementById('nontaxable').value = Math.round(nontaxable);
					
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qtysum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(qtysum);
					
					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseFloat(this.value);
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
					var qttotal = 0;

					$('.qty').each(function () {

						if (!isNaN(this.value) && this.value.length != 0) {
							qttotal += parseFloat(this.value);
						}
					});
					document.getElementById('qtyt').value = Math.round(qttotal);
					//=====================================
					//Total GST Amount
					$('.gst').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('totalgst').value = Math.round(totgst);
					//=====================================
					//Other Tax Total amounts
					$('.othertax_amount1').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					var tax1 = document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					$('.othertax_amount2').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot2 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					var tax2 = document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					$('.othertax_amount3').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot3 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					var tax3 = document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					$('.othertax_amount4').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot4 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					var tax4 = document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					$('.othertax_amount5').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot5 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					var tax5 = document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					//Total Amount
					document.getElementById('other_tax_total_amount').value = Math.round(tax1 + tax2 + tax3 + tax4 + tax5);
					//===============================
					
					/* Discount Key Calculation   */
				$('.discount').keyup(function () {
                            
					$('#discounttotal_' + index).val(parseInt($('#gross_' + index).val()) - parseInt($('#gross_' + index).val()) + parseInt($('#gross_' + index).val()) * parseInt($('#discount_' + index).val()) / 100);
					
					var disa = 0;
					var dis = 0;
					var tot = 0;
					
					$('.discounttotal').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							dis += parseFloat(this.value);
						}
					});
					document.getElementById('discountt').value = Math.round(dis);

					$('#totalcost_' + index).val(parseInt($('#total_' + index).val()) - parseInt($('#discounttotal_' + index).val()));
					$('#unitprice_' + index).val(parseInt($('#totalcost_' + index).val()) / parseInt($('#qty_' + index).val()));

					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseInt($('#totalprice').val()) - parseInt($('#discountt').val());
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
				});
				$('#coolie').keyup(function () {

					$('#fright').val(parseInt($('#coolie').val()) / parseInt($('#qtyt').val()));
					
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()) + parseInt($('#fright').val()));
					$('#gtotalprice').val(parseInt($('#coolie').val()) + parseInt($('#totalprice').val()));
				});
				$('#paidamount').keyup(function () {

					$('#balance_amt').val(parseInt($('#gtotalprice').val()) - parseInt($('#paidamount').val()));
				});
					
					
					
				});
				}
	
				/* Discount Key Calculation   */
				$('.discount').keyup(function () {

					$('#discounttotal_' + index).val(parseInt($('#gross_' + index).val()) - parseInt($('#gross_' + index).val()) + parseInt($('#gross_' + index).val()) * parseInt($('#discount_' + index).val()) / 100);
					var disa = 0;
					var dis = 0;
					var tot = 0;
					
					$('.discounttotal').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							dis += parseFloat(this.value);
						}
					});
					document.getElementById('discountt').value = Math.round(dis);

					$('#totalcost_' + index).val(parseInt($('#total_' + index).val()) - parseInt($('#discounttotal_' + index).val()));
					$('#unitprice_' + index).val(parseInt($('#totalcost_' + index).val()) / parseInt($('#qty_' + index).val()));

					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseInt($('#totalprice').val()) - parseInt($('#discountt').val());
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
				});
				$('#coolie').keyup(function () {

					$('#fright').val(parseInt($('#coolie').val()) / parseInt($('#qtyt').val()));
					
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()) + parseInt($('#fright').val()));
					$('#gtotalprice').val(parseInt($('#coolie').val()) + parseInt($('#totalprice').val()));
				});
				$('#paidamount').keyup(function () {

					$('#balance_amt').val(parseInt($('#gtotalprice').val()) - parseInt($('#paidamount').val()));
				});
				/* End Discount Key Calculation   */
			});
			
		/*=================//Location Name fetch========================================*/
		$(document).on('keydown', '.location_name', function () {
				var id = this.id;
				var splitid = id.split('_');
				var index = splitid[1];
			
			$( '#' + id ).autocomplete({
				source: function ( request, response ) {
					$.ajax( {
						url: "purchase-action/location-fill.php",
						type: 'post',
						dataType: "json",
						data: {
							search: request.term,
							request: 1
						},
						success: function ( data ) {
							response( data );
						}
					} );
				},
				select: function ( event, ui ) {
					$( this ).val( ui.item.label ); // display the selected text
					var location = ui.item.value;
					var tkn = ui.item.label;
					
					// selected id to input
					// AJAX
					$.ajax( {
						url: 'purchase-action/location-fill.php',
						type: 'post',
						data: {
							location: location,
							request: 2
						},
						dataType: 'json',
						success: function ( data ){

								//var location_tkn = response.location_tkn;
								
								var loc = data.location_tkn;
							document.getElementById('location_tkn_' + index).value = loc;
							
						}
					} );
					return false;
				}
			} );
		});
			/*============================== Tab index properties ============================== */
			
					 $( window ).on('keydown', '.qty', function ( event ) {
						var id = this.id;
						var splitid = id.split('_');
						var index = splitid[1];
						 console.log(id);
						var total = $( '#total_' + index ).val(); 
						//var credit_amt = $( '#cr_' + index ).val();
							if ( total > 0 &&   event.keyCode == 9 && $('#total_' + index ).is(':focus') ) {
								event.preventDefault();
								//alert(index);
								document.getElementById( 'addmore' ).click();

							}
						} );
			//=============================================================
			/* Product Name Wise Search and Auto fill datas */
			//=============================================================
			$(document).on('keydown', '.name', function () {
				var id = this.id;
				var splitid = id.split('_');
				var index = splitid[1];

				$('#' + id).autocomplete({
					source: function (request, response) {
						$.ajax({
							url: "purchase-action/autosearch_purchase/purchasefill.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 3
							},
							success: function (data) {
								response(data);
							}
						});
					},
					select: function (event, ui) {
						$(this).val(ui.item.label); // display the selected text
						var pr_name = ui.item.valuename; // selected id to input
						// AJAX
						$.ajax({
							url: 'purchase-action/autosearch_purchase/purchasefill.php',
							type: 'post',
							data: {
								pr_name: pr_name,
								request: 4
							},
							dataType: 'json',
							success: function (response) {
								var len = response.length;
								if (len > 0) {
									if(response[0]['pr_code'] != ''){
									var pr_code = response[0]['pr_code'];
										document.getElementById('code_' + index).value = pr_code;
									var pr_name = response[0]['pr_name'];
										document.getElementById('name_' + index).value = pr_name;
									
									var pr_hsn = response[0]['pr_hsn'];
										document.getElementById('hsn_' + index).value = pr_hsn;
									
									var tax = response[0]['tax_gst'];
										document.getElementById('gstin_' + index).value = tax;
									
									var pr_unit = response[0]['pr_unit'];
										document.getElementById('unit_' + index).value = pr_unit;
									
									var purchase_ledger = response[0]['purch_ledger'];
										document.getElementById('purchase_token_' + index).value = purchase_ledger;
									
									var ledger_name = response[0]['ledger_name'];
										document.getElementById('ledger_name_' + index).value = ledger_name;
										document.getElementById('purchprice_' + index).focus();
									}
									
									//Other Tax Values
									document.getElementById('othertax_amt1_' + index).value = 0;
									document.getElementById('othertax_amt2_' + index).value = 0;
									document.getElementById('othertax_amt3_' + index).value = 0;
									document.getElementById('othertax_amt4_' + index).value = 0;
									document.getElementById('othertax_amt5_' + index).value = 0;
									document.getElementById('othertax_typ1_' + index).value = 0;
									document.getElementById('othertax_typ2_' + index).value = 0;
									document.getElementById('othertax_typ3_' + index).value = 0;
									document.getElementById('othertax_typ4_' + index).value = 0;
									document.getElementById('othertax_typ5_' + index).value = 0;
								    
									if(response[0]['tax_rate'] != ''){
										var other_tax1 = response[0]['tax_rate'];
										var othertax_typ1 = response[0]['o_tax_type'];
										document.getElementById('othertax_typ1_' + index).value = othertax_typ1;
										document.getElementById('othertax_amt1_' + index).value = other_tax1;
										
									} 
									if(response[1]['tax_rate'] != ''){
										var other_tax2 = response[1]['tax_rate'];
										var othertax_typ2 = response[1]['o_tax_type'];
										document.getElementById('othertax_typ2_' + index).value = othertax_typ2;
										document.getElementById('othertax_amt2_' + index).value = other_tax2;
									} 
									if(response[2]['tax_rate'] != ''){
										var other_tax3 = response[2]['tax_rate'];
										var othertax_typ3 = response[2]['o_tax_type'];
										document.getElementById('othertax_typ3_' + index).value = othertax_typ3;
										document.getElementById('othertax_amt3_' + index).value = other_tax3;
									} 
									if(response[3]['tax_rate'] != ''){
										var other_tax4 = response[3]['tax_rate'];
										var othertax_typ4 = response[3]['o_tax_type'];
										document.getElementById('othertax_typ4_' + index).value = othertax_typ4;
										document.getElementById('othertax_amt4_' + index).value = other_tax4;
									} 
									if(response[4]['tax_rate'] != ''){
										var other_tax5 = response[4]['tax_rate'];
										var othertax_typ5 = response[4]['o_tax_type'];
										document.getElementById('othertax_typ5_' + index).value = othertax_typ5;
										document.getElementById('othertax_amt5_' + index).value = other_tax5;
									}
								}
							}
						});
						return false;
					}
				});
				if(state = 'Kerala'){
				$(".qty, purchprice").keyup(function () {
					$('#gross_' + index).val($('#purchprice_' + index).val() * $('#qty_' + index).val());
					$('#gst_' + index).val($('#purchprice_' + index).val() * $('#gstin_' + index).val() / 100 * $('#qty_' + index).val());
					//GST + Other Taxes calculation
					if($('#othertax_amt1_' + index ).val() != 0){
                  	$('#othertax_amount1_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt1_' + index) .val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt2_' + index ).val() != 0){
                  	$('#othertax_amount2_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt3_' + index ).val() != 0){
                  	$('#othertax_amount3_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt4_' + index ).val() != 0){
                  	$('#othertax_amount4_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt5_' + index ).val() != 0){
                  	$('#othertax_amount5_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $('#qty_' + index).val() );
					}$('#total_' + index ).val(parseInt($('#gross_' + index).val()) + parseInt($('#gst_' + index).val()) + parseInt($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()) );
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()));
					$('#gstinperc_' + index).val(parseInt($('#gstin_' + index).val()) / 2);
					$('#gstincgst_' + index).val(parseInt($('#gstin_' + index).val()) / 2);
					$('#gstincgstamt_' + index).val(parseInt($('#gst_' + index).val()) / 2);
					$('#gstinsgstamt_' + index).val(parseInt($('#gst_' + index).val()) / 2);

					var sum = 0; var qtysum = 0; var gst = 0; var tot = 0; var totgst = 0; var taxable = 0;
					var nontaxable = 0; var gstinvalue = $('#gstin_' + index).val(); var qtygst = $('#qty_' + index).val();
					var othertaxtot1 = 0;var othertaxtot2 = 0; var othertaxtot3 = 0; var othertaxtot4 = 0; var othertaxtot5 = 0;
					//taxable
					 if(gstinvalue != 0){
					 $('.total').each(function () {
					 if (!isNaN(this.value) && this.value.length != 0) {
						taxable += parseFloat(this.value);
						}
							});
						document.getElementById('taxable').value = Math.round(taxable); 
					}
					//nontaxable
					  if(gstinvalue == 0){
						  //alert(gstinvalue);
						$('.total' ).each(function () {
						if (!isNaN(this.value) && this.value.length != 0){
							nontaxable += parseFloat(this.value);
						}
					});
					document.getElementById('nontaxable').value = Math.round(nontaxable);	
					}
				
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							sum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(sum);
					
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qtysum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(qtysum);
					
					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseFloat(this.value);
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
					var qttotal = 0;

					$('.qty').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qttotal += parseFloat(this.value);
						}
					});
					document.getElementById('qtyt').value = Math.round(qttotal);
					//=====================================
					//Total GST Amount
					$('.gst').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('totalgst').value = Math.round(totgst);
					//=====================================
					//Other Tax Total amounts
					$('.othertax_amount1').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					var tax1 = document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					$('.othertax_amount2').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot2 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					var tax2 = document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					$('.othertax_amount3').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot3 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					var tax3 = document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					$('.othertax_amount4').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot4 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					var tax4 = document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					$('.othertax_amount1').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot5 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					var tax5 = document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					//Total Amount
					document.getElementById('other_tax_total_amount').value = Math.round(tax1 + tax2 + tax3 + tax4 + tax5);
					//===============================
				});
				}else{
				$(".qty, .purchprice").keyup(function () {
				/* IGST Calculation */	
					$('#gross_' + index).val($('#purchprice_' + index).val() * $('#qty_' + index).val());
					$('#gst_' + index).val($('#purchprice_' + index).val() * $('#gstin_' + index).val() / 100 * $('#qty_' + index).val());
					//GST + Other Taxes calculation
					if($('#othertax_amt1_' + index ).val() !=0){
                  	$('#othertax_amount1_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt1_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt2_' + index ).val() !=0){
                  	$('#othertax_amount2_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt3_' + index ).val() !=0){
                  	$('#othertax_amount3_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt4_' + index ).val() !=0){
                  	$('#othertax_amount4_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					if($('#othertax_amt5_' + index ).val() !=0){
                  	$('#othertax_amount5_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					$('#total_' + index).val(parseInt($('#gross_' + index).val()) + parseInt($('#gst_' + index).val()) + parseInt($('#othertax_amount1_' + index).val()) + parseInt($('#othertax_amount2_' + index).val()) + parseInt($('#othertax_amount3_' + index).val()) + parseInt($('#othertax_amount4_' + index).val()) + parseInt($('#othertax_amount5_' + index).val()) );
					//$( '#gstcesssum_' + index ).val( $( '#purchprice_' + index ).val() * ($( '#gstcess_' + index ).val()) / 100 * $('#qty_' + index).val() );
					//$('#total_' + index).val(parseInt($('#gross_' + index).val()) + parseInt($('#gst_' + index).val()) + parseInt($('#gstcesssum_' + index).val()) );
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()));
					$('#igstperc_' + index).val(parseInt($('#gstin_' + index).val()));
					$('#igstamt_' + index).val(parseInt($('#gst_' + index).val()));
					
					var sum = 0;
					var qtysum = 0;
					var gst = 0;
					var tot = 0;
					var totgst = 0;
					var cesstot = 0;
					var othertaxtot1 = 0; var othertaxtot2 = 0; var othertaxtot3 = 0; var othertaxtot4 = 0; var othertaxtot5 = 0;
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							sum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(sum);
					
						var gstinvalue = $('#gstin_' + index).val();
					//taxable
					 if(gstinvalue != '0')
						 {
							$('#total_' + index).each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							taxable += parseFloat(this.value);
						}
					});
					
						 }
					document.getElementById('taxable').value = Math.round(taxable); 
					//nontaxable
					if(gstinvalue <= '0'){
						$('#total_' + index).each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							nontaxable += parseFloat(this.value);
						}
					});
					}
					
					document.getElementById('nontaxable').value = Math.round(nontaxable);
					
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qtysum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(qtysum);
					
					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseFloat(this.value);
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
					var qttotal = 0;

					$('.qty').each(function () {

						if (!isNaN(this.value) && this.value.length != 0) {
							qttotal += parseFloat(this.value);
						}
					});
					document.getElementById('qtyt').value = Math.round(qttotal);
					//=====================================
					//Total GST Amount
					$('.gst').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('totalgst').value = Math.round(totgst);
					//=====================================
					//Other Tax Total amounts
					$('.othertax_amount1').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					var tax1 = document.getElementById('other_tax_total1').value = Math.round(othertaxtot1);
					$('.othertax_amount2').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot2 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					var tax2 = document.getElementById('other_tax_total2').value = Math.round(othertaxtot2);
					$('.othertax_amount3').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot3 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					var tax3 = document.getElementById('other_tax_total3').value = Math.round(othertaxtot3);
					$('.othertax_amount4').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot4 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					var tax4 = document.getElementById('other_tax_total4').value = Math.round(othertaxtot4);
					$('.othertax_amount5').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							othertaxtot5 += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					var tax5 = document.getElementById('other_tax_total5').value = Math.round(othertaxtot5);
					//Total Amount
					document.getElementById('other_tax_total_amount').value = Math.round(tax1 + tax2 + tax3 + tax4 + tax5);
					//===============================
					
					/* Discount Key Calculation   */
				$('.discount').keyup(function () {
                            
					$('#discounttotal_' + index).val(parseInt($('#gross_' + index).val()) - parseInt($('#gross_' + index).val()) + parseInt($('#gross_' + index).val()) * parseInt($('#discount_' + index).val()) / 100);
					
					var disa = 0;
					var dis = 0;
					var tot = 0;
					
					$('.discounttotal').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							dis += parseFloat(this.value);
						}
					});
					document.getElementById('discountt').value = Math.round(dis);

					$('#totalcost_' + index).val(parseInt($('#total_' + index).val()) - parseInt($('#discounttotal_' + index).val()));
					$('#unitprice_' + index).val(parseInt($('#totalcost_' + index).val()) / parseInt($('#qty_' + index).val()));

					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseInt($('#totalprice').val()) - parseInt($('#discountt').val());
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
				});
				$('#coolie').keyup(function () {

					$('#fright').val(parseInt($('#coolie').val()) / parseInt($('#qtyt').val()));
					
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()) + parseInt($('#fright').val()));
					$('#gtotalprice').val(parseInt($('#coolie').val()) + parseInt($('#totalprice').val()));
				});
				$('#paidamount').keyup(function () {

					$('#balance_amt').val(parseInt($('#gtotalprice').val()) - parseInt($('#paidamount').val()));
				});
				});
				}
	
				/* Discount Key Calculation   */
				$('.discount').keyup(function () {

					$('#discounttotal_' + index).val(parseInt($('#gross_' + index).val()) - parseInt($('#gross_' + index).val()) + parseInt($('#gross_' + index).val()) * parseInt($('#discount_' + index).val()) / 100);
					var disa = 0;
					var dis = 0;
					var tot = 0;
					
					$('.discounttotal').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							dis += parseFloat(this.value);
						}
					});
					document.getElementById('discountt').value = Math.round(dis);

					$('#totalcost_' + index).val(parseInt($('#total_' + index).val()) - parseInt($('#discounttotal_' + index).val()));
					$('#unitprice_' + index).val(parseInt($('#totalcost_' + index).val()) / parseInt($('#qty_' + index).val()));

					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseInt($('#totalprice').val()) - parseInt($('#discountt').val());
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
				});
				$('#coolie').keyup(function () {

					$('#fright').val(parseInt($('#coolie').val()) / parseInt($('#qtyt').val()));
					
					$('#totalt_' + index).val(parseInt($('#total_' + index).val()) / parseInt($('#qty_' + index).val()) + parseInt($('#fright').val()));
					$('#gtotalprice').val(parseInt($('#coolie').val()) + parseInt($('#totalprice').val()));
				});
				$('#paidamount').keyup(function () {

					$('#balance_amt').val(parseInt($('#gtotalprice').val()) - parseInt($('#paidamount').val()));
				});
				
				/* End Discount Key Calculation   */
			});
			// Add more WITH ENTER
			$(window).keydown(function (event){
				if (event.keyCode == 107) {
					event.preventDefault();
					$('#addmore').click();
				}
				
			});
			$(window).keydown(function (event){
				if (event.keyCode == 109) {
					event.preventDefault();
					$('#delete').click();
				}
				
			});
			
			
					
			// Add more With Button
			$('#addmore').click(function (){
				
				// Get last id 
				var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
				var split_id = lastname_id.split('_');
				// New index
				var index = Number(split_id[1]) + 1;
				
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text' tabindex='-1' class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder=''></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder=' Code'></td><td><input type='text' class='form-control name' name='name[]' id='name_" + index + "' placeholder='Product Name' ></td><td><input type='text' class='form-control location_name' id='location_name_" + index +"' name='location_name[]' ><input type='hidden' class='form-control location_tkn' id='location_tkn_" + index +"' name='location_tkn[]' ></td><td><input type='text' class='form-control batch' name='batch[]' id='batch_" + index + "' placeholder='Batch'></td><td><input type='date' class='form-control expairy' name='expairy[]' id='expairy_" + index +"'></td><td><input type='text' class='form-control hsn' name='hsn[]' id='hsn_" + index + "' placeholder='HSN' ></td><td><input type='text' class='form-control unit' name='unit[]' id='unit_" + index + "' placeholder='Unit' ></td><td><input type='text' class='form-control  purchprice' placeholder='Purchase Price' name='purchprice[]' id='purchprice_" + index + "' ></td><td><input type='text' placeholder='GST%'  class='form-control gstin' name='gstin[]' id='gstin_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstinperc' name='gstinperc[]' id='gstinperc_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstincgst' name='gstincgst[]' id='gstincgst_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstincgstamt' name='gstincgstamt[]' id='gstincgstamt_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstinsgstamt' name='gstinsgstamt[]' id='gstinsgstamt_" + index + "' ><input type='hidden' class='form-control othertax_amount1' name='othertax_amount1[]' id='othertax_amount1_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amount2' name='othertax_amount2[]' id='othertax_amount2_" + index +"' value='0'><input type='hidden' class='form-control othertax_amount3' name='othertax_amount3[]' id='othertax_amount3_" + index +"' value='0' ><input type='hidden' class='form-control othertax_amount4' name='othertax_amount4[]' id='othertax_amount4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amount5' name='othertax_amount5[]' id='othertax_amount5_" + index + "' value='0' ><input type='hidden' placeholder='GST%'  class='form-control igstperc' name='igstperc[]' id='igstperc_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control igstamt' name='igstamt[]' id='igstamt_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control purchase_token' name='purchase_token[]' id='purchase_token_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control ledger_name' name='ledger_name[]' id='ledger_name_" + index + "' ><input type='hidden' class='form-control othertax_amt1' name='othertax_amt1[]' id='othertax_amt1_" + index + "' placeholder='Gst Cess %' value='0'><input type='hidden' class='form-control othertax_amt2' name='othertax_amt2[]' id='othertax_amt2_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt3' name='othertax_amt3[]' id='othertax_amt3_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt4' name='othertax_amt4[]' id='othertax_amt4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt5' name='othertax_amt5[]' id='othertax_amt5_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ1' name='othertax_typ1[]' id='othertax_typ1_" + index + "' value='0'><input type='hidden' class='form-control othertax_typ2' name='othertax_typ2[]' id='othertax_typ2_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ3' name='othertax_typ3[]' id='othertax_typ3_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ4' name='othertax_typ4[]' id='othertax_typ4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ5' name='othertax_typ5[]' id='othertax_typ5_" + index + "' value='0' ></td><td><input type='text'  class='form-control qty' placeholder='Qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text' placeholder='Discount'  class='form-control discount' name='discount[]' id='discount_" + index + "' ><input type='hidden' placeholder='Discount'  class='form-control discounttotal' name='discounttotal' id='discounttotal_" + index + "' ><input type='hidden' placeholder=''  class='form-control totalcost' name='totalcost[]' id='totalcost_" + index + "' ><input type='hidden' placeholder=''  class='form-control unitprice' name='unitprice[]' id='unitprice_" + index + "' ><input type='hidden' placeholder='gross'  class='form-control gross' name='gross[]' id='gross_" + index + "' ><input type='hidden' placeholder='GST' class='form-control gst' name='gst[]' id='gst_" + index + "' ><input type='hidden' class='form-control taxrate_amount' name='taxrate_amount[]' value='0' id='taxrate_amount_" + index + "'></td><td><input type='text'  class='form-control total' name='total[]' placeholder='Total' id='total_" + index + "' ></td><td><input type='hidden'  class='form-control totalt' name='totalt' placeholder='Unit Price' id='totalt_" + index + "' ><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='-'></button></td></tr>";
				// Append data
				$('#code_' + index).focus();
				$('#purchase').append(html);
				$(document).on('click', '.delete', function (){
					$('#code_' + index).focus();
					$(this).closest('tr').remove();
					$('#discountt').val() - $('#discounttotal_' + index).val();
					$('#totalgst').val() - $('#gstincgstamt_' + index).val() + $('#gstinsgstamt_' + index).val();
					$('#other_tax_total_amount').val() - $('#othertax_amount_' + index).val();
					$('#totalprice').val() - $('#total_' + index).val();
					$('#gtotalprice').val() - $('#total_' + index).val();
				});
			});
		
			$('#insert_form').on('submit', function (event) {
			event.preventDefault();
			/* Validation */
			var error = '';
			/* Creating Index WHEN Clicking Add Button Or Enter Button */
			var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
			var split_id = lastname_id.split('_');
			// New index
			var index = Number(split_id[1]);
				
			var vendor = $('#v_name').val();
			var bill = $('#billno').val();
			var invo = $('#invno').val();
			var dat = $('#date').val();
			//var paid = $('#paidamount').val();
			var name = $('#name_' + index).val();
			var purch = $('#purchprice_' + index).val();
			var qty = $('#qty_' + index).val();
		
			 if(vendor == ''){
				 $.toast({heading: 'Select A Supplier.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});error = 1;
			 }else if(bill == ''){
				 $.toast({heading: 'Enter Supplier Bill No.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});error = 1;
			 }else if(name == ''){
				 $.toast({heading: 'Enter Product Name.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500}); error = 1;
			 }else if(purch == ''){
				 $.toast({heading: 'Enter Purchase Amount.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});error = 1;
			 }else if(qty == ''){
				 $.toast({heading: 'Enter Quantity.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});error = 1;
			 }
				var form_data = $(this).serialize();
				if (error == ''){
					$.ajax({
						url: "purchase-action/estimate_product.php",
						method: "POST",
						data: form_data,
						success: function (data){
							if (data == 'ok'){
								$('#savedata').click();
								//$('#submit').hide();
							} else {
							$.toast({heading: 'Error',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500});
							}
						}
					});
				}
			});
			$( "#order_no" ).change( function () {
					
				//var vendor = $( '#v_name' ).val();
				var order_no = $( '#order_no' ).val();
				
                if(order_no == ''){
					$.toast( {heading: 'Enter Order No.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1200} );
				} 
				$.ajax({
					type: 'POST',
					url: 'purchase-order-fetch.php',
					data: 'order_no=' + order_no,
					success: function ( r ) {
						$( "#bill_data" ).html( r );
						 $( '.qty' ).click();
					}
				});
				
			} );
		});
	</script>

	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
					</li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
					</li>
				</ul>
				
			</div>
		</div>
	</div>
	</div>
<?php if(isset($_COOKIE['SC']) && $_COOKIE['SC'] == true) {  ?>
<script>
	$(document).ready( function () {$.toast({heading: 'Order Bill Not Found.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1900}); });
</script>
<?php } ?>
	
	</div>
	</div>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	
	<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
</script>
<script>
			
$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
	<script>
		(function () {
			'use strict';
			window.addEventListener('load', function () {
				var forms = document.getElementsByClassName('needs-validation');
				var validation = Array.prototype.filter.call(forms, function (form) {
					form.addEventListener('submit', function (event) {
						if (form.checkValidity() === false) {
							event.preventDefault();
							event.stopPropagation();
						}
						form.classList.add('was-validated');
					}, false);
				});
			}, false);
		})();
	</script>
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>
	<script src="js/custom.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
<?php include ('include/disable_fn.php'); ?>
	<script>
		$(function () {
			var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
			$('.js-switch').each(function () {
				new Switchery($(this)[0], $(this).data());
			});
			$(".select2").select2();
			$('.selectpicker').selectpicker();
			
			$('#pre-selected-options').multiSelect();
			$('#optgroup').multiSelect({
				selectableOptgroup: true
			});
			$('#public-methods').multiSelect();
			$('#select-all').click(function () {
				$('#public-methods').multiSelect('select_all');
				return false;
			});
			$('#deselect-all').click(function () {
				$('#public-methods').multiSelect('deselect_all');
				return false;
			});
			$('#refresh').on('click', function () {
				$('#public-methods').multiSelect('refresh');
				return false;
			});
			$('#add-option').on('click', function () {
				$('#public-methods').multiSelect('addOption', {
					value: 42,
					text: 'test 42',
					index: 0
				});
				return false;
			});
			$(".ajax").select2({
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function (params) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function (data, params) {
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: (params.page * 30) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function (markup) {
					return markup;
				}, 
				minimumInputLength: 1,
			});
		});
	</script>
<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
	var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>
</html>