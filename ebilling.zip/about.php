<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>About</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
</head>
<body class="fix-header card-no-border fix-sidebar">
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label"></p>
        </div>
    </div>
    <div id="main-wrapper">
       <?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor float-left">About</h3>
                    </div>
                    
                    <div class="col-md-12">
					</div>
                    <div>
                        
                   </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
								<div class="row">
                               		<div class="col-md-2 m-t-5 m-l-10">
									</div>
								</div>
								<img src="assets/images/logo.png" alt="homepage" class="dark-logo" /><span>
                         <!-- dark Logo text -->
                         <img src="assets/images/billingmaster.png" alt="homepage" class="dark-logo" /></span>
								<hr/>
								<h4><strong>Version 1.0.0</strong></h4>
								<h4><strong>© 2019 - <?php echo date("Y"); ?> Codebuz.in</strong></h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span></div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a></li>
                                <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
	
	<?php if(isset($_COOKIE['ED']) && $_COOKIE['ED'] == true){ ?> <script> $(document).ready(function(){
		
		$.toast({
			heading: 'Updated Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	});</script>
	<?php } ?>
   <script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});
         	
		</script>
    <script src="assets/plugins/popper/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="js/perfect-scrollbar.jquery.min.js"></script>
		<script src="js/waves.js"></script>
		<script src="js/sidebarmenu.js"></script>
		<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
		<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
		<script src="js/custom.min.js"></script>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
		<script src="js/mask.init.js"></script>
		<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
		<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
		<?php include ('include/disable_fn.php'); ?>
    <script>
		$('#example23').DataTable({
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		});
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

</body>

</html>