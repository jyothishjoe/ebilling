<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "supermarket");
$columns = array('v_name', 'phone', 'company', 'address', 'bill_date');

$query = "SELECT * FROM purchase_product WHERE ";

if($_POST["is_date_search"] == "yes")
{
 $query .= 'bill_date BETWEEN "'.$_POST["start_date"].'" AND "'.$_POST["end_date"].'" AND ';
}

if(isset($_POST["search"]["value"]))
{
 $query .= '
  (bill_date LIKE "%'.$_POST["search"]["value"].'%" 
  OR v_name LIKE "%'.$_POST["search"]["value"].'%" 
  OR phone LIKE "%'.$_POST["search"]["value"].'%" 
  OR company LIKE "%'.$_POST["search"]["value"].'%")
 ';
}

if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' 
 ';
}
else
{
 $query .= 'ORDER BY bill_date DESC ';
}

$query1 = '';

if($_POST["length"] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));

$result = mysqli_query($connect, $query . $query1);

$data = array();

while($row = mysqli_fetch_array($result))
{
 $sub_array = array();
 $sub_array[] = $row["bill_date"];
 $sub_array[] = $row["v_name"];
 $sub_array[] = $row["phone"];
 $sub_array[] = $row["company"];
 $sub_array[] = $row["address"];
 $data[] = $sub_array;
}

function get_all_data($connect)
{
 $query = "SELECT * FROM purchase_product";
 $result = mysqli_query($connect, $query);
 return mysqli_num_rows($result);
}

$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  get_all_data($connect),
 "recordsFiltered" => $number_filter_row,
 "data"    => $data
);

echo json_encode($output);

?>