<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];

$bill = $_GET[ 'alter' ];

	$date_set = $today;


$result_bill_tok = $db->prepare( "select * from  purchasereturn_invoice WHERE company_tkn='$user_company' AND inv='$bill' " );
$result_bill_tok->execute();
$rows_bill_tok = $result_bill_tok->fetch();
$sup_token = $rows_bill_tok[ 'sup_token' ];


$result_supplier = $db->prepare( "select * from  supplier WHERE company_tkn='$user_company' AND supplier_token='$sup_token' " );
$result_supplier->execute();
$rows_supplier = $result_supplier->fetch();

$state = $rows_supplier['state']; 
$gstin = $rows_supplier['gstin']; 
$phone = $rows_supplier['phone']; 
$id =	  $rows_supplier['id']; 
$supplier_tkn =	$rows_supplier['supplier_token']; 
$ledger_tkn = $rows_supplier['ledger_token']; 
$city = $rows_supplier['city']; 
$supplier_name = $rows_supplier[ 'v_name' ];
$bill_date = $rows_bill_tok[ 'bill_date' ];
?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Purchase Return Bill | Edit</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/auto/all.css">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>

	<div class="col-md-12">
		<!--<a href="create-ledger.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="openledger">Ledger(F1)</a>
								<a href="add-supplier.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="opensupplier">Add Supplier(F2)</a>
								<a href="add-product.php" class="btn btn-sm btn-info simple-ajax-popup-align-top" id="openproduct">Add Product(F3)</a>-->
		
	</div>
	<div class="">
		
	</div>
	</div>
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body">
					<a href="supplier-info.php?sup_id=<?php echo $supplier_name; ?>" style="float: right;" class="btn btn-sm btn-info" id="">Back</a>
					<div class="clear"></div>
					<hr/>
					<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
						<div class="form-row">
							<div class="col-md-1 col-sm-6 col-xs-12  mb-3">
								<div class="row">
								</div>
							</div>
							<div class="col-md-5 col-sm-6 col-xs-12"></div>
							<label for="" class="control-label">Return Bill</label>
							<div class="col-md-1 col-sm-6 col-xs-12 mb-2">
								<input type="hidden" class="form-control" name="invno" value="<?php echo $bill; ?>" id="invno" readonly>
							</div>
							<div class="col-md-2 col-sm-6 col-xs-6 mb-2">
								<input type="date" class="form-control" id="order_invdate" name="order_invdate" value="<?= $date_set; ?>">
							</div>
							<div class="col-md-2 col-sm-6 col-xs-6 mb-2">
								<input type="time" class="form-control" id="order_invtime" name="time" value="<?php echo $current_time;?>" readonly>
							</div>
						</div>
						<input type="hidden" class="form-control" id="addby" name="addby" value="" readonly>
						<div class="form-row">
							<div class="col-md-3 col-sm-6 col-xs-12 mb-2">
								<input type="text" class="form-control" name="billno" id="billno" placeholder="PV NO" value="<?php echo $bill; ?>">
							</div>
						</div>
						<div class="form-row">
							<?php 
									$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid'  ORDER BY id DESC LIMIT 1");
									$result->execute();
									$rows=$result->fetch();
									$dateformate=$rows['dateformate'];
									?>
							<?php if($dateformate == 'datechoos') { ?>
							<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
								<input type="date" class="form-control" id="billdate" name="billdate" placeholder="PV Date" value="<?php echo $date_set; ?>" required>
							</div>
							<?php } else { ?>
							<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
								<input type="text" class="form-control date-inputmask" id="billdate" placeholder="PV Date" value="<?php echo $bill_date; ?>" name="billdate" required>
							</div>
							<?php } ?>
							<div class="col-md-3 col-sm-6 col-xs-12  mb-3">
								<div class="form-group row">
									<div class="col-12">
										<select class="form-control select2" id="v_name" name="v_name" style="width: 100%; height:36px;">
											<option value="<?php echo $supplier_name; ?>"><?php echo $supplier_name; ?></option>
											<?php
											$result_vendor = $db->prepare( "SELECT * FROM supplier WHERE company_tkn='$user_company'" );
											$result_vendor->execute();
											for ( $i = 0; $rows_vendor = $result_vendor->fetch(); $i++ ) {
												?>
											<option value="<?php echo $rows_vendor['v_name']; ?>">
												<?php echo $rows_vendor['v_name']; ?>
											</option>
											<?php } ?>
										</select>
									</div>
								</div>
								<input type="hidden" class="form-control" name="company" id="company" placeholder="Company">
								<input type="hidden" class="form-control" name="state" id="state" value="<?php echo $state; ?>">
								<input type="hidden" class="form-control" name="supgst" id="supgst" value='<?php echo $gstin; ?>'>
								<input type="hidden" class="form-control" name="address" id="address" value="<?php echo $city; ?>">
								<input type="hidden" class="form-control" name="userid" id="userid" value="<?php echo $userid; ?>" placeholder="Address">
								<input type="hidden" class="form-control" name="company" id="company" value="<?php echo $user_company; ?>" placeholder="Address">
								<input type="hidden" class="form-control" name="supid" id="supid" value="<?php echo $id; ?>">
								<input type="hidden" class="form-control" name="suptoken" id="suptoken" value="<?php echo $supplier_tkn; ?>">
								<input type="hidden" class="form-control" name="phone" id="phone" value="<?php echo $phone; ?>">
								<input type="hidden" class="form-control" name="purchase_ledger" id="purchase_ledger" value="<?php echo $supplier_tkn; ?>" placeholder="Supplier NTokename">
							</div>

						</div>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<div class="form-group row">
								<textarea type="text" class="form-control" name="remarks" id="remarks" placeholder="Remarks"></textarea>
							</div>
						</div>
						<div class=" col-md-5"></div>
						<div class=" col-md-12 col-xs-12 no-padding" id="form_data"></div>
						<input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty" readonly>
						<input type="hidden" class="form-control" id="datetym" name="datetym" value="<?php echo $current_date_time;?>">
						<hr/>
						<!----Table-->
						<div class="col-md-12">
							<h4>Product Details </h4>
						</div>
						<div class="col-sm-12 col-xs-12 " style="overflow-x: auto; ">
							<table class="table table-bordered" style="min-width: 1100px;">
								<thead>
									<tr>
										<th style="width: 58px;">Sl No</th>
										<th style="width: 100px;">Code</th>
										<th style="width: 135px;">Item Name</th>
										<th style="width: 135px;">Location</th>
										<th style="width: 75px;">Batch</th>
										<th style="width: 55px;">Expairy</th>
										<th style="width: 75px;">HSN</th>
										<th style="width: 100px;">Unit</th>
										<th style="width: 85px;">Rate</th>
										<th style="width: 70px;">GST%</th>
										<th style="width: 75px;">Qty</th>
										<th style="width: 75px;">Ret Qty</th>
										<th style="width: 70px;">Disc%</th>
										<!--<th>Gross</th>
										<th>GST</th>
										<th>Other Tax</th>-->
										<th style="width: 140px;">Total</th>

									</tr>
								</thead>
								<tbody id="purchase">
									<?php
									$k = 0;
									$result = $db->prepare( "SELECT * FROM purchasereturn_invoice a LEFT JOIN purchasereturn_productdetails b ON a.purch_token=b.purch_token   WHERE b.invoice = '$bill' " );
									$sl = 0;
									$result->execute();
									$row_count = $result->rowcount();
									for ( $i = 0; $rows_purch = $result->fetch(); $i++ ) {
										$product_code = $rows_purch[ 'p_id' ];
										$gst = $rows_purch[ 'tax' ];
										$ret_qty = $rows_purch[ 'qty' ];
										$discount = $rows_purch['discount'];
										$discounttotal= $rows_purch['discount_total'];
										$gst_amt= $rows_purch['gst'];
										$other_tax= $rows_purch['other_tax'];
										$total= $rows_purch['total'];
										$total_price = $rows_purch['total_price'];
										$other_tax_tot = $rows_purch['other_taxtotal'];
										$frieght = $rows_purch['frieght'];
										$grand_total = $rows_purch['grand_total'];
										$balance = $rows_purch['balance'];
										$paid_amt = $rows_purch['paid'];
										$gst_total = $rows_purch['totalgst_amt'];
										$gross = $rows_purch['gross'];
										$location_name = $rows_purch['location_name'];
										$location_tkn = $rows_purch['location_tkn'];
										$stock_tkn = $rows_purch['stock_tkn'];
										$batch_no = $rows_purch['batch_no'];
										$expairy = $rows_purch['expairy_date'];
										
										$result_ledger = $db->prepare( "SELECT * FROM account_ledger a LEFT JOIN transaction b ON a.ledger_token=b.ledger_token WHERE b.voucher_no = '$bill'  AND b.ledger_name='purchase taxable' " );
										$result_ledger->execute();
										$rows_ledger = $result_ledger->fetch();
										$taxable_token = $rows_ledger[ 'ledger_token' ];
										$taxable_ledger = $rows_ledger[ 'ledger_name' ];

										$result_ledger1 = $db->prepare( "SELECT * FROM account_ledger a LEFT JOIN transaction b ON a.ledger_token=b.ledger_token WHERE b.voucher_no = '$bill'  AND b.ledger_name='purchase non taxable' " );
										$result_ledger1->execute();
										$rows_ledger1 = $result_ledger1->fetch();
										$taxable_token = $rows_ledger1[ 'ledger_token' ];
										$taxable_ledger = $rows_ledger1[ 'ledger_name' ];
										//Other Tax Details Fetch
										if ( $row_count > 0 ) {
											$val = 1;
										}else{
											$val = 0;
										}
										?>
									<tr class='tr_input'>
										<td><input type='text' tabindex="-1" style="width: 40px;" class="form-control code" name="serial" id='serial_1' value="<?= ++$k; ?>" placeholder='Product Code'>
											<input type='hidden' class="form-control val" name="val[]" id='val_<?php echo $i+1; ?>' placeholder='Product Code' value="<?php echo $val; ?>" readonly>
											<input type='hidden' class="form-control stock_tkn" name="stock_tkn[]" id='stock_tkn_<?php echo $i+1; ?>' value="<?php echo $stock_tkn; ?>">
										</td>
										<td><input type='text' tabindex="-1" class="form-control code" name="code[]" id='code_<?php echo $i+1; ?>' value="<?php echo $rows_purch['p_id']; ?>" placeholder='Product Code' readonly>
										</td>
										<td><input type='text' tabindex="-1" class="form-control name" name="name[]" id='name_<?php echo $i+1; ?>' value="<?php echo $rows_purch['pr_name']; ?>" placeholder='Product Name' readonly>
										</td>
										<td>
											<input type='text' class="form-control location_name" id="location_name_<?php echo $i+1; ?>" name="location_name[]" value="<?php echo $location_name; ?>">
											<input type='hidden' class="form-control location_tkn" id="location_tkn_<?php echo $i+1; ?>" name="location_tkn" value="<?php echo $location_tkn; ?>">
										</td>
										<td>
											<input type='text' class="form-control batch" name="batch[]" id='batch_<?php echo $i+1; ?>' placeholder='Batch' value="<?php echo $batch_no; ?>">
										</td>
										<td>
											<input type='date' class="form-control expairy" name="expairy[]" id='expairy_<?php echo $i+1; ?>' value="<?php echo $expairy; ?>">
										</td>
										<td><input type='text' tabindex="-1" class="form-control hsn" name="hsn[]" id='hsn_<?php echo $i+1; ?>' value="<?php echo $rows_purch['hsn']; ?>" placeholder='HSN' readonly>
										</td>
										<td><input type='text' tabindex="-1" class="form-control unit" name="unit[]" id='unit_<?php echo $i+1; ?>' value="<?php echo $rows_purch['unit']; ?>" placeholder='Unit' readonly>
										</td>
										<td><input type='text' tabindex="-1" class="form-control purchprice" name="purchprice[]" value="<?php echo $rows_purch['purch_price']; ?>" id='purchprice_<?php echo $i+1; ?>' placeholder='Purchase Price' readonly>
										</td>
										<td><input type='text' tabindex="-1" class="form-control gstin" name="gstin[]" id='gstin_<?php echo $i+1; ?>' value="<?php echo $rows_purch['tax']; ?>" placeholder='GST%'>
												<input type='hidden' class="form-control gstinperc" name="gstinperc[]" id='gstinperc_<?php echo $i+1; ?>' placeholder='GST%'>
												<input type='hidden' class="form-control gstincgst" name="gstincgst[]" id='gstincgst_<?php echo $i+1; ?>' placeholder='GST%'>
												<input type='hidden' class="form-control gstincgstamt" name="gstincgstamt[]" id='gstincgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
												<input type='hidden' class="form-control gstinsgstamt" name="gstinsgstamt[]" id='gstinsgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
												<!--Taxable Non Taxable-->
												<input type='hidden' class="form-control purchase_token" name="purchase_token[]" value="<?php  if($gst != '0'){ echo $rows_ledger['ledger_token']; }else{ echo $rows_ledger1['ledger_token']; } ?>" id='purchase_token_<?php echo $i+1; ?> '>

												<input type='hidden' class="form-control ledger_name" name="ledger_name[]" value="<?php  if($gst !='0'){ echo $rows_ledger['ledger_name']; }else{ echo $rows_ledger1['ledger_name']; } ?>" id='ledger_name_<?php echo $i+1; ?>'>
												<!--===================================-->
												<!--Other Tax Rate-->
												<?php 
												 $result_other_tax = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill'  ");
												 $result_other_tax->execute();
												 for($i1=0; $rows_other_tax = $result_other_tax->fetch(); $i1++){ $o_tax_rate=$rows_other_tax['tax_rate']; ?>
												<input type='hidden' class="form-control othertax_amt<?php echo $i1+1; ?>" name="othertax_amt<?php echo $i1+1; ?>[]" id='othertax_amt<?php echo $i1+1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_rate; ?>">
												<?php } ?>
												<!--Empty Text Boxes of tax rate-->
												<?php for($otax=$i1; $otax <=4; $otax++){  ?>
												<input type='hidden' class="form-control othertax_amt<?php echo $otax+1; ?>" name="othertax_amt<?php echo $otax+1; ?>[]" id='othertax_amt<?php echo $otax+1; ?>_<?php echo $i+1; ?>' value="0">
												<?php  } ?>
												<!--===================================-->
												<!--Other Tax Amounts-->
												<?php 
												 $result_other_taxamt = $db->prepare("SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill'  ");
												 $result_other_taxamt->execute();
												 for($i3=0; $rows_other_taxamt = $result_other_taxamt->fetch(); $i3++){ ?>
												<input type='hidden' class="form-control othertax_amount<?php echo $i3+1; ?>" name="othertax_amount<?php echo $i3+1; ?>[]" id='othertax_amount<?php echo $i3+1; ?>_<?php echo $i+1; ?>' value="0">
												<?php } ?>
												<!--Empty Text Boxes of tax Amount-->
												<?php for($otax1=$i3; $otax1 <=4; $otax1++){  ?>
												<input type='hidden' class="form-control othertax_amount<?php echo $otax1+1; ?>" name="othertax_amount<?php echo $otax1+1; ?>[]" id='othertax_amount<?php echo $otax1+1; ?>_<?php echo $i+1; ?>' value="0">
												<?php  } ?>
												<!--===================================-->
												<!--Other Tax Type Names (CESS, etc)-->
												<?php
												$result_other_taxtype = $db->prepare( "SELECT * FROM other_taxdetails_purchase WHERE product_code = '$product_code' AND invoice_no = '$bill' " );
												$result_other_taxtype->execute();
												for ( $i2 = 0; $rows_other_taxtype = $result_other_taxtype->fetch(); $i2++ ) {
												$o_tax_typ=$rows_other_taxtype['tax_type']; ?>
												<input type='hidden' class="form-control othertax_typ<?php echo $i2 + 1; ?>" name="othertax_typ<?php echo $i2 + 1; ?>[]" id='othertax_typ<?php echo $i2 + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_typ; ?>">
												<?php } ?>
												<!--Empty Text Boxes of Tax type Names-->
												<?php for($type=$i2; $type <=4; $type++){ ?>
												<input type='hidden' class="form-control othertax_typ<?php echo $type + 1; ?>" name="othertax_typ<?php echo $type + 1; ?>[]" id='othertax_typ<?php echo $type + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_typ; ?>">
												<?php } ?>
												<!--===================================-->
											</td>
										<td><input type='text' tabindex="-1" class="form-control retqty" name="retqty[]" value="<?php echo $ret_qty; ?>" id='retqty_<?php echo $i+1; ?>' placeholder='Qty' readonly>
										</td>
										<td><input type='text' class="form-control qty" name="qty[]" value="<?php echo $ret_qty ?>" id='qty_<?php echo $i+1; ?>' placeholder='Qty'>
										</td>
										<td>
											<?php if($rows_purch['discount'] == 0){ ?>
											<input type='text' tabindex="-1" class="form-control discount" name="discount[]" value="<?php echo $discount; ?>" id='discount_<?php echo $i+1; ?>' readonly>
											<?php }else{ ?>
											<input type='text' tabindex="-1" class="form-control discount" name="discount[]" value="<?php echo $discount; ?>" id='discount_<?php echo $i+1; ?>'>
											<?php } ?>
											<input type='hidden' class="form-control discounttotal" name="discounttotal" id='discounttotal_<?php echo $i+1; ?>' >
											<input type='hidden' class="form-control totalcost" name="totalcost[]" id='totalcost_<?php echo $i+1; ?>' placeholder=''>
											<input type='hidden' class="form-control unitprice" name="unitprice[]" id='unitprice_<?php echo $i+1; ?>' placeholder=''>
											<!--Gross Amount / other Tax total / gst amt/ -->
											<input type='hidden' tabindex="-1" class="form-control gross" name="gross[]" value="<?php echo $gross; ?>" id='gross_<?php echo $i+1; ?>' placeholder='Gross'  readonly>
											<input type='hidden' tabindex="-1" class="form-control gst" name="gst[]" value="<?php echo $gst_amt; ?>" id='gst_<?php echo $i+1; ?>' placeholder='GST' readonly>
											<input type='hidden' class="form-control taxrate_amount" name="taxrate_amount[]" value="<?php echo $other_tax; ?>" id='taxrate_amount_<?php echo $i+1; ?>'>
										</td>
										<td>
											<input type='text' tabindex="-1" class="form-control total" name="total[]" value="<?php echo $total; ?>" id='total_<?php echo $i+1; ?>' placeholder='Total' readonly>
											<input type='hidden' class="form-control totalt" name="totalt" id='totalt_<?php echo $i+1; ?>' placeholder='Unit Cost'>
										</td>
										<td></td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
						<br>
						<div class="col-md-12 col-sm-6 col-xs-12">
							<table class="table">
								<tr>
									<td align="right" class="control-label">Discount:</td>
									<td width="150">
										<input type="text" tabindex="-1" readonly class="form-control" name="discountt" id="discountt" placeholder="Discount" value="<?php echo $discounttotal; ?>">
										<input type="hidden" readonly class="form-control" name="discounttt" id="discounttt" placeholder="Discount" value="0" style="width:120px;">
									</td>
									<td align="right" class="control-label">Total Amount:</td>
									<td width="250"><input type="text" tabindex="-1" readonly class="form-control totalprice" value="<?php echo $total_price; ?>" name="totalprice" id="totalprice">
									</td>
									<td align="right" class="control-label">GST Total:</td>
									<td>
										<input type="text" readonly class="form-control totalgst" name="totalgst" id="totalgst" value="<?php echo $gst_total; ?>">
									</td>
								</tr>
								<tr style="display:none;">
									<td style=" font-stretch:expanded;" align="right" class="control-label">Freight:</td>
									<td width="150">
										<input type="text" value="<?php echo $frieght; ?>" class="form-control" name="coolie" id="coolie" placeholder="Coolie" style="width:120px;">
										<input type="hidden" value="0" class="form-control" name="qtyt" id="qtyt" placeholder="Qtytotal" style="width:120px;">
										<input type="hidden" value="0" class="form-control" name="fright" id="fright" placeholder="frighttotal" style="width:120px;">
									</td>
								</tr>
								<tr id="show1" style="display:none;">
									<td align="right" class="control-label">Old Balance</td>
									<td style="width:150px;"><input type="text" readonly class="form-control" value="" name="totaldiscount" id="totaldiscount" placeholder="Old Balance" style="width:120px;">
									</td>
								</tr>
								<tr>
									<!--Other Tax  Total -->
									<td align="right" class="control-label">Other Tax Total:</td>
									<td>
										<!--Other Tax  Total SUM-->
										<input type="text" readonly class="form-control other_tax_total_amount" value="<?php echo $other_tax_tot; ?>" name="other_tax_total_amount" id="other_tax_total_amount">
									</td>
									<td align="right" class="control-label">Grant Total:</td>
									<td width="150"><input type="text" readonly class="form-control" value="<?php echo $grand_total; ?>" name="gtotalprice" id="gtotalprice" placeholder="Grant Total">
									</td>
									<tr id="show1" style="">
										<td align="right" class="control-label">Balance:</td>
										<td style="width:150"><input type="text" readonly class="form-control" name="balance_amt" id="balance_amt" placeholder="Balance" value="<?php echo $balance; ?>" style="width:150px;">
											<td align="right" class="control-label">Paid Amount:</td>
											<td width="150"><input type="text" class="form-control" name="paidamount" id="paidamount" placeholder="Paid Amount" value="<?php echo $paid_amt; ?>" style="width:250px;">
											</td>
										</td>
									<td align="right" class="control-label">Pay Mode:</td>
									<td width="100">
									<select class="form-control" id="paymode" name="paymode" style="width: 100%; height:33px;">
									<option value="cash">Cash</option>
									<option value="bank">Bank</option>
									</select>	
									</td>
									</tr>
								</tr>
								<tr>
									<td align="right" class="control-label"></td>
									<td width="150"><input type="hidden" readonly class="form-control " value="0" name="balance" id="balance" placeholder="Balance" style="width:120px;">
									</td>
								</tr>
							</table>
						</div>
				</div>
				<div class="col-md-12" style="margin-bottom: 25px;">
					<input type="submit" name="submit" id="submit" style="float: right; margin-top: 25px;" class="btn btn-sm btn-info" value="Save & Print"/>
				</div>
				</form>
			</div>
			<br>
		</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	<script>
		$( window ).keydown( function ( event ) {
			if ( event.keyCode == 112 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$.fancybox.open( {
						href: "create-ledger.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event.keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( '#opensupplier' ).click();
			}
			if ( event.keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( '#openproduct' ).click();
			}
			if ( event.keyCode == 115 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$( '#openpurchaseorder' ).click();
			}
		} );

		/* table data (Purchase Return bill items)*/
		$( "#v_name" ).change( function () {

			var vendor = $( '#v_name' ).val();
			var bill = $( '#billno' ).val();
			var billdate = $( '#billdate' ).val();
			//Checking Bill if its exist Or Not
			if ( bill == '' ) {
				$.toast( {
					heading: 'Enter Invoice Number.',
					text: '',
					position: 'top-right',
					loaderBg: '#ff6849',
					icon: 'error',
					hideAfter: 1900
				} );
			} else if ( billdate == '' ) {
				$.toast( {
					heading: 'Please Enter Invoice Date.',
					text: '',
					position: 'top-right',
					loaderBg: '#ff6849',
					icon: 'error',
					hideAfter: 1900
				} );
			} else {
				//setTimeout($('.preloader').show(), 2000);
				//Fetching Bill Data For Enterd Date And Inv No
				$.ajax( {
					type: 'POST',
					url: 'purchase-return-data.php',
					data: 'vendor=' + vendor + '&bill=' + bill + '&billdate=' + billdate,
					success: function ( r ) {
						$( "#billdata" ).html( r );
						//$('.preloader').hide();
					}
				} );
			}
		} );
		/*Supplier Details Search */
		$( function () {
			$( "#v_name" ).autocomplete( {
				source: "purchase-action/sup_search.php",
				select: function ( event, ui ) {
					event.preventDefault();
					$( "#v_name" ).val( ui.item.value );
				}
			} );
		} );

		$( '#v_name' ).change( function () {
			var v_name = $( "#v_name" ).val();
			$.ajax( {
				type: 'POST',
				url: 'purchase-action/sup_phone_change.php',
				data: 'v_name=' + v_name,
				dataType: "JSON",
				success: function ( data ) {
					$( '#phone' ).val( data.phone );
					$( '#supid' ).val( data.sup_id );
					$( '#state' ).val( data.state );
					$( '#address' ).val( data.address );
					$( '#supgst' ).val( data.supgst );
					$( '#company' ).val( data.company );
					$( '#suptoken' ).val( data.sup_tkn );
					$( '#city' ).val( data.city );
					$( '#purchase_ledger' ).val( data.token );
				}
			} );
		} );
		//addRowCount('.js-serial');

		function setFocusToTextBox() {
			document.getElementById( "code_1" ).focus();
		}
	</script>
	<script type="text/javascript">
		var taxable = 0;
		var nontaxable = 0;

		$( document ).ready( function () {
			$( '#billno' ).focus();
			$( document ).on( 'keyup', '.qty', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
				//Gross Value
				$( '#gross_' + index ).val( $( '#purchprice_' + index ).val() * $( '#qty_' + index ).val() );
				//GST Calculation
				$( '#gst_' + index ).val( $( '#purchprice_' + index ).val() * $( '#gstin_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				// Other Taxes calculation
				if ( $( '#othertax_amt1_' + index ).val() != 0 ) {
					$( '#othertax_amount1_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt1_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				}
				if ( $( '#othertax_amt2_' + index ).val() != 0 ) {
					$( '#othertax_amount2_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				}
				if ( $( '#othertax_amt3_' + index ).val() != 0 ) {
					$( '#othertax_amount3_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				}
				if ( $( '#othertax_amt4_' + index ).val() != 0 ) {
					$( '#othertax_amount4_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				}
				if ( $( '#othertax_amt5_' + index ).val() != 0 ) {
					$( '#othertax_amount5_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $( '#qty_' + index ).val() );
				}
				//Total AMount of the Produt(Each row Wise total amount)  
				$( '#taxrate_amount_' + index ).val( parseFloat( $( '#othertax_amount1_' + index ).val() ) + parseFloat( $( '#othertax_amount2_' + index ).val() ) + parseFloat( $( '#othertax_amount3_' + index ).val() ) + parseFloat( $( '#othertax_amount4_' + index ).val() ) + parseFloat( $( '#othertax_amount5_' + index ).val() ) );
				$( '#total_' + index ).val( parseFloat( $( '#gross_' + index ).val() ) + parseFloat( $( '#gst_' + index ).val() ) + parseFloat( $( '#othertax_amount1_' + index ).val() ) + parseFloat( $( '#othertax_amount2_' + index ).val() ) + parseFloat( $( '#othertax_amount3_' + index ).val() ) + parseFloat( $( '#othertax_amount4_' + index ).val() ) + parseFloat( $( '#othertax_amount5_' + index ).val() ) );

				//GST For Product And CGST ,SGST Separation
				$( '#totalt_' + index ).val( parseInt( $( '#total_' + index ).val() ) / parseInt( $( '#qty_' + index ).val() ) );
				$( '#gstinperc_' + index ).val( parseInt( $( '#gstin_' + index ).val() ) / 2 );
				$( '#gstincgst_' + index ).val( parseInt( $( '#gstin_' + index ).val() ) / 2 );
				$( '#gstincgstamt_' + index ).val( parseInt( $( '#gst_' + index ).val() ) / 2 );
				$( '#gstinsgstamt_' + index ).val( parseInt( $( '#gst_' + index ).val() ) / 2 );
				//===========================
				var sum = 0;
				var qtysum = 0;
				var gst = 0;
				var tot = 0;
				var totgst = 0;
				var taxable = 0;
				var nontaxable = 0;
				var gstinvalue = $( '#gstin_' + index ).val();
				var qtygst = $( '#qty_' + index ).val();
				var other_taxtot = 0;
				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						sum += parseFloat( this.value );
					}
				} );
				document.getElementById( 'totalprice' ).value = Math.round( sum );

				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qtysum += parseFloat( this.value );
					}
				} );
				document.getElementById( 'totalprice' ).value = Math.round( qtysum );

				$( '.totalprice' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						tot += parseFloat( this.value );
					}
				} );
				document.getElementById( 'gtotalprice' ).value = Math.round( tot );
				var qttotal = 0;

				$( '.qty' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qttotal += parseFloat( this.value );
					}
				} );
				document.getElementById( 'qtyt' ).value = Math.round( qttotal );
				//=====================================
				//Total GST Amount
				$( '.gst' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						totgst += parseFloat( this.value );
					}
				} );
				document.getElementById( 'totalgst' ).value = Math.round( totgst );
				//=====================================
				//Other Tax Total amounts
				$( '.taxrate_amount' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						other_taxtot += parseFloat( this.value );
					}
				} );
				document.getElementById( 'other_tax_total_amount' ).value = Math.round( other_taxtot );
				//===============================
				$( '#paidamount' ).keyup( function () {

					$( '#balance_amt' ).val( $( '#gtotalprice' ).val() - $( '#paidamount' ).val() );
				} );
			} );

			$( '#insert_form' ).on( 'submit', function ( event ) {
				event.preventDefault();
				/* Validation */
				var error = '';
				/* Creating Index WHEN Clicking Add Button Or Enter Button */
				var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				// New index
				var index = Number( split_id[ 1 ] );

				$( '.qty' ).each( function () {
					if ( $( this ).val() == '' ) {
						$( this ).closest( 'tr' ).remove();
					}
				} );

				var vendor = $( '#v_name' ).val();
				var bill = $( '#billno' ).val();
				//var paid = $( '#paidamount' ).val();
				var name = $( '#name_' + index ).val();
				var purch = $( '#purchprice_' + index ).val();
				var qty = $( '#qty_' + index ).val();
				var purchqty = $( '#retqty_' + index ).val();
				var ledger = $( '#purchase_ledger_' + index ).val();

				if ( qty == '' ) {
					$.toast( {
						heading: 'Enter Quantity.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1500
					} );
					error = 1;
				}
				if ( parseInt( qty ) > parseInt( purchqty ) ) {
					$.toast( {
						heading: 'Return Quantity Canot Be Greater Than Purchase Qty.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1500
					} );
					error = 1;
				}

				var form_data = $( this ).serialize();
				if ( error == '' ) {

					$.ajax( {
						url: "purchase-action/edit-purchase-return.php",
						method: "POST",
						data: form_data,
						success: function ( data ) {
							if ( data == 'ok' ) {
								//$('#submit').hide();
								document.getElementById( "insert_form" ).reset();
								$( '#purchase' ).find( "tr:gt(0)" ).remove();
								$.toast( {
									heading: 'Bill Saved Successfully',
									text: '',
									position: 'top-right',
									loaderBg: '#4AD55E',
									icon: 'success',
									hideAfter: 7000,
									hideMethod: 'fadeOut'
								} );
								window.location.href = "supplier-info.php?sup_id=<?php echo $supplier_name; ?>";
							} else {
								$.toast( {
									heading: 'Error',
									text: '',
									position: 'top-right',
									loaderBg: '#F13109',
									icon: 'error',
									hideAfter: 4500
								} );
							}
						}
					} );
				}
			} );
		} );
	</script>
	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
					</li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
					</li>
				</ul>
				
			</div>
		</div>
	</div>
	</div>
	
	</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<!--select-->
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script>
		$( function () {
			// Switchery
			var elems = Array.prototype.slice.call( document.querySelectorAll( '.js-switch' ) );
			$( '.js-switch' ).each( function () {
				new Switchery( $( this )[ 0 ], $( this ).data() );
			} );
			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();


			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
	</script>
	<script>
		$( document ).ready( function () {
			$( '.simple-ajax-popup-align-top' ).magnificPopup( {
				type: 'ajax',
				alignTop: false,
				closeOnBgClick: false,
				openDelay: 800,
				overflowY: 'scroll'

			} );
			$( '.simple-ajax-popup' ).magnificPopup( {
				type: 'ajax'
			} );
		} );
	</script>
	<script>
		$( document ).ready( function () {

			$( '.fancybox' ).fancybox( {

				closeBtn: false, // hide close button
				closeClick: false, // prevents closing when clicking INSIDE fancybox
				helpers: {
					// prevents closing when clicking OUTSIDE fancybox
					overlay: {
						closeClick: false
					}
				},
				keys: {
					// prevents closing when press ESC button
					close: true
				}
			} );

		} );
		$( '#close_fbx' ).on( 'click', function () {
			parent.jQuery.fancybox.close();
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
	<script>
		$( document ).keyup( function ( e ) {
			if ( e.altKey && e.which == 49 ) {
				window.location.href = "creation.php";
			} else if ( e.altKey && e.which == 50 ) {
				window.location.href = "purchase-home.php";
			} else if ( e.altKey && e.which == 51 ) {
				window.location.href = "saleshome.php";
			} else if ( e.altKey && e.which == 52 ) {
				window.location.href = "inventory-home.php";
			} else if ( e.altKey && e.which == 53 ) {
				window.location.href = "accounts-home.php";
			} else if ( e.altKey && e.which == 54 ) {
				window.location.href = "cashcounter-home.php";
			} else if ( e.altKey && e.which == 55 ) {
				window.location.href = "anayisis.php";
			} else if ( e.altKey && e.which == 56 ) {
				window.location.href = "setting-home.php";
			}

			//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
			/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
		} );
	</script>
</body>

</html>