<?php
	session_start();
    if(isset($_COOKIE['_nhb']) && isset($_COOKIE['_vhb'])){
	$cukname = $_COOKIE['_nhb'];
	$cukval = $_COOKIE['_vhb'];
	include('db-connect/db.php');
	include('datetime_creation/datetime_creation.php');
	if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST[$cukname]) && ($_POST[$cukname] == $cukval)){
		$length = 5;
		$randomString = substr(str_shuffle("0123456789qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM"),0,$length);
		$token = date("dmY").time().''.$randomString.''.rand(100000, 990000);

		$username = $_POST['username'];
		$password = $_POST['password'];
		$company = $_POST['company'];
		$days = $_POST['days_left'];
		$current_date_time = date("Y-m-d H:i:s", time());
		
		$log_token = $token;
		$new_sess_tkn = $token;
		
		$company_details= $db->prepare("SELECT * FROM company ");
		$company_details->execute();
		$company_count = $company_details->rowcount();
		$rows_company= $company_details->fetch();
		// echo $rows_company['c_token'];
		
		if($company_count == '0' ){
		$check_1 = $db->prepare("SELECT * FROM admin_user WHERE user_username = '$username' AND user_password = '$password' AND stat='1'");
		$check_1->execute();
		$check_count = $check_1->rowcount();
		$rows_check1 = $check_1->fetch();
			if($rows_check1['user_username'] === $username && $rows_check1['user_password'] === $password && $rows_check1['typ'] == 'ADMIN'){
			$_SESSION['SESS_USERID'] = $rows_check1['user_tkn'];
			$_SESSION['SESS_USERTYPE'] = $rows_check1['typ'];
			$_SESSION['SESS_LOGTOKEN'] = $log_token;
			$_SESSION['SESS_EXPIRE'] = $days;
			session_write_close();	
				
			header("Location: company-creation.php");
			}else{
			setcookie("log_f2", true, time() + (3), "/");
			header('Location: index.php'); ?>
			<script>$.toast( {heading: 'Incorrect login details, Please try again.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});</script>	
		<?php }
		}else{
		
		
		
		$qry = $db->prepare("SELECT * FROM admin_user WHERE user_username = '$username' AND user_password = '$password' AND stat='1'");
		$qry->execute();
		$admin_user_count = $qry->rowcount();
		$rows = $qry->fetch();
		$user_tkn=$rows['user_tkn'];
			
		$company_data= $db->prepare("SELECT * FROM company WHERE c_token='$company' ");
		$company_data->execute();
		$company_data_count = $company_data->rowcount();
		$rows_company_data= $company_data->fetch();		
		
		if(!isset($_POST['company'])){
			setcookie("log_f6", true, time() + (3), "/");
				header('Location: index.php');	
		}else if($admin_user_count > 0){
			
			if($rows['user_username'] === $username && $rows['user_password'] === $password && $rows['typ'] == 'ADMIN') {
			$company_details1= $db->prepare("SELECT * FROM company where c_token='$company'");
			$company_details1->execute();
			$company_count1 = $company_details1->rowcount();
			$rows_company1= $company_details1->fetch();	
				
			$_SESSION['SESS_USERID_AS'] = $rows['user_tkn'];
			$_SESSION['SESS_USERTYPE_AS'] = $rows['typ'];
			$_SESSION['SESS_COMPANY_ID'] = $rows_company1['c_token'];
			$_SESSION['SESS_LOGTOKEN_AS'] = $log_token;
			$_SESSION['SESS_EXPIRE_IN'] = $days;
			session_write_close();

			$user_token = $rows['user_tkn'];
			$typ = $rows['typ'];
			if(!empty($_POST["remember"])) {
					setcookie ("username",$_POST["username"],time()+ 3600);
					setcookie ("password",$_POST["password"],time()+ 3600);
				
				} else {
					setcookie("username","");
					setcookie("password","");
				
				}
				
			$qry_log = $db->prepare("SELECT * FROM admin_user_log WHERE user_token = '$user_token' AND out_time = NULL ORDER BY id DESC LIMIT 1");
			$qry_log->execute();
			if($qry_log->rowcount() > 0){
				$rows_log = $qry_log->fetch();
				$log_token_c = $rows_log['log_token'];
				$db->prepare("UPDATE admin_user_log SET logout_as = 'session_out' WHERE log_token = '$log_token_c'")->execute();
			}
			$db->prepare("INSERT INTO admin_user_log (log_token, user_token, typ, in_time, in_date) VALUES ('$log_token','$user_token','$typ','$current_date_time','$today')")->execute();
			setcookie("CC", true, time() + (3), "/");		
			header("Location: index2.php");
			}else if(isset($_POST['company']) && $rows['user_username'] === $username && $rows['user_password'] === $password && $rows['typ'] == 'ADMIN'){
			$company_details1= $db->prepare("SELECT * FROM company where c_token='$company'");
			$company_details1->execute();
			$company_count1 = $company_details1->rowcount();
			$rows_company1= $company_details1->fetch();	
			$_SESSION['SESS_USERID_AS'] = $rows['user_tkn'];
			$_SESSION['SESS_USERTYPE_AS'] = $rows['typ'];
			$_SESSION['SESS_COMPANY_ID'] = $rows_company['c_token'];
			$_SESSION['SESS_LOGTOKEN_AS'] = $log_token;
			$_SESSION['SESS_EXPIRE_IN'] = $days;
			session_write_close();

			$user_token = $rows['user_tkn'];
			$typ = $rows['typ'];
			if(!empty($_POST["remember"])) {
					setcookie ("username",$_POST["username"],time()+ 3600);
					setcookie ("password",$_POST["password"],time()+ 3600);
					echo "Cookies Set Successfuly";
				} else {
					setcookie("username","");
					setcookie("password","");
					echo "Cookies Not Set";
				}
			$qry_log = $db->prepare("SELECT * FROM admin_user_log WHERE user_token = '$user_token' AND out_time = NULL ORDER BY id DESC LIMIT 1");
			$qry_log->execute();
			if($qry_log->rowcount() > 0){
				$rows_log = $qry_log->fetch();
				$log_token_c = $rows_log['log_token'];
				$db->prepare("UPDATE admin_user_log SET logout_as = 'session_out' WHERE log_token = '$log_token_c'")->execute();
			}
			$db->prepare("INSERT INTO admin_user_log (log_token, user_token, typ, in_time, in_date) VALUES ('$log_token','$user_token','$typ','$current_date_time','$today')")->execute();
				
				
			setcookie("CC", true, time() + (3), "/");	
			header("Location: index2.php");
			}else if(!isset($_POST['company']) && $rows['typ'] !='ADMIN'){	
				setcookie("log_f6", true, time() + (3), "/");
				header('Location: index.php');	
			}else if( $rows['user_username'] === $username && $rows['user_password'] === $password && $rows['typ'] != 'ADMIN' && $rows_company_data['c_token'] === $company){
			$company_details12= $db->prepare("SELECT * FROM company where c_token='$company' AND user_tkn='$user_tkn' ");
			$company_details12->execute();
			$company_count12 = $company_details12->rowcount();
			$rows_company12= $company_details12->fetch();
			if($company_count12 > 0){
			$_SESSION['SESS_USERID_AS'] = $rows['user_tkn'];
			$_SESSION['SESS_USERTYPE_AS'] = $rows['typ'];
			$_SESSION['SESS_COMPANY_ID'] = $rows_company12['c_token'];
			$_SESSION['SESS_LOGTOKEN_AS'] = $log_token;
			$_SESSION['SESS_EXPIRE_IN'] = $days;
			session_write_close();

			$user_token = $rows['user_tkn'];
			$typ = $rows['typ'];
			//remember
				if(!empty($_POST["remember"])) {
					setcookie ("username",$_POST["username"],time()+ 3600);
					setcookie ("password",$_POST["password"],time()+ 3600);
					echo "Cookies Set Successfuly";
				} else {
					setcookie("username","");
					setcookie("password","");
					echo "Cookies Not Set";
				}
			$qry_log = $db->prepare("SELECT * FROM admin_user_log WHERE user_token = '$user_token' AND out_time = NULL ORDER BY id DESC LIMIT 1");
			$qry_log->execute();
			if($qry_log->rowcount() > 0){
				$rows_log = $qry_log->fetch();
				$log_token_c = $rows_log['log_token'];
				$db->prepare("UPDATE admin_user_log SET logout_as = 'session_out' WHERE log_token = '$log_token_c'")->execute();
			}
			$db->prepare("INSERT INTO admin_user_log (log_token, user_token, typ, in_time, in_date) VALUES ('$log_token','$user_token','$typ','$current_date_time','$today')")->execute();
			setcookie("CC", true, time() + (3), "/");	
			header("Location: index2.php");
			}else{
			setcookie("log_f7", true, time() + (3), "/");
				header('Location: index.php');	
			}
			}else{
				setcookie("log_f2", true, time() + (3), "/");
				header('Location: index.php');
			}
			}else{
			$qry_0 = $db->prepare("SELECT * FROM admin_user WHERE user_username = '$username' AND user_password = '$password'");
			$qry_0->execute();
			if($qry_0->rowcount() > 0){
				setcookie("log_f3", true, time() + (3), "/");
				header('Location: index.php');
			}else{
				setcookie("log_f2", true, time() + (3), "/");
				header('Location: index.php');
			}
		} }
	}else{
		setcookie("log_f1", true, time() + (3), "/");
		header('Location: index.php');
	} 
}else{
	setcookie("log_f0", true, time() + (3), "/");
	header('Location: index.php');
}
	
?>