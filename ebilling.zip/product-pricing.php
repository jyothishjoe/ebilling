<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid=$_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];

$date_set = $today;

?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Product Pricing </title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/auto/all.css">

</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					    <h4 class="text-themecolor" style="float: left;">Item Pricing&nbsp; <strong>(<?php echo $today = date('d-m-Y'); ?>)</strong> </h4>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item active"><a href="inventory-home.php">Inventory</a></li>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<a href="purchse.php?billn=<?= $billno+1 ?>"></a>
								<div class="clear"></div>
								<hr/>
								<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
									<div class="form-row">
										<div class="col-md-3 col-sm-6 col-xs-12  mb-3">
											<input type="text" class="form-control billno" name="billno" id="billno" placeholder="PV Number">
										</div>
										<div class="col-md-3 col-sm-6 col-xs-12  mb-3">
											<input type="date" class="form-control" name="billdate" id="billdate" autocomplete="off" placeholder="PV Date">
											<input type="hidden" class="form-control" name="phone" id="phone" placeholder="Mobile Number">
											<input type="hidden" class="form-control" name="company" id="company" value="<?php echo $user_company; ?>">
										</div>
										<div class="col-md-2"><input type="button" name="getdata" id='getdata' class="btn btn-sm btn-info" value="Submit" style="margin-top: 3px;"></div>
										<div class="col-md-2 col-sm-6 col-xs-12 " style="float: right">
											<input type="date" class="form-control" name="date" id="date" value="<?= $date_set; ?>" > &nbsp;
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-3">
											<input type="time" class="form-control" name="time" id="time" value="<?= date('H:i') ?>" readonly>
										</div>
									</div>
										</div><br>
									<div class="col-12" id="billdata">
									</div>
								</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			$( document ).ready( function () {
				$( ':input[type="submit"]' ).prop( 'disabled', true );
				$(document).on( 'keyup', '.mrp' , function () {
					var id = this.id;
					var splitid = id.split( '_' );
					var index = splitid[ 1 ];
						$( '#totalpurchamount_' + index ).val( $( '#purchprice_' + index ).val() * $( '#qty_' + index ).val() );
						var ad= $('#purchprice_' + index ).val() - ($('#purchprice_' + index ).val() * (100/(100 + parseInt($( '#salesgstin_' + index ).val()))));
						$( '#gstinamt_' + index ).val(ad);
						
						
						//$( '#unitgst_' + index ).val( $( '#gstinamt_' + index ).val() );
						$( '#totalpurch_' + index ).val( parseInt( $( '#totalpurchamount_' + index ).val() ) + parseInt( $( '#gstinamt_' + index ).val() / $( '#qty_' + index ).val() ) );
						// Other Taxes calculation
						if($('#othertax_amt1_' + index ).val() != 0){
						$('#othertax_amount1_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt1_' + index ).val() / 100);
						}
						if($('#othertax_amt2_' + index ).val() != 0){
						$('#othertax_amount2_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100);
						}
						if($('#othertax_amt3_' + index ).val() != 0){
						$('#othertax_amount3_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100);
						}
						if($('#othertax_amt4_' + index ).val() != 0){
						$('#othertax_amount4_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100);
						}
						if($('#othertax_amt5_' + index ).val() != 0){
						$('#othertax_amount5_' + index ).val( $( '#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100);
						}
						//Total AMount of the Produt(Each row Wise total amount)  
					
						$( '#tax_total_' + index ).val(parseFloat($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()) + parseInt($( '#gstinamt_' + index ).val()));
						$( '#totalcost_' + index ).val( parseInt( $( '#totalpurch_' + index ).val() ) / $( '#qty_' + index ).val() );
						$( '#mrprate_' + index ).val( parseInt( $( '#purchprice_' + index ).val()) - $( '#tax_total_' + index ).val());
						
					} );
					$( '.mrp' ).change( function () {
						var text1 = parseInt( $( '#mrp_' + index ).val());
						var text2 = parseInt( $( '#purchprice_' + index ).val());
						if ( text1 < text2 ) {
							$.toast( {
								heading: 'MRP Should Be Greater Than Purchase Cost.',
								text: '',
								position: 'top-right',
								loaderBg: '#F13109',
								icon: 'error',
								hideAfter: 1900
							} );
							$( ':input[type="submit"]' ).prop( 'disabled', true );
							$( ':input[type="submit"]' ).attr( "disabled" ).css( "not-allowed", "default" ).fadeTo( 500, 0.2 ).cursor( "crosshair;" );
						} else if ( text1 == '' ) {
							$.toast( {
								heading: 'Enter Mrp.',
								text: '',
								position: 'top-right',
								loaderBg: '#F13109',
								icon: 'error',
								hideAfter: 1800
							} );
							$( ':input[type="submit"]' ).prop( 'disabled', true );
							$( ':input[type="submit"]' ).attr( "disabled" ).css( "pointer", "not-allowed! important;" ).fadeTo( 500, 0.2 ).cursor( "crosshair;" );
						} else {
							$( ':input[type="submit"]' ).prop( 'disabled', false );
						}
					} );
				
			} );
		</script>
		
		<script type="text/javascript">
			/* table data (purchase bill items)*/
			$( "#getdata" ).click( function () {

				//var vendor = $( '#v_name' ).val();
				var bill = $( '#billno' ).val();
				var company = $( '#company' ).val();
				var billdate = $( '#billdate' ).val();
                if(bill == ''){
					$.toast( {heading: 'Enter Bill No.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 4500} );
				} else if(billdate == ''){
					$.toast( {heading: 'Enter Bill Date.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 4500} );
				}else{
				$.ajax({
					type: 'POST',
					url: 'stock-pricing.php',
					data: 'bill=' + bill + '&billdate=' + billdate + '&company=' + company,
					success: function ( r ) {
						$( "#billdata" ).html( r );
					}
				});
			}
			} );
			var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
		</script>

		<div class="right-sidebar">
			<div class="slimscrollright">
				<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
				<div class="r-panel-body">
					<ul id="themecolors" class="m-t-20">
						<li><b>With Light sidebar</b>
						</li>
						<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
						</li>
						<li class="d-block m-t-30"><b>With Dark sidebar</b>
						</li>
						<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
						</li>
						<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
						</li>
					</ul>
					
				</div>
			</div>
		</div>
	</div>
	
	</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
    <script src="js/mask.init.js"></script>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	
</body>

</html>