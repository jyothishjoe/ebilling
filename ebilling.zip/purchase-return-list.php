<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
if(isset ($_GET['startdate'] )){
$startdates = date_create($_GET['startdate']);
$startdates = date_format($startdates,'Y-m-d');

}else{
$startdates = date_create($today);
$startdates = date_format($startdates,'Y-m-d');	
	
}
$result_sum = $db->prepare( "SELECT SUM(grand_total) AS total FROM purchasereturn_invoice WHERE company_tkn='$user_company'" );
$result_sum->execute();
$rows_sum = $result_sum->fetch();
$sum = $rows_sum[ 'total' ];
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Purchase Return List</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/auto/all.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>

</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor" style="float: left;">Purchase Return Reports</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item"><a href="purchase-home.php">Purchase</a></li>
							<li class="breadcrumb-item active">Purchase Return List</li>
						</ol>
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
									<form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datelist.php'); ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 15px;" value="Submit"/>
										</div>
									</div>
								</form>
									<div class="table-responsive m-t-40">
									<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>#</th>
												<th>PV No</th>
												<th>PV Date</th>
												<th>Supplier</th>
												<th>Return Bill No</th>
												<th>Return Invoice Date</th>
												<th>Location</th>
												<th>Qty</th>
												<th>Amount</th>
												<th>Discount</th>
												<th>GST Amount</th>
												<th>Net Total</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php 
											$result_purchase = $db->prepare("SELECT * FROM purchasereturn_invoice a LEFT JOIN supplier b ON b.supplier_token=a.sup_token  WHERE a.bill_date = '$startdates' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' ");
											$result_purchase ->execute(); 
											$sl = 0;
											for ($i=0; $rows_purchase  = $result_purchase ->fetch(); $i++){
											$norm_date = $rows_purchase['bill_date'];
											$date = date_create($norm_date);
											$condate = date_format($date,'d-m-Y');
											$retdate = date_create($rows_purchase['bill_date']);
											$retdate = date_format($retdate,'d-m-Y');
												$tok = $rows_purchase['purch_token'];
											?>
											<tr>
												<td><?php echo $i+1; ?></td>
												<td><?php echo $rows_purchase['inv']; ?></td>
												<td><?php echo $condate; ?></td>
												<td><?php echo $rows_purchase['v_name']; ?></td>
												<td><?php echo $rows_purchase['bill_no']; ?></td>
												<td><?php echo $retdate; ?><br>
												<?php echo $rows_purchase['bill_time']; ?></td>
												<td><?php echo $rows_purchase['city']; ?></td>
												<td><?php
													$result_sum = $db->prepare( "SELECT SUM(qty) AS total FROM purchasereturn_productdetails WHERE purch_token='$tok' AND company_tkn='$user_company' " );
													$result_sum->execute();
													$rows_sum = $result_sum->fetch();
													echo $rows_sum[ 'total' ];
													?></td>
												<td>₹<?php echo $rows_purchase['total_price']; ?></td>
												<td>₹<?php echo $rows_purchase['discount_total']; ?></td>
												<td>₹<?php echo $rows_purchase['totalgst_amt']; ?></td>
											    <td>₹<?php echo $rows_purchase['grand_total']; ?></td>
											    <th><a href="purchase-return-print1.php?bill=<?php echo $rows_purchase['inv']; ?>" class="btn btn-sm btn-info"><i class="fa fa-print" aria-hidden="true"></i></a></th>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script>
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>

	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>