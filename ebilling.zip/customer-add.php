<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
?>
<?php 
$result =$db->prepare("SELECT * FROM  customer WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
$result->execute();
$rows=$result->fetch();
if(empty($rows)){
$cus_no=1;	
}else{
$cus_no=$rows['cus_no'] + 1;	
}

?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
ul, li{z-index:9999 !important;}
</style>
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-ui.min.js"></script>
<div class="col-xs-12 no-padding" style="width:600px; overflow: hidden;">
<h3 class="text-center">Add Customer</h3><br>
<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
  <div class="form-row">
      <input type="hidden" class="form-control" id="date_" name="date_"  value="<?php echo $today;?>" required>
    <input type="hidden" class="form-control" id="cus_no" name="cus_no" value="<?php echo $cus_no;?>" readonly>
    <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
	  <input type="hidden" class="form-control"  id="company" name="company" value="<?php echo $user_company;?>" readonly>
    <input type="hidden" class="form-control"  id="cus_tkn" name="cus_tkn" value="<?php echo create_token();?>" readonly>
    <input type="hidden" class="form-control"  value="<?php echo $current_date_time;?>" name="datetym"  id="datetym" readonly>
    <div class="col-md-12"></div>
   
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Customer Name</label>
      <input type="text" class="form-control cus_name" id="customer_name" name="customer_name" placeholder="Enter Customer Name">
      <div id="uname_response" class="response"></div>
    </div>
	  <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Opening Balance</label>
      <input type="text" class="form-control" name="credit_limit" id="credit_limit"  placeholder="Opening balance">
    </div>
    <div class="col-md-12 col-sm-6 col-xs-12 mb-3">
	<div class="row">
	<div class="col-md-4">
      <label for="" class="control-label">Address</label>
      <textarea class="form-control" id="addres" rows="4" name="addres" placeholder="Required address" ></textarea>
	</div>
	<div class="col-md-8">
	<div class="row">
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Location</label>
      <input type="text" class="form-control" id="location" name="location" placeholder="Enter Location">
    </div>
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">State</label>
      <select class="form-control select2" id="state" name="state" style="width: 100%; height:36px;">
		<option value="">Select State</option>
		<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
		<option value="Andhra Pradesh">Andhra Pradesh</option>
		<option value="Arunachal Pradesh">Arunachal Pradesh</option>
		<option value="Assam">Assam</option>
		<option value="Bihar">Bihar</option>
		<option value="Chandigarh">Chandigarh</option>
		<option value="Chhattisgarh">Chhattisgarh</option>
		<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
		<option value="Daman and Diu">Daman and Diu</option>
		<option value="Delhi">Delhi</option>
		<option value="Goa">Goa</option>
		<option value="Gujarat">Gujarat</option>
		<option value="Haryana">Haryana</option>
		<option value="Himachal Pradesh">Himachal Pradesh</option>
		<option value="Jammu and Kashmir">Jammu and Kashmir</option>
		<option value="Jharkhand">Jharkhand</option>
		<option value="Karnataka">Karnataka</option>
		<option value="Kerala">Kerala</option>
		<option value="Lakshadweep">Lakshadweep</option>
		<option value="Madhya Pradesh">Madhya Pradesh</option>
		<option value="Maharashtra">Maharashtra</option>
		<option value="Manipur">Manipur</option>
		<option value="Meghalaya">Meghalaya</option>
		<option value="Mizoram">Mizoram</option>
		<option value="Nagaland">Nagaland</option>
		<option value="Orissa">Orissa</option>
		<option value="Pondicherry">Pondicherry</option>
		<option value="Punjab">Punjab</option>
		<option value="Rajasthan">Rajasthan</option>
		<option value="Sikkim">Sikkim</option>
		<option value="Tamil Nadu">Tamil Nadu</option>
		<option value="Tripura">Tripura</option>
		<option value="Uttaranchal">Uttaranchal</option>
		<option value="Uttar Pradesh">Uttar Pradesh</option>
		<option value="West Bengal">West Bengal</option>
	</select>
    </div>
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Contact No 1</label>
      <input type="text" class="form-control" id="contact_no1" name="contact_no1"  placeholder="Enter Contact Number">
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Contact No 2</label>
      <input type="text" class="form-control" id="contact_no2" name="contact_no2"  placeholder="Enter Contact Number">
    </div>
	</div>
	</div>
		<div class="col-md-4 col-sm-6 col-xs-12">
      <label for="" class="control-label">Credit Limit</label>
      <input type="date" class="form-control" name="cr_limit" id="cr_limit" placeholder="Credit Limit" >
    </div>
		<div class="col-md-4 col-sm-6 col-xs-12">
      <label for="" class="control-label">Credit Amount</label>
      <input type="text" class="form-control" name="cr_amt" id="cr_amt" placeholder="Amount" >
    </div>
		<div class="col-md-4 col-sm-6 col-xs-12">
      <label for="" class="control-label">Discount</label>
      <input type="text" class="form-control" name="discount" id="discount" placeholder="Discount" >
    </div>
    </div>
		
	</div>
   
    
  </div>
  <div class="text-right" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info" id="cussave">Submit</a>
    <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right">CANCEL</button>
  </div>
</form>
	<div id="respond"></div>
<script>
  $( document ).ready( function () {

					$( "#customer_name" ).keyup( function () {
						var cus = $( "#customer_name" ).val().trim();
						if ( cus != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'creation_actions/customer/cusnamesearch.php',
								type: 'post',
								data: {
									cus: cus
								},
								dataType : 'JSON',
								success: function ( data ) {
									if ( data.customer > 0 || data.ledger > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  already in use.</span>" );
										document.getElementById("location").disabled = true;
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										   document.getElementById( 'location' ).value = '';
										  document.getElementById("location").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("location").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
</script> 
<script>
		  $( '#close_fbx' ).on( 'click', function () {
		 location.reload();
	        } );
          function save_user(){
			var cus_no = $("#cus_no").val();
			var aco_tkn = $("#aco_tkn").val();
			var addby = $("#addby").val();
			var datetym = $("#datetym").val();
			var acco_name = $("#acco_name").val();
			var customer_name = $("#customer_name").val();
			var cus_tkn = $("#cus_tkn").val();
			var company = $("#company").val();
			var location = $("#location").val();
			var addres = $("#addres").val();
			var contact_no1 = $("#contact_no1").val();
			var contact_no2 = $("#contact_no2").val();
		  	var cr_limit = $("#cr_limit").val();
		  	var cr_amt = $("#cr_amt").val();
		  	var discount = $("#discount").val();

			var sate = $("#state").val();
			var date_ = $("#date_").val();
			 if($("#customer_name").val() == ""){$.toast( {heading: 'Fill customer name.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1200} );
			
		
			} else {	
			$( "#cussave" ).hide();
			$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/customer/customer_save.php',
					data: "cus_no="+ cus_no + "&date_=" + date_ + "&addby=" + addby + "&datetym=" + datetym + "&acco_name=" + acco_name + "&customer_name=" + customer_name + "&location=" + location + "&contact_no1=" + contact_no1 + "&contact_no2=" + contact_no2 + "&credit_limit=" + credit_limit + "&addres=" + addres + "&cus_tkn=" + cus_tkn + "&aco_tkn=" + aco_tkn + "&sate=" + sate + "&company=" + company + "&cr_limit=" + cr_limit + "&cr_amt=" + cr_amt + "&discount=" + discount,
					success : function(r) {						
				    $("#respond").html(r);
					} 
				});
				//document.getElementById( "insert_form" ).reset(); $( "#uname_response" ).hide();
				$( "#cussave" ).show();
			/*	parent.jQuery.fancybox.close();*/
			/*	setTimeout(function(){ window.location.reload(1);}, 1500);*/
				/*document.getElementById( "insert_form" ).reset(); $( "#uname_response" ).hide(); $( "#cussave" ).show();
					$.toast( {
					heading: 'Customer Add Succeccfully.',
					text: '',
					position: 'top-right',
					loaderBg: '#1FDE13',
					icon: 'success',
					hideAfter: 2500
					} );*/
				return false;
			}
		}

</script>