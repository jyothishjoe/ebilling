<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include('db-connect/db.php');
$token=$_GET['cusid'];
$result_user = $db->prepare("SELECT * FROM admin_user WHERE user_tkn='$token' ");
$result_user->execute();
$rows_user = $result_user->fetch(); 
?>
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php");?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
#close_fbx { margin: 0px; position: relative;  background: #ef5350 !important; color: #fff; opacity: 1; width: 50px; font-size: 13px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #ef5350 !important;}
</style>

<div id="custom-content"  class="col-md-3 col-sm-6 col-xs-12" style="margin: 50px auto; width:600px; padding-top:20px; overflow: hidden;  background-color: #f2f2f2;">
<h3 class="text-center">Update User</h3><br>
<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
  <div class="form-row">
    <div class="col-md-12"></div>
  <div class="form-row text-left">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">User Name </label>
				<input type="text" class="form-control" id="user_name" name="user_name"  value="<?php echo $rows_user['user_username'];?>">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="user_tkn" name="user_tkn" value="<?php echo $token; ?>">
			</div>
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">User Type </label>
				<input type="text" readonly class="form-control user_type" id="user_type" name="user_type"  value="<?php echo $rows_user['typ'];?>">
				<input type="hidden" class="form-control" id="user_type_tkn" name="user_type_tkn"  value="<?php echo $rows_user['user_type'];?>">
			</div>
				<input type="hidden" class="form-control" id="user_password" name="user_password"  readonly value="<?php echo $rows_user['user_password'];?>">
				
				<input type="hidden" class="form-control" id="counter" name="counter"  readonly value="<?php echo $rows_user['counter'];?>">
			
		</div>
  <div class="col-md-12" style="margin-bottom: 18px;">
    <div class="text-right"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Update</a>
      <button type="button"  id="close_fbx" class="btn btn-sm btn-danger mfp-close ">Cancel</button>
    </div>
  </div>
</form>

<script>
											
			                             function myFunction() {
		                                  parent.jQuery.magnificPopup.close();
	                                               } 
										function save_user() {
											var user_name = $("#user_name").val();
											var user_password = $("#user_password").val();
											var user_type_tkn = $("#user_type_tkn").val();
											var user_type = $("#user_type").val();
											var counter = $("#counter").val();
											var userid = $("#userid").val();
											var user_tkn = $("#user_tkn").val();
											
											if ( $("#user_name").val() == "" || $("#user_password").val() == "" || $("#user_type").val() == "" || $("#counter").val() == "") {
											$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 4500} );
											}else{
												$( "#gstsave" ).hide();
												$.ajax({
													type: 'POST',
													url: "settings-action/user/update_user.php",
													data: "user_name=" + user_name + "&userid=" + userid + "&user_password=" + user_password  + "&user_type=" + user_type + "&counter=" + counter + "&user_tkn=" + user_tkn,
													success: function (r) {
													$( "#respond" ).html(r);
													}
												});
												//parent.jQuery.magnificPopup.close();
												  
												  //setTimeout(function(){ window.location.reload(1);}, 1500);
												/*$.toast( {
													heading: 'user Update Succeccfully.',
													text: '',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1000
												} );*/
												return false;
											}
										}
									</script>
									<div id="respond"></div>