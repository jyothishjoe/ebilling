<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
?>

<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
ul, li{z-index:9999 !important;}
</style>
<div class="col-xs-12 no-padding" style="width:400px; overflow: hidden;">
<h3 class="text-center">Add Season</h3><br>
<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
  <div class="form-row">
    <div class="col-md-6 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Season Name</label>
      <input type="text" class="form-control season_name" name="season_name" id="season_name" placeholder="Enter Season Name" autofocus>
		<input type="hidden" class="form-control company" name="company" id="company" value="<?php echo $user_company; ?>"> 
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Year</label>
      <input type="number" class="form-control season_year" id="season_year" name="season_year" value="<?php echo $year;?>">
    </div>
	 <?php 
				$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' AND company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				$dateformate=$rows['dateformate'];
				?>
 <?php if($dateformate == 'datechoos') { ?>
<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
  <label for="" class="control-label">Start Date</label>
  <input type="date" class="form-control" id="start_date" name="start_date" required>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
  <label for="" class="control-label">End Date</label>
  <input type="date" class="form-control" id="end_date" name="end_date"  required>
</div>
<?php } else { ?>
<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
  <label for="" class="control-label">Start Date</label>
  <input type="text" class="form-control date-inputmask" id="start_date"  name="start_date" required>
</div>
<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
  <label for="" class="control-label">End Date</label>
  <input type="text" class="form-control date-inputmask" id="end_date"  name="end_date" required>
</div>
<?php } ?>
   </div>
  <div class="text-right" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
    <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right">CANCEL</button>
  </div>
</form>
</div>

<script>
		  $( '#close_fbx' ).on( 'click', function () {
		   parent.jQuery.fancybox.close();
	        } );
           function save_user(){
			var cus_no = $("#cus_no").val();
			var season_name = $("#season_name").val();
			var season_year = $("#season_year").val();
			   var company = $("#company").val();
			var start_date = $("#start_date").val();
			var end_date = $("#end_date").val();
		    if($("#season_name").val() == ""){$.toast( {heading: 'Fill Season Name.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
			} else if($("#start_date").val() == ""){	$.toast( {	heading: 'Fill Start Date.',	text: '',	position: 'top-right',loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#end_date").val() == ""){	$.toast( {	heading: 'Fill End Date.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',icon: 'error',hideAfter: 1500	} );
			} else    {	$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/season/season_save.php',
					data: "season_name=" + season_name + "&season_year=" + season_year + "&start_date=" + start_date + "&end_date=" + end_date + "&compay=" + company,
					success : function(r) {						
						$("#respond").html(r);
					}
				});
				//parent.jQuery.fancybox.close();
			/*	setTimeout(function(){ window.location.reload(1);}, 1500);*/
				document.getElementById( "insert_form" ).reset();
				/*$.toast( {
				heading: 'Season Add Succeccfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#1FDE13',
				icon: 'success',
				hideAfter: 1000
				} );*/
				return false;
			}
		}

</script>
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<?php include("assets/custom/custom.php");?>
