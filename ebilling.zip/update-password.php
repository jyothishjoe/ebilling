<?php 
include ('include/auth.php');
include('db-connect/db.php');
include('include/today.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div  class="col-md-12 col-sm-6 col-xs-12" style="overflow: hidden; width: 500px; background-color: #f2f2f2;">
	 <h3 class="text-center" style="margin-top: 12px;">Update Password</h3>
			 <form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
				 <input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
				 <input type="hidden" name="company" id="company" value="<?php echo $user_company; ?>">
					<div class="form-row">
						<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
							<label for="" class="control-label">Old Password</label>
							<input type="text" class="form-control" id="oldpassword" name="oldpassword" value="" placeholder="Old Password">
						</div>
				 </div>
				 <div class="form-row">
						<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
							<label for="" class="control-label">New Password</label>
							<input type="text" class="form-control" id="newpass" name="newpass" placeholder="New Password" required>
						</div>
					</div>
					<div class="form-row">
						<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
							<label for="" class="control-label">Confirm Password</label>
							<input type="text" class="form-control" id="newpassword" name="newpassword" placeholder="Confirm Password" required>
						</div>
					</div>
					<div class="text-right">
							<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">Cancel</button>
							<a href="javascript: save_customer()" class="btn btn-sm  btn-info">Update</a> 
					</div>
				</form>
				<script>
		$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
			function save_customer() {
				var oldpassword = $( "#oldpassword" ).val();
				var newpassword = $( "#newpassword" ).val();
				var userid = $( "#userid" ).val();
				var newpass = $( "#newpass" ).val();
				var company = $( "#company" ).val();


				if ($("#oldpassword").val() == "" || $("#newpassword").val() == "" ){
					$.toast({heading: 'Fill all required fields.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200});
				}else if(newpassword !== newpass){
					$.toast({heading: 'Passwords Not match.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200});
				}else{
					$.ajax({
					type : 'POST',
					url  : "settings-action/update_password.php",
					data: "oldpassword="+ oldpassword + "&newpassword=" + newpassword + "&userid=" + userid + "&company=" + company,
					success : function(r) {						
					$("#respond").html(r);
						}
					});
					/*$.toast( {
						heading: 'Updated Succeccfully.',
						text: '',
						position: 'top-right',
						loaderBg: '#1FDE13',
						icon: 'success',
						hideAfter: 1200
					} );*/
					 parent.jQuery.fancybox.close();

					return false;
				
			}
			}
		
		</script>
		<div id="respond"></div>