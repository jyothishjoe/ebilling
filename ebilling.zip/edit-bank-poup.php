<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'datetime_creation/datetime_creation.php' );
$token = $_GET[ 'edit' ];
$result_bank = $db->prepare( "SELECT * FROM bank  WHERE bank_token = '$token'" );
$result_bank->execute();
$rows_bank = $result_bank->fetch();
$userid = $_SESSION[ 'SESS_USERID_AS' ];
?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>
<div id="custom-content" class="col-md-10 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #ffffff;">
<h3 class="text-center">Bank</h3>
<form action="" method="post" id="insert_form">
<div class="form-row">
<div class="col-md-4 mb-3">
<div class="form-group row">
<label for="validationTooltip01" class="control-label  col-12">Account Name</label>
			<div class="col-12">
				<input type="text" class="form-control " id="accname" name="accname" value="<?php echo $rows_bank['account_name']; ?>" readonly>
				<input type="hidden" class="form-control " id="token" name="token" value="<?php echo $token; ?>" readonly>
			</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip01" class="control-label  col-md-12">Bank Name</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo $rows_bank['bank_name']; ?>">
					<input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
				</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Bank Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="code" id="code" placeholder="Bank Code" value="<?php echo $rows_bank['bank_name']; ?>">
				</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltipUsername" class="control-label  col-md-12">Address</label>
				<div class="input-group col-md-12">
					<textarea class="form-control" name="address" id="address" placeholder="Address" aria-describedby="validationTooltipUsernamePrepend" rows="4"><?php echo $rows_bank['bank_address']; ?></textarea>
				</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
			<label for="validationTooltip03" class="control-label col-md-12">State</label>
				<div class="col-md-12">
				<select name="state" id="state" class="form-control">
				<option value="<?php echo $rows_bank['bank_state'];  ?>"><?php echo $rows_bank['bank_state']; ?></option>
				<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
				<option value="Andhra Pradesh">Andhra Pradesh</option>
				<option value="Arunachal Pradesh">Arunachal Pradesh</option>
				<option value="Assam">Assam</option>
				<option value="Bihar">Bihar</option>
				<option value="Chandigarh">Chandigarh</option>
				<option value="Chhattisgarh">Chhattisgarh</option>
				<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
				<option value="Daman and Diu">Daman and Diu</option>
				<option value="Delhi">Delhi</option>
				<option value="Goa">Goa</option>
				<option value="Gujarat">Gujarat</option>
				<option value="Haryana">Haryana</option>
				<option value="Himachal Pradesh">Himachal Pradesh</option>
				<option value="Jammu and Kashmir">Jammu and Kashmir</option>
				<option value="Jharkhand">Jharkhand</option>
				<option value="Karnataka">Karnataka</option>
				<option value="Kerala">Kerala</option>
				<option value="Lakshadweep">Lakshadweep</option>
				<option value="Madhya Pradesh">Madhya Pradesh</option>
				<option value="Maharashtra">Maharashtra</option>
				<option value="Manipur">Manipur</option>
				<option value="Meghalaya">Meghalaya</option>
				<option value="Mizoram">Mizoram</option>
				<option value="Nagaland">Nagaland</option>
				<option value="Orissa">Orissa</option>
				<option value="Pondicherry">Pondicherry</option>
				<option value="Punjab">Punjab</option>
				<option value="Rajasthan">Rajasthan</option>
				<option value="Sikkim">Sikkim</option>
				<option value="Tamil Nadu">Tamil Nadu</option>
				<option value="Tripura">Tripura</option>
				<option value="Uttaranchal">Uttaranchal</option>
				<option value="Uttar Pradesh">Uttar Pradesh</option>
				<option value="West Bengal">West Bengal</option>
				</select>
			</div>
			<label for="validationTooltip03" class="control-label col-md-12">Pin Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="pincode" id="pincode" placeholder="Pin" value="<?php echo $rows_bank['bank_pin']; ?>" >
				</div>
		</div>
	</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">IFC Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="ifsc" id="ifsc" placeholder="IFSC" value="<?php echo $rows_bank['bank_ifsc']; ?>">
				</div>
				<label for="validationTooltip01" class="control-label  col-md-12">Branch</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="branch" id="branch" placeholder="Branch" value="<?php echo $rows_bank['bank_branch']; ?>">
				</div>
			</div>
	</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Account No</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="accno" id="accno" placeholder="Account No" value="<?php echo $rows_bank['account_no']; ?>">
				</div>
			</div>
		</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Book Balance</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="balance" id="balance" placeholder="Balance" value="<?php echo $rows_bank['book_balance']; ?>">
				</div>
			</div>
		</div>
	<div class="col-md-12" style="margin-bottom: 12px;"> 
		<a href="javascript: save_customer()" name="submit" class="btn btn-info btn-sm" id="submit" style="float: right;">Submit</a>
		<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close" style="float: right; margin-right: 5px;">Cancel</button>
	</div>
	</form>
<script>
	$( '#close_fbx' ).on( 'click', function (){
	  parent.jQuery.fancybox.close();
		});
	   function save_customer() {
		var name = $( "#name" ).val();
		var branch = $( "#branch" ).val();
		var ifsc = $( "#ifsc" ).val();
		var state = $( "#state" ).val();	
		var address = $( "#address" ).val();
		var pin = $( "#pincode" ).val();
		var userid = $( "#userid" ).val();
		var code = $( "#code" ).val();
	   //var accname = $( "#accname" ).val();
	   var accno = $( "#accno" ).val();
	   var balance = $( "#balance" ).val();
		     var token = $( "#token" ).val();

		if ( $( "#name" ).val() == "" || $( "#branch" ).val() == "" || $( "#ifsc" ).val() == "" || $( "#state" ).val() == "" || $( "#code" ).val() == "" ){
			$.toast({heading: 'Fill all required fields.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500});
		} else {
			$.ajax({
			type : 'POST',
			url  : "accounts/edit_bank.php",
			data: "name="+ name + "&branch=" + branch + "&accno=" + accno + "&balance=" + balance + "&ifsc=" + ifsc + "&state=" + state + "&address=" + address + "&pin=" + pin + "&userid=" + userid + "&code=" + code + "&token=" + token,
			success : function(r){						
			$("#respond").html(r);
			}
			});
			window.location.href="bank-list.php";
			//parent.jQuery.fancybox.close();
			//document.getElementById('insert_form').reset();
			$.toast( {heading: 'Updated Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 4500});
			return false;
			
			
		}
	}
</script>
