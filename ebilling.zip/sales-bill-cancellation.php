<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
ul, li{z-index:9999 !important;}
.demo-checkbox label, .demo-radio-button label {
  min-width: 140px !important;
  margin-bottom: 20px; margin-left:30px;}
  #close_fbx { margin: 0px; position: relative;  background: #ef5350 !important; color: #fff; opacity: 1; width: 50px; font-size: 13px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #ef5350 !important;}
</style>
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<div id="custom-content"  class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; width:760px; padding-top:20px; overflow: auto;  background-color: #f2f2f2;">
<h3 class="text-center">Sales Bill Cancelation</h3><br>
<form method="post" action="creation_actions/bill-cancel/sales_bill_cancel.php" class="forms" name="insert_form" id="insert_form" autocomplete="off">
 <div class="demo-checkbox text-left">
 <?php
 $results =$db ->prepare("SELECT * FROM sales_invoice where status='1'");
$results->execute();	$row_count =  $results->rowcount();
$result =$db ->prepare("SELECT * FROM sales_invoice where status='1'");
$result->execute();	
for($i=0; $rows = $result->fetch(); $i++) {$sbill_no=$rows["sbill_no"];
?>
 <input type="checkbox" id="basic_checkbox_<?php echo $i;?>" class="filled-in" name="billno[]" value="<?php echo $sbill_no;?>"  />
 <label for="basic_checkbox_<?php echo $i;?>"><?php echo $sbill_no;?></label>
<?php } ?>
<?php if($row_count!=0){?>
 <br>
  <input type="hidden"  name='company'  id="company" value="<?php echo $user_company; ?>" />
  <input type="checkbox"  class="filled-in"  id="selectall" />
 <label for="selectall">Select All</label>
<?php } else { ?>
<P><center>No Cancelation Bill</center></p>
<?php } ?>
  </div>
 <div class="text-right" style="margin-bottom:20px;">  <input type="submit" name="submit" id="" class="btn btn-info btn-sm"  value="Bill Cancel"/>
    <button type="button"  id="close_fbx" class="btn btn-sm btn-danger mfp-close ">Exit</button>
  </div>
</form>
<script>
		  $( '#close_fbx' ).on( 'click', function () {
		           parent.jQuery.magnificPopup.close();
	                 } );
	</script> 
<script type="text/javascript" src="assets/checkall/jquery.min.js"></script>
<SCRIPT language="javascript">
$(function(){

	// add multiple select / deselect functionality
	$("#selectall").click(function () {
		  $('.filled-in').attr('checked', this.checked);
	});

	// if all checkbox are selected, check the selectall checkbox
	// and viceversa
	$(".filled-in").click(function(){

		if($(".filled-in").length == $(".filled-in:checked").length) {
			$("#selectall").attr("checked", "checked");
		} else {
			$("#selectall").removeAttr("checked");
		}

	});
});


</SCRIPT>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script>
<script type="text/javascript">
 
		$("#insert_form").submit(function(e) {

    e.preventDefault(); // avoid to execute the actual submit of the form.
  if( $("input:checkbox[class=filled-in]:checked").val()){

    var form = $(this);
    var url = form.attr('action');

    $.ajax({
           type: "POST",
           url: url,
           data: form.serialize(), // serializes the form's elements.
           success: function(data)
           {
              
			   $.toast( {
								heading: 'Sales Bill Cancelation Successfully.',
								text: '',
								position: 'top-right',
								loaderBg: '#04F92D',
								icon: 'success',
								hideAfter: 3000
							} );
				setTimeout(function(){ window.location.reload(1);}, 3000);			
						
           } 
		   
         });
} else {
	$.toast( {
						heading: 'Select Sales Bill Number.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1500
					} );
	
}
			
});
</script>