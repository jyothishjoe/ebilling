<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-lg-12 col-sm-6 col-xs-12" style="width:350px; overflow: hidden;">
	<h3 class="text-center">Add Sub Category</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Sub Category Name</label>
				<input type="text" class="form-control" id="subcat" name="subcat" value="" placeholder="Sub Category">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid;  ?>">
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company;  ?>">
			</div>
			
		</div>
		
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" id="subcate">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
		</div>
	</form>
</div>
	<script>
		$(document).ready( function (){
		$('#subcat').focus();
		});
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 255 ) {
				parent . jQuery . fancybox . close();

				// $( "#custom-content" ).hide();
				$( "#clickadd" ).click();
			}
		if ( event . keyCode == 13 ) {
				// $( "#custom-content" ).hide();
				$( "#catesave" ).click();
			}
	});
		function save_customer() {
			var subcat = $("#subcat").val();
			var catname = $("#catname").val();
			//var manufact = $("#manufact").val();
			var userid = $("#userid").val();
			var company = $("#company").val();
			var unit = $("#unit").val();
			
			if ( $("#catname").val() == "" || $( "#subcat" ).val() == "" ) {
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200} );
			}else{
				$( "#subcate" ).hide();
				$.ajax({
					type: 'POST',
					url: "product-action/subcategory_creation.php",
					data: "subcat=" + subcat + "&userid=" + userid + "&company=" + company,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				//parent.jQuery.fancybox.close();
				document.getElementById( "insert_form" ).reset(); $( "#subcate" ).show(); $('#subcat').focus();
				return false;
			}
		}
	</script>