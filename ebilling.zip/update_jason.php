<?php
date_default_timezone_set( "Asia/Kolkata" );
$today = date( "Y-m-d");
$month = date( "Y-m" );
$current_date_time = date( "d M Y H:i:s", time() );
$current_time = date( "H:i:s", time() );

if(isset($_POST['action'])){
	
$action=$_POST['action'];
	
if($action == '1'){	
	
$softwarekey = $_POST['software_key'];
$productkey = $_POST['product_key'];
$daysleft = $_POST['soft_validity'];
$totaldays = $_POST['total_days_left'];
$expairy_date = $_POST['expairy_date'];
$status = $_POST['status'];

	//read file
	$data = file_get_contents('assets/jquery/dist/data.json');
	//decode json to array
	$json_arr = json_decode( $data, true );

	foreach ( $json_arr as $key => $value ){

		if ($value[ 'softwarekey' ] == $softwarekey ){
			$json_arr[ $key ][ 'date' ] = $expairy_date;
			$json_arr[ $key ][ 'softwarekey' ] = $softwarekey;
			$json_arr[ $key ][ 'productkey' ] = $productkey;
			$json_arr[ $key ][ 'daysleft' ] = $totaldays;
			$json_arr[ $key ][ 'totaldays' ] = $daysleft;
			$json_arr[ $key ][ 'status' ] = "1";

		}
	}
	//encode array to json and save to file
	file_put_contents( 'assets/jquery/dist/data.json', json_encode( $json_arr ));

	$data1 = file_get_contents( "assets/jquery/dist/data.json" );
	$data1 = json_decode( $data1, true );
	foreach ( $data1 as $row ){

	$data2[ "status" ] = $row[ "status" ];
	echo json_encode( $data2 );
	}
}
	
if($action == '4'){
	
$softwarekey = $_POST['softwarekey'];

	
$data1 = file_get_contents( "assets/jquery/dist/data.json" );
	$data1 = json_decode( $data1, true );
	foreach ( $data1 as $row ){

	$upresponse[ "software_key" ] = $row[ "softwarekey" ];
	$upresponse[ "date" ] = $row[ "date" ];
		
	echo json_encode( $upresponse );
	}
	
}	
	
if($action == '2'){
	
$softwarekey = $_POST['software_key'];
$date_of_exp=$_POST['date'];
	
//days_left
$date1 = date_create($today);
$date2 = date_create($date_of_exp);
$diff = date_diff( $date1, $date2);
$date_diff = $diff->format("%a days Left To Expire");	
	
//read file
$data = file_get_contents('assets/jquery/dist/data.json');
//decode json to array
$json_arr = json_decode( $data, true );

foreach ($json_arr as $key => $value ){

	if ($value[ 'softwarekey' ] == $softwarekey ) {
		$json_arr[ $key ][ 'daysleft' ] = $date_diff;
	}
}
//encode array to json and save to file
file_put_contents( 'assets/jquery/dist/data.json', json_encode( $json_arr ));
	
}

if($action == '5'){
	
$softwarekey = $_POST['software_key'];
	
$data1 = file_get_contents( "assets/jquery/dist/data.json" );
	$data1 = json_decode( $data1, true );
	foreach ( $data1 as $row ){

	$response_date[ "software_key" ] = $row[ "softwarekey" ];
	$response_date[ "expairy_date" ] = $row[ "date" ];
		
	echo json_encode( $response_date );
	}
	
}
} 
?>