<?php
error_reporting(0);
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$date = date_create($today);
date_sub($date,date_interval_create_from_date_string("2 days"));
$date1 = date_format($date,"Y-m-d");

if(isset ($_GET['startdate'],$_GET['enddate'])){

$startdates = date_create($_GET['startdate']);
$startdates = date_format($startdates,'Y-m-d');
$enddates = date_create($_GET['enddate']);
$enddates = date_format($enddates,'Y-m-d');
}else{
$startdates = date_create($today);
$startdates = date_format($startdates,'Y-m-d');	
$enddates = date_create($today);
$enddates = date_format($enddates,'Y-m-d');	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Sales Profit</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/auto/all.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor float-left">Profit</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item"><a href="accounts-home.php">Accounts</a></li>
							<li class="breadcrumb-item active">Report</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								 <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datemask.php'); ?>
										
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 14px;" value="Submit"/>
											<?php if(isset ($_GET['startdate'],$_GET['enddate'])){ ?>
											<a href="profit.php" name="" id="search_id" class="btn btn-danger btn-sm" style="margin-top:30px; font-size: 14px;" />Clear</a>
											<?php } ?>
										</div>
									</div>
								</form>
								 <div class="table-responsive m-t-40">
									<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>Sl.No</th>
												<th>Date</th>
												<th>Bill No</th>
												<th>Cost</th>
												<th>Qty</th>
												<th>Total Amt</th>
												<th>Net Amt</th>
												<th>Profit</th>
											</tr>
										</thead>
										<tbody>
											<?php 
											    $sl=1;
												$result_sales = $db->prepare("SELECT * FROM sales_invoice_prdct_detail a LEFT JOIN sales_invoice b ON a.sales_invono=b.sales_invono AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' ");
												$result_sales ->execute(); 
												for($i=0; $rows_sales  = $result_sales->fetch(); $i++){
												$pcode=$rows_sales['prdct_tkn'];
												$billid=$rows_sales['sbill_no'];
													
												$result_stock_details = $db->prepare("SELECT * FROM purchase_productdetails WHERE p_id='$pcode' AND company_tkn='$user_company' ");
												$result_stock_details ->execute(); 
												$rows_stock_details  = $result_stock_details->fetch();
											?>
											<tr class='tr_input'>
												<td><?= $sl++; ?></td>
												<td><?php echo date('d-m-Y', strtotime( $rows_sales['sales_invodate'])); ?></td>
												<td><?php echo ucwords($billid); ?></td>
												<td><?php echo $rows_sales['rate']; ?></td>
												<td><?php echo $rows_sales['qty']; ?></td>
												<td><?php echo $rows_sales['amount']; ?></td>
												<td><?php 
													/*$tax=$rows_sales['rate'] * $rows_sales['sales_tax']/100+$rows_sales['sales_tax'];
													$net=$rows_sales['rate'] - $tax;
													$totalnet=$net*$rows_sales['qty'];
												    echo round($totalnet, 2); //Substracting Tax Amount(Inclusive)*/
													$tax=$rows_sales['gst_amt'];
													$net=$rows_sales['amount'] ;
													$totalnet= $net - $tax;
													$totalnet1= $net + $tax;
												    echo $totalnet1; //Substracting Tax Amount(Inclusive)
													?></td>
												   <?php $results = $db->prepare("select * from  cash_invoice_recpt_details where receipt_no = '$billid' AND company_tkn='$user_company'");
													$results->execute();
													for($i=0; $rows = $results->fetch(); $i++)
													{ $decs=$rows['decs']; } ?>
												
												<td>
												<?php
												$purchprice=$rows_stock_details['purch_price'] * $rows_sales['qty'];
													$saleprice=$rows_sales['rate'] * $rows_sales['qty'];
													$tot=$totalnet - $purchprice - $decs;
													echo abs($tot);
												?>	
												</td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>

	<script>

		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			searching		: false,
			fixedHeader: true,
			paging: true,
			info: true,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
			
		} );
		 
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
	
	
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>