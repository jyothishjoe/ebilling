<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Acocunt Groups</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/auto/all.css" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<script src="assets/jquery/dist/jquery.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<script src="assets/Magnific-Popup-master/libs/jquery-loader.js"></script>
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
					<div class="row page-titles">
						<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor" style="float: left;">Accounts Group</h3>
						</div>
						<div class="col-md-7 align-self-center">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="creation.php">Home</a></li>
								</li>
								<li class="breadcrumb-item">Accounts</li>
								<li class="breadcrumb-item active">Account Groups</li>
							</ol>
						</div>
						<div>
							
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
										<table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%">
											<thead>
												<tr>
													<th>#</th>
													<th>Account Group</th>
													<th>Group Type</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
											<?php 
											$result_account = $db->prepare("SELECT * FROM account_group ");
											$result_account ->execute(); 
											$sl = 0;
											for ($i=0; $rows_account  = $result_account ->fetch(); $i++){
											?>
												<tr>
													<td><?php echo ++$sl; ?></td>
													<td><?php echo $rows_account['acc_name']; ?></td>
													<td><?php echo $rows_account['account']; ?></td>
													<td>
													<span><a href="edit-accountgroup-popup.php?id=<?php echo $rows_account['id']; ?>" class="btn btn-sm  btn-info simple-ajax-popup-align-top"><i class="fa fa-pencil-alt"></i></a>
													<a href="accgrp-delete.php?delete=<?php echo $rows_account['id']; ?>"  class="btn btn-sm btn-danger simple-ajax-popup-align-top" ><i class="fa fa-times"></i></a>
													</span>
													</td>
											   </tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<script>
				$(document).ready(function(){
				$.datepicker.setDefaults({
				dateFormat: 'yy-mm-dd'
				});
				$(function(){
				$("#From").datepicker();
				$("#to").datepicker();
				});
				$('#range').click(function(){
				var From = $('#From').val();
				var to = $('#to').val();
				if(From != '' && to != '')
				{
				$.ajax({
				url:"purchase-filter.php",
				method:"POST",
				data:{From:From, to:to},
				success:function(data)
				{
				$('#example').html(data);
				}
				});
				}
				else
				{
				alert("Please Select the Date");
				}
				});
				});
				</script>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
									<div class="r-panel-body">
										<ul id="themecolors" class="m-t-20">
											<li><b>With Light sidebar</b>
											</li>
											<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
											</li>
											<li class="d-block m-t-30"><b>With Dark sidebar</b>
											</li>
											<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
											</li>
										</ul>
										
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
			<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
			</script>
			<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
			<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
			<script src="js/perfect-scrollbar.jquery.min.js"></script>
			<script src="js/waves.js"></script>
			<script src="js/sidebarmenu.js"></script>
			<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
			<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
			<script src="assets/bootstrap/dist/js/bootstrap.min.js"></script>
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
			<script src="js/custom.min.js"></script>
			<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
			<script src="js/toastr.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
			<?php include("assets/custom/custom.php");?>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>