<?php include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include( 'db-connect/db.php' );
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type where user_tkn = '$user_type_tkn'");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{ $add_supplier=$row_user['add_supplier']; $update_supplier=$row_user['update_supplier']; $Purchase_invo=$row_user['Purchase_invo']; $Purchase_order_invo=$row_user['Purchase_order_invo']; $Purchase_rtn_invo=$row_user['Purchase_rtn_invo']; $purchas_rep=$row_user['purchas_rep']; $purchase_order_rep=$row_user['purchase_order_rep']; $purchase_return_rep=$row_user['purchase_return_rep'];  } ?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
	<title>Purchase Home</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav_home.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor">Purchase</h4>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a oncontextmenu="return false;" href="javascript:void(0)">Home</a>
							</li>
							<li class="breadcrumb-item active">Purchase</li>
						</ol>
					</div>
					<div class="">
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-body">
								<form class="needs-validation" novalidate>
									<div class="form-row">
									<?php if($add_supplier==0){ ?>
									<div class="col-lg-3" style="display: none;"  >
										<div class="card bg-primary text-white" style="background-color: #873839" >
											<div class="card-body">
												<div class="d-flex">
													<div class="stats">
														<h4 class="text-white">Supplier <label style="font-size: 13px;"> ( F1 )</label></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="add-supplier.php" id="supplier1" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Add Supplier</a>
														<a oncontextmenu="return false;" href="supplier-all.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">Check list</a>
													</div>
													<div class="stats-icon text-right ml-auto"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($Purchase_invo==0){?>
										<div class="col-lg-3">
											<div class="card bg- text-white" style="background-color: #5795C4">
												<div class="card-body">
													<div class="d-flex" style="color: aliceblue;">
														<div class="stats">
															<h4 class="text-white">Purchase <label style="font-size: 13px;"> ( F2 )</label></h4>
															<h6 class="text-white"></h6>
															<a oncontextmenu="return false;" href="purchase-product.php" id="purchase1"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Purchase Invoice</a>
															<a oncontextmenu="return false;" href="purchase-invoice-list.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a>
														</div>
														<div class="stats-icon text-right"></div>
													</div>
												</div>
											</div>
										</div>
										<!--<div class="col-lg-3">
											<div class="card bg- text-white" style="background-color: #5795C4">
												<div class="card-body">
													<div class="d-flex" style="color: aliceblue;">
														<div class="stats">
															<h4 class="text-white">Purchase Estimate <label style="font-size: 13px;"> ( F2 )</label></h4>
															<h6 class="text-white"></h6>
															<a oncontextmenu="return false;" href="purchase-estimate.php" id="purchase1"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Estimate</a>
															<a oncontextmenu="return false;" href="purchase-estimate-list.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a>
														</div>
														<div class="stats-icon text-right"></div>
													</div>
												</div>
											</div>
										</div>-->
									<?php } if($Purchase_rtn_invo==0) { ?>
                                       <div class="col-lg-3" >
										<div class="card bg- text-white" style="background-color: #0A4D80" >
											<div class="card-body">
												<div class="d-flex" style="color: aliceblue;">
													<div class="stats">
														<h4 class="text-white">Purchase Return <label style="font-size: 13px;"> ( F3 )</label></h4>
														<h6 class="text-white"></h6>
														<a oncontextmenu="return false;" href="purchase-return.php" id="purchasereturn1"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Return Invoice</a>
														<a oncontextmenu="return false;" href="purchase-return-list.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a>
													</div>
													<div class="stats-icon text-right"></div>
												</div>
											</div>
										</div>
									</div>
									<?php } if($Purchase_order_invo==0) { ?>
                                        <div class="col-lg-3">
											<div class="card  text-white" style="background-color: #D780E3">
												<div class="card-body">
													<div class="d-flex" style="color: aliceblue;">
														<div class="stats">
															<h4 class="text-white">Purchase Order <label style="font-size: 13px;"> ( F4 )</label></h4>
															<h6 class="text-white"></h6>
															<a oncontextmenu="return false;" href="add-purchase-order.php" id="purchaseorder1"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Order Invoice</a>
															<a oncontextmenu="return false;" href="purchase-order-list.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">List</a>
														</div>
														<div class="stats-icon text-right"></div>
													</div>
												</div>
											</div>
										</div>
									<?php } if($purchas_rep==0 || $purchase_order_rep==0 || $purchase_return_rep==0) { ?>
									 <div class="col-lg-5">
											<div class="card  text-white" style="background-color: #533333">
												<div class="card-body">
													<div class="d-flex" style="color: aliceblue;">
														<div class="stats">
															<h4 class="text-white">Reports</h4>
															<h6 class="text-white"></h6>
															<?php  if($purchas_rep==0){ ?>
															<a oncontextmenu="return false;" href="purchase-all.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Purchase</a>
															<?php } if($purchase_return_rep==0) { ?>
															<a oncontextmenu="return false;" href="purchase-return-all.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Purchase Return</a>
															<?php } if($purchase_order_rep==0) { ?>
															<a oncontextmenu="return false;" href="purchase-order.php"   class="btn btn-rounded btn-outline btn-light m-t-10 font-14">Purchase Order</a>
															<?php } ?>
														</div>
														<div class="stats-icon text-right"></div>
													</div>
												</div>
											</div>
										</div>
									<?php } ?>
								</form>
								</div>
								<div class="col-md-12">
									<div class="card" style="text-align: center;">
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="right-sidebar">
						<div class="slimscrollright">
							<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
							<div class="r-panel-body">
								<ul id="themecolors" class="m-t-20">
									<li><b>With Light sidebar</b>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
									</li>
									<li class="d-block m-t-30"><b>With Dark sidebar</b>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
									</li>
									<li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
									</li>
								</ul>
								
							</div>
						</div>
					</div>
				</div></div>
				
			</div>
		</div>
<script>
	

$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
	

	
	//Short Cut Keys 
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 112 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "add-supplier.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event . keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="purchase-product.php";
			}
			if ( event . keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="purchase-return.php";
			}
			if ( event . keyCode == 115 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				window.location.href="add-purchase-order.php";
			}
			
		} );	
</script>

		<script src="assets/plugins/popper/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="js/perfect-scrollbar.jquery.min.js"></script>
		<script src="js/waves.js"></script>
		<script src="js/sidebarmenu.js"></script>
		<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
		<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
		<script src="js/custom.min.js"></script>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
		<script src="js/mask.init.js"></script>
		<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
		<script src="js/toastr.js"></script>
		<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
		<?php include ('include/disable_fn.php'); ?>
	
	
	
</body>

</html>