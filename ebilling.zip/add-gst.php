<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-sm-6 col-xs-12" style="width: 300px; overflow: hidden;">
	<h3 class="text-center">Add Gst</h3>
	<form autocomplete="off" method="post" action="" id="insert_form"  class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Gst Rate </label>
				<input type="text" class="form-control"  name="gst" id="gst" value="" placeholder="Gst Rate">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>">
			</div>
		</div>
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" id="gstsave">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">Cancel</button>
		</div>
	</form>
	<script>
		$(document).ready( function (){
		$('#gst').focus();
		});
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 255 ) {
				parent . jQuery . fancybox . close();

				// $( "#custom-content" ).hide();
				$( "#clickadd" ).click();
			}
		if ( event . keyCode == 13 ) {
				// $( "#custom-content" ).hide();
				$( "#catesave" ).click();
			}
	});
		function save_customer() {
	
			var gst = $("#gst").val();
			var userid = $("#userid").val();
			
			if ( $("#gst").val() == "") {
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 4500} );
			}else{
				$( "#gstsave" ).hide();
				$.ajax({
					type: 'POST',
					url: "product-action/gst_creation.php",
					data: "gst=" + gst + "&userid=" + userid ,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				//parent.jQuery.fancybox.close(); 
				document.getElementById( "insert_form" ).reset(); $( "#gstsave" ).show(); $('#gst').focus();
				return false;
			}
		}
	</script>