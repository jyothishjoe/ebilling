<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include('db-connect/db.php');
$token=$_GET['seasonid'];
$result_seasontomer = $db->prepare("SELECT * FROM season WHERE season_tkn='$token' ");
$result_seasontomer->execute();
$rows_seasontomer = $result_seasontomer->fetch(); 
?>
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php");?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
#close_fbx { margin: 0px; position: relative;  background: #ef5350 !important; color: #fff; opacity: 1; width: 50px; font-size: 13px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #ef5350 !important;}
</style>

<div id="seasontom-content"  class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; width:400px; padding-top:20px; overflow: hidden;  background-color: #f2f2f2;">
<h3 class="text-center">Update Season</h3><br>
<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
  <div class="form-row">
    <div class="col-md-12"></div>
        <div class="col-md-6 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Season Name</label>
      <input type="text" class="form-control season_name" name="season_name" value="<?php echo $rows_seasontomer['season_name']; ?>" id="season_name" placeholder="Enter Season Name" autofoseason>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Year</label>
      <input type="number" class="form-control season_year" id="season_year" name="season_year"   value="<?php echo $rows_seasontomer['season_year']; ?>" readonly>
    </div>
	 <?php 
				$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				$dateformate=$rows['dateformate'];
				?>
	 <?php if($dateformate == 'datechoos') { ?>
	<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
	  <label for="" class="control-label">Start Date</label>
	  <input type="date" class="form-control" id="start_date" name="start_date"  value="<?php echo $rows_seasontomer['start_date']; ?>" required>
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
	  <label for="" class="control-label">End Date</label>
	  <input type="date" class="form-control" id="end_date" name="end_date"  value="<?php echo $rows_seasontomer['end_date']; ?>" required>
	</div>
	<?php } else { ?>
	<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
	  <label for="" class="control-label">Start Date</label>
	  <input type="text" class="form-control date-inputmask" id="start_date"  name="start_date"  value="<?php echo $rows_seasontomer['start_date']; ?>" required>
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
	  <label for="" class="control-label">End Date</label>
	  <input type="text" class="form-control date-inputmask" id="end_date"  value="<?php echo $rows_seasontomer['end_date']; ?>"  name="end_date" required>
	</div>
	<?php } ?>
    <input type="hidden" class="form-control" id="season_tkn" name="season_tkn" value="<?php echo $rows_seasontomer['season_tkn']; ?>" readonly>
  </div>
  <div class="col-md-12" style="margin-bottom: 18px;">
    <div class="text-right"> <a href="javascript: save_seasontomer()" class="btn btn-sm  btn-info">Update</a>
      <button type="button"  id="close_fbx" class="btn btn-sm btn-danger mfp-close ">Cancel</button>
    </div>
  </div>
</form>

<script>
											
			                             function myFunction() {
		                                  parent.jQuery.fancybox.close();
	                                               } 
										function save_seasontomer() {
											var season_name = $( "#season_name" ).val();
											var season_year = $( "#season_year" ).val();
											var start_date = $( "#start_date" ).val();
											var end_date = $( "#end_date" ).val();
											var season_tkn = $( "#season_tkn" ).val();
	
											if ( $( "#season_name" ).val() == "" || $( "#start_date" ).val() == "" || $( "#end_date" ).val() == "" ) {
												$.toast( {
													heading: 'Fill all required fields.',
													text: '',
													position: 'top-right',
													loaderBg: '#ff6849',
													icon: 'error',
													hideAfter: 1200
												} );
											} else {
												$.ajax({
												type : 'POST',
												url  : "creation_actions/season/season_update.php",
												data: "season_name="+ season_name  + "&season_tkn=" + season_tkn +  "&start_date=" + start_date + "&end_date=" + end_date  + "&season_year=" + season_year,
												success : function(r) {						
												$("#respond").html(r);
													}
												});
												// parent.jQuery.fancybox.close(); 
											//window.location = "season-list.php";
											 setTimeout("location.href = 'season-list.php';", 1000);
												return false;
											}
										}
									</script>
									<div id="respond"></div>