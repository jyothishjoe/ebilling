<?php
include( 'include/auth.php' );
include( "php_fn/basic.php" );
include( "datetime_creation/datetime_creation.php" );
include( 'db-connect/db.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$sbill_no = $_GET[ 'bill' ];
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];
$result_user_company = $db->prepare( "SELECT * FROM company WHERE c_token = '$user_company'" );
$result_user_company->execute();
$rows_user_company = $result_user_company->fetch();
$logo = $rows_user_company[ 'c_logo' ];
$previous = "javascript:history.go(-1)";
if ( isset( $_SERVER[ 'HTTP_REFERER' ] ) ){
	$previous = $_SERVER[ 'HTTP_REFERER' ];
}
?>
<html>
<title>Supermarket | Sales Bill Print</title>
<head>
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>


	<style>
		table td {
			height: 15px;
		}
		
		@media print {
			.btn {
				display: none;
			}
		}
		
		.hr {
			border: none;
			border-top: 1px solid black;
			margin-top: 10px;
		}
	</style>
	<?php include("include/print_size.php");?>
</head>

<body>
	<a href="<?php echo $previous; ?>" </a><button type="button" class="btn" style="float:left; margin-right: 25px;padding:.5em 1em;">Back</button>
		</a>
		<button type="button" class="btn" onClick="window.location.reload()" style="float:right; margin-right: 25px;padding:.5em 1em;">Print</button>

	<?php
	$result = $db->prepare( "SELECT * FROM sales_invoice where sbill_no='$sbill_no'" );
	$result->execute();
	$row_count = $result->rowcount();
	for ( $i = 0; $rows = $result->fetch(); $i++ ) {
		$order_no = $rows[ "order_no" ];
		$sales_invono = $rows[ "sales_invono" ];
		$datetym = $rows[ "sales_invodate" ];
		if ( $rows[ "cus_name" ] != '' ) {
			$cus_name = $rows[ "cus_name" ];
		} else {
			$cus_name = '';
		}
		$cus_tkn = $rows[ "cus_tkn" ];
		$tax_tot = $rows[ "tax_tot" ];
		$tot_qty = $rows[ "tot_qty" ];
		$cess_total = $rows[ "o_tax_total" ];


		$result1 = $db->prepare( "SELECT * FROM customer where acco_tkn='$cus_tkn'" );
		$result1->execute();
		$row_count1 = $result1->rowcount();
	}
	?>
	
		<div class=" printwidth" >
			<table style="width:100%;">
					<th colspan="8" align="center">
						<h2>TAX INVOICE</h2>
					</th>
				<thead>
					<tr>

						<th colspan="8" width="100%" align="left">
							
							<strong style="font-size: 22px;">
								<?php echo $rows_user_company['c_company_name']; ?>
							</strong>
							<p style="float: right; font-size: 14px;">GSTIN : <?php echo $rows_user_company['c_gst']; ?></p>
							<br>
							<?php echo $rows_user_company['c_shopaddress']; ?><br> Ph:
							<?php echo $rows_user_company['c_phone']; ?>, Mob:
							<?php echo $rows_user_company['c_mobile']; ?><br> Email :
							<?php echo $rows_user_company['c_email']; ?><br>
							
						</th>
						
						<!--<th colspan="4" width="50%">
						
						</th>-->
					</tr>
				</thead>
			
				<?php
				$result = $db->prepare( "SELECT * FROM customer where acco_tkn='$cus_tkn'" );
				$result->execute();
				$row_count = $result->rowcount();
				$rows = $result->fetch();
				if($row_count > 0){
				$addres = $rows[ "addres" ];
				$contact_no1 = $rows[ "contact_no1" ];	
				}
				
				?>
				<tr>
					<td colspan="4" >
					
					    <p>To,</p>
						<p>Name    : <?php echo ucfirst($cus_name);?></p>
						<p>Address : <?php echo ucfirst($addres);?></p>
						<p>Contact : <?php echo $contact_no1;?></p>
						</td>
						<td colspan="4" align="right">
							<p>Bill No :  <?php echo strtoupper($sbill_no);?></p><p>Date : <?php echo $datetym;?></p>
						</td>
				</tr>
				<tr>
					<?php 
           			if (!empty($order_no)) {?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_order_invoice where order_invno='$order_no'" );
					$result->execute();
					$row_count = $result->rowcount();
					for ( $i = 0; $rows3 = $result->fetch(); $i++ ) {
						$orderbill_no = $rows3[ "bill_no" ];
					}
					?>
					<th>Sales Order No:</th>
					<td>
						<?php echo strtoupper($orderbill_no);?>
					</td>
					<?php } else {?>
					<td style="display:none;">Sales Order No:
						<?php echo $orderbill_no;?> </td>
					<?php }?>
				</tr>

				<?php if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
				
				<tr style="text-align:center;" class="top-border bottom-border">
					<td  align="left" width="10%"><p>Sl</p></td>
					<th rowspan="2" width="30%" style="text-align: left"><p>Item Description</p></th>
					<th rowspan="2" width="10%"><p>Qty</p></th>
					<th rowspan="2" width="10%"><p>Rate</p></th>
					<th rowspan="2" width="10%"><p>Mrp</p></th>
					<th rowspan="2" width="10%"><p>Gst%</p></th>
					<th rowspan="2" width="10%"><p>O.Tax%</p></th>
					<th rowspan="2" width="10%"><p>Amount</p></th>
				</tr>
				<tbody>
				<?php
				$qty_tot=0;
				$result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
					
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result1->execute();
				$rows1= $result1->fetch(); 
					
                $prdct_tkn = $rows['prdct_tkn'];
                $qty = $rows['qty'];
                $qty_tot += $rows['qty'];
                $rate = $rows['rate'];
                $net_tot = $rows['net_tot'];
                $sales_tax = $rows['sales_tax'];
                $gst_amt = $rows1['gst_amt'];
                $pr_hsn = $rows['pr_hsn'];
                $mrp = $rows['mrp'];
                $prdct_name = $rows['prdct_name'];
                $amount = $rows['amount'];
                $grand_tot = $rows['grand_tot'];
                $disc = $rows['disc'];
                $units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
					$sl=0;
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              	?>

					<tr class="bottom-border">
						<td align="left"><p><?php echo $e+1; ?></p></td>
						<td align="left">
							<p><?php echo ucfirst( $prdct_name ); ?> -[ <?php echo $pr_hsn; ?>] </p></td>
						<td align="center">
							<p><?php echo $qty;?></p>
						</td>
						<td align="center">
							<p><?php echo $rate;?></p>
						</td>
						<td align="center">
							<p><?php echo $mrp;?></p>
						</td>
						<td align="center">
							<p><?php echo $sales_tax;?></p>
						</td>
						<td align="center">
							<p><?php echo $otaxrate;?></p>
						</td>
						<td align="center">
							<p><?php echo $amount;?></p>
						</td>
					</tr>
					<?php } ?>
					<tr class="top-border bottom-border">
						<td colspan="2" align="right" ><p>Total</p></td>
						<td  align="center"><p>
								<?php echo  $qty_tot;?>
							</p></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<p >
								<?php echo  $net_tot;?>
							</p>
							<?php if ( $tax_tot!=0) { ?> 
							<p >
								(+) GST/Tax :
								<?php echo $gst_amt + $gstcess_amt; ?>
							</p>
							<?php  } ?>
						</td>
					</tr>
					
					<tr class="bottom-border">
						<td colspan="6">
							<p><?php echo convertToIndianCurrency($net_tot + $gst_amt + $gstcess_amt); ?></p>
						</td>
						<td colspan="2" align="right">
							<p>
							Gr.Total  : <?php echo  $net_tot + $gst_amt + $gstcess_amt;?>
							</p>
						</td>
					</tr>
					<tr class="bottom-border">
						<td align="right" colspan="4" rowspan="1" width="33%"><p>Taxable Amount</p></td>
						<td align="center" colspan="2" rowspan="1" width="33%"><p>SGST</p></td>
						<td align="center" colspan="2" rowspan="1" width="33%"><p>CGST</p></td>
					</tr>
					<?php
					$total_gst_amt=0;
					$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(amount) AS amount FROM sales_invoice_prdct_detail where  sales_invono ='$sales_invono' GROUP BY sales_tax" );
					$resultret->execute();
					for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
					$gstsum = $rowret[ 'gst_amt' ];
					$taxable = $rowret[ 'amount' ];
					$total_gst_amt +=$gstsum/2;
					?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<p>
								<?php echo $taxable; ?>
							</p>
						</td>
						<td align="center" colspan="2" width="33%">
							<p><?php echo $gstsum/2; ?></p>
						</td>
						<td align="center" colspan="2" width="33%">
							<p><?php echo $gstsum/2; ?></p>
						</td>
					</tr>
					<?php } ?>
					<tr>
						<td colspan="2" ><p style="float: right">Total</p>
						</td>
						<td colspan="2">
						<p style="float: right; ">
								<?php echo $net_tot; ?>
							</p>
						</td>
						<td align="center" colspan="2" width="33%">
							<p><?php echo $total_gst_amt; ?></p>
						</td>

						<td align="center" colspan="2" width="33%">
							<p><?php echo $total_gst_amt; ?></p>
						</td>
					</tr>
					<?php 
    				if ( $cess_total==0) { ?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type" );
					$result->execute();
					for ( $i = 0; $rows = $result->fetch(); $i++ ) {
						$o_tax_typeg = $rows[ 'o_tax_type' ];

						$qty_total = 0;
						$result_ptkn = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn" );
						$result_ptkn->execute();
						for ( $i = 0; $rows_ptk = $result_ptkn->fetch(); $i++ ) {
							$prdct_tkns = $rows_ptk[ 'prdct_tkn' ];

							$resultret = $db->prepare( "SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$o_tax_rate = $rowret[ 'o_tax_rate' ];
								$o_tax_total = $rowret[ 'o_tax_total' ];
							}
								
							$resultrets = $db->prepare( "SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultrets->execute();
							for ( $i = 0; $rowretss = $resultrets->fetch(); $i++ ) {
								$qtysum = $rowretss[ 'amount' ];
							}
							$other_taxtotal = $qtysum * $o_tax_total;
							$qty_total = $other_taxtotal + $qty_total;
						}

						?>
					
					<tr class="border-bottom border-top">
						<td colspan="4"><p style="float: left">Other Tax Included</p></td>
						<td colspan="2" align="left">
							<p><?php echo $o_tax_typeg;?></p></td>
						<td colspan="2" align="left">
							<p><?php echo $qty_total;?></p>
						</td>
					</tr>
					<?php  } } ?>

					<tr class="top-border bottom-border">
						<td colspan="8" align="right"><p>We declare this invoice shows the actual price of the goods and that all the purticulars are true and correct.</p><br> </td>
					</tr>
				
					<tr class="border-bottom border-top">
						<td colspan="4"><strong style="font-size: 14px;"><u>Our Bank details</u></strong>
							<p>Bank Name :<?php echo $rows_user_company['c_bank']; ?></p>
							<p>A/C No    :<?php echo $rows_user_company['c_accno']; ?></p>
							<p>IFSC Code :<?php echo $rows_user_company['c_ifsc']; ?></p>&nbsp;&nbsp;&nbsp; <p>Branch :<?php echo $rows_user_company['c_branch']; ?></p>
						</td>
						<td colspan="4" align="right">For
							<p>
								<?php echo strtoupper($rows_user_company['c_company_name']); ?>
							</p><br><br><p>Authorised Sign.</p>
						</td>
					</tr >
				</tbody>
				

			</table>
			<?php } else if( $printer_width == 'b7' || $printer_width == '80mm' || $printer_width == 'a7'  || $printer_width == 'b8') { ?>

			<tr class="border-bottom">
					<td colspan="8"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom">
					<td  align="left" width="10%" >Sl</td>
					<th rowspan="2" width="30%" style="text-align: left">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">Other Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody class="hr">
					<?php
				$qty_tot=0;
				$result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
					
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result1->execute();
				$rows1= $result1->fetch(); 
					
                $prdct_tkn = $rows['prdct_tkn'];
                $qty = $rows['qty'];
                $qty_tot += $rows['qty'];
                $rate = $rows['rate'];
                $net_tot = $rows['net_tot'];
                $sales_tax = $rows['sales_tax'];
                $gst_amt = $rows1['gst_amt'];
                $pr_hsn = $rows['pr_hsn'];
                $mrp = $rows['mrp'];
                $prdct_name = $rows['prdct_name'];
                $amount = $rows['amount'];
                $grand_tot = $rows['grand_tot'];
                $disc = $rows['disc'];
                $units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
					$sl=0;
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              	?>

					<tr class="border-bottom">
						<td align="left"><?php
							echo $e+1;
							?></td>
						<td align="left">
							<?php
							echo ucfirst( $prdct_name );
							?> -[
							<?php echo $pr_hsn; ?>] </td>
						<td align="center">
							<?php echo $qty;?>
						</td>
						<td align="center">
							<?php echo $rate;?>
						</td>
						<td align="center">
							<?php echo $mrp;?>
						</td>
						<td align="center">
							<?php echo $sales_tax;?>
						</td>
						<td align="center">
							<?php echo $otaxrate;?>
						</td>
						<td align="center">
							<?php echo $amount;?>
						</td>
					</tr>
					<?php } ?>
					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong >
								<?php echo  $net_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong >
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php  } ?>
						</td>
					</tr>
					
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($net_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left; ">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $net_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>

					
					<tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr class="border-bottom">
						<td align="right" colspan="4" rowspan="1" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" rowspan="1" width="33%">SGST</td>
						<td align="center" colspan="2" rowspan="1" width="33%">CGST</td>
					</tr>
					<?php
					$total_gst_amt=0;
							$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(amount) AS amount FROM sales_invoice_prdct_detail where  sales_invono ='$sales_invono' GROUP BY sales_tax" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$gstsum = $rowret[ 'gst_amt' ];
								$taxable = $rowret[ 'amount' ];
								$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $net_tot; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
					

					<?php 
    				if ( $cess_total!=0) { ?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type" );
					$result->execute();
					for ( $i = 0; $rows = $result->fetch(); $i++ ) {
						$o_tax_typeg = $rows[ 'o_tax_type' ];

						$qty_total = 0;
						$result_ptkn = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn" );
						$result_ptkn->execute();
						for ( $i = 0; $rows_ptk = $result_ptkn->fetch(); $i++ ) {
							$prdct_tkns = $rows_ptk[ 'prdct_tkn' ];

							$resultret = $db->prepare( "SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$o_tax_rate = $rowret[ 'o_tax_rate' ];
								$o_tax_total = $rowret[ 'o_tax_total' ];
							}
								
							$resultrets = $db->prepare( "SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultrets->execute();
							for ( $i = 0; $rowretss = $resultrets->fetch(); $i++ ) {
								$qtysum = $rowretss[ 'amount' ];
							}
							$other_taxtotal = $qtysum * $o_tax_total;
							$qty_total = $other_taxtotal + $qty_total;
						}

						?>
					<tr>
						<td colspan="8"><strong style="float: left;">Other Tax Included</strong></td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
					<?php  } } ?>

					<tr class="border-bottom">
						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
				<br>
					<tr style="margin-top: 4px;">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($rows_user_company['c_company_name']); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr >

				</tbody>

			</table>
			<?php } else if ( $printer_width == 'a8' || $printer_width == 'b9') { ?>
			<tr class="border-bottom">
					<td colspan="8"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom">
					<td  align="left" width="10%" >Sl</td>
					<th rowspan="2" width="30%" style="text-align: left">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">Other Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody class="hr">
					<?php
				$qty_tot=0;
				$result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
					
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result1->execute();
				$rows1= $result1->fetch(); 
					
                $prdct_tkn = $rows['prdct_tkn'];
                $qty = $rows['qty'];
                $qty_tot += $rows['qty'];
                $rate = $rows['rate'];
                $net_tot = $rows['net_tot'];
                $sales_tax = $rows['sales_tax'];
                $gst_amt = $rows1['gst_amt'];
                $pr_hsn = $rows['pr_hsn'];
                $mrp = $rows['mrp'];
                $prdct_name = $rows['prdct_name'];
                $amount = $rows['amount'];
                $grand_tot = $rows['grand_tot'];
                $disc = $rows['disc'];
                $units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
					$sl=0;
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              	?>

					<tr class="border-bottom">
						<td align="left"><?php
							echo $e+1;
							?></td>
						<td align="left">
							<?php
							echo ucfirst( $prdct_name );
							?> -[
							<?php echo $pr_hsn; ?>] </td>
						<td align="center">
							<?php echo $qty;?>
						</td>
						<td align="center">
							<?php echo $rate;?>
						</td>
						<td align="center">
							<?php echo $mrp;?>
						</td>
						<td align="center">
							<?php echo $sales_tax;?>
						</td>
						<td align="center">
							<?php echo $otaxrate;?>
						</td>
						<td align="center">
							<?php echo $amount;?>
						</td>
					</tr>
					<?php } ?>
					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong >
								<?php echo  $net_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong >
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php  } ?>
						</td>
					</tr>
					
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($net_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left; ">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $net_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>

					
					<tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr class="border-bottom">
						<td align="right" colspan="4" rowspan="1" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" rowspan="1" width="33%">SGST</td>
						<td align="center" colspan="2" rowspan="1" width="33%">CGST</td>
					</tr>
					<?php
					$total_gst_amt=0;
							$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(amount) AS amount FROM sales_invoice_prdct_detail where  sales_invono ='$sales_invono' GROUP BY sales_tax" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$gstsum = $rowret[ 'gst_amt' ];
								$taxable = $rowret[ 'amount' ];
								$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $net_tot; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
					

					<?php 
    				if ( $cess_total!=0) { ?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type" );
					$result->execute();
					for ( $i = 0; $rows = $result->fetch(); $i++ ) {
						$o_tax_typeg = $rows[ 'o_tax_type' ];

						$qty_total = 0;
						$result_ptkn = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn" );
						$result_ptkn->execute();
						for ( $i = 0; $rows_ptk = $result_ptkn->fetch(); $i++ ) {
							$prdct_tkns = $rows_ptk[ 'prdct_tkn' ];

							$resultret = $db->prepare( "SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$o_tax_rate = $rowret[ 'o_tax_rate' ];
								$o_tax_total = $rowret[ 'o_tax_total' ];
							}
								
							$resultrets = $db->prepare( "SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultrets->execute();
							for ( $i = 0; $rowretss = $resultrets->fetch(); $i++ ) {
								$qtysum = $rowretss[ 'amount' ];
							}
							$other_taxtotal = $qtysum * $o_tax_total;
							$qty_total = $other_taxtotal + $qty_total;
						}

						?>
					<tr>
						<td colspan="8"><strong style="float: left;">Other Tax Included</strong></td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
					<?php  } } ?>

					<tr class="border-bottom">
						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
				<br>
					<tr style="margin-top: 4px;">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($rows_user_company['c_company_name']); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr >

				</tbody>

			</table>
			<?php } else { ?>
			<tr class="border-bottom">
					<td colspan="8"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom">
					<td  align="left" width="10%" >Sl</td>
					<th rowspan="2" width="30%" style="text-align: left">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">Other Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody class="hr">
					<?php
				$qty_tot=0;
				$result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
					
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_invoice_prdct_detail where sales_invono ='$sales_invono'");
				$result1->execute();
				$rows1= $result1->fetch(); 
					
                $prdct_tkn = $rows['prdct_tkn'];
                $qty = $rows['qty'];
                $qty_tot += $rows['qty'];
                $rate = $rows['rate'];
                $net_tot = $rows['net_tot'];
                $sales_tax = $rows['sales_tax'];
                $gst_amt = $rows1['gst_amt'];
                $pr_hsn = $rows['pr_hsn'];
                $mrp = $rows['mrp'];
                $prdct_name = $rows['prdct_name'];
                $amount = $rows['amount'];
                $grand_tot = $rows['grand_tot'];
                $disc = $rows['disc'];
                $units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
					$sl=0;
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_invoice_otax_detail where prdct_tkn='$prdct_tkn' AND sales_invono ='$sales_invono'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              	?>

					<tr class="border-bottom">
						<td align="left"><?php
							echo $e+1;
							?></td>
						<td align="left">
							<?php
							echo ucfirst( $prdct_name );
							?> -[
							<?php echo $pr_hsn; ?>] </td>
						<td align="center">
							<?php echo $qty;?>
						</td>
						<td align="center">
							<?php echo $rate;?>
						</td>
						<td align="center">
							<?php echo $mrp;?>
						</td>
						<td align="center">
							<?php echo $sales_tax;?>
						</td>
						<td align="center">
							<?php echo $otaxrate;?>
						</td>
						<td align="center">
							<?php echo $amount;?>
						</td>
					</tr>
					<?php } ?>
					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong >
								<?php echo  $net_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong >
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php  } ?>
						</td>
					</tr>
					
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($net_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left; ">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $net_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>

					
					<tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr class="border-bottom">
						<td align="right" colspan="4" rowspan="1" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" rowspan="1" width="33%">SGST</td>
						<td align="center" colspan="2" rowspan="1" width="33%">CGST</td>
					</tr>
					<?php
					$total_gst_amt=0;
							$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(amount) AS amount FROM sales_invoice_prdct_detail where  sales_invono ='$sales_invono' GROUP BY sales_tax" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$gstsum = $rowret[ 'gst_amt' ];
								$taxable = $rowret[ 'amount' ];
								$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $net_tot; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
					

					<?php 
    				if ( $cess_total!=0) { ?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' GROUP By o_tax_type" );
					$result->execute();
					for ( $i = 0; $rows = $result->fetch(); $i++ ) {
						$o_tax_typeg = $rows[ 'o_tax_type' ];

						$qty_total = 0;
						$result_ptkn = $db->prepare( "SELECT * FROM sales_invoice_otax_detail where sales_invono ='$sales_invono' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn" );
						$result_ptkn->execute();
						for ( $i = 0; $rows_ptk = $result_ptkn->fetch(); $i++ ) {
							$prdct_tkns = $rows_ptk[ 'prdct_tkn' ];

							$resultret = $db->prepare( "SELECT * FROM sales_invoice_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultret->execute();
							for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
								$o_tax_rate = $rowret[ 'o_tax_rate' ];
								$o_tax_total = $rowret[ 'o_tax_total' ];
							}
								
							$resultrets = $db->prepare( "SELECT  COALESCE(SUM(qty), 0) AS amount FROM sales_invoice_prdct_detail where prdct_tkn='$prdct_tkns' AND sales_invono ='$sales_invono'" );
							$resultrets->execute();
							for ( $i = 0; $rowretss = $resultrets->fetch(); $i++ ) {
								$qtysum = $rowretss[ 'amount' ];
							}
							$other_taxtotal = $qtysum * $o_tax_total;
							$qty_total = $other_taxtotal + $qty_total;
						}

						?>
					<tr>
						<td colspan="8"><strong style="float: left;">Other Tax Included</strong></td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
					<?php  } } ?>

					<tr class="border-bottom">
						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
				<br>
					<tr style="margin-top: 4px;">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($rows_user_company['c_company_name']); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr >

				</tbody>

			</table>
			<?php } ?>
		</div>
	</div>
<?php 
function convertToIndianCurrency($number) {
    $no = round($number);
    $decimal = round($number - ($no = floor($number)), 2) * 100;    
    $digits_length = strlen($no);    
    $i = 0;
    $str = array();
    $words = array(
        0 => '',
        1 => 'One',
        2 => 'Two',
        3 => 'Three',
        4 => 'Four',
        5 => 'Five',
        6 => 'Six',
        7 => 'Seven',
        8 => 'Eight',
        9 => 'Nine',
        10 => 'Ten',
        11 => 'Eleven',
        12 => 'Twelve',
        13 => 'Thirteen',
        14 => 'Fourteen',
        15 => 'Fifteen',
        16 => 'Sixteen',
        17 => 'Seventeen',
        18 => 'Eighteen',
        19 => 'Nineteen',
        20 => 'Twenty',
        30 => 'Thirty',
        40 => 'Forty',
        50 => 'Fifty',
        60 => 'Sixty',
        70 => 'Seventy',
        80 => 'Eighty',
        90 => 'Ninety');
    $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
    while ($i < $digits_length) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
            $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
        } else {
            $str [] = null;
        }  
    }
    
    $Rupees = implode(' ', array_reverse($str));
    $paise = ($decimal) ? "And Paise " . ($words[$decimal - $decimal%10]) ." " .($words[$decimal%10])  : '';
    return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Only";
}

?>
	<script>
		$( document ).ready( function () {

			window.print();
		
		} );
		window.onafterprint = function() {
		history.go(-1);
		};
		
	</script>

</body>
</html>