<?php include ('include/auth.php'); ?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Supermarket</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
    <link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor">Accounts Creation </h4>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="javascript:void(0)">Home</a>
							</li>
							<li class="breadcrumb-item active">Accounts</li>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-body">
								<form class="needs-validation" novalidate>
									<div class="form-row">
									<div class="container">
									<h1>Edit Profile</h1>
									<hr>
									<div class="row">
									  <!-- left column -->
									  <div class="col-md-3">
										<div class="text-center">
										  <img src="//placehold.it/100" class="avatar img-circle" alt="avatar">
										  <h6>Upload a different photo...</h6>
										  <input type="file" class="form-control">
										</div>
									  </div>
									  <!-- edit form column -->
									  <div class="col-md-9 personal-info">
										<h3>Update Password</h3>
										<form class="form-horizontal" role="form">
										  <div class="form-group">
											<label class="col-lg-3 control-label">Enter Old Password:</label>
											<div class="col-lg-8">
											  <input class="form-control" type="password" value="">
											</div>
										  </div>
										  <div class="form-group">
											<label class="col-lg-3 control-label">Enter New Password:</label>
											<div class="col-lg-8">
											  <input class="form-control" type="password" value="">
											</div>
										  </div>
										  <div class="form-group">
											<label class="col-md-3 control-label"></label>
											<div class="col-md-8">
											  <input type="button" class="btn btn-primary" value="Save Changes">
											  <span></span>
											  <input type="reset" class="btn btn-danger" value="Cancel">
											</div>
										  </div>
										</form>
									  </div>
								  </div>
								</div>
								<hr>
									</div>
								</form>
							</div>
							<div class="col-md-12">
								<div class="card" style="text-align: center;">
								</div>
							</div>
						</div>
					</div>
				</div>
				<script>

				</script>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>

	<script>
		//For validation with custom styles
		( function () {
			'use strict';
			window.addEventListener( 'load', function () {
				// Fetch all the forms we want to apply custom Bootstrap validation styles to
				var forms = document.getElementsByClassName( 'needs-validation' );
				// Loop over them and prevent submission
				var validation = Array.prototype.filter.call( forms, function ( form ) {
					form.addEventListener( 'submit', function ( event ) {
						if ( form.checkValidity() === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
						form.classList.add( 'was-validated' );
					}, false );
				} );
			}, false );
		} )();
	</script>
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>
	<script>
		$( function () {
			// Switchery
			var elems = Array.prototype.slice.call( document.querySelectorAll( '.js-switch' ) );
			$( '.js-switch' ).each( function () {
				new Switchery( $( this )[ 0 ], $( this ).data() );
			} );
			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();
			//Bootstrap-TouchSpin
			$( ".vertical-spin" ).TouchSpin( {
				verticalbuttons: true
			} );
			var vspinTrue = $( ".vertical-spin" ).TouchSpin( {
				verticalbuttons: true
			} );
			if ( vspinTrue ) {
				$( '.vertical-spin' ).prev( '.bootstrap-touchspin-prefix' ).remove();
			}
			$( "input[name='tch1']" ).TouchSpin( {
				min: 0,
				max: 100,
				step: 0.1,
				decimals: 2,
				boostat: 5,
				maxboostedstep: 10,
				postfix: '%'
			} );
			$( "input[name='tch2']" ).TouchSpin( {
				min: -1000000000,
				max: 1000000000,
				stepinterval: 50,
				maxboostedstep: 10000000,
				prefix: '$'
			} );
			$( "input[name='tch3']" ).TouchSpin();
			$( "input[name='tch3_22']" ).TouchSpin( {
				initval: 40
			} );
			$( "input[name='tch5']" ).TouchSpin( {
				prefix: "pre",
				postfix: "post"
			} );
			// For multiselect
			$( '#pre-selected-options' ).multiSelect();
			$( '#optgroup' ).multiSelect( {
				selectableOptgroup: true
			} );
			$( '#public-methods' ).multiSelect();
			$( '#select-all' ).click( function () {
				$( '#public-methods' ).multiSelect( 'select_all' );
				return false;
			} );
			$( '#deselect-all' ).click( function () {
				$( '#public-methods' ).multiSelect( 'deselect_all' );
				return false;
			} );
			$( '#refresh' ).on( 'click', function () {
				$( '#public-methods' ).multiSelect( 'refresh' );
				return false;
			} );
			$( '#add-option' ).on( 'click', function () {
				$( '#public-methods' ).multiSelect( 'addOption', {
					value: 42,
					text: 'test 42',
					index: 0
				} );
				return false;
			} );
			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
	</script>
	<?php include("assets/custom/custom.php");?>
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>