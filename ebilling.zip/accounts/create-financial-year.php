<?php  
include('../php_fn/basic.php');
include( '../datetime_creation/datetime_creation.php' );
include( '../db-connect/db.php' );
$season_tkn = create_token();
$start_year = $_POST['startdate'];
$end_year = $_POST['enddate'];
$book_begning = $_POST['book'];
$datetym = $current_date_time;
$addby = $_POST['userid'];
$company = $_POST['company'];

$result_cus = $db->prepare("SELECT * FROM  financial_year WHERE company_tkn='$company' AND start_year='$start_year' ");
$result_cus->execute();	
$check_count = $result_cus->rowcount(); 
if($check_count==0){
$db->prepare("INSERT INTO financial_year ( start_year, end_year, book_begning, addby, dattym, company_tkn) 
VALUES ( '$start_year', '$end_year', '$book_begning','$addby','$datetym', '$company')")->execute();

?><script>
$.toast( { heading: '<strong><?php echo ucfirst($datetym); ?><br> Add Successfully.', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 1200} ); 
</script>
<?php } else { ?>
<script>
$.toast( { heading: '<strong><?php echo ucfirst($start_year); ?><br> Date Already Exist.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1200} ); 
</script>
<?php } ?>
