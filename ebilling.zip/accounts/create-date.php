<?php 
include( '../include/auth.php' );
include('../php_fn/basic.php');
include( '../datetime_creation/datetime_creation.php' );
include( '../db-connect/db.php' );

$date = $_POST['date'];

$datetym = $current_date_time;
$addby = $_POST['userid'];
$company = $_SESSION['SESS_COMPANY_ID'];

$result_cus = $db->prepare("SELECT * FROM  date_set WHERE company_tkn='$company' AND date='$date' ");
$result_cus->execute();	
$check_count = $result_cus->rowcount(); 

$result_cus1 = $db->prepare("SELECT * FROM  date_set WHERE company_tkn='$company' AND status='pending' ");
$result_cus1->execute();	
$check_count1 = $result_cus1->rowcount(); 
	
if($check_count==0 && $check_count1 == 0){
$db->prepare("INSERT INTO date_set ( date_created, add_by, date, company_tkn) 
VALUES ( '$today', '$addby', '$date', '$company')")->execute();
?>
<script>
$.toast( { heading: ' Date Set Succesfull<br><strong>Logout And Login</strong>  ', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 2000} ); 
</script>
<?php } else if($check_count1 !=0) { ?>
<script>
$.toast( { heading: ' Previous Day Closing Pending.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1200} ); 
</script>
<?php }else{ ?>
<script>
$.toast( { heading: '<strong>Date Already Closed!</strong>.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1200} ); 
</script>
<?php } ?>

