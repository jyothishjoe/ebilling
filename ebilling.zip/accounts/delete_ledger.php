<?php
include '../db-connect/db.php';

$token = $_GET['delete'];
$sql="DELETE FROM account_ledger WHERE ledger_token='$token'";
$q1 = $db->prepare($sql);
$q1->execute();
header("location:../ledger-report.php");
?>