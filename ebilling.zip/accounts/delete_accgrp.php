<?php
include '../db-connect/db.php';

$token = $_GET['delete'];
$sql="DELETE FROM account_group WHERE id='$token'";
$q1 = $db->prepare($sql);
$q1->execute();
header("location:../account-group-list.php");
?>