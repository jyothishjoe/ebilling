<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$token=$_POST[ 'token' ];
$trans_name = $_POST[ 'trans_name' ];
$trans_code = $_POST[ 'trans_code' ];
$userid = $_POST[ 'userid' ];

$sql =  "UPDATE transaction_types SET  trans_name='$trans_name', trans_code='$trans_code' WHERE tax_token='$token' ";
$q1 = $db->prepare($sql);
$q1->execute();	
header("location:../trans_type_list.php");	

?>