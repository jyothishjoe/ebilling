<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$name = $_POST[ 'name' ];
$branch = $_POST[ 'branch' ];
$ifsc = $_POST[ 'ifsc' ];
$address = $_POST[ 'address' ];
$pin = $_POST[ 'pin' ];
$state = $_POST[ 'state' ];
$userid = $_POST[ 'userid' ];
//$accname = $_POST[ 'accname' ];
$accno = $_POST[ 'accno' ];
$balance = $_POST[ 'balance' ];
$code = $_POST[ 'code' ];
$token=$_POST[ 'token' ];

$sql = "UPDATE bank SET  bank_name='$name',bank_branch='$branch',account_no='$accno',bank_ifsc='$ifsc',book_balance='$balance', bank_pin='$pin', bank_code='$code', bank_address='$address' WHERE bank_token='$token'";
$q1 = $db->prepare($sql);
$q1->execute();	

$sql1 = "UPDATE bank_log SET bank_name='$name',bank_branch='$branch',account_no='$accno',bank_ifsc='$ifsc',book_balance='$balance', bank_pin='$pin', bank_code='$code', bank_address='$address' WHERE bank_token='$token'";
$q11 = $db->prepare($sql1);
$q11->execute();	
 if ( isset( $q1 ) ) {
	echo 'ok';
}else{
	 echo 'Not';
 }

?>