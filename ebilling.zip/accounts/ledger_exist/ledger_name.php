<?php
include "../../include/auth.php";
$user_company=$_SESSION['SESS_COMPANY_ID'];
include "../../db-connect/db.php";
/* Get name */
$ledger_name = $_POST['name'];
/* Query */
$result_pr =$db->prepare( "select count(*) as cntcode from account_ledger WHERE company_tkn='$user_company' AND ledger_name='$ledger_name'");
$result_pr ->execute();
$rows_pr = $result_pr->fetch(); 
$count = $rows_pr['cntcode'];

echo $count;