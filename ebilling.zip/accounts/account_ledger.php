<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$token=create_token();
$accname = $_POST[ 'accname' ];
$ledger = strtolower($_POST[ 'ledger' ]);
$gstin = $_POST[ 'gstin' ];
$pan = $_POST[ 'pan' ];
$dr = $_POST[ 'dr' ];
$balance = $_POST[ 'balance' ];
$descr = $_POST[ 'descr' ];
$date = $_POST[ 'date' ];
$grouphead = $_POST[ 'grouphead' ];
$acc_head = $_POST[ 'acchead' ];
$company = $_POST[ 'company' ];

$statement = $db->prepare( "INSERT INTO account_ledger (ledger_token, ledger_name, group_head, acc_head, account_group, gstin, pan, balance, trans, descr, date, company_tkn, invoice_year )
VALUES('$token','$ledger', '$grouphead','$acc_head', '$accname','$gstin','$pan', '$balance', '$dr', '$descr', '$today', '$company', '$current_invoice_year')" );
$statement->execute();
$statement1 = $db->prepare( "INSERT INTO account_ledger_log ( ledger_token,ledger_name, group_head, acc_head, account_group, gstin, pan, balance, trans, descr, date, datetym, invoice_year )
VALUES('$token','$ledger', '$grouphead','$acc_head', '$accname','$gstin','$pan', '$balance', '$dr', '$descr', '$today', '$current_date_time', '$current_invoice_year')" );
$statement1->execute();
?>