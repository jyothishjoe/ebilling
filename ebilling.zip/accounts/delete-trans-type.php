<?php
include '../db-connect/db.php';

$token = $_GET['delete'];
$sql="DELETE FROM transaction_types WHERE tax_token='$token'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../trans_type_list.php");
?>