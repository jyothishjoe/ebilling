<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$name = $_POST[ 'gst' ];

//$accname = $_POST[ 'accname' ];

$token=$_POST[ 'token' ];

$sql = "UPDATE gst_tax SET  gst_rate='$name' WHERE gst_token='$token'";
$q1 = $db->prepare($sql);
$q1->execute();	


$sql1 = "UPDATE gst_tax_log SET  gst_rate='$name' WHERE gst_token='$token'";
$q11 = $db->prepare($sql1);
$q11->execute();	
	
 if ( isset( $q1 ) ) {
	echo 'ok';
}else{
	 echo 'Not';
 }

?>