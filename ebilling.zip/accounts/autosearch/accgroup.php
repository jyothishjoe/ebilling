<?php
include "../../include/auth.php";
$user_company=$_SESSION['SESS_COMPANY_ID'];
include "../../db-connect/db.php";

$request = $_POST[ 'request' ]; // request
// Get username list
if ( $request == 1 ) {
	$search = $_POST[ 'search' ];
	$result = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company' AND ledger_name  like'%" . $search . "%'" );
	$result->execute();
	while ( $row = $result->fetch() ) {
		$response[] = array( "value" => $row[ 'ledger_name' ], 
							"label" => $row[ 'ledger_name' ] );
	}
	// encoding array to json format
	echo json_encode( $response );
	exit;
		// encoding array to json format
	echo json_encode( $users_arr );
}
if ( $request == 2 ) {
	$search = $_POST[ 'account' ];
	$result = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company' AND ledger_name  like'%" . $search . "%'" );
	$result->execute();
	while ( $row = $result->fetch() ) {
		$response[] = array("ledger_token" => $row[ 'ledger_token' ], 
							"token_label" => $row[ 'ledger_token' ] );
	}
	// encoding array to json format
	echo json_encode( $response );
	exit;

	// encoding array to json format
	echo json_encode( $users_arr );
}