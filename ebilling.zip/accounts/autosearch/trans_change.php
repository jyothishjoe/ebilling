<?php	
include('../../db-connect/db.php');	
$name=$_POST["depart"];

  // department id

$result =$db->prepare( "SELECT id,name,typ FROM accountgroup WHERE name='$name'");

$result->execute(); 


$users_arr = array();

while( $rows = $result->fetch() ){
    $userid = $rows['typ'];
    $name = $rows['typ'];

    $users_arr[] = array("id" => $userid, "name" => $name);
}

// encoding array to json format
echo json_encode($users_arr);
?>
	  