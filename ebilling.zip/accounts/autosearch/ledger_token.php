<?php
include "../../include/auth.php";
$user_company=$_SESSION['SESS_COMPANY_ID'];
include('../db-connect/db.php');	
$name=$_POST["v_name"];
$result =$db->prepare("SELECT * FROM accounts_ledger WHERE compnay_tkn='$user_company' AND ledger_name='$name' ");
$result->execute(); 
$rows = $result->fetch();

$data["token"] = $rows["ledger_token"];

echo json_encode($data);
?>
	  