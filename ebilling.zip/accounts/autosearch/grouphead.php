<?php	
include('../../db-connect/db.php');	
$name=$_POST["accname"];
$result =$db->prepare("SELECT * FROM accountgroup WHERE name='$name' ");
$result->execute(); $rows = $result->fetch();
$data["value"] = $rows["group_head"];
$data["acc"] = $rows["acc_head"];
echo json_encode($data);
?>
	  