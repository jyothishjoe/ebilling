<?php
include( "../db-connect/db.php" );
include( '../datetime_creation/datetime_creation.php' );
include( '../php_fn/basic.php' );
$payment = create_token();
for ($count = 0; $count < count($_POST[ "account" ]); $count++){
	if($_POST['dr'][$count] != '')
	{
	$debit= $_POST['dr'][$count];
		
	}else{
		$debit='0';
	}
	if(isset($_POST['cr'][$count]) !='' ){
	$credit= $_POST['cr'][$count];
		
	}else{
		$credit='0';
	}
	$query1 = "INSERT INTO journal
  	(payment_token, j_dat, voucher_no, j_no, trans_code, account, narration,dr, cr) 
	VALUES (:token, :date, :vno, :inv,:trans, :account, :narration, :dr, :cr)";
	$statement1 = $db->prepare($query1);
	$statement1->execute(
		array(
		    ':vno' => $_POST[ "vno" ],
			':trans' => $_POST['trans'],
			':account' => $_POST[ "account" ][ $count ],
			':token' => $payment,
			':date' => $_POST['date'],
			':inv' => $_POST[ "inv_no" ],
			':narration' => $_POST[ "narration" ][ $count ],
			':dr' => $_POST[ "dr" ][ $count ],
			':cr' => $_POST[ "cr" ][ $count ]
		)
	);
	$dr=$_POST[ "dr" ][ $count ];
	$cr=$_POST[ "cr" ][ $count ];
	
$array = array(':dr' => $_POST[ "dr" ][ $count], ':cr' => $_POST[ "cr" ][ $count ]);
$maxValue = max($array);
$maxIndex = array_search(max($array), $array);
 $acc=$_POST['account'][$count];
	
	
	if($dr == $maxValue){
	$query = "INSERT INTO transaction
  	(trn_date, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, debit_amt, remarks, max_status, datetym) 
	VALUES (:date, :vno, :ledger_token, :account, :transtyp, :cr, :dr ,:narration, :status, :current_date)";
	$statement = $db->prepare($query);
	$statement->execute(
		array(
			':vno' => $_POST["vno"],	
			':date' => $_POST['date'],
			':current_date' => $current_date_time,
			':transtyp' => 'cash',
			':narration' => $_POST[ "narration"][$count],
			':account' => $_POST[ "account" ][ $count],
			':cr' => $credit,
			':dr' =>  $debit,
			':ledger_token' => $_POST["ledger_token"][$count],
			':status' => 2
		));
	}else if($cr == $maxValue){
	$query = "INSERT INTO transaction
  	(trn_date, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, debit_amt, remarks, max_status, datetym) 
	VALUES (:date, :vno, :ledger_token, :account, :transtyp, :cr, :dr ,:narration, :status, :current_date)";
	$statement = $db->prepare($query);
	$statement->execute(
		array(
			':vno' => $_POST["vno"],	
			':date' => $_POST['date'],
			':current_date' => $current_date_time,
			':transtyp' => 'cash',
			':narration' => $_POST[ "narration"][$count],
			':account' => $_POST[ "account" ][ $count],
			':cr' => $credit,
			':dr' =>  $debit,
			':ledger_token' => $_POST["ledger_token"][$count],
			':status' => 1
		));	
	}
	}
if (isset($statement1)) {
	echo 'ok';
}
?>