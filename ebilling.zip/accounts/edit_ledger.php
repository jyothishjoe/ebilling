<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$token=$_POST[ 'token' ];
$accname = $_POST[ 'accname' ];
$ledger = $_POST[ 'ledger' ];
$gstin = $_POST[ 'gstin' ];
$pan = $_POST[ 'pan' ];
$dr = $_POST[ 'dr' ];
$balance = $_POST[ 'balance' ];
$descr = $_POST[ 'descr' ];
$grouphead = $_POST[ 'grouphead' ];
$acc_head = $_POST[ 'acchead' ];

$sql =  "UPDATE account_ledger SET  ledger_name='$ledger', group_head='$grouphead', acc_head='$acc_head', account_group='$accname', gstin='$gstin', pan='$pan', balance='$balance', trans='$dr', descr='$descr' WHERE ledger_token='$token' ";
$q1 = $db->prepare($sql);
$q1->execute();	

$sql1 =  "UPDATE account_ledger_log SET  ledger_name='$ledger', group_head='$grouphead', acc_head='$acc_head', account_group='$accname', gstin='$gstin', pan='$pan', balance='$balance', trans='$dr', descr='$descr' WHERE ledger_token='$token' ";
$q11 = $db->prepare($sql1);
$q11->execute();	

?>