<?php
include '../db-connect/db.php';

$token = $_GET['delete'];
$sql="DELETE FROM gst_tax WHERE gst_token='$token'";
$q1 = $db->prepare($sql);
$q1->execute();
$sql1="DELETE FROM gst_tax WHERE gst_token='$token'";
$q11 = $db->prepare($sql1);
$q11->execute();
header("location:../gst-list.php");
?>