<?php
include '../db-connect/db.php';
include('../datetime_creation/datetime_creation.php');
include('../php_fn/basic.php');
$name = $_POST[ 'name' ];
$branch = $_POST[ 'branch' ];
$ifsc = $_POST[ 'ifsc' ];
$address = $_POST[ 'address' ];
$pin = $_POST[ 'pin' ];
$state = $_POST[ 'state' ];
$userid = $_POST[ 'userid' ];
$accname = $_POST[ 'accname' ];
$accno = $_POST[ 'accno' ];
$balance = $_POST[ 'balance' ];
$company = $_POST[ 'company' ];
$code = $_POST[ 'code' ];
$token=create_token();
$result_cat = $db->prepare("SELECT * FROM  bank WHERE account_name='$accname' and bank_name='$name' AND company_tkn='$company'");
$result_cat->execute();	
$check_count = $result_cat->rowcount(); 
if($check_count==0){
$statement = $db->prepare( "INSERT INTO bank ( bank_token, account_name, bank_name, bank_code, bank_branch, account_no, book_balance, bank_ifsc, bank_address, bank_pin, bank_state, date, company_tkn )
VALUES('$token', '$accname',  '$name', '$code','$branch', '$accno','$balance', '$ifsc','$address', '$pin', '$state', '$today', '$company')" );
$statement->execute();

$statement1 = $db->prepare("INSERT INTO bank_log (bank_token, account_name, bank_name, bank_code, bank_branch, account_no, book_balance, bank_ifsc, bank_address, bank_pin, bank_state, date, addby, dattym, company_tkn)
VALUES('$token', '$accname',  '$name','$code','$branch', '$accno','$balance', '$ifsc','$address', '$pin', '$state', '$today' , '$userid', '$current_date_time', '$company')");
$statement1->execute();
?><script>
$.toast( { heading: '<strong><?php echo '&quot;'.ucfirst($accname).'&quot;'; ?> Add Succeccfully.', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 1200} ); 
</script>
<?php } else { ?>
<script>
$.toast( { heading: '<strong><?php echo '&quot;'.ucfirst($accname).'&quot;'; ?> already exist.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1200} ); 
</script>
<?php } ?>
