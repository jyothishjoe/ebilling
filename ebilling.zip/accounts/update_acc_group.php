<?php
include '../db-connect/db.php';
include '../datetime_creation/datetime_creation.php';
$accname = $_POST[ 'accname' ];
$acc = $_POST[ 'acc' ];
$editq = $_POST['edit'];
$sql = "UPDATE account_group SET acc_name='$accname', account='$acc' WHERE id='$editq' ";
$q1 = $db->prepare($sql);
$q1->execute();
$sql1 = "UPDATE account_group_log SET acc_name='$accname', account='$acc' WHERE id='$editq' ";
$q11 = $db->prepare($sql1);
$q11->execute();	
if ( isset( $q1 ) ) {
echo 'ok';
}
?>