<?php
include( "../include/auth.php" );
include( "../db-connect/db.php" );
include( '../datetime_creation/datetime_creation.php' );
include( '../php_fn/basic.php' );
$token = $_POST['token'];
$payment = create_token();
$company_tkn = $_SESSION['SESS_COMPANY_ID'];

$result_journal = $db->prepare("SELECT * FROM payment_transaction a LEFT JOIN transaction b ON a.voucher_no=b.voucher_no WHERE b.voucher_no='$token' AND a.company_tkn='$company_tkn' AND b.company_tkn='$company_tkn'");
$result_journal ->execute();	
$rows_journal  = $result_journal ->fetch();
$voucher_no=$rows_journal['voucher_no'];
	
	
$sql="DELETE payment_transaction, transaction FROM payment_transaction  LEFT JOIN transaction  ON (payment_transaction.voucher_no=transaction.voucher_no) WHERE payment_transaction.voucher_no='$token'";
$q1 = $db->prepare($sql);
$q1->execute();
	
	for ($count = 0; $count < count($_POST[ "account" ]); $count++){
	if(!empty($_POST['dr'][$count]))
	{
	$debit= $_POST['dr'][$count];
	$debit_p=$_POST[ "account" ][ $count];
		$type='Dr';
	}else{
		$debit='0';
		$debit_p='';
		$type='Dr';
	}
	if(!empty($_POST['cr'][$count])){
	$credit= $_POST['cr'][$count];
		$credit_p=$_POST["account"][$count];
		$type2='Cr';
	}else{
		$credit='0';
		$credit_p='';
		$type2='Cr';
	}
	
    $query1 = "INSERT INTO payment_transaction
  	(payment_token, payment_date, voucher_no, trans_no, trans_code, account, narration,dr, cr,debit,credit, company_tkn) 
	VALUES (:token, :date, :vno, :inv,:trans, :account, :narration, :dr, :cr, :debit, :credit, :company)";
	$statement1 = $db->prepare($query1);
	$statement1->execute(
		array(
		    ':vno' => $_POST[ "vno" ],
			':trans' => $_POST['trans'],
			':account' => $_POST[ "account" ][$count],
			':token' => $payment,
			':date' => $_POST['date'],
			':company' => $company_tkn,
			':credit' => $credit_p,
			':debit' => $debit_p,
			':inv' => $_POST[ "inv_no" ],
			':narration' => $_POST[ "narration" ][ $count ],
			':dr' => $_POST[ "dr" ][ $count ],
			':cr' => $_POST[ "cr" ][ $count ]
		)
	);	
	$totalcr=$_POST["totalamt"];
	$totaldr=$_POST[ "totalamtdr" ];
	//$totalamt=$totalcr+$totaldr;
	$dr=$_POST[ "dr" ][ $count ];
	$cr=$_POST[ "cr" ][ $count ];
	
$array = array(':dr' => $_POST[ "dr" ][ $count], ':cr' => $_POST[ "cr" ][ $count ]);
$maxValue = max($array);
$maxIndex = array_search(max($array), $array);
 $acc=$_POST['account'][$count];
	
	
	if($dr == $maxValue){
	$query = "INSERT INTO transaction
  	(trn_date, trans_voucherno, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, debit_amt, remarks, max_status, datetym,typ, company_tkn) 
	VALUES (:date, :trans_voucherno, :vno, :ledger_token, :account, :transtyp, :cr, :dr ,:narration, :status, :current_date,:typ, :company)";
	$statement = $db->prepare($query);
	$statement->execute(
		array(
			':vno' => $_POST["vno"],	
			':date' => $_POST['date'],
			':current_date' => $current_date_time,
			':transtyp' => 'cash',
			':narration' => $_POST[ "narration"][$count],
			':account' => $_POST[ "account" ][ $count],
			':cr' => $credit,
			':dr' =>  $debit,
			':company' => $company_tkn,
			':ledger_token' => $_POST["ledger_token"][$count],
			':typ' => $type,
			':trans_voucherno' => $_POST["trans_voucherno"],
			':status' => 2
		));
	}else if($cr == $maxValue){
	$query = "INSERT INTO transaction
  	(trn_date, trans_voucherno, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, debit_amt, remarks, max_status, datetym,typ, company_tkn) 
	VALUES (:date, :trans_voucherno, :vno, :ledger_token, :account, :transtyp, :cr, :dr ,:narration, :status, :current_date,:typ, :company)";
	$statement = $db->prepare($query);
	$statement->execute(
		array(
			':vno' => $_POST["vno"],	
			':date' => $_POST['date'],
			':current_date' => $current_date_time,
			':transtyp' => 'cash',
			':narration' => $_POST[ "narration"][$count],
			':account' => $_POST[ "account" ][ $count],
			':cr' => $credit,
			':company' => $company_tkn,
			':dr' =>  $debit,
			':ledger_token' => $_POST["ledger_token"][$count],
			':trans_voucherno' => $_POST["trans_voucherno"],
			':typ' => $type2,
			':status' => 1
		));	
	}
}
if (isset($statement1)) {
	setcookie("NC", true, time() + (3), "/");
	echo 'ok';
}
?>