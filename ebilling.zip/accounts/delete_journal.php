<?php
include( "../db-connect/db.php" );
include( '../datetime_creation/datetime_creation.php' );
include( '../php_fn/basic.php' );
$token = $_GET['delete'];

	
$sql="DELETE payment_transaction, transaction FROM payment_transaction  LEFT JOIN transaction  ON (payment_transaction.voucher_no=transaction.voucher_no) WHERE payment_transaction.voucher_no='$token'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../journal-all.php");

?>
