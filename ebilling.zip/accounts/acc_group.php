<?php
include '../db-connect/db.php';
include('../include/today.php');

$accname = $_POST[ 'accname' ];
$acc = $_POST[ 'acc' ];
$descr = $_POST[ 'descr' ];


$statement = $db->prepare( "INSERT INTO account_group ( acc_name, account, descr, date )
VALUES('$accname','$acc','$descr','$date')" );
$statement->execute();
$statement1 = $db->prepare( "INSERT INTO account_group_log ( acc_name, account, descr, date, datetym )
VALUES('$accname','$acc','$descr','$today', '$current_date_time')" );
$statement1->execute();

?>