<?php
include '../include/auth.php';
include '../db-connect/db.php';
include '../php_fn/basic.php';
include '../datetime_creation/datetime_creation.php';

$trans_token = create_token();
$trans_name = $_POST[ 'trans_name' ];
$trans_code = $_POST[ 'trans_code' ];
$cash = $_POST[ 'cash' ];
$company = $_SESSION['SESS_COMPANY_ID'];
$sales = $_POST[ 'sales' ];
$purchase = $_POST[ 'purchase' ];
$user = $_POST['userid'];

$db->prepare("INSERT INTO transaction_types (tax_token, trans_name, trans_code, cash,sales,purchase, addby,datetym, company_tkn) VALUES ('$trans_token','$trans_name','$trans_code', '$cash','$sales','$purchase','$user' ,'$current_date_time', '$company')")->execute();

?>