<?php
include '../include/auth.php';
include '../db-connect/db.php';
include '../datetime_creation/datetime_creation.php';
$addby=$_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID']; ?>
<?php
$check_status = $db->prepare("SELECT SUM(status) AS status, SUM(day_close) AS day_close_status, sales_invodate As sales_invodate FROM sales_invoice WHERE company_tkn='$user_company'");
$check_status->execute();
$rows_check = $check_status->fetch(); 
$status=$rows_check['status']; 
$day_status=$rows_check['day_close_status']; 
$status_date=$rows_check['sales_invodate']; 

$check_status1 = $db->prepare("SELECT * FROM sales_invoice WHERE  company_tkn='$user_company'");
$check_status1->execute();
for($i=0; $rows_check1 = $check_status1->fetch(); $i++){
$status_date=$rows_check1['sales_invodate']; 
}
$result_close_check = $db->prepare("select * from  date_set WHERE date='$status_date' AND company_tkn='$user_company'");
$result_close_check->execute();
for($i=0; $rows_close_check = $result_close_check->fetch(); $i++){ 
$check_date_set = $rows_close_check[ 'status' ]; 
$closed_date = $rows_close_check[ 'date' ];
$closed_date=date_create($closed_date);
$date=date_format($closed_date,"d/m/Y");
}

if($status > 0 ){  ?>

<script>$.toast({heading: 'Transaction Are Pending',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1300});</script>
<?php }else if($day_status == '0'){  ?>
<script>$.toast({heading: 'Day Closing Completed',text:'Day CLosing Already Finished.',position:'top-right',loaderBg:'#053CAA',icon:'info',hideAfter: 1600});</script>
			<?php 
			}else{
			/*$result_code = $db->prepare( "SELECT * FROM  transaction_types WHERE sales ='sales'" );
			$result_code->execute();
			$rows_code = $result_code->fetch();
			$trn_code = $rows_code['trans_code'];*/
	
	        $result_bill = $db->prepare("SELECT * FROM transaction WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
			$result_bill->execute();
			$rows_bill = $result_bill->fetch();
			$row_count = $result_bill->rowCount();
			$prefix = 'SALES';
			if($row_count == 0){
			$invno = 'SALES1';
				
			}else{
			$invno =sprintf( "%s%1s", $prefix, $rows_bill['id'] + 1);
			
			}
	     	
			//SALES RETURN INVOICE
	    	$result_return = $db->prepare( "SELECT SUM(grand_tot) AS grand_tot, bill_no  AS bill_no,status AS status, tax_total_amt AS tax_total_amt, sales_invdate AS sales_invdate  FROM sales_rtn_invoice WHERE status='0' AND day_close='1' AND company_tkn='$user_company' GROUP BY sales_invdate");
			$result_return->execute();
			$rows_return = $result_return->fetch();
			
			$grand_return_tot = $rows_return[ 'grand_tot' ];
			$grand_return_tax = $rows_return[ 'tax_total_amt' ];
				
		
			
			//Sales INVOICE
			$resultes = $db->prepare( "SELECT SUM(net_tot) AS net_tot, b_no AS b_no,status AS status,sum(non_taxable_amt) AS non_taxable_amt, SUM(taxable_amt) AS taxable_amt,SUM(total_tax_amt) AS total_tax_amt, sbill_no AS sbill_no, cashtype AS cashtype, sales_invodate AS sales_invodate  FROM sales_invoice WHERE process ='pay' AND day_close='1' AND company_tkn='$user_company' GROUP BY order_date");
			$resultes->execute();
			$rowes = $resultes->fetch();
			$sales_invodate = $today;
			$order_date = $rowes['sales_invodate'];
			$b_nos = $rowes[ 'b_no' ];
			$cashtype = $rowes[ 'cashtype' ];
			$taxable_amt = $rowes[ 'taxable_amt' ];
			$tax_total = $rowes[ 'total_tax_amt' ] - $grand_return_tax;
	 		$net_tot = $rowes[ 'net_tot' ] - $grand_return_tot;
			$non_taxable_amt = $rowes[ 'non_taxable_amt' ];
	 		$sbill_nosa = $rowes[ 'sbill_no' ];
			
	
			$resultecash = $db->prepare( "SELECT * FROM account_ledger WHERE ledger_name='cash' AND company_tkn='$user_company' ");
			$resultecash->execute();
			$rows_cash = $resultecash->fetch();	
			$cus_name=$rows_cash['ledger_name'];
			$cus_tkn=$rows_cash['ledger_token'];

			   
	
				//transaction insert	
				$result_ledger = $db->prepare( "SELECT * FROM account_ledger WHERE ledger_name = 'sales' AND company_tkn='$user_company'" );
				$result_ledger->execute();
				$rows_ledger = $result_ledger->fetch();
				$taxable_ledger = $rows_ledger['ledger_token'];
				$taxable_ledger_name = $rows_ledger['ledger_name'];


				$result_gst_taxable = $db->prepare( "SELECT * FROM account_ledger WHERE ledger_name = 'gst' AND company_tkn='$user_company'" );
				$result_gst_taxable->execute();
				$rows_gst_taxable = $result_gst_taxable->fetch();
				$gst_ledger_name=$rows_gst_taxable['ledger_name'];
				$gst_ledger_token=$rows_gst_taxable['ledger_token'];
	
	
					$query_customer = "INSERT INTO transaction 
				(trn_date, voucher_no, ledger_token, ledger_name, trans_type, debit_amt, max_status, datetym, typ,company_tkn) 
				VALUES (:date, :billno, :cus_tkn, :cu_name, :trans_type, :debit_amt, :status, :datetym , :typ, :company)";
				$statement_customer = $db->prepare( $query_customer );
				$statement_customer->execute(
					array(
						':date' => $order_date,
						':trans_type' => 'sales',
						':cus_tkn' => $cus_tkn,
						':company' => $user_company,
						':cu_name' => strtolower($cus_name),
						':billno' => $invno,
						':debit_amt' => $net_tot,
						':typ' => 'Dr',
						':datetym' => $current_date_time,
						':status' => 2
					)
				);
	
	
	
	            $query_sales = "INSERT INTO transaction 
				(trn_date, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, max_status, datetym, typ, company_tkn) 
				VALUES (:date, :billno, :cus_tkn, :cu_name, :trans_type, :credit_amt, :status, :datetym, :typ, :company )";
				$statement_sales = $db->prepare( $query_sales );
				$statement_sales->execute(
					array(
						':date' => $order_date,
						':trans_type' => 'sales',
						':company' => $user_company,
						':cus_tkn' => $taxable_ledger,
						':cu_name' => strtolower($taxable_ledger_name),
						':billno' => $invno,
						':typ' => 'Cr',
						':credit_amt' => $net_tot - $tax_total,
						':datetym' => $current_date_time,
						':status' => 1
					)
				); 
				
					$query_gst = "INSERT INTO transaction 
					(trn_date, voucher_no, ledger_token, ledger_name, trans_type, credit_amt, max_status, datetym, typ, company_tkn) 
					VALUES (:date, :billno, :cus_tkn, :cu_name, :trans_type, :credit_amt, :status, :datetym, :typ, :company )";
					$statement_gst = $db->prepare( $query_gst );
					$statement_gst->execute(
						array(
							':date' => $order_date,
							':trans_type' => 'tax',
							':company' => $user_company,
							':cus_tkn' => $gst_ledger_token,
							':cu_name' => strtolower( $gst_ledger_name ),
							':billno' => $invno,
							':credit_amt' => $tax_total,
							':datetym' => $current_date_time,
							':typ' => 'Cr',
							':status' => 1
						)
					);
				
					//Closing Stock Update//
					$result_openingbalance = $db->prepare( "SELECT * FROM account_ledger WHERE account_group = 'STOCK' AND company_tkn=:company " );
					$result_openingbalance->execute( array(
						':company' => $user_company
					));
					$rows_opbalance = $result_openingbalance->fetch();
					$opening_balance = $rows_opbalance['balance'];
					$closing_balance_amt = $rows_opbalance['closing_balance'];
					$amt = $opening_balance + $closing_balance_amt - $net_tot;
					$closing_stock = $closing_balance_amt - $net_tot ;
					
					//echo $closing_stock;
	
					
					$closing_balance = "UPDATE account_ledger SET  closing_balance= :closing_stock  WHERE account_group = 'STOCK' AND company_tkn='$user_company'";
					$closing_bal = $db->prepare( $closing_balance );
					$closing_bal->execute( array(
						':closing_stock' => abs($closing_stock),
					));

?>
 <script>
	$.toast({heading: 'Day Closing Succesfull',text: '',position: 'top-right',loaderBg: '#16F06D',icon: 'success',hideAfter: 1300});
 </script>
	<?php 
	//slaes 
		$sql = "UPDATE sales_invoice SET day_close='0'  WHERE sales_invodate='$today' AND company_tkn='$user_company'";
		$q = $db->prepare($sql);
		$q->execute();
	//slaes return
		$sql = "UPDATE sales_rtn_invoice SET status='0',day_close='0'  WHERE sales_invdate='$today' AND company_tkn='$user_company'";
		$q = $db->prepare($sql);
		$q->execute();
} ?>


