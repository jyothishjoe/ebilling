<?php
include('include/auth.php');
include('db-connect/db.php');
$userid=$_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-sm-6 col-xs-12" style="width: 950px;">
<h3 class="text-center">Bank</h3>
<form action="" method="post" id="insert_form">
	<div class="form-row">
	<div class="col-md-4 mb-3">
<div class="form-group row">
<label for="validationTooltip01" class="control-label  col-12">Account Name</label>
			<div class="col-12">
				<select class="form-control " id="accname" name="accname" style="width: 100%; height:36px;">
					<option></option>
					<?php
					$result_acc = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company'" );
					$result_acc->execute();
					for ($i = 0; $rows_acc = $result_acc->fetch(); $i++ ){
						$accgrp = $rows_acc[ 'ledger_name' ];
						?>
					<option value="<?php echo $accgrp; ?>">
						<?php echo $accgrp; ?>
					</option>
					<?php } ?>
				</select>
			</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip01" class="control-label  col-md-12">Bank Name</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="name" id="name" placeholder="Name">
					<input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
					<input type="hidden" name="company" id="company" value="<?php echo $user_company; ?>">
				</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Bank Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="code" id="code" placeholder="Bank Code">
				</div>
			</div>
		</div>
		
		
		<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltipUsername" class="control-label  col-md-12">Address</label>
				<div class="input-group col-md-12">
					<textarea class="form-control" name="address" id="address" placeholder="Address" aria-describedby="validationTooltipUsernamePrepend" rows="4"></textarea>
				</div>
			</div>
		</div>
		<div class="col-md-4 mb-3">
			<div class="form-group row">
			<label for="validationTooltip03" class="control-label col-md-12">State</label>
				<div class="col-md-12" >
				<select name="state" id="state" class="form-control">
				<option value="">Select State</option>
				<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
				<option value="Andhra Pradesh">Andhra Pradesh</option>
				<option value="Arunachal Pradesh">Arunachal Pradesh</option>
				<option value="Assam">Assam</option>
				<option value="Bihar">Bihar</option>
				<option value="Chandigarh">Chandigarh</option>
				<option value="Chhattisgarh">Chhattisgarh</option>
				<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
				<option value="Daman and Diu">Daman and Diu</option>
				<option value="Delhi">Delhi</option>
				<option value="Goa">Goa</option>
				<option value="Gujarat">Gujarat</option>
				<option value="Haryana">Haryana</option>
				<option value="Himachal Pradesh">Himachal Pradesh</option>
				<option value="Jammu and Kashmir">Jammu and Kashmir</option>
				<option value="Jharkhand">Jharkhand</option>
				<option value="Karnataka">Karnataka</option>
				<option value="Kerala">Kerala</option>
				<option value="Lakshadweep">Lakshadweep</option>
				<option value="Madhya Pradesh">Madhya Pradesh</option>
				<option value="Maharashtra">Maharashtra</option>
				<option value="Manipur">Manipur</option>
				<option value="Meghalaya">Meghalaya</option>
				<option value="Mizoram">Mizoram</option>
				<option value="Nagaland">Nagaland</option>
				<option value="Orissa">Orissa</option>
				<option value="Pondicherry">Pondicherry</option>
				<option value="Punjab">Punjab</option>
				<option value="Rajasthan">Rajasthan</option>
				<option value="Sikkim">Sikkim</option>
				<option value="Tamil Nadu">Tamil Nadu</option>
				<option value="Tripura">Tripura</option>
				<option value="Uttaranchal">Uttaranchal</option>
				<option value="Uttar Pradesh">Uttar Pradesh</option>
				<option value="West Bengal">West Bengal</option>
				</select>
			</div>
			<label for="validationTooltip03" class="control-label col-md-12">Pin Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="pincode" id="pincode" placeholder="Pin" required>
				</div>
		</div>
	</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">IFC Code</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="ifsc" id="ifsc" placeholder="IFSC">
				</div>
				<label for="validationTooltip01" class="control-label  col-md-12">Branch</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="branch" id="branch" placeholder="Branch">
				</div>
			</div>
	</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Account No</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="accno" id="accno" placeholder="Account No">
				</div>
			</div>
		</div>
	<div class="col-md-4 mb-3">
			<div class="form-group row">
				<label for="validationTooltip06" class="control-label  col-md-12">Book Balance</label>
				<div class="col-md-12">
					<input type="text" class="form-control" name="balance" id="balance" placeholder="Balance">
				</div>
			</div>
		</div>
	<div class="col-md-12">
		<a href="javascript: save_customer()" name="submit" class="btn btn-info btn-sm" id="submit" style="float: right;">Submit</a>
		<input type="submit" name="insert" class="btn btn-danger btn-sm" id="close_fbx" style="float: right; margin-right: 8px;" value="Cancel">
	</div>
	</form>
</div>
<script>
	$( '#close_fbx' ).on( 'click', function (){
	  parent.jQuery.fancybox.close();
		});
	   function save_customer() {
		var name = $( "#name" ).val();
		var branch = $( "#branch" ).val();
		var ifsc = $( "#ifsc" ).val();
		var state = $( "#state" ).val();
		var company = $( "#company" ).val();
		var address = $( "#address" ).val();
		var pin = $( "#pin" ).val();
		var userid = $( "#userid" ).val();
		var code = $( "#code" ).val();
	   var accname = $( "#accname" ).val();
	   var accno = $( "#accno" ).val();
	   var balance = $( "#balance" ).val();

		if ( $( "#name" ).val() == "" || $( "#branch" ).val() == "" || $( "#ifsc" ).val() == "" || $( "#state" ).val() == "" || $( "#code" ).val() == "" ){
			$.toast({heading: 'Fill all required fields.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200});
		} else {
			$( "#submit" ).hide();
			$.ajax({
			type : 'POST',
			url  : "accounts/create_bank.php",
			data: "name="+ name + "&branch=" + branch + "&accname=" + accname + "&accno=" + accno + "&balance=" + balance + "&ifsc=" + ifsc + "&state=" + state + "&address=" + address + "&pin=" + pin + "&userid=" + userid + "&code=" + code + "&company=" + company,
			success : function(r){						
			$("#respond").html(r);
			}
			});
			//parent.jQuery.fancybox.close();
			document.getElementById('insert_form').reset(); $( "#submit" ).show();
			return false;
		}
	}
	$(document).keyup(function(e){
		
	if(e.altKey && e.which == 76){  $('#ledger').click();

	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
</script>
