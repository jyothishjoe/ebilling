<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');
$today_date = date_create($today);
$sales_invodate=date_format($today_date,"Y-m-d");

$results = $db->prepare("select * from  admin_user where user_tkn = '$userid' ");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $counter=$rows['counter']; }

$date_set = $today;

 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
<title>POS</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-3.2.1.min.js"></script>
<script src="js/auto_js/jquery-ui.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">

</head>
<style>
.totalprice {
	font-size: 20px !important;
}
</style>
<body class="fix-header fix-sidebar card-no-border" onload='setFocusToTextBox()'>
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h3 class="text-themecolor">POS</h3>
        </div>
        <div class="col-md-7 align-self-center" style="z-index:9 !important;">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
            <li class="breadcrumb-item"><a href="saleshome.php">Sales</a></li>
            <li class="breadcrumb-item active">POS</li>
          </ol>
        </div>
        <div class="">
          
        </div>
      </div>
      <?php 
			    $result =$db->prepare("SELECT * FROM  sales_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				$sbill_no=$rows['b_no'] + 1;
				$identification_leter='sa';
		?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <div class="text-right">
				  
				  <button oncontextmenu="return false;" class="btn btn-info btn-sm" onclick="window.open('salesof-point.php?Billno=<?php echo $sbill_no +1;?>','',' scrollbars=yes,menubar=no,width=1680,height=750, resizable=yes,toolbar=no,location=no,status=no')" ><i class="fa fa-plus"></i> Another Bill</button>&nbsp;&nbsp;
				  
				 <a href="customer-add-popup.php" class="btn btn-info  btn-sm simple-ajax-popup-align-top " style="float: right;margin-right:13px; font-size:13px;" id="cbutton" ><i class="fa fa-plus"></i> Add Customer OR F4</a></div>
              <div class="clear"></div>
              <hr>
              <form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
                <div class="form-row">
                  <div class="col-md-4 col-sm-6 col-xs-12  mb-1">
                    <div class="row">
                      <div class="col-md-3 col-sm-6 col-xs-12">
                        <label for="" class="control-label">Bill No:</label>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                         <input type="text" class="form-control" id="sbill_no" name="sbill_no" value="<?php echo strtoupper($identification_leter); echo strtoupper($counter); echo $sbill_no;?>" readonly>
						 <input type="hidden" class="form-control"  value="<?php echo $counter;?>" name="counter"  id="counter" readonly>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-xs-12"></div>
                  <input type="hidden" class="form-control" id="addby" name="addby" value="<?php echo $userid; ?>">
					<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>">
                  <input type="hidden" class="form-control" id="bill_type" name="bill_type" value="pos">
                  <input type="hidden" class="form-control" id="sales_invono" name="sales_invono"  value="<?php echo create_token() ; ?>"  readonly>
                  <div class="col-md-2 col-sm-6 col-xs-6 mb-1">
                    <input type="date" class="form-control" id="sales_invodate" name="sales_invodate" value="<?php echo $date_set; ?>">
                  </div>
                  <div class="col-md-2 col-sm-6 col-xs-6 mb-1">
                    <input type="time" class="form-control"  id="sales_invotime" name="sales_invotime" value="<?php echo $current_time;?>" readonly>
                  </div>
				    <input type="hidden" class=" form-control cashtype" name="cashtype" id="cashtype" value="cash sales">
				 
                  <div class="col-md-2 col-sm-6 col-xs-12  mb-1">
                    <label for="" class="control-label">Customer Name</label>
                    <select class="select2 form-control" name="cus_tkn" id="cus_tkn" style="width: 100%; height:36px;">
                      <option value="">select Customer</option>
                      <?php
							$result =$db->prepare("SELECT * FROM  customer WHERE company_tkn='$user_company'");
							$result->execute();
							while($row = $result->fetch()){
					   ?>
                      <option value="<?php echo $row['cus_tkn'];?>"><?php echo ucfirst($row['cus_name']);?></option>
                      <?php } ?>
                    </select>
                  </div>
                  <input type="hidden" value="0" name="order_invno" id="order_invno">
                  <input type="hidden" value="0" name="order_invdate" id="order_invdate">
                  <div class="col-md-2 col-sm-6 col-xs-6 mb-1">
                    <input type="text" class="form-control" id="contact_no1"  readonly>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                <input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty"  readonly>
                <input type="hidden" class="form-control" id="cus_name" name="cus_name"  readonly>
                <input type="hidden" class="form-control" id="datetym" name="datetym" value="<?php echo $current_date_time;?>">
                <label for="" class="control-label">Product Details</label>
                <div class="table-responsive col-md-12 col-sm-12 col-xs-12" >
                  <table border='0' class="table table-bordered table-striped mb-0" style="min-width: 800px;">
                    <thead>
                      <tr>
                        <th>Sl No</th>
                        <th>Barcode</th>
                        <th>Item code</th>
                        <th>Item Name</th>
                        <th>Qty</th>
                        <th>Unit</th>
                        <th>Gst %</th>
                        <th>Unit Price</th>
                        <th>Gst Amount</th>
						<th>Other Tax Amt</th>
                        <th>Total</th>
                        <th><input type="button" id="addmore" name="button" class="btn btn-sm btn-info" value="+">
                          </button>
                        </th>
                      </tr>
                    </thead>
                    <tbody id="hello">
                      <tr class='tr_input'>
                        <td width="70" class="css-serialw"><input type='text' class="form-control slno" name="slno[]" id='slno_1' value="1"></td>
                        <td><input type='text' class="form-control brcode" name="brcode[]" id='brcode_1' placeholder='Barcode'></td>
                        <td><input type='text' class="form-control code" name="code[]" id='code_1' placeholder='Product Code'><input type='hidden' class="form-control stock_tkn" name="stock_tkn[]" id='stock_tkn_1'></td>
                        <td><input type='text' class="form-control name" name="name[]" id='name_1' placeholder='Product Name' ></td>
                        <td><input type='text' class="form-control qty" name="qty[]" id='qty_1' placeholder='Qty' ></td>
                        <td><input type='text' class="form-control unit"  readonly name="unit[]" id='unit_1' placeholder='unit'></td>
                        <td><input type='text' class="form-control stax" readonly name="stax[]" id='stax_1' placeholder='Gst %'></td>
						<!--other  Tax rate-->
							<td style="display:none;">
							<input type='text' class="form-control othertax_amt1" name="othertax_amt1[]" id='othertax_amt1_1' placeholder='Gst Cess %' value="0">
							<input type='text' class="form-control othertax_amt2" name="othertax_amt2[]" id='othertax_amt2_1' value="0" >
							<input type='text' class="form-control othertax_amt3" name="othertax_amt3[]" id='othertax_amt3_1' value="0" >
							<input type='text' class="form-control othertax_amt4" name="othertax_amt4[]" id='othertax_amt4_1' value="0" >
							<input type='text' class="form-control othertax_amt5" name="othertax_amt5[]" id='othertax_amt5_1' value="0" >
											
							<!-- other tax amount(one) -->			
							<input type='text' class="form-control o_tax_amt1" readonly name="o_tax_amt1[]" id='o_tax_amt1_1' placeholder='other tax  amt' value="0">
							<input type='text' class="form-control o_tax_amt2" readonly name="o_tax_amt2[]" id='o_tax_amt2_1' placeholder='other tax  amt' value="0">
							<input type='text' class="form-control o_tax_amt3" readonly name="o_tax_amt3[]" id='o_tax_amt3_1' placeholder='other tax  amt' value="0">
							<input type='text' class="form-control o_tax_amt4" readonly name="o_tax_amt4[]" id='o_tax_amt4_1' placeholder='other tax  amt' value="0">
							<input type='text' class="form-control o_tax_amt5" readonly name="o_tax_amt5[]" id='o_tax_amt5_1' placeholder='other tax  amt' value="0">
							<!-- other tax types -->
							<input type='text' class="form-control o_tax_type1" readonly name="o_tax_type1[]" id='o_tax_type1_1' placeholder='other tax type' value="0">
							<input type='text' class="form-control o_tax_type2" readonly name="o_tax_type2[]" id='o_tax_type2_1' placeholder='other tax type' value="0">
							<input type='text' class="form-control o_tax_type3" readonly name="o_tax_type3[]" id='o_tax_type3_1' placeholder='other tax type' value="0">
							<input type='text' class="form-control o_tax_type4" readonly name="o_tax_type4[]" id='o_tax_type4_1' placeholder='other tax type' value="0">
							<input type='text' class="form-control o_tax_type5" readonly name="o_tax_type5[]" id='o_tax_type5_1' placeholder='other tax type' value="0">
							
							</td>
                        <td style="display:none;"><input type='text' class="form-control gst" readonly name="gst[]" id='gst_1' placeholder='Gst Rate'></td>
                        <td><input type='text' class="form-control unitprice" name="unitprice[]" id='unitprice_1' placeholder='unit Price'></td>
                        <td><input type='text' class="form-control totalgst" readonly name="totalgst[]" id='totalgst_1' placeholder='Gst Amount'>
						<!-- other tax total amount-->
							<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total1[]" id='o_tax_total1_1' placeholder='Other tax Amount' value="0">
							<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total2[]" id='o_tax_total2_1' placeholder='Other tax Amount' value="0">
							<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total3[]" id='o_tax_total3_1' placeholder='Other tax Amount' value="0">
							<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total4[]" id='o_tax_total4_1' placeholder='Other tax Amount' value="0">
							<input type='hidden' class="form-control o_tax_total" readonly name="o_tax_total5[]" id='o_tax_total5_1' placeholder='Other tax Amount' value="0">
							
						</td>
						<td><input type='text' class="form-control totalgstcess" readonly name="totalgstcess[]" id='totalgstcess_1' placeholder='Other Tax Amount'></td>
                        <td><input type='text' class="form-control total" readonly name="total[]" id='total_1' placeholder='Total'>
						<input type='hidden' class="form-control base_amount" readonly name="base_amount[]" id='base_amount_1' placeholder='Total'>
						<input type='hidden' class="form-control net_tax" readonly name="net_tax[]" id='net_tax_1' placeholder='Total'>
						</td>
                        <td style="display:none;"><input type='text' class="form-control hsn" readonly name="hsn[]" id='hsn_1' placeholder='hsn'></td>
                        <td style="display:none;"><input type='text' class="form-control mrp" readonly name="mrp[]" id='mrp_1' placeholder='mrp'></td>
                        <td style="display:none;"><input type='text' class="form-control catname" readonly name="catname[]" id='catname_1' placeholder='cate'></td>
                        <td style="display:none;"><input type='text' class="form-control subcat" readonly name="subcat[]" id='subcat_1' placeholder='subcate'></td>
                        <td><input type='button' id='delete_1' name='button' class='btn btn-sm btn-danger delete' value='x' style="display:none;">
                      </tr>
                    </tbody>
                  </table>
                </div>
                <br>
                <br>
                <hr>
                <div class="col-md-12 col-sm-12 col-xs-12 form-horizontal">
                  <div class="row">
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Total Amount</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <input type="text" readonly class="form-control totalprice" name="totalprice" id="totalprice" placeholder="0">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-6 col-sm-6 col-xs-9">Tax Amount</label>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                          <input type="text" readonly class="form-control tax_tot" name="tax_tot" id="tax_tot">
                        </div>
                      </div>
					  <div class="form-group row">
                            <label class="control-label  col-md-6 col-sm-6 col-xs-9">Other Tax Total</label>
                            <div class="col-md-6 col-sm-6 col-xs-6">
							  <input type="text" readonly class="form-control cesstotal" name="cesstotal" id="cesstotal" placeholder="0">
                            </div>
                          </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Discount</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <input type="text"  class="form-control discount" name="discount" id="discount" placeholder="Discount" value="0">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Net Total</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <input type="text" readonly class="form-control gtotalprice" name="gtotalprice" id="gtotalprice" placeholder="Grant Total">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12" style="border-bottom: 1px solid #D5D2D2; margin-bottom: 18px;"></div>
                    <hr>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Mode of Payment</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <select class="form-control paytype" name="paytype" id="paytype">
                            <option value="CASH">Cash</option>
                            <option value="BANK">Bank</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Paid Amount</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <input type="text" class="form-control paidamount" name="paidamount" id="paidamount"  placeholder="Paid Amount">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-3">
                      <div class="form-group row">
                        <label class="control-label  col-md-5 col-sm-6 col-xs-9">Balance</label>
                        <div class="col-md-7 col-sm-6 col-xs-6">
                          <input type="text" readonly class="form-control balance"  name="balance" id="balance" placeholder="Balance">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-12 col-xs-12">
                      <div class="form-group row">
                        <label class="control-label  col-md-4 col-sm-6 col-xs-3">Remark</label>
                        <div class="col-md-8 col-sm-6 col-xs-9">
                          <textarea class="form-control" id="other_notes" rows="" id="other_notes" name="other_notes" ></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 text-right">
                      <input type="submit" name="submit" id="cus_tkn" class="btn btn-info btn-sm"  value="Save & Print"/>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="respond"></div>
<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: true,
					closeOnBgClick: false,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			</script> 
<script>
function setFocusToTextBox(){
    $("#brcode_1").focus();
}
</script> 
<script type="text/javascript">

		$( document ).ready( function () {

			$( document ).on( 'keydown', '.code', function () {

				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];

				$( '#' + id ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "creation_actions/sales-bill/autosearch_prodct/prdctcode.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 1
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
					select: function ( event, ui ) {
						$( this ).val( ui.item.value ); // display the selected text
						var prdct_code = ui.item.value; // selected id to input
						var stock_tkn = ui.item.stock_tkn;
						document.getElementById( 'stock_tkn_' + index ).value = stock_tkn;	
						// AJAX
						$.ajax( {
							url: 'creation_actions/sales-bill/autosearch_prodct/prdctcode.php',
							type: 'post',
							data: {
								prdct_code: prdct_code,stock_tkn: stock_tkn,
								request: 2
							},
							dataType: 'json',
							success: function ( response ) {

								var len = response.length;

								if ( len > 0 ) {
									document.getElementById('othertax_amt2_' + index).value = 0;
									document.getElementById( 'o_tax_amt2_' + index ).value = 0;
									document.getElementById( 'o_tax_type2_' + index ).value = 0;
									
									document.getElementById('othertax_amt3_' + index).value = 0;
									document.getElementById( 'o_tax_amt3_' + index ).value = 0;
									document.getElementById( 'o_tax_type3_' + index ).value = 0;
									
									document.getElementById('othertax_amt4_' + index).value = 0;
									document.getElementById( 'o_tax_amt4_' + index ).value = 0;
									document.getElementById( 'o_tax_type4_' + index ).value = 0;
									
									document.getElementById('othertax_amt5_' + index).value = 0;
									document.getElementById( 'o_tax_amt5_' + index ).value = 0;
									document.getElementById( 'o_tax_type5_' + index ).value = 0;
									if(response[0]['pr_code'] != ''){
									var prdct_code = response[ 0 ][ 'pr_code' ];
									var prdct_name = response[ 0 ][ 'pr_name' ];
									var prdct_price = response[ 0 ][ 'pr_saleprice' ];
									var unit = response[ 0 ][ 'pr_unit' ];
									var pr_hsn = response[ 0 ][ 'pr_hsn' ];
									var gst_amt = response[ 0 ][ 'unit_gst_amt' ];
									var sales_tax = response[ 0 ][ 'sales_tax' ];
									var mrp = response[ 0 ][ 'unit_price' ];
									var pr_barcode = response[ 0 ][ 'pr_barcode' ];
									var sub_cat = response[ 0 ][ 'sub_cat' ];
									var cat_name = response[ 0 ][ 'cat_name' ];
									var tax_type = response[0]['tax_type'];
									document.getElementById( 'o_tax_type1_' + index ).value = tax_type;
									var o_tax_amt = response[0]['o_tax_amt'];
									document.getElementById( 'o_tax_amt1_' + index ).value = o_tax_amt;
									var tax = response[0]['tax_rate'];
									document.getElementById( 'othertax_amt1_' + index ).value = tax;
									document.getElementById( 'subcat_' + index ).value = sub_cat;
									document.getElementById( 'catname_' + index ).value = cat_name;
									document.getElementById( 'brcode_' + index ).value = pr_barcode;
									document.getElementById( 'mrp_' + index ).value = mrp;
									document.getElementById( 'stax_' + index ).value = sales_tax;
									document.getElementById( 'gst_' + index ).value = gst_amt;
									
									document.getElementById( 'hsn_' + index ).value = pr_hsn;
									document.getElementById( 'name_' + index ).value = prdct_name;
									document.getElementById( 'unitprice_' + index ).value = prdct_price;
									document.getElementById( 'unit_' + index ).value = unit;
									document.getElementById( 'qty_' + index ).focus();
									$( '#totalprice' ).val( $( '#totalprice' ).val() - $( '#total_' + index ).val() );
									$( '#tax_tot' ).val( $( '#tax_tot' ).val() - $( '#totalgst_' + index ).val() );
									document.getElementById( 'total_' + index ).value=0;
									document.getElementById( 'qty_' + index ).value=0;
									document.getElementById( 'totalgst_' + index ).value=0;
									}
										if(response[1]['tax_rate'] != ''){
										var other_tax1 = response[1]['tax_rate'];
										document.getElementById('othertax_amt2_' + index).value = other_tax1;
										var o_tax_amt2 = response[1]['o_tax_amt'];
										document.getElementById( 'o_tax_amt2_' + index ).value = o_tax_amt2;
										var tax_type2 = response[1]['tax_type'];
										document.getElementById( 'o_tax_type2_' + index ).value = tax_type2;
									}
									if(response[2]['tax_rate'] !=''){
										var other_tax2 = response[2]['tax_rate'];
										document.getElementById('othertax_amt3_' + index).value = other_tax2;
										var o_tax_amt3 = response[2]['o_tax_amt'];
										document.getElementById( 'o_tax_amt3_' + index ).value = o_tax_amt3;
										var tax_type3 = response[2]['tax_type'];
										document.getElementById( 'o_tax_type3_' + index ).value = tax_type3;
									} 
									if(response[3]['tax_rate'] !=''){
										var other_tax3 = response[3]['tax_rate'];
										document.getElementById('othertax_amt4_' + index).value = other_tax3;
										var o_tax_amt4 = response[3]['o_tax_amt'];
										document.getElementById( 'o_tax_amt4_' + index ).value = o_tax_amt4;
										var tax_type4 = response[3]['tax_type'];
										document.getElementById( 'o_tax_type4_' + index ).value = tax_type4;
									} 
									if(response[4]['tax_rate'] !=''){
										var other_tax4 = response[4]['tax_rate'];
										document.getElementById('othertax_amt5_' + index).value = other_tax4;
										var o_tax_amt5 = response[4]['o_tax_amt'];
										document.getElementById( 'o_tax_amt5_' + index ).value = o_tax_amt5;
										var tax_type5 = response[4]['tax_type'];
										document.getElementById( 'o_tax_type5_' + index ).value = tax_type5;
									} 
									
									$( '#cesstotal' ).val( $( '#cesstotal' ).val() - ($( '#o_tax_total1_' + index ).val() + $( '#o_tax_total2_' + index ).val() + $( '#o_tax_total3_' + index ).val()+ $( '#o_tax_total4_' + index ).val() + $( '#o_tax_total5_' + index ).val()));
									document.getElementById( 'o_tax_total1_' + index ).value=0;
									document.getElementById( 'o_tax_total2_' + index ).value=0;
									document.getElementById( 'o_tax_total3_' + index ).value=0;
									document.getElementById( 'o_tax_total4_' + index ).value=0;
									document.getElementById( 'o_tax_total5_' + index ).value=0;
								}
							}
						} );
						return false;
					}
				} );

 

				$(".qty,.unitprice").keyup(function () {
 

					$('#total_' + index ).val($('#unitprice_'  + index).val() * $('#qty_'  + index).val());
					$( '#totalgst_' + index ).val( $( '#gst_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total1_' + index ).val( $( '#o_tax_amt1_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total2_' + index ).val( $( '#o_tax_amt2_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total3_' + index ).val( $( '#o_tax_amt3_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total4_' + index ).val( $( '#o_tax_amt4_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total5_' + index ).val( $( '#o_tax_amt5_' + index ).val() * $( '#qty_' + index ).val() );
					
					/*other tax total - one product */
					$( '#totalgstcess_' + index ).val(  parseFloat($( '#o_tax_total1_' + index ).val()) +  parseFloat($( '#o_tax_total2_' + index ).val()) +  parseFloat($( '#o_tax_total3_' + index ).val()) +  parseFloat($( '#o_tax_total4_' + index ).val()) +  parseFloat($( '#o_tax_total5_' + index ).val()) );
					$( '#net_tax_' + index ).val(  parseInt($( '#totalgstcess_' + index ).val()) + parseInt($( '#totalgst_' + index ).val()) );
					$( '#base_amount_' + index ).val( $( '#total_' + index ).val() - $( '#net_tax_' + index ).val() );
                    
		/*net sum */
					var sum = 0;
					var qtysum = 0; var taxtot = 0;  var cesstot=0; 
		//iterate through each textboxes and add the values
		$(".total").each(function() {

			//add only if the value is number
			if(!isNaN(this.value) && this.value.length!=0) {
				sum += parseFloat(this.value);
			}
 
		}); 
		//.toFixed() method will roundoff the final sum to 2 decimal places
		document.getElementById('totalprice').value =  Math.round(sum);
		/*qty sum*/
		$(".qty").each(function() {
			if(!isNaN(this.value) && this.value.length!=0) {
				qtysum += parseFloat(this.value);
			}
		}); 
		document.getElementById('totalqty').value =  Math.round(qtysum);
		/* tax total*/
					$( ".totalgst" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							taxtot += parseFloat( this.value );
						}
					} );
	document.getElementById( 'tax_tot' ).value = Math.round( taxtot );
	/* other tax  total*/
	  $( ".totalgstcess" ).each( function () {
			 if ( !isNaN( this.value ) && this.value.length != 0 ) {
				 cesstot += parseFloat( this.value );
			 }
		 } );
	 document.getElementById( 'cesstotal' ).value = Math.round( cesstot );
		/*net total*/
		var totalpri = document.getElementById("totalprice").value;
    var discount = document.getElementById("discount").value;
    var gtotal = parseInt(totalpri) - parseInt(discount);
	document.getElementById('gtotalprice').value =  Math.round(gtotal);
 });
			} );

	$( document ).on( 'keydown', '.name', function () {

				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];

				$( '#' + id ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "creation_actions/sales-bill/autosearch_prodct/prdctcode.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 3
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
					select: function ( event, ui ) {
						$( this ).val( ui.item.value ); // display the selected text
						var prdct_name = ui.item.value; // selected id to input
						var stock_tkn = ui.item.stock_tkn;
						document.getElementById( 'stock_tkn_' + index ).value = stock_tkn;
						// AJAX
						$.ajax( {
							url: 'creation_actions/sales-bill/autosearch_prodct/prdctcode.php',
							type: 'post',
							data: {
								prdct_name: prdct_name,stock_tkn: stock_tkn,
								request: 4
							},
							dataType: 'json',
							success: function ( response ) {

								var len = response.length;

								if ( len > 0 ) {
									document.getElementById('othertax_amt2_' + index).value = 0;
									document.getElementById( 'o_tax_amt2_' + index ).value = 0;
									document.getElementById( 'o_tax_type2_' + index ).value = 0;
									
									document.getElementById('othertax_amt3_' + index).value = 0;
									document.getElementById( 'o_tax_amt3_' + index ).value = 0;
									document.getElementById( 'o_tax_type3_' + index ).value = 0;
									
									document.getElementById('othertax_amt4_' + index).value = 0;
									document.getElementById( 'o_tax_amt4_' + index ).value = 0;
									document.getElementById( 'o_tax_type4_' + index ).value = 0;
									
									document.getElementById('othertax_amt5_' + index).value = 0;
									document.getElementById( 'o_tax_amt5_' + index ).value = 0;
									document.getElementById( 'o_tax_type5_' + index ).value = 0;
									
									if(response[0]['pr_code'] != ''){
									var prdct_code = response[ 0 ][ 'pr_code' ];
									var prdct_name = response[ 0 ][ 'pr_name' ];
									var prdct_price = response[ 0 ][ 'pr_saleprice' ];
									var units = response[ 0 ][ 'pr_unit' ];
									var pr_hsn = response[ 0 ][ 'pr_hsn' ];
									var gst_amt = response[ 0 ][ 'unit_gst_amt' ];
									var sales_tax = response[ 0 ][ 'sales_tax' ];
									var mrp = response[ 0 ][ 'unit_price' ];
									var pr_barcode = response[ 0 ][ 'pr_barcode' ];
									var sub_cat = response[ 0 ][ 'sub_cat' ];
									var cat_name = response[ 0 ][ 'cat_name' ];
									var tax_type = response[0]['tax_type'];
									document.getElementById( 'o_tax_type1_' + index ).value = tax_type;
									var o_tax_amt = response[0]['o_tax_amt'];
									document.getElementById( 'o_tax_amt1_' + index ).value = o_tax_amt;
									var tax = response[0]['tax_rate'];
									document.getElementById( 'othertax_amt1_' + index ).value = tax;
									document.getElementById( 'subcat_' + index ).value = sub_cat;
									document.getElementById( 'catname_' + index ).value = cat_name;
									document.getElementById( 'brcode_' + index ).value = pr_barcode;
									document.getElementById( 'mrp_' + index ).value = mrp;
									document.getElementById( 'stax_' + index ).value = sales_tax;
									document.getElementById( 'gst_' + index ).value = gst_amt;
									document.getElementById( 'hsn_' + index ).value = pr_hsn;
									document.getElementById( 'code_' + index ).value = prdct_code;
									document.getElementById( 'unitprice_' + index ).value = prdct_price;
									document.getElementById( 'unit_' + index ).value = units;
									document.getElementById( 'qty_' + index ).focus();
									$( '#totalprice' ).val( $( '#totalprice' ).val() - $( '#total_' + index ).val() );
									$( '#tax_tot' ).val( $( '#tax_tot' ).val() - $( '#totalgst_' + index ).val() );
									document.getElementById( 'total_' + index ).value=0;
									document.getElementById( 'qty_' + index ).value=0;
									document.getElementById( 'totalgst_' + index ).value=0;
										}
									if(response[1]['tax_rate'] != ''){
										var other_tax1 = response[1]['tax_rate'];
										document.getElementById('othertax_amt2_' + index).value = other_tax1;
										var o_tax_amt2 = response[1]['o_tax_amt'];
										document.getElementById( 'o_tax_amt2_' + index ).value = o_tax_amt2;
										var tax_type2 = response[1]['tax_type'];
										document.getElementById( 'o_tax_type2_' + index ).value = tax_type2;
									}
									if(response[2]['tax_rate'] !=''){
										var other_tax2 = response[2]['tax_rate'];
										document.getElementById('othertax_amt3_' + index).value = other_tax2;
										var o_tax_amt3 = response[2]['o_tax_amt'];
										document.getElementById( 'o_tax_amt3_' + index ).value = o_tax_amt3;
										var tax_type3 = response[2]['tax_type'];
										document.getElementById( 'o_tax_type3_' + index ).value = tax_type3;
									} 
									if(response[3]['tax_rate'] !=''){
										var other_tax3 = response[3]['tax_rate'];
										document.getElementById('othertax_amt4_' + index).value = other_tax3;
										var o_tax_amt4 = response[3]['o_tax_amt'];
										document.getElementById( 'o_tax_amt4_' + index ).value = o_tax_amt4;
										var tax_type4 = response[3]['tax_type'];
										document.getElementById( 'o_tax_type4_' + index ).value = tax_type4;
									} 
									if(response[4]['tax_rate'] !=''){
										var other_tax4 = response[4]['tax_rate'];
										document.getElementById('othertax_amt5_' + index).value = other_tax4;
										var o_tax_amt5 = response[4]['o_tax_amt'];
										document.getElementById( 'o_tax_amt5_' + index ).value = o_tax_amt5;
										var tax_type5 = response[4]['tax_type'];
										document.getElementById( 'o_tax_type5_' + index ).value = tax_type5;
									} 
									
									$( '#cesstotal' ).val( $( '#cesstotal' ).val() - ($( '#o_tax_total1_' + index ).val() + $( '#o_tax_total2_' + index ).val() + $( '#o_tax_total3_' + index ).val()+ $( '#o_tax_total4_' + index ).val() + $( '#o_tax_total5_' + index ).val()));
									document.getElementById( 'o_tax_total1_' + index ).value=0;
									document.getElementById( 'o_tax_total2_' + index ).value=0;
									document.getElementById( 'o_tax_total3_' + index ).value=0;
									document.getElementById( 'o_tax_total4_' + index ).value=0;
									document.getElementById( 'o_tax_total5_' + index ).value=0;
								}

							}
						} );
						return false;
					}
				} );


				
				
$(".qty,.unitprice").keyup(function () {
  $('#total_' + index ).val($('#unitprice_'  + index).val() * $('#qty_'  + index).val());
  	$( '#totalgst_' + index ).val( $( '#gst_' + index ).val() * $( '#qty_' + index ).val() );
	$( '#o_tax_total1_' + index ).val( $( '#o_tax_amt1_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total2_' + index ).val( $( '#o_tax_amt2_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total3_' + index ).val( $( '#o_tax_amt3_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total4_' + index ).val( $( '#o_tax_amt4_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total5_' + index ).val( $( '#o_tax_amt5_' + index ).val() * $( '#qty_' + index ).val() );
					
					/*product other tax total*/
					$( '#totalgstcess_' + index ).val(  parseFloat($( '#o_tax_total1_' + index ).val()) +  parseFloat($( '#o_tax_total2_' + index ).val()) +  parseFloat($( '#o_tax_total3_' + index ).val()) +  parseFloat($( '#o_tax_total4_' + index ).val()) +  parseFloat($( '#o_tax_total5_' + index ).val()) );
	$( '#net_tax_' + index ).val(  parseInt($( '#totalgstcess_' + index ).val()) + parseInt($( '#totalgst_' + index ).val()) );
					$( '#base_amount_' + index ).val( $( '#total_' + index ).val() - $( '#net_tax_' + index ).val() );

	
  /*net sum */
  var sum = 0; var qtysum=0; var taxtot= 0; var cesstot=0;
		//iterate through each textboxes and add the values
		$(".total").each(function() {

			//add only if the value is number
			if(!isNaN(this.value) && this.value.length!=0) {
				sum += parseFloat(this.value);
			}
 
		}); 
		//.toFixed() method will roundoff the final sum to 2 decimal places
		document.getElementById('totalprice').value =  Math.round(sum);
		/*qty sum*/
		$(".qty").each(function() {
			if(!isNaN(this.value) && this.value.length!=0) {
				qtysum += parseFloat(this.value);
			}
		}); 
		document.getElementById('totalqty').value =  Math.round(qtysum);
		/* tax total*/
					$( ".totalgst" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							taxtot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'tax_tot' ).value = Math.round( taxtot );
					/* other tax total*/
					$( ".totalgstcess" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							cesstot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'cesstotal' ).value = Math.round( cesstot );
		/*net total*/
		var totalpri = document.getElementById("totalprice").value;
    var discount = document.getElementById("discount").value;
    var gtotal = parseInt(totalpri) - parseInt(discount);
	document.getElementById('gtotalprice').value =  Math.round(gtotal);
	
 });


			} );
			/* net tot with desc */
			$(".discount").keyup(function () {
				var totalpri = document.getElementById("totalprice").value;
    var discount = document.getElementById("discount").value;
    var gtotal = parseInt(totalpri) - parseInt(discount);
	document.getElementById('gtotalprice').value =  Math.round(gtotal);
				
			});
			/*balance amount*/
			$(".paidamount").keyup(function () {
				var paidamount = document.getElementById("paidamount").value;
    var gtotalprice = document.getElementById("gtotalprice").value;
    var balance = parseInt(paidamount) - parseInt(gtotalprice);
	document.getElementById('balance').value =  Math.round(balance);
			});
			$( document ).on( 'keydown', '.brcode', function () {

				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];

				$( '#' + id ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "creation_actions/sales-bill/autosearch_prodct/prdctcode.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 5
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
					select: function ( event, ui ) {
						$( this ).val( ui.item.label ); // display the selected text
						var pr_barcode = ui.item.value; // selected id to input

						// AJAX
						$.ajax( {
							url: 'creation_actions/sales-bill/autosearch_prodct/prdctcode.php',
							type: 'post',
							data: {
								pr_barcode: pr_barcode,
								request: 6
							},
							dataType: 'json',
							success: function ( response ) {

								var len = response.length;

								if ( len > 0 ) {
									document.getElementById('othertax_amt2_' + index).value = 0;
									document.getElementById( 'o_tax_amt2_' + index ).value = 0;
									document.getElementById( 'o_tax_type2_' + index ).value = 0;
									
									document.getElementById('othertax_amt3_' + index).value = 0;
									document.getElementById( 'o_tax_amt3_' + index ).value = 0;
									document.getElementById( 'o_tax_type3_' + index ).value = 0;
									
									document.getElementById('othertax_amt4_' + index).value = 0;
									document.getElementById( 'o_tax_amt4_' + index ).value = 0;
									document.getElementById( 'o_tax_type4_' + index ).value = 0;
									
									document.getElementById('othertax_amt5_' + index).value = 0;
									document.getElementById( 'o_tax_amt5_' + index ).value = 0;
									document.getElementById( 'o_tax_type5_' + index ).value = 0;
									
									if(response[0]['pr_code'] != ''){
									var prdct_code = response[ 0 ][ 'pr_code' ];
									var prdct_name = response[ 0 ][ 'pr_name' ];
									var prdct_price = response[ 0 ][ 'pr_saleprice' ];
									var units = response[ 0 ][ 'pr_unit' ];
									var pr_hsn = response[ 0 ][ 'pr_hsn' ];
									var gst_amt = response[ 0 ][ 'unit_gst_amt' ];
									var sales_tax = response[ 0 ][ 'sales_tax' ];
									var mrp = response[ 0 ][ 'unit_price' ];
									var pr_barcode = response[ 0 ][ 'pr_barcode' ];
									var sub_cat = response[ 0 ][ 'sub_cat' ];
									var cat_name = response[ 0 ][ 'cat_name' ];
									document.getElementById( 'subcat_' + index ).value = sub_cat;
									document.getElementById( 'catname_' + index ).value = cat_name;
									document.getElementById( 'name_' + index ).value = prdct_name;
									document.getElementById( 'mrp_' + index ).value = mrp;
									document.getElementById( 'stax_' + index ).value = sales_tax;
									document.getElementById( 'gst_' + index ).value = gst_amt;
									
									document.getElementById( 'hsn_' + index ).value = pr_hsn;
									document.getElementById( 'code_' + index ).value = prdct_code;
									document.getElementById( 'unitprice_' + index ).value = prdct_price;
									document.getElementById( 'unit_' + index ).value = units;
									document.getElementById( 'qty_' + index ).focus();
									$( '#totalprice' ).val( $( '#totalprice' ).val() - $( '#total_' + index ).val() );
									$( '#tax_tot' ).val( $( '#tax_tot' ).val() - $( '#totalgst_' + index ).val() );
									document.getElementById( 'total_' + index ).value=0;
									document.getElementById( 'qty_' + index ).value=0;
									document.getElementById( 'totalgst_' + index ).value=0;
										}
									if(response[1]['tax_rate'] != ''){
										var other_tax1 = response[1]['tax_rate'];
										document.getElementById('othertax_amt2_' + index).value = other_tax1;
										var o_tax_amt2 = response[1]['o_tax_amt'];
										document.getElementById( 'o_tax_amt2_' + index ).value = o_tax_amt2;
										var tax_type2 = response[1]['tax_type'];
										document.getElementById( 'o_tax_type2_' + index ).value = tax_type2;
									}
									if(response[2]['tax_rate'] !=''){
										var other_tax2 = response[2]['tax_rate'];
										document.getElementById('othertax_amt3_' + index).value = other_tax2;
										var o_tax_amt3 = response[2]['o_tax_amt'];
										document.getElementById( 'o_tax_amt3_' + index ).value = o_tax_amt3;
										var tax_type3 = response[2]['tax_type'];
										document.getElementById( 'o_tax_type3_' + index ).value = tax_type3;
									} 
									if(response[3]['tax_rate'] !=''){
										var other_tax3 = response[3]['tax_rate'];
										document.getElementById('othertax_amt4_' + index).value = other_tax3;
										var o_tax_amt4 = response[3]['o_tax_amt'];
										document.getElementById( 'o_tax_amt4_' + index ).value = o_tax_amt4;
										var tax_type4 = response[3]['tax_type'];
										document.getElementById( 'o_tax_type4_' + index ).value = tax_type4;
									} 
									if(response[4]['tax_rate'] !=''){
										var other_tax4 = response[4]['tax_rate'];
										document.getElementById('othertax_amt5_' + index).value = other_tax4;
										var o_tax_amt5 = response[4]['o_tax_amt'];
										document.getElementById( 'o_tax_amt5_' + index ).value = o_tax_amt5;
										var tax_type5 = response[4]['tax_type'];
										document.getElementById( 'o_tax_type5_' + index ).value = tax_type5;
									} 
									
									$( '#cesstotal' ).val( $( '#cesstotal' ).val() - ($( '#o_tax_total1_' + index ).val() + $( '#o_tax_total2_' + index ).val() + $( '#o_tax_total3_' + index ).val()+ $( '#o_tax_total4_' + index ).val() + $( '#o_tax_total5_' + index ).val()));
									document.getElementById( 'o_tax_total1_' + index ).value=0;
									document.getElementById( 'o_tax_total2_' + index ).value=0;
									document.getElementById( 'o_tax_total3_' + index ).value=0;
									document.getElementById( 'o_tax_total4_' + index ).value=0;
									document.getElementById( 'o_tax_total5_' + index ).value=0;
								}

							}
						} );
						return false;
					}
				} );

				$( ".qty,.unitprice" ).keyup( function () {
        
		 $( '#total_' + index ).val( $( '#unitprice_' + index ).val() * $( '#qty_' + index ).val() );
		 $( '#totalgst_' + index ).val( $( '#gst_' + index ).val() * $( '#qty_' + index ).val() );
		$( '#o_tax_total1_' + index ).val( $( '#o_tax_amt1_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total2_' + index ).val( $( '#o_tax_amt2_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total3_' + index ).val( $( '#o_tax_amt3_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total4_' + index ).val( $( '#o_tax_amt4_' + index ).val() * $( '#qty_' + index ).val() );
					$( '#o_tax_total5_' + index ).val( $( '#o_tax_amt5_' + index ).val() * $( '#qty_' + index ).val() );
					
					/*product other tax total*/
					$( '#totalgstcess_' + index ).val(  parseFloat($( '#o_tax_total1_' + index ).val()) +  parseFloat($( '#o_tax_total2_' + index ).val()) +  parseFloat($( '#o_tax_total3_' + index ).val()) +  parseFloat($( '#o_tax_total4_' + index ).val()) +  parseFloat($( '#o_tax_total5_' + index ).val()) );
					$( '#net_tax_' + index ).val(  parseInt($( '#totalgstcess_' + index ).val()) + parseInt($( '#totalgst_' + index ).val()) );
					$( '#base_amount_' + index ).val( $( '#total_' + index ).val() - $( '#net_tax_' + index ).val() );
					/*net sum */
					var sum = 0;
					var qtysum = 0;  var taxtot= 0;  var cesstot=0;
					//iterate through each textboxes and add the values
					$( ".total" ).each( function () {

						//add only if the value is number
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							sum += parseFloat( this.value );
						}

					} );

					document.getElementById( 'totalprice' ).value = Math.round( sum );
					document.getElementById( 'gtotalprice' ).value = Math.round( sum ); /* net total disc=0*/
					/*qty sum*/
					$( ".qty" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							qtysum += parseFloat( this.value );
						}
					} );
					document.getElementById( 'totalqty' ).value = Math.round( qtysum );
					/* tax total*/
					$( ".totalgst" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							taxtot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'tax_tot' ).value = Math.round( taxtot );
					/* other tax total*/
					$( ".totalgstcess" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							cesstot += parseFloat( this.value );
						}
					} );
					document.getElementById( 'cesstotal' ).value = Math.round( cesstot );
				} );
			} );
			$(window).keydown(function(event){
                if(event.keyCode == 13) {
					
                    event.preventDefault();
                var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				// New index
				var index = Number( split_id[ 1 ] ) + 1;
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text' class='form-control slno' name='slno[]' value=" + index + " id='slno_" + index + "'></td><td><input type='text' class='form-control brcode' name='brcode[]'  id='brcode_" + index + "' placeholder='Barcode'></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder='Product Code'><input type='hidden' class='form-control stock_tkn' name='stock_tkn[]'  id='stock_tkn_" + index + "' ></td><td><input type='text' class='form-control name' name='name[]' id='name_" + index + "' placeholder='Product Name' ></td><td><input type='text'  class='form-control qty' placeholder='Qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text'  class='form-control unit' placeholder='unit' readonly name='unit[]' id='unit_" + index + "' ></td><td><input type='text'  class='form-control stax' name='stax[]' readonly placeholder='Gst %' id='stax_" + index + "' ></td><td style='display:none;'><input type='text'  class='form-control othertax_amt1' name='othertax_amt1[]' readonly id='othertax_amt1_" + index + "'><input type='text'  class='form-control othertax_amt2' name='othertax_amt2[]' readonly id='othertax_amt2_" + index + "'><input type='text'  class='form-control othertax_amt3' name='othertax_amt3[]' readonly id='othertax_amt3_" + index + "'><input type='text'  class='form-control othertax_amt4' name='othertax_amt4[]' readonly id='othertax_amt4_" + index + "'><input type='text'  class='form-control othertax_amt5' name='othertax_amt5[]' readonly id='othertax_amt5_" + index + "'><input type='text'  class='form-control o_tax_amt1' name='o_tax_amt1[]' readonly id='o_tax_amt1_" + index + "'><input type='text'  class='form-control o_tax_amt2' name='o_tax_amt2[]' readonly id='o_tax_amt2_" + index + "'><input type='text'  class='form-control o_tax_amt3' name='o_tax_amt3[]' readonly id='o_tax_amt3_" + index + "'><input type='text'  class='form-control o_tax_amt4' name='o_tax_amt4[]' readonly id='o_tax_amt4_" + index + "'><input type='text'  class='form-control o_tax_amt5' name='o_tax_amt5[]' readonly id='o_tax_amt5_" + index + "'><input type='text'  class='form-control o_tax_type1' name='o_tax_type1[]' readonly id='o_tax_type1_" + index + "'><input type='text'  class='form-control o_tax_type2' name='o_tax_type2[]' readonly id='o_tax_type2_" + index + "'><input type='text'  class='form-control o_tax_type3' name='o_tax_type3[]' readonly id='o_tax_type3_" + index + "'><input type='text'  class='form-control o_tax_type4' name='o_tax_type4[]' readonly id='o_tax_type4_" + index + "'><input type='text'  class='form-control o_tax_type5' name='o_tax_type5[]' readonly id='o_tax_type5_" + index + "'></td><td style='display:none;'><input type='text'  class='form-control gst' name='gst[]' readonly placeholder='Gst Rate' id='gst_" + index + "' ></td><td><input type='text' class='form-control  unitprice' placeholder='unit Price' name='unitprice[]' id='unitprice_" + index + "' ></td><td><input type='text'  class='form-control totalgst' name='totalgst[]' readonly placeholder='Gst Amount' id='totalgst_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total1[]' readonly placeholder='Other tax Amount' id='o_tax_total1_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total2[]' readonly placeholder='Other tax Amount' id='o_tax_total2_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total3[]' readonly placeholder='Other tax Amount' id='o_tax_total3_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total4[]' readonly placeholder='Other tax Amount' id='o_tax_total4_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total5[]' readonly placeholder='Other tax Amount' id='o_tax_total5_" + index + "' ></td><td><input type='text'  class='form-control totalgstcess' name='totalgstcess[]' readonly placeholder='Other Tax Amount' id='totalgstcess_" + index + "' ></td><td><input type='text'  class='form-control total' name='total[]' readonly placeholder='Total' id='total_" + index + "' ><input type='hidden'  class='form-control base_amount' name='base_amount[]' readonly placeholder='Total' id='base_amount_" + index + "' ></td><td  style='display:none;'><input type='hidden'  class='form-control net_tax' name='net_tax[]' readonly placeholder='Total' id='net_tax_" + index + "' ><input type='text'  class='form-control hsn' name='hsn[]' readonly placeholder='HSN' id='hsn_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control mrp' name='mrp[]' readonly placeholder='mrp' id='mrp_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control catname' name='catname[]' readonly placeholder='catname' id='catname_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control subcat' name='subcat[]' readonly placeholder='subcat' id='subcat_" + index + "' ></td><td><input type='button' id='delete_" + index + "' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
				// Append data
				
				$( '#hello' ).append( html );
				
    }
	$('#brcode_' + index).focus();
});
			
			// Add more
			$( '#addmore' ).click( function () {
				// Get last id 
				var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				// New index
				var index = Number( split_id[ 1 ] ) + 1;
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text' class='form-control slno' name='slno[]' value=" + index + " id='slno_" + index + "'></td><td><input type='text' class='form-control brcode' name='brcode[]'  id='brcode_" + index + "' placeholder='Barcode'></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder='Product Code'><input type='hidden' class='form-control stock_tkn' name='stock_tkn[]'  id='stock_tkn_" + index + "' ></td><td><input type='text' class='form-control name' name='name[]' id='name_" + index + "' placeholder='Product Name' ></td><td><input type='text'  class='form-control qty' placeholder='Qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text'  class='form-control unit' placeholder='unit' readonly name='unit[]' id='unit_" + index + "' ></td><td><input type='text'  class='form-control stax' name='stax[]' readonly placeholder='Gst %' id='stax_" + index + "' ></td><td style='display:none;'><input type='text'  class='form-control othertax_amt1' name='othertax_amt1[]' readonly id='othertax_amt1_" + index + "'><input type='text'  class='form-control othertax_amt2' name='othertax_amt2[]' readonly id='othertax_amt2_" + index + "'><input type='text'  class='form-control othertax_amt3' name='othertax_amt3[]' readonly id='othertax_amt3_" + index + "'><input type='text'  class='form-control othertax_amt4' name='othertax_amt4[]' readonly id='othertax_amt4_" + index + "'><input type='text'  class='form-control othertax_amt5' name='othertax_amt5[]' readonly id='othertax_amt5_" + index + "'><input type='text'  class='form-control o_tax_amt1' name='o_tax_amt1[]' readonly id='o_tax_amt1_" + index + "'><input type='text'  class='form-control o_tax_amt2' name='o_tax_amt2[]' readonly id='o_tax_amt2_" + index + "'><input type='text'  class='form-control o_tax_amt3' name='o_tax_amt3[]' readonly id='o_tax_amt3_" + index + "'><input type='text'  class='form-control o_tax_amt4' name='o_tax_amt4[]' readonly id='o_tax_amt4_" + index + "'><input type='text'  class='form-control o_tax_amt5' name='o_tax_amt5[]' readonly id='o_tax_amt5_" + index + "'><input type='text'  class='form-control o_tax_type1' name='o_tax_type1[]' readonly id='o_tax_type1_" + index + "'><input type='text'  class='form-control o_tax_type2' name='o_tax_type2[]' readonly id='o_tax_type2_" + index + "'><input type='text'  class='form-control o_tax_type3' name='o_tax_type3[]' readonly id='o_tax_type3_" + index + "'><input type='text'  class='form-control o_tax_type4' name='o_tax_type4[]' readonly id='o_tax_type4_" + index + "'><input type='text'  class='form-control o_tax_type5' name='o_tax_type5[]' readonly id='o_tax_type5_" + index + "'></td><td style='display:none;'><input type='text'  class='form-control gst' name='gst[]' readonly placeholder='Gst Rate' id='gst_" + index + "' ></td><td><input type='text' class='form-control  unitprice' placeholder='unit Price' name='unitprice[]' id='unitprice_" + index + "' ></td><td><input type='text'  class='form-control totalgst' name='totalgst[]' readonly placeholder='Gst Amount' id='totalgst_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total1[]' readonly placeholder='Other tax Amount' id='o_tax_total1_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total2[]' readonly placeholder='Other tax Amount' id='o_tax_total2_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total3[]' readonly placeholder='Other tax Amount' id='o_tax_total3_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total4[]' readonly placeholder='Other tax Amount' id='o_tax_total4_" + index + "' ><input type='hidden'  class='form-control o_tax_total' name='o_tax_total5[]' readonly placeholder='Other tax Amount' id='o_tax_total5_" + index + "' ></td><td><input type='text'  class='form-control totalgstcess' name='totalgstcess[]' readonly placeholder='Other Tax Amount' id='totalgstcess_" + index + "' ></td><td><input type='text'  class='form-control total' name='total[]' readonly placeholder='Total' id='total_" + index + "' ><input type='hidden'  class='form-control base_amount' name='base_amount[]' readonly placeholder='Total' id='base_amount_" + index + "' ></td><td  style='display:none;'><input type='hidden'  class='form-control net_tax' name='net_tax[]' readonly placeholder='Total' id='net_tax_" + index + "' ><input type='text'  class='form-control hsn' name='hsn[]' readonly placeholder='HSN' id='hsn_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control mrp' name='mrp[]' readonly placeholder='mrp' id='mrp_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control catname' name='catname[]' readonly placeholder='catname' id='catname_" + index + "' ></td><td  style='display:none;'><input type='text'  class='form-control subcat' name='subcat[]' readonly placeholder='subcat' id='subcat_" + index + "' ></td><td><input type='button' id='delete_" + index + "' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
				// Append data
				
				$( '#hello' ).append( html ); $('#brcode_' + index).focus();
			} );
			
			$(document).on('click', '.delete', function(){
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
			$( '#totalprice' ).val( $( '#totalprice' ).val() - $( '#total_' + index ).val() );
			$( '#tax_tot' ).val( $( '#tax_tot' ).val() - $( '#totalgst_' + index ).val() );
			$( '#cesstotal' ).val( $( '#cesstotal' ).val() - $( '#totalgstcess_' + index ).val() );
			 
          $(this).closest('tr').remove();
          });
			$('#insert_form').on('submit', function(event){
  event.preventDefault();
  var error = '';
	
  $('.code').each(function(){
   var count = 1;
   if ( $( this ).val() == '' ) {
						
						$.toast( {
						heading: 'Enter Item Code.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
					} );
				    error += "<p>Enter Item Code at " + count + " Row</p>";
						return false;
					}
   count = count + 1;
  });
  
  $('.name').each(function(){
   var count = 1;
   if ( $( this ).val() == '' ) {
						
						$.toast( {
						heading: 'Enter Item Name.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
					} );
				    error += "<p>Enter Item Name at " + count + " Row</p>";
						return false;
					}
   count = count + 1;
  });
  
  
  $('.qty').each(function(){
   var count = 1;
  if ( parseInt($( this ).val()) == '' ) {
						
						$.toast( {
						heading: 'Enter Item Quantity.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
					} );
				    error += "<p>Enter Item Quantity at " + count + " Row</p>";
						return false;
					}
   count = count + 1;
  });
  $('.paidamount').each(function(){
   var count = 1;
   if ( $( this ).val() == '' ) {
						
						$.toast( {
						heading: 'Enter Paid Amount.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
					} );
				    error += "<p>Enter Item Name at " + count + " Row</p>";
						return false;
					}
   count = count + 1;
  });
  var form_data = $(this).serialize();
  if(error == '')
  {
	  $( "#cus_tkn" ).show();
   $.ajax({
    url:"creation_actions/sales-bill/pointsales_bill_prdct.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
		 $("#respond").html(data);
    
    }
   });
   $( "#cus_tkn" ).show();
  }
  else
  {
 
  }
 });
 
 
		} );
		
	</script> 
<script type="text/javascript">
$(document).ready(function()
{
	$('#cus_tkn').change(function()
	{
		var cus_tkn = $("#cus_tkn").val();	
			$.ajax({				
				type:'POST',
				url:'creation_actions/customer-fetch/customer_fetch.php',
				data:'cus_tkn='+cus_tkn,	
				dataType:"JSON",			
				success:function(data)
				{
					
				   $('#contact_no1').val(data.contact_no1);   
				  
				     $('#cus_name').val(data.cus_name);
				 
				}				
			}); 						
	});			
});

</script>
<div class="right-sidebar">
  <div class="slimscrollright">
    <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
    <div class="r-panel-body">
      <ul id="themecolors" class="m-t-20">
        <li><b>With Light sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
        <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
        <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
        <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
        <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
        <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
      </ul>
      
    </div>
  </div>
</div>
</div>

</div>
</div>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 
<script src="assets/plugins/tiny-editable/numeric-input-example.js"></script> 
<?php include ('include/disable_fn.php'); ?>
<script>
		$(document).ready(function(){
  $("#contact_no1").hide();
  $("#formButton").click(function(){
	  if ($(this).is(":checked")) {
	  $("#contact_no1").show();}else { $("#contact_no1").hide();}
  });
});
  $(document).keyup(function(e){
   if(e.keyCode === 115){
      $("#cbutton").click();
   }
});	

		$( function () {

					// For select 2
					$( ".select2" ).select2();
					$( '.selectpicker' ).selectpicker();


					$( ".ajax" ).select2( {
						ajax: {
							url: "https://api.github.com/search/repositories",
							dataType: 'json',
							delay: 250,
							data: function ( params ) {
								return {
									q: params.term, // search term
									page: params.page
								};
							},
							processResults: function ( data, params ) {
								// parse the results into the format expected by Select2
								// since we are using custom formatting functions we do not need to
								// alter the remote JSON data, except to indicate that infinite
								// scrolling can be used
								params.page = params.page || 1;
								return {
									results: data.items,
									pagination: {
										more: ( params.page * 30 ) < data.total_count
									}
								};
							},
							cache: true
						},
						escapeMarkup: function ( markup ) {
							return markup;
						}, // let our custom formatter work
						minimumInputLength: 1,
						//templateResult: formatRepo, // omitted for brevity, see the source of this page
						//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
					} );
				} );

    </script> 
<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
		<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>

</body>
</html>