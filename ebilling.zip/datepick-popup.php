<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");

$result_trading2 = $db->prepare("SELECT * FROM  date_mask WHERE company_tkn='$user_company' AND addby = '$userid' ORDER BY id DESC LIMIT 1");
$result_trading2 ->execute(); 
$rows_trading2  = $result_trading2->fetch(); 
$selected=$rows_trading2['dateformate'];
?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
</style>
<div class="col-xs-12 no-padding" style="width:300px; overflow: hidden;">
  <h3 class="text-center">Date Mask</h3>
  <form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
    <div class="form-row">
      <div class="col-md-12 col-sm-6 col-xs-12  mb-3">
        <label for="" class="control-label">Choose Type </label>
        <select class="form-control" id="dateformate" name="dateformate" style="width: 100%; height:36px;">
			<option value=""><?php if($selected =='datechoos'){ echo 'Date Picker'; }else if($selected =='datemask'){ echo 'Date Mask'; }else if($selected == 'sematic'){ echo 'Sematic'; } ?></option>
          <?php if($selected !='datechoos'){ ?><option value="datechoos">Date Picker</option><?php } ?>
           <?php if($selected !='datemask'){ ?><option value="datemask">Date Mask</option><?php } ?>
			
        </select>
      </div>
      <input type="hidden" class="form-control datetym"  id="datetym" name="datetym"  value="<?php echo $current_date_time;?>" readonly>
      <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
		<input type="hidden" class="form-control"  id="company" name="company" value="<?php echo $user_company;?>" readonly>
    </div>
    <div class="text-right" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
      <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right">CANCEL</button>
    </div>
  </form>
</div>
<script>
					  $( '#close_fbx' ).on( 'click', function () {
		           parent.jQuery.fancybox.close();
	                 } );
          function save_user(){
			var dateformate = $("#dateformate").val();
			var addby = $("#addby").val();
			  var company = $("#company").val();
			var datetym = $("#datetym").val();
			 if($("#dateformate").val() == ""){$.toast( {heading: ' Select Date  Formate.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1200} );
			} else {
				$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/date-mask/date_mask.php',
					data: "dateformate="+ dateformate + "&addby=" + addby + "&datetym=" + datetym  + "&company=" + company,
					success : function(r) {						
						$("#respond").html(r);
					}
				});
				parent.jQuery.fancybox.close();
				//setTimeout(function(){ window.location.reload(1);}, 1500);
				
												$.toast( {
													heading: 'Updated.',
													text: 'Date Picker Changed Succeccfully.',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1000
												} );
				return false;
		  }} 
</script>