<?php
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$sbill_no=$_GET[ 'bill' ];
 include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');

$result_user_company = $db->prepare("SELECT * FROM company WHERE c_token = '$user_company'");
$result_user_company->execute();	
$rows_user_company = $result_user_company->fetch(); 
$logo=$rows_user_company['c_logo'];
$previous = "javascript:history.go(-1)";
if ( isset( $_SERVER[ 'HTTP_REFERER' ] ) ) {
	$previous = $_SERVER[ 'HTTP_REFERER' ];
}
?>
<html>
<title>Sales Return Bill Print</title>
<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="js/auto_js/jquery-3.2.1.min.js"></script>
<link href="css/style.css" rel="stylesheet">
<style>
table td {
	height: 15px;
}
 @media print {
.btn {
	display: none;
}
}
.hr {
	border: none;
	border-top: 1px solid black;
	margin-top:10px;
}
</style>
<?php include("include/print_size.php");?>
</head>
<body>
<div class="col-md-12" style="margin-top: 18px;">
		<a href="<?php echo $previous; ?>" </a><button type="button" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:left; margin-right: 25px; margin-top: 10px;"><i class="fa fa-backward"></i> Back</button>
		</a>
		<button type="button" onClick="window.print()" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:right; margin-right: 25px; margin-top: 10px;"><i class="fa fa-print"></i> Print</button>
	</div>
<?php
 $result =$db ->prepare("SELECT * FROM sales_rtn_invoice where bill_no='$sbill_no'");
	
$result->execute();	$row_count =  $result->rowcount();
for($i=0; $rows = $result->fetch(); $i++) {$sales_invno=$rows["sales_invno"]; $sales_invdate=$rows["sales_invdate"]; $sales_rtnno=$rows["sales_rtnno"];  $datetym=$rows["sales_rtndate"]; $cus_name=$rows["custmr_name"];  $tax_tot=$rows["tax_tot"]; $cess_total=$rows["o_tax_total"];}

$result =$db ->prepare("SELECT * FROM sales_invoice where sales_invono='$sales_invno'");
$result->execute();	$row_count =  $result->rowcount();
for($i=0; $rows2 = $result->fetch(); $i++) {$cus_tkn=$rows2["cus_tkn"]; $salesbill_no=$rows2["sbill_no"];}
	$result1 = $db->prepare( "SELECT * FROM customer where acco_tkn='$cus_tkn'" );
	$result1->execute();
	$row_count1 = $result1->rowcount();
?>
<div class="row">
  <div class=" col-xs-12 printwidth" style="padding:0px 50px;">
    <table align="center" class="table-bordered-0" style="line-height: 25px;" width="100%">

				<thead>
					<br>
					<tr class="m-t-10">

						<th colspan="8">
							
							<strong style="font-size: 20px; margin-top: 10px;">
								<?php echo $rows_user_company['c_company_name']; ?>
							</strong>
							<b style="float: right">GSTIN : <?php echo $rows_user_company['c_gst']; ?></b>
							<br>
							<?php echo $rows_user_company['c_shopaddress']; ?><br> Ph:
							<?php echo $rows_user_company['c_phone']; ?>, Mob:
							<?php echo $rows_user_company['c_mobile']; ?><br> Email :
							<?php echo $rows_user_company['c_email']; ?><br>
							
							<u style="text-align: center; margin-left:355px; font-size:18px"><strong>TAX INVOICE</strong></u>
						</th>
					</tr>
				</thead>
				<!--<img src="assets/images/company_logo/<?php echo $rows_user_company['c_logo']; ?>" style="font-size: 25px; width: 12px;" alt="user">-->
				<?php
				$result = $db->prepare( "SELECT * FROM customer where acco_tkn='$cus_tkn'" );

				$result->execute();
				$row_count = $result->rowcount();
				$rows = $result->fetch();
				$addres = $rows[ "addres" ];
				$contact_no1 = $rows[ "contact_no1" ];
				?>
				<tr>
					<td colspan="4" style="width:50%;"><b>To, <br></b>
						<?php echo ucfirst($cus_name);?><br>
						<?php echo ucfirst($addres);?><br>
						<?php echo $contact_no1;?>
					</td>
					<td colspan="4" align="right" ><strong style="margin-right: 14px;">Bill No : <?php echo strtoupper($sbill_no);?></strong><br>
						Date : <?php echo $datetym;?>
					</td>
				</tr>
				<tr>
					<?php 
           			if (!empty($order_no)) {?>
					<?php
					$result = $db->prepare( "SELECT * FROM sales_order_invoice where order_invno='$order_no'" );
					$result->execute();
					$row_count = $result->rowcount();
					for ( $i = 0; $rows3 = $result->fetch(); $i++ ) {
						$orderbill_no = $rows3[ "bill_no" ];
					}
					?>
					<th>Sales Order No:</th>
					<td>
						<?php echo strtoupper($orderbill_no);?>
					</td>
					<?php } else {?>
					<td style="display:none;">Sales Order No:
						<?php echo $orderbill_no;?> </td>
					<?php }?>
				</tr>

				<?php if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
				<tr>
					<td colspan="8" class="border-bottom"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom" >
					<td rowspan="2" width="10%" style="text-align:left !important;">Sl</td>
					<th rowspan="2" width="30%" style="text-align:left !important;">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">O.Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody >
        		<?php 
				$qty_tot = 0;
				$result= $db->prepare("SELECT * FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
				
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result1->execute();
				$rows1= $result1->fetch(); 	
					
				$prdct_tkn = $rows['prdct_tkn'];
				$qty = $rows['rtn_qty'];
				$qty_tot += $rows['rtn_qty'];
				$rate = $rows['rtn_rate'];
				$sales_tax = $rows['sales_tax'];
				$gst_amt = $rows1['gst_amt'];
				$pr_hsn = $rows['pr_hsn'];
				$mrp = $rows['mrp'];
				$prdct_name = $rows['prdct_name'];
				$amount = $rows['rtn_amt'];
				$grand_tot = $rows['rtn_grand_tot'];
				$units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_rtn_otax_detail where prdct_tkn='$prdct_tkn' AND sales_rtnno ='$sales_rtnno'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr class="border-bottom">
		  <td><?php echo $e+1; ?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?> -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax;?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong style="margin-right: 5px;">
								<?php echo  $grand_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong style="margin-right: 5px;">
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php } ?>
						</td>
					</tr>
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($grand_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $grand_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>
        
			 <tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr>
						<td align="right" colspan="4" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" width="33%">Sgst</td>
						<td align="center" colspan="2" width="33%">Cgst</td>
					</tr>
			  <?php
					$total_gst_amt= $taxable1=0;
					$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(rtn_amt) AS amount FROM sales_rtn_prdct_details where  sales_rtnno ='$sales_rtnno' GROUP BY sales_tax" );
					$resultret->execute();
					for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
						$gstsum = $rowret[ 'gst_amt' ];
						$taxable = $rowret[ 'amount' ];
						$taxable1 += $rowret[ 'amount' ];
						$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $taxable1; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
 
       <?php 
    if ( $cess_total!=0) { ?>
    
	
	<?php
	         $result= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_rtn_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(rtn_qty), 0) AS amount FROM sales_rtn_prdct_details where prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			<tr>
				<td colspan="8"><strong style="float: left;">Other Tax Included</strong> </td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
			  <?php  }  } ?> 
					<tr class="border-bottom">

						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
					<tr class="border-bottom">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($cus_name); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr>

				</tbody>

			</table>
	
<?php } else if( $printer_width == 'b7' || $printer_width == '80mm' || $printer_width == 'a7'  || $printer_width == 'b8') { ?>

    <tr>
					<td colspan="8" class="border-bottom"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom" >
					<td rowspan="2" width="10%" style="text-align:left !important;">Sl</td>
					<th rowspan="2" width="30%" style="text-align:left !important;">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">O.Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody >
        		<?php 
				$qty_tot = 0;
				$result= $db->prepare("SELECT * FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
				
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result1->execute();
				$rows1= $result1->fetch(); 	
					
				$prdct_tkn = $rows['prdct_tkn'];
				$qty = $rows['rtn_qty'];
				$qty_tot += $rows['rtn_qty'];
				$rate = $rows['rtn_rate'];
				$sales_tax = $rows['sales_tax'];
				$gst_amt = $rows1['gst_amt'];
				$pr_hsn = $rows['pr_hsn'];
				$mrp = $rows['mrp'];
				$prdct_name = $rows['prdct_name'];
				$amount = $rows['rtn_amt'];
				$grand_tot = $rows['rtn_grand_tot'];
				$units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_rtn_otax_detail where prdct_tkn='$prdct_tkn' AND sales_rtnno ='$sales_rtnno'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr class="border-bottom">
		  <td><?php echo $e+1; ?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?> -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax;?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong style="margin-right: 5px;">
								<?php echo  $grand_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong style="margin-right: 5px;">
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php } ?>
						</td>
					</tr>
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($grand_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $grand_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>
        
			 <tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr>
						<td align="right" colspan="4" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" width="33%">Sgst</td>
						<td align="center" colspan="2" width="33%">Cgst</td>
					</tr>
			  <?php
					$total_gst_amt= $taxable1=0;
					$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(rtn_amt) AS amount FROM sales_rtn_prdct_details where  sales_rtnno ='$sales_rtnno' GROUP BY sales_tax" );
					$resultret->execute();
					for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
						$gstsum = $rowret[ 'gst_amt' ];
						$taxable = $rowret[ 'amount' ];
						$taxable1 += $rowret[ 'amount' ];
						$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $taxable1; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
 
       <?php 
    if ( $cess_total!=0) { ?>
    
	
	<?php
	         $result= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_rtn_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(rtn_qty), 0) AS amount FROM sales_rtn_prdct_details where prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			<tr>
				<td colspan="8"><strong style="float: left;">Other Tax Included</strong> </td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
			  <?php  }  } ?> 
					<tr class="border-bottom">

						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
					<tr class="border-bottom">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($cus_name); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr>

				</tbody>

			</table>
  <?php } else if ( $printer_width == 'a8' || $printer_width == 'b9') { ?>
  <tr>
					<td colspan="8" class="border-bottom"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom" >
					<td rowspan="2" width="10%" style="text-align:left !important;">Sl</td>
					<th rowspan="2" width="30%" style="text-align:left !important;">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">O.Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody >
        		<?php 
				$qty_tot = 0;
				$result= $db->prepare("SELECT * FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
				
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result1->execute();
				$rows1= $result1->fetch(); 	
					
				$prdct_tkn = $rows['prdct_tkn'];
				$qty = $rows['rtn_qty'];
				$qty_tot += $rows['rtn_qty'];
				$rate = $rows['rtn_rate'];
				$sales_tax = $rows['sales_tax'];
				$gst_amt = $rows1['gst_amt'];
				$pr_hsn = $rows['pr_hsn'];
				$mrp = $rows['mrp'];
				$prdct_name = $rows['prdct_name'];
				$amount = $rows['rtn_amt'];
				$grand_tot = $rows['rtn_grand_tot'];
				$units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_rtn_otax_detail where prdct_tkn='$prdct_tkn' AND sales_rtnno ='$sales_rtnno'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr class="border-bottom">
		  <td><?php echo $e+1; ?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?> -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax;?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong style="margin-right: 5px;">
								<?php echo  $grand_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong style="margin-right: 5px;">
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php } ?>
						</td>
					</tr>
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($grand_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $grand_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>
        
			 <tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr>
						<td align="right" colspan="4" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" width="33%">Sgst</td>
						<td align="center" colspan="2" width="33%">Cgst</td>
					</tr>
			  <?php
					$total_gst_amt= $taxable1=0;
					$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(rtn_amt) AS amount FROM sales_rtn_prdct_details where  sales_rtnno ='$sales_rtnno' GROUP BY sales_tax" );
					$resultret->execute();
					for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
						$gstsum = $rowret[ 'gst_amt' ];
						$taxable = $rowret[ 'amount' ];
						$taxable1 += $rowret[ 'amount' ];
						$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $taxable1; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
 
       <?php 
    if ( $cess_total!=0) { ?>
    
	
	<?php
	         $result= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_rtn_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(rtn_qty), 0) AS amount FROM sales_rtn_prdct_details where prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			<tr>
				<td colspan="8"><strong style="float: left;">Other Tax Included</strong> </td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
			  <?php  }  } ?> 
					<tr class="border-bottom">

						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
					<tr class="border-bottom">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($cus_name); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr>

				</tbody>

			</table>
  <?php } else { ?>
  <tr>
					<td colspan="8" class="border-bottom"></td>
				</tr>
				<tr style="text-align:center;" class="border-bottom" >
					<td rowspan="2" width="10%" style="text-align:left !important;">Sl</td>
					<th rowspan="2" width="30%" style="text-align:left !important;">Item Description</th>
					<th rowspan="2" width="10%"> Qty</th>
					<th rowspan="2" width="10%"> Rate</th>
					<th rowspan="2" width="10%">Mrp</th>
					<th rowspan="2" width="10%">Gst%</th>
					<th rowspan="2" width="10%">O.Tax%</th>
					<th rowspan="2" width="10%"> Amount</th>
				</tr>
				<tbody >
        		<?php 
				$qty_tot = 0;
				$result= $db->prepare("SELECT * FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result->execute();
				for($e=0; $rows= $result->fetch(); $e++){
				
				$result1= $db->prepare("SELECT SUM(gst_amt) AS gst_amt, SUM(o_tax_amt) AS o_tax_amt FROM sales_rtn_prdct_details where sales_rtnno ='$sales_rtnno'");
				$result1->execute();
				$rows1= $result1->fetch(); 	
					
				$prdct_tkn = $rows['prdct_tkn'];
				$qty = $rows['rtn_qty'];
				$qty_tot += $rows['rtn_qty'];
				$rate = $rows['rtn_rate'];
				$sales_tax = $rows['sales_tax'];
				$gst_amt = $rows1['gst_amt'];
				$pr_hsn = $rows['pr_hsn'];
				$mrp = $rows['mrp'];
				$prdct_name = $rows['prdct_name'];
				$amount = $rows['rtn_amt'];
				$grand_tot = $rows['rtn_grand_tot'];
				$units = $rows['units'];
				$gstcess_amt = $rows1['o_tax_amt'];
			    $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_rtn_otax_detail where prdct_tkn='$prdct_tkn' AND sales_rtnno ='$sales_rtnno'");
			    $resulotax->execute();
			    for($i=0; $rowotax = $resulotax->fetch(); $i++){  
			    $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr class="border-bottom">
		  <td><?php echo $e+1; ?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?> -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $mrp;?></td>
          <td align="center"><?php echo $sales_tax;?></td>
		  <td align="center"><?php echo $otaxrate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    					<tr class="border-bottom">
						<td colspan="2" align="right" class="border-right-0" ><strong>Total</strong></td>
						<td  align="center"><strong>
								<?php echo  $qty_tot;?>
							</strong></td>
						<td></td>
						<td></td>
						<td colspan="3" align="right">
							<strong style="margin-right: 5px;">
								<?php echo  $grand_tot;?>
							</strong><br>
							<?php if ( $tax_tot!=0) { ?> (+) GST/Tax :
							<strong style="margin-right: 5px;">
								<?php echo $gst_amt + $gstcess_amt; ?>
							</strong>
							<?php } ?>
						</td>
					</tr>
					<tr class="border-bottom">
						<td colspan="6">
							<?php echo convertToIndianCurrency($grand_tot + $gst_amt + $gstcess_amt); ?>
						</td>
						<td colspan="2"><b style="float: left">Gr.Total</b>
							<strong style="font-size: 16px; float: right;">
								<?php echo  $grand_tot + $gst_amt + $gstcess_amt;?>
							</strong>
						</td>
					</tr>
        
			 <tr>
						<td colspan="8" rowspan="1"></td>
					</tr>
					<tr>
						<td align="right" colspan="4" width="33%">Taxable Amount</td>
						<td align="center" colspan="2" width="33%">Sgst</td>
						<td align="center" colspan="2" width="33%">Cgst</td>
					</tr>
			  <?php
					$total_gst_amt= $taxable1=0;
					$resultret = $db->prepare( "SELECT  SUM(gst_amt) AS gst_amt, SUM(rtn_amt) AS amount FROM sales_rtn_prdct_details where  sales_rtnno ='$sales_rtnno' GROUP BY sales_tax" );
					$resultret->execute();
					for ( $i = 0; $rowret = $resultret->fetch(); $i++ ) {
						$gstsum = $rowret[ 'gst_amt' ];
						$taxable = $rowret[ 'amount' ];
						$taxable1 += $rowret[ 'amount' ];
						$total_gst_amt +=$gstsum/2;
								
							
							?>
					<tr>
						<td align="right" colspan="4" width="33%">
							<strong>
								<?php echo $taxable; ?>
							</strong>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
						<td align="center" colspan="2" width="33%">
							<?php echo $gstsum/2; ?>
						</td>
					</tr>
					<?php }  ?>
					<tr class="border-bottom border-top">
						<td colspan="2" ><strong style="float: right">Total</strong>
						
						</td>
						<td colspan="2">
						<strong style="float: right; ">
								<?php echo $taxable1; ?>
							</strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>

						<td align="center" colspan="2" width="33%">
							<strong><?php echo $total_gst_amt; ?></strong>
						</td>
					</tr>
 
       <?php 
    if ( $cess_total!=0) { ?>
    
	
	<?php
	         $result= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' GROUP By o_tax_type");
              $result->execute();
              for($i=0; $rows= $result->fetch(); $i++){ 
			  $o_tax_typeg=$rows['o_tax_type'];
			  
			  $qty_total=0;
			  $result_ptkn= $db->prepare("SELECT * FROM sales_rtn_otax_detail where sales_rtnno ='$sales_rtnno' AND  o_tax_type='$o_tax_typeg' GROUP By prdct_tkn");
              $result_ptkn->execute();
              for($i=0; $rows_ptk= $result_ptkn->fetch(); $i++){ 
			  $prdct_tkns=$rows_ptk['prdct_tkn'];
			  
	          $resultret = $db->prepare("SELECT * FROM sales_rtn_otax_detail  where o_tax_type='$o_tax_typeg' AND prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultret->execute();
			  for($i=0; $rowret = $resultret->fetch(); $i++){  
			  $o_tax_rate=$rowret['o_tax_rate'];  $o_tax_total=$rowret['o_tax_total'];}
			  
			  $resultrets = $db->prepare("SELECT  COALESCE(SUM(rtn_qty), 0) AS amount FROM sales_rtn_prdct_details where prdct_tkn='$prdct_tkns' AND sales_rtnno ='$sales_rtnno'");
			  $resultrets->execute();
			  for($i=0; $rowretss = $resultrets->fetch(); $i++){  
			  $qtysum=$rowretss['amount'];}
              $other_taxtotal = $qtysum *  $o_tax_total;
			  $qty_total = $other_taxtotal + $qty_total;}

			  ?>
			<tr>
				<td colspan="8"><strong style="float: left;">Other Tax Included</strong> </td>
					</tr>
					<tr>
						<td colspan="4" align="center"></td>
						<td colspan="2" align="center">
							<?php echo $o_tax_typeg;?>%</td>
						<td colspan="2" align="center">
							<?php echo $qty_total;?>
						</td>
					</tr>
			  <?php  }  } ?> 
					<tr class="border-bottom">

						<td colspan="8" align="right">We declare that this invoice shows the actual price of the goods described and that all the purticulars are true and correct. </td>
					</tr>
					<tr class="border-bottom">
						<td colspan="4"><b><u>Our Bank details</u></b><br>
							<b>Bank Name :</b>
							<?php echo $rows_user_company['c_bank']; ?><br>
							<b>A/C No    :</b>
							<?php echo $rows_user_company['c_accno']; ?><br>
							<b>IFSC Code :</b>
							<?php echo $rows_user_company['c_ifsc']; ?>&nbsp;&nbsp;&nbsp; <b>Branch :</b>
							<?php echo $rows_user_company['c_branch']; ?><br>
						</td>
						<td colspan="4" align="right">For
							<b>
								<?php echo strtoupper($cus_name); ?>
							</b><br><br><b>Authorised Sign.</b>
						</td>
					</tr>

				</tbody>

			</table>
  <?php } ?>
  </div>
</div>
<?php 
function convertToIndianCurrency($number) {
    $no = round($number);
    $decimal = round($number - ($no = floor($number)), 2) * 100;    
    $digits_length = strlen($no);    
    $i = 0;
    $str = array();
    $words = array(
        0 => '',
        1 => 'One',
        2 => 'Two',
        3 => 'Three',
        4 => 'Four',
        5 => 'Five',
        6 => 'Six',
        7 => 'Seven',
        8 => 'Eight',
        9 => 'Nine',
        10 => 'Ten',
        11 => 'Eleven',
        12 => 'Twelve',
        13 => 'Thirteen',
        14 => 'Fourteen',
        15 => 'Fifteen',
        16 => 'Sixteen',
        17 => 'Seventeen',
        18 => 'Eighteen',
        19 => 'Nineteen',
        20 => 'Twenty',
        30 => 'Thirty',
        40 => 'Forty',
        50 => 'Fifty',
        60 => 'Sixty',
        70 => 'Seventy',
        80 => 'Eighty',
        90 => 'Ninety');
    $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
    while ($i < $digits_length) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
            $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
        } else {
            $str [] = null;
        }  
    }
    
    $Rupees = implode(' ', array_reverse($str));
    $paise = ($decimal) ? "And Paise " . ($words[$decimal - $decimal%10]) ." " .($words[$decimal%10])  : '';
    return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Only";
}

?>
<script>$( document ).ready( function () {

			var headstr = "<html><head><title></title></head><body>";
			var footstr = "</body>";

			var oldstr = document.body.innerHTML;
			document.body.innerHTML = headstr + footstr;
			window.print();
			document.body.innerHTML = oldstr;
			//window.location.href="sales-bill.php";

		} );
		window.onafterprint = function() {
		history.go(-1);
		};</script>
</body>
</html>