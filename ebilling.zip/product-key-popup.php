<?php include('include/today.php'); ?>
<style>
	.not-exists {
		color: #FF4633;
		margin-top: 20px;
	}
	
	.exists {
		color: #34D908;
		margin-top: 20px;
	}
	
	button.mfp-close {
		display: none;
	}
	
	#close_fbx {
		margin: 0px;
		position: relative;
		background: #ef5350 !important;
		color: #fff;
		opacity: 1;
		width: 50px;
		font-size: 13px;
		height: 30px;
		line-height: 0px;
		padding: 0px !important;
		display: inline;
	}
	#close_fbx:hover {
		background: #ef5350 !important;
	}
</style>
<div id="custom-content" class="col-md-4 col-sm-6 col-xs-12" style="margin: 50px auto; width:600px; padding-top:20px; overflow: hidden;  background-color: #f2f2f2;">
	<center>
		<h4 style="padding-bottom: 8px; "> Product Key</h4>
	</center>
	<center>
		<div id="uname_response" class="response"></div>
	</center>
	<div class="form-row">
		<div class="col-md-12  col-sm-6 col-xs-12">
			<div class="form-group row">
				<label for="validationTooltip01" class="control-label  col-12"></label>
				<div class="col-12">
					<input type="text" class="form-control" name="prdct_token" id="prdct_token" placeholder="Enter Product Key">
					<input type="hidden" class="form-control" name="adddate" id="adddate" value='<?php echo $today; ?>'>
					<input type="hidden" class="form-control" name="software_key" id="software_key" >
				</div>
			</div>
		</div>
	</div>
	<div class="text-right" style="margin-bottom: 18px;">
		<div class="text-right"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
	</div>
	</div>	
<script>
	$( document ).ready( function (){
	var request = '1';
	$.ajax({
		type: "POST",
		url: "post_item.php",
		datatype: "json",
		data: {
			request: request
		},
		success: function (data){

			var result = JSON.parse(data);
			var software_key =  result.softwarekey;
			var software_key = $('#software_key').val(result.softwarekey);
			
		}
	});
	});
function save_user(){
	
var prdct_token = $('#prdct_token').val();

		if(prdct_token == ''){
			$.toast({ heading: 'Provide A Product Key.', text: 'Key Is Empty', position: 'top-right', loaderBg: '#F13109', icon: 'error', hideAfter: 1500 });
		}else{
			
		var prdct_token = $('#prdct_token').val();
		var adddate = $('#adddate').val();
		$('#loading-image').show();
			var software_key = $('#software_key').val();
			    //Check software Key From server
				$.ajax({
					type: "POST",
					url: "send_data.php",
					datatype: "json",
					data:{
						prdct_token: prdct_token,software_key: software_key,
					},
					success: function (response){
					var result = JSON.parse(response);
					var software_key = result.software_key;
					var product_key = result.product_key;
					var sw_added = result.sw_added;
					var expairy_date = result.expairy_date;
					var soft_validity = result.soft_validity;
					var total_days_left = result.total_days_left;
					var status = result.status;
					console.log(status);
					var action = '1';
					$('#loading-image').hide();	
						
   					if(status == '1'){
					$('#loading-image').show();
						
			   	//Updating Json File		
			   $.ajax({
					type: "POST",
					url: "update_jason.php",
					datatype: "json",
					data:{
						 software_key: software_key, product_key: product_key, sw_added: sw_added, soft_validity: soft_validity,expairy_date: expairy_date, total_days_left: total_days_left, status: status, action: action,
					},
					success: function (data2){

					}
					});
						
					$('#loading-image').hide();
					location.reload();
					$.toast({heading: 'Product Activated',text: '',position: 'top-right',loaderBg: '#DC3608',icon: 'success',hideAfter: 1600,hideMethod:'fadeOut'});
					$('#wrapper').show();	
						
					}else if(status == '2'){
						
					$.toast({heading: 'Software Not Genuine',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1200});
						
				}else if(status == '3'){
					
					$.toast({heading: 'Invalid Product Key',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1200});
				}
			}
		});
	}
}
</script>