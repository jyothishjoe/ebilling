<?php
$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'supermarket';
$db = new PDO('mysql:host='.$db_host.';dbname='.$db_database, $db_user, $db_pass);
  
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//date
date_default_timezone_set( "Asia/Kolkata" );
$today = date( "Y-m-d");
$month = date( "Y-m" );
$current_date_time = date( "d M Y H:i:s", time() );
$current_time = date( "H:i:s", time() );


if (!empty($_GET[ 'prdct_token' ])){

	$key = $_GET['prdct_token'];
	
	$software_key = $_GET['software_key'];
	
	$results_soft = $db->prepare( "SELECT * FROM  software_info  WHERE  software_key = '$software_key' ");
	$results_soft->execute();
	$rows_soft = $results_soft->fetch();
	$soft_count = $results_soft->rowcount();	
	
	if($soft_count > 0 ){
	
	$total_validity=$rows_soft['soft_validity'];

	$results_user = $db->prepare( "SELECT * FROM  software_info  WHERE  product_key = '$key' AND status='1' " );
	$results_user->execute();
	$rows_user = $results_user->fetch();
	$product_count = $results_user->rowcount();
		
		if($product_count > 0){
		
		$soft_key=$software_key;
		$total_validity=$total_validity;
		
		$date_plus_days = new DateTime($today);
		$date_plus_days->modify( "+$total_validity days");
		$date_of_exp = $date_plus_days->format( "Y-m-d");

		//days_left
		$date1 = date_create($today);
		$date2 = date_create($date_of_exp);
		$diff = date_diff( $date1, $date2);
		$date_diff = $diff->format("%a days Left To Expair");
		
		$response["software_key"] = $soft_key;
		$response["product_key"] = $rows_user['product_key'];
		$response["sw_added"] = $rows_user['sw_added'];
		$response["soft_validity"] = $total_validity;
		$response["expairy_date"] = $date_of_exp;
		$response["total_days_left"] = $date_diff;
		$response["status"] = '1';
	
		$sql = "UPDATE product_info SET  sw_key='$soft_key', validity_days='$date_diff', expairy_date='$date_of_exp',sw_key='$soft_key', sw_added='$current_date_time', status='0'  WHERE product_key='$key' AND status='1'";
		$q1 = $db->prepare( $sql );
		$q1->execute();	
			
			
		echo json_encode($response);
			
		}else{
		$response["status"] = '3';
		echo json_encode($response);
		}
		}else{
		//software not genuie
		$response["status"] = '2';
		echo json_encode($response);
		}
}

?>