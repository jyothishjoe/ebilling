<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<style>

fieldset {
	margin-top:17px;
	border: 1px solid #999;
	font-size:12px;
	padding:0px 10px;
}
legend {
	margin-left:10px;
	width: 95px;
	font-size:12px; padding-left:7px;
}
.container {
	display: inline;
	position: relative;
	padding-left: 20px;
	margin-bottom: 12px;
	cursor: pointer;
	font-size: 12px;
	bottom:5px;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	cursor: pointer;
}
.checkmark {
	position: absolute;
	top: 0;
	left: 0;
	height: 15px;
	width: 15px;
	border:1px solid #666;
	border-radius: 50%;
}
.container input:checked ~ .checkmark {
 background-color: #2196F3;
}
.checkmark:after {
	content: "";
	position: absolute;
	display: none;
}
.container input:checked ~ .checkmark:after {
 display: block;
}
.container .checkmark:after {
	top: 3px;
	left: 3px;
	width: 7px;
	height: 7px;
	border-radius: 50%;
	background: white;
}
</style>
<div class="col-md-12 col-sm-6 col-xs-12" style=" overflow: hidden;">
	<h3 class="text-center">Add Transaction Types</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Transaction Name</label>
				<input type="text" class="form-control" id="trans_name" name="trans_name" value="" placeholder="Transaction Name">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>">
			</div>
			</div>
			<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Transaction Code</label>
				<input type="text" class="form-control" id="trans_code" name="trans_code" value="" placeholder="Transaction Code">
	    	</div>
	    	</div>
	    	<div class="form-row">
	    	 <div class="col-md-12" style="margin-bottom: 18px;">
                    <fieldset>
                      	<legend class="control-label">Attach In</legend>
						
						<label class="container">Journal
						<input type="radio" id="cash" name="type" value="cash">
                        <span class="checkmark"></span></label>
                        <label class="container">Sales
                        <input type="radio" id="sales" name="type" value="sales">
                        <span class="checkmark"></span></label>
                        <label class="container">Purchase
                        <input type="radio" id="purchase" name="type" value="purchase">
                        <span class="checkmark"></span></label>
                    </fieldset>
                  </div>
		</div>
		<div class="text-right" style="margin-bottom: 12px;">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" style="margin-top: 15px;">Save</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger " style="margin-top: 15px;">Cancel</button>
		</div>
	</form>
</div>
	<script>
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		function save_customer() {
            if( $("input[value='cash']:checked").val()){
				 var cash='cash';
			} else {var cash='';}
          
			if( $("input[value='purchase']:checked").val()){
				 var purchase='purchase';
			} else {var purchase='';}
			
			if( $("input[value='sales']:checked").val()){
				 var sales='sales';
			} else {var sales='';}
		
			var trans_name = $("#trans_name").val();
			var trans_code = $("#trans_code").val();
			var userid = $("#userid").val();
			
			
			if ($("#trans_code").val() == ""){
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500} );
			}else{
				$.ajax({
					type: 'POST',
					url: "accounts/tax_type_creation.php",
					data: "trans_name=" + trans_name + "&trans_code=" + trans_code + "&userid=" + userid + "&cash=" + cash  + "&purchase=" + purchase + "&sales=" + sales,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				document.getElementById( "insert_form" ).reset();
				//parent.jQuery.fancybox.close();
				$.toast( {heading: 'Added Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 1500} );
				return false;
			}
		}
	</script>