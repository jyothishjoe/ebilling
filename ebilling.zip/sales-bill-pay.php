<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');
$today_date = date_create($today);
$sales_rtndate=date_format($today_date,"Y-m-d");


$date_set = $today;

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
<title>Cash Counter</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="assets/table/css/jquery-ui.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-3.2.1.min.js"></script>
<script src="js/auto_js/jquery-ui.min.js"></script>
</head>
<style>
.hightset{ height: 200px;}
fieldset{
	margin-top:17px; border: 1px solid #999; font-size:12px; padding:0px 10px;}
</style>
<body class="fix-header fix-sidebar card-no-border" onload='setFocusToTextBox()'>
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h3 class="text-themecolor">Cash Counter</h3>
        </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
            <li class="breadcrumb-item"><a href="cashcounter-home.php">Cash Counter</a></li>
            <li class="breadcrumb-item active">Cash Counter</li>
          </ol>
        </div>
        <div class="">
          
        </div>
      </div>
	   <?php 
		$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
		$results->execute();
		for($i=0; $rowss = $results->fetch(); $i++)
		{ $counter=$rowss['counter']; } 
		$result =$db->prepare("SELECT * FROM  cash_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
		$result->execute();
		$rows=$result->fetch();
		$sbill_no=$rows['b_no'] + 1;
		?>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <form method="post" action="" class="forms" autocomplete="off" name="insert_form" id="insert_form">
                <div class="form-row">
                  <div class="col-md-4 col-sm-6 col-xs-12  mb-1">
                    <div class="row">
                      <div class="col-md-3 col-sm-6 col-xs-12">
                        <label for="" class="control-label">Bill No:</label>
                      </div>
                      <div class="col-md-4 col-sm-6 col-xs-12">
                        <input type="text" class="form-control" id="ebill_no" name="ebill_no" value="<?php echo ucfirst($counter); echo $sbill_no;?>"  readonly>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-xs-12"></div>
                  <div class="col-md-2 col-sm-6 col-xs-6">
                    <input type="date" class="form-control" id="cash_date"  value="<?php echo $date_set;?>"  name="cash_date">
                  </div>
                  <div class="col-md-2 col-sm-6 col-xs-6">
                    <input type="time" class="form-control" id="cash_time" value="<?php echo $current_time;?>" name="cash_time" readonly>
					<input type="hidden" class="form-control"  value="<?php echo $counter;?>" name="counter"  id="counter" readonly>
					<input type="hidden" class="form-control"  value="<?php echo $userid;?>" name="addby"  id="addby" readonly>
					  <input type="hidden" class="form-control"  value="<?php echo $user_company;?>" name="company"  id="company" readonly>
                  </div>
				  <div class="col-md-8">
				  <div class="row">
				  <div class="col-md-6">
				  <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 50px; font-size:18px; padding-left:7px;}
">Sales</legend>
                 <div class="table-responsive col-md-12 col-sm-12 col-xs-12" style="height:140px; overflow-y:auto;">
                    <table border='0' class="table table-bordered  mb-0" id="sales_data">
                      <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>Receipt No</th>
                          <th>Amount</th>
                          <th><input type="button" id="salesaddmore" name="button" class="btn btn-sm btn-info" value="+">
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody id="sales">
                        <tr class='tr_input'>
                          <td width="50"><input type='text' class="form-control aslno" name="aslno[]" id='aslno_1' value="1"></td>
                          <td><input type='text' class="form-control salesreceipt" name="receipt[]" id='salesreceipt_1' placeholder='Receipt No'></td>
                          <td width="120"><input type='text' class="form-control salestotamt" name="totamt[]" id='salestotamt_1' placeholder='Amount'value="0" readonly></td>
						  <td style="display:none;"><input type='text' class="form-control salesbilltype" name="billtype[]" id='salesbilltype_1'  readonly></td>
						  <td style="display:none;"><input type='text' class="form-control salescashtype" name="cashtype[]" id='salescashtype_1'  readonly></td>
                          <td><input type='button' id='adelete_1' name='button' class='btn btn-sm btn-danger adelete' value='x' style="display:none;">
                            </button></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
				<input type="hidden" id="salessum" name="salessum" value="0">
				</fieldset>
				  </div>
				
				  <div class="col-md-6">
				  <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 76px; font-size:18px; padding-left:7px;}
">Estimate</legend>
                 <div class="table-responsive col-md-12 col-sm-12 col-xs-12" style="height:140px; overflow-y:auto;">
                    <table border='0' class="table table-bordered  mb-0" id="sales_data">
                      <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>Receipt No</th>
                          <th>Amount</th>
                          <th><input type="button" id="estimateaddmore" name="button" class="btn btn-sm btn-info" value="+">
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody id="estimate">
                        <tr class='tr_input'>
                          <td width="50"><input type='text' class="form-control bslno" name="bslno[]" id='blno_1' value="1"></td>
                          <td><input type='text' class="form-control estreceipt" name="receipt[]" id='estreceipt_1' placeholder='Receipt No'></td>
                          <td width="120"><input type='text' class="form-control esttotamt" name="totamt[]" id='esttotamt_1' placeholder='Amount' value="0" readonly></td>
						    <td style="display:none;"><input type='text' class="form-control estbilltype" name="billtype[]" id='estbilltype_1'  readonly></td>
							 <td style="display:none;"><input type='text' class="form-control estcashtype" name="cashtype[]" id='estcashtype_1'  readonly></td>
                          <td><input type='button' id='bdelete_1' name='button' class='btn btn-sm btn-danger bdelete' value='x' style="display:none;">
                            </button></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
				<input type="hidden" id="estimatesum" name="estimatesum" value="0">
				</fieldset>
				  </div>
				  
				  <div class="col-md-6">
				  <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 104px; font-size:18px; padding-left:7px;}
">Sales Return</legend>
                 <div class="table-responsive col-md-12 col-sm-12 col-xs-12" style="height:140px; overflow-y:auto;">
                    <table border='0' class="table table-bordered  mb-0" id="sales_ret">
                      <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>Receipt No</th>
                          <th>Amount</th>
                          <th><input type="button" id="salesretaddmore" name="button" class="btn btn-sm btn-info" value="+">
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody id="salesret">
                        <tr class='tr_input'>
                          <td width="50"><input type='text' class="form-control cslno" name="cslno[]" id='cslno_1' value="1"></td>
                          <td><input type='text' class="form-control saretreceipt" name="receipt[]" id='saretreceipt_1' placeholder='Receipt No'></td>
                          <td width="120"><input type='text' class="form-control sarettotamt" name="totamt[]" id='sarettotamt_1' placeholder='Amount' value="0" readonly></td>
						  <td style="display:none;"><input type='text' class="form-control saretbilltype" name="billtype[]" id='saretbilltype_1'  readonly></td>
						  <td style="display:none;"><input type='text' class="form-control saretcashtype" name="cashtype[]" id='saretcashtype_1'  readonly></td>
                          <td><input type='button' id='cdelete_1' name='button' class='btn btn-sm btn-danger cdelete' value='x' style="display:none;">
                            </button></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
				<input type="hidden" id="s_returnsum" name="s_returnsum" value="0">
				</fieldset>
				  </div>
				  <div class="col-md-6">
				  <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 148px; font-size:18px; padding-left:7px;}
">Advanced Receipt</legend>
                 <div class="table-responsive col-md-12 col-sm-12 col-xs-12" style="height:140px; overflow-y:auto;">
                    <table border='0' class="table table-bordered  mb-0" id="sales_data">
                      <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>Receipt No</th>
                          <th>Amount</th>
                          <th><input type="button" id="advanceaddmore" name="button" class="btn btn-sm btn-info" value="+">
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody id="advance">
                        <tr class='tr_input'>
                          <td width="50"><input type='text' class="form-control dslno" name="dslno[]" id='dslno_1' value="1"></td>
                          <td><input type='text' class="form-control advreceipt" name="receipt[]" id='advreceipt_1' placeholder='Receipt No'></td>
                          <td width="120"><input type='text' class="form-control advtotamt" name="totamt[]" id='advtotamt_1' placeholder='Amount' value="0" readonly></td>
						   <td style="display:none;"><input type='text' class="form-control advbilltype" name="billtype[]" id='advbilltype_1'  readonly></td>
						    <td style="display:none;"><input type='text' class="form-control advcashtype" name="cashtype[]" id='advcashtype_1'  readonly></td>
                          <td><input type='button' id='ddelete_1' name='button' class='btn btn-sm btn-danger ddelete' value='x' style="display:none;">
                            </button></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
				<input type="hidden" id="advancesum" name="advancesum" value="0">
				</fieldset>
				  </div>
				 </div></div>
				 <div class="col-md-4">
				 <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 50px; font-size:18px; padding-left:7px;}
">Cash</legend>
				 <div class="row">
				  <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Grand Total</label>
                    <input type="text" class="form-control gradtot" name="gradtot" id="gradtot" value="0" readonly>
                  </div>
				   <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Discount</label>
                    <input type="text" class="form-control discounta" name="discount" id="discounta" style="width:60px; position:relative; flot:left;" placeholder="In Amount" value="0">
					 <input type="text" class="form-control discountp" name="discounta" id="discountp" style="width:50px; position:relative; flot:left; bottom:34px; left:62px;" placeholder="In %" value="0">
                  </div>
				   <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Net Total</label>
                    <input type="text" class="form-control nettot" name="nettot" id="nettot" value="0" readonly>
                  </div>
				    <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Payment Mode</label>
                   <select class="form-control paytype" name="paytype" id="paytype"  onchange='checkvalue(this.value)'>
                            <option value="CASH">Cash</option>
                            <option value="BANK">Card</option>
                   </select>
                  </div>
				   <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Paid Amount</label>
                    <input type="text" class="form-control paidamt" name="paidamt" id="paidamt">
                  </div>
				   <div class="col-md-4 col-sm-6 col-xs-6 mb-1">
                    <label for="" class="control-label">Balance</label>
                    <input type="text" class="form-control balance" name="balance" id="balance" value="0" readonly>
                  </div>

          
          <div class="col-md-4 col-sm-6 col-xs-6 mb-1" id="carddetails1">
                    <label for="" class="control-label">Card No</label>
                    <input type="text" class="form-control cardno" name="cardno" id="cardno" placeholder="Card No">
          </div>
          <div class="col-md-4 col-sm-6 col-xs-6 mb-1" id="carddetails2">
                    <label for="" class="control-label">Bank</label>
                    <input type="text" class="form-control bank" name="bank" id="bank" placeholder="Bank Name">
          </div>
           <div class="col-md-4 col-sm-6 col-xs-6 mb-1" id="carddetails3">
                    <label for="" class="control-label">Expiry</label>
                    <input type="text" class="form-control expiry date-inputmask" name="expiry" id="expiry" placeholder="Expiry Date">
          </div>
         
				   <div class="col-md-12 col-sm-12 col-xs-12 text-right" style="padding:20px 10px;">
				  <input type="submit" name="submit"  class="btn btn-info btn-sm"  value="Save & Print"/>
				  </div>
				  </div>
				  </fieldset>
				  </div>
				  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
	$( document ).ready( function () {
		$( document ).on( 'keydown keyup', '.salesreceipt', function () {
			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];
			$( '#' + id ).autocomplete( {
			  source: function ( request, response ) {
				$.ajax( {
					url: "creation_actions/cash-counter/bill_fetch.php",
					type: 'post',
					dataType: "json",
					data: {
						search: request.term,
						request: 1
				    },
				    success: function ( data ) {
					   response( data );
				    }
			    } );
			  },
			  select: function ( event, ui ) {
				$( this ).val( ui.item.label ); 
				var salesreceipt = ui.item.value;
				$.ajax( {
					url: 'creation_actions/cash-counter/bill_fetch.php',
					type: 'post',
					data: {
						salesreceipt: salesreceipt,
						request: 2
					},
					dataType: 'json',
					success: function ( response ) {
						var len = response.length;
						if ( len > 0 ) {
							var salesreceipt = response[ 0 ][ 'salesreceipt' ];
							var salestotamt = response[ 0 ][ 'salestotamt' ];
							var bill_name = response[ 0 ][ 'bill_name' ];
							var salescashtype = response[ 0 ][ 'salescashtype' ];
							document.getElementById( 'salescashtype_' + index ).value=salescashtype;
							document.getElementById( 'salesbilltype_' + index ).value = bill_name;
							document.getElementById( 'salesreceipt_' + index ).value = salesreceipt;
							document.getElementById( 'salestotamt_' + index ).value=salestotamt;
							
							
						}
						else {
							   $.toast( {
						        heading: 'Already Used Receipt No.',
								text: '',
								position: 'top-right',
								loaderBg: '#ff6849',
								icon: 'error',
								hideAfter: 1500
		                       } );
							document.getElementById( 'salesreceipt_' + index ).value ='';
						}
						$( ".salestotamt" ).keydown();
						$('#salessum').focus();
					}
					

				} );
				return false;
			 }
			} );
			 var gtot = document.getElementById("gradtot").value;
          $( ".salestotamt" ).keydown( function () {
			var sum = 0;
			$( ".salestotamt" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							sum += parseFloat( this.value );
						}

					} );
 /*total*/
					document.getElementById( 'salessum' ).value = Math.round( sum );
/* grand tot*/
					var salestot = document.getElementById('salestotamt_' + index ).value;
		            document.getElementById('gradtot').value =  parseFloat(salestot) + parseFloat(gtot);
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					
		  });
/* cancel*/		  
		  var salescan = document.getElementById('salesreceipt_' + index ).value;
		  if(salescan=='')	{	
		            $( '#salessum' ).val( $( '#salessum' ).val() - $( '#salestotamt_' + index ).val() );
		            $( '#gradtot' ).val( $( '#gradtot' ).val() - $( '#salestotamt_' + index ).val() );
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					document.getElementById('salestotamt_' + index ).value=0;
}
			});	
/*estimate*/
				$( document ).on( 'keydown keyup', '.estreceipt', function () {

				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];

				$( '#' + id ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "creation_actions/cash-counter/bill_fetch.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
								request: 3
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
					select: function ( event, ui ) {
						$( this ).val( ui.item.label ); 
						var estreceipt = ui.item.value; 
						$.ajax( {
							url: 'creation_actions/cash-counter/bill_fetch.php',
							type: 'post',
							data: {
								estreceipt: estreceipt,
								request: 4
							},
							dataType: 'json',
							success: function ( response ) {
								var len = response.length;
								if ( len > 0 ) {
									var estreceipt = response[ 0 ][ 'estreceipt' ];
									var esttotamt = response[ 0 ][ 'esttotamt' ];
									var bill_name = response[ 0 ][ 'bill_name' ];
									var estcashtype = response[ 0 ][ 'estcashtype' ];
							        document.getElementById( 'estcashtype_' + index ).value=estcashtype;
							        document.getElementById( 'estbilltype_' + index ).value = bill_name;
									document.getElementById( 'estreceipt_' + index ).value = estreceipt;
									document.getElementById( 'esttotamt_' + index ).value=esttotamt;
								}
								else {
										$.toast( {
										heading: 'Already Used Receipt No.',
										text: '',
										position: 'top-right',
										loaderBg: '#ff6849',
										icon: 'error',
										hideAfter: 1500
		                                 } );
							     document.getElementById( 'estreceipt_' + index ).value ='';
						        }
								$( ".esttotamt" ).keydown();
						        document.getElementById('estimatesum').focus();
							}
						} );
						return false;
					}
				} );
				 var esgtot = document.getElementById("gradtot").value;
				$( ".esttotamt" ).keydown( function () {
			var estsum = 0;
			$( ".esttotamt" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							estsum += parseFloat( this.value );
						}

					} );

					document.getElementById( 'estimatesum' ).value = Math.round( estsum );
					var estitot = document.getElementById('esttotamt_' + index ).value;
		            document.getElementById('gradtot').value =  parseFloat(estitot) + parseFloat(esgtot);
                    document.getElementById('nettot').value =  document.getElementById('gradtot').value; 					
		  });
/* cancel*/	
		 var estican = document.getElementById('estreceipt_' + index ).value;
		  if(estican=='')	{	
		         $( '#estimatesum' ).val( $( '#estimatesum' ).val() - $( '#esttotamt_' + index ).val() );
				 $( '#gradtot' ).val( $( '#gradtot' ).val() - $( '#esttotamt_' + index ).val() );
				  document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					document.getElementById('esttotamt_' + index ).value=0;
}
	         });
			 
/* sales return*/
$( document ).on( 'keydown keyup', '.saretreceipt', function () {
			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];
			$( '#' + id ).autocomplete( {
			  source: function ( request, response ) {
				$.ajax( {
					url: "creation_actions/cash-counter/bill_fetch.php",
					type: 'post',
					dataType: "json",
					data: {
						search: request.term,
						request: 5
				    },
				    success: function ( data ) {
					   response( data );
				    }
			    } );
			  },
			  select: function ( event, ui ) {
				$( this ).val( ui.item.label ); 
				var saretreceipt = ui.item.value;
				$.ajax( {
					url: 'creation_actions/cash-counter/bill_fetch.php',
					type: 'post',
					data: {
						saretreceipt: saretreceipt,
						request: 6
					},
					dataType: 'json',
					success: function ( response ) {
						var len = response.length;
						if ( len > 0 ) {
							var saretreceipt = response[ 0 ][ 'saretreceipt' ];
							var sarettotamt = response[ 0 ][ 'sarettotamt' ];
							var bill_name = response[ 0 ][ 'bill_name' ];
							var saretcashtype = response[ 0 ][ 'saretcashtype' ];
							document.getElementById( 'saretcashtype_' + index ).value=saretcashtype;
							document.getElementById( 'saretbilltype_' + index ).value = bill_name;
							document.getElementById( 'saretreceipt_' + index ).value = saretreceipt;
							document.getElementById( 'sarettotamt_' + index ).value=sarettotamt;
							
						}
						else {
							   $.toast( {
						        heading: 'Already Used Receipt No.',
								text: '',
								position: 'top-right',
								loaderBg: '#ff6849',
								icon: 'error',
								hideAfter: 1500
		                       } );
							document.getElementById( 'saretreceipt_' + index ).value ='';
						}
						$( ".sarettotamt" ).keydown();
						document.getElementById('s_returnsum').focus();
					}
					

				} );
				return false;
			 }
			} );
			 var retgtot = document.getElementById("gradtot").value;
          $( ".sarettotamt" ).keydown( function () {
			var retsum = 0;
			$( ".sarettotamt" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							retsum += parseFloat( this.value );
						}

					} );
 /*total*/
					document.getElementById( 's_returnsum' ).value = Math.round( retsum );
/* grand tot*/
					var rettot = document.getElementById('sarettotamt_' + index ).value;
		            document.getElementById('gradtot').value =  parseFloat(retgtot) - parseFloat(rettot);
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					
		  });
/* cancel*/		  
		  var salescan = document.getElementById('saretreceipt_' + index ).value;
		  if(salescan=='')	{	
		            $( '#s_returnsum' ).val( $( '#s_returnsum' ).val() - $( '#sarettotamt_' + index ).val() );
		            $( '#gradtot' ).val( $( '#gradtot' ).val() - (- $( '#sarettotamt_' + index ).val()) );
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					document.getElementById('sarettotamt_' + index ).value=0;
}
			});	

/*advance Amount*/

$( document ).on( 'keydown keyup', '.advreceipt', function () {
			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];
			$( '#' + id ).autocomplete( {
			  source: function ( request, response ) {
				$.ajax( {
					url: "creation_actions/cash-counter/bill_fetch.php",
					type: 'post',
					dataType: "json",
					data: {
						search: request.term,
						request: 7
				    },
				    success: function ( data ) {
					   response( data );
				    }
			    } );
			  },
			  select: function ( event, ui ) {
				$( this ).val( ui.item.label ); 
				var advreceipt = ui.item.value;
				$.ajax( {
					url: 'creation_actions/cash-counter/bill_fetch.php',
					type: 'post',
					data: {
						advreceipt: advreceipt,
						request: 8
					},
					dataType: 'json',
					success: function ( response ) {
						var len = response.length;
						if ( len > 0 ) {
							var advreceipt = response[ 0 ][ 'advreceipt' ];
							var advtotamt = response[ 0 ][ 'advtotamt' ];
							var bill_name = response[ 0 ][ 'bill_name' ];
							var advcashtype = response[ 0 ][ 'advcashtype' ];
							document.getElementById( 'advcashtype_' + index ).value=advcashtype;
							document.getElementById( 'advbilltype_' + index ).value = bill_name;
							document.getElementById( 'advreceipt_' + index ).value = advreceipt;
							document.getElementById( 'advtotamt_' + index ).value= advtotamt;
							
						} else {
							   $.toast( {
						        heading: 'Already Used Receipt No.',
								text: '',
								position: 'top-right',
								loaderBg: '#ff6849',
								icon: 'error',
								hideAfter: 1500
		                       } );
							document.getElementById( 'advreceipt_' + index ).value ='';
						}
						$( ".advtotamt" ).keydown();
						document.getElementById('advancesum').focus();
					}
					

				} );
				return false;
			 }
			} );
			 var advgtot = document.getElementById("gradtot").value;
          $( ".advtotamt" ).keydown( function () {
			var advsum = 0;
			$( ".advtotamt" ).each( function () {
						if ( !isNaN( this.value ) && this.value.length != 0 ) {
							advsum += parseFloat( this.value );
						}

					} );
 /*total*/
					document.getElementById( 'advancesum' ).value = Math.round( advsum );
/* grand tot*/
					var advtot = document.getElementById('advtotamt_' + index ).value;
					document.getElementById('gradtot').value =  parseFloat(advgtot) - parseFloat(advtot);
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					
		  });
/* cancel*/		  
		  var advcan = document.getElementById('advreceipt_' + index ).value;
		  if(advcan=='')	{	
		            $( '#advancesum' ).val( $( '#advancesum' ).val() - $( '#advtotamt_' + index ).val() );
		            $( '#gradtot' ).val($( '#gradtot' ).val() - (- $( '#advtotamt_' + index ).val()) );
					 document.getElementById('nettot').value =  document.getElementById('gradtot').value;
					document.getElementById('advtotamt_' + index ).value=0;
}
			});	

/*discount in amt */
	$( ".discounta" ).keyup( function () {
		   var tot = document.getElementById("gradtot").value;
		   var discount = document.getElementById("discounta").value;
		  var pm=parseFloat(discount)*100/parseFloat(tot);
		  document.getElementById('discountp').value = pm;
           var balance = parseFloat(tot) - parseFloat(discount);
	       document.getElementById('nettot').value =  Math.round(balance);
		
	});	
/* discount in %*/	
	$( ".discountp" ).keyup( function () {
		    var tot = document.getElementById("gradtot").value;
		    var discountp = document.getElementById("discountp").value;
			var p = (parseFloat(tot) * parseFloat(discountp))/100;
            var balance = parseFloat(tot)-parseFloat(p);
	        document.getElementById('nettot').value =  Math.round(balance);
			document.getElementById('discounta').value = p;
		
	});	
/*balance amount*/
			$(".paidamt").keyup(function () {
	var paidamount = document.getElementById("paidamt").value;
    var gtotalprice = document.getElementById("nettot").value;
    var balance = parseInt(paidamount) - parseInt(gtotalprice);
	document.getElementById('balance').value =  Math.round(balance);
			});	
	});	
	
</script> 

<script>
function setFocusToTextBox() {
	$( "#sales_invno" ).focus();
}
/* Add more*/
			$( '#salesaddmore' ).click( function () {
				var lastname_id = $( '.aslno' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				var index = Number( split_id[ 1 ] ) + 1;
			    var html = "<tr class='tr_input'><td><input type='text' class='form-control aslno' name='aslno[]' value=" + index + " id='aslno_" + index + "'></td><td><input type='text' class='form-control salesreceipt' name='receipt[]'  id='salesreceipt_" + index + "' placeholder='Receipt No'></td><td><input type='text' class='form-control salestotamt' name='totamt[]'  id='salestotamt_" + index + "' placeholder='Amount' readonly></td><td style='display:none;'><input type='text' class='form-control salesbilltype' name='billtype[]'  id='salesbilltype_" + index + "' ></td><td style='display:none;'><input type='text' class='form-control salescashtype' name='cashtype[]'  id='salescashtype_" + index + "' ></td><td><input type='button' id='adelete_" + index + "' name='button' class='btn btn-sm btn-danger adelete' value='x'></button></td></tr>";
				$( '#sales' ).append( html ); document.getElementById('salesreceipt_' + index).focus();
			} );
			$( '#estimateaddmore' ).click( function () {
				var lastname_id = $( '.bslno' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				var index = Number( split_id[ 1 ] ) + 1;
			    var html = "<tr class='tr_input'><td><input type='text' class='form-control bslno' name='bslno[]' value=" + index + " id='bslno_" + index + "'></td><td><input type='text' class='form-control estreceipt' name='receipt[]'  id='estreceipt_" + index + "' placeholder='Receipt No'></td><td><input type='text' class='form-control esttotamt' name='totamt[]'  id='esttotamt_" + index + "' placeholder='Amount' readonly></td><td style='display:none;'><input type='text' class='form-control estbilltype' name='billtype[]'  id='estbilltype_" + index + "' ></td><td style='display:none;'><input type='text' class='form-control estcashtype' name='cashtype[]'  id='estcashtype_" + index + "' ></td><td><input type='button' id='bdelete_" + index + "' name='button' class='btn btn-sm btn-danger bdelete' value='x'></button></td></tr>";
			$( '#estimate' ).append( html ); document.getElementById('estreceipt_' + index).focus();
			} );
			$( '#salesretaddmore' ).click( function () {
				var lastname_id = $( '.cslno' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				var index = Number( split_id[ 1 ] ) + 1;
			    var html = "<tr class='tr_input'><td><input type='text' class='form-control cslno' name='cslno[]' value=" + index + " id='cslno_" + index + "'></td><td><input type='text' class='form-control saretreceipt' name='receipt[]'  id='saretreceipt_" + index + "' placeholder='Receipt No'></td><td><input type='text' class='form-control sarettotamt' name='totamt[]'  id='sarettotamt_" + index + "' placeholder='Amount' readonly></td><td style='display:none;'><input type='text' class='form-control saretbilltype' name='billtype[]'  id='saretbilltype_" + index + "' ></td><td style='display:none;'><input type='text' class='form-control saretcashtype' name='cashtype[]'  id='saretcashtype_" + index + "' ></td><td><input type='button' id='cdelete_" + index + "' name='button' class='btn btn-sm btn-danger cdelete' value='x'></button></td></tr>";
			    $( '#salesret' ).append( html ); document.getElementById('saretreceipt_' + index).focus();
			} );
			$( '#advanceaddmore' ).click( function () {
				var lastname_id = $( '.dslno' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				var index = Number( split_id[ 1 ] ) + 1;
			    var html = "<tr class='tr_input'><td><input type='text' class='form-control dslno' name='dslno[]' value=" + index + " id='dslno_" + index + "'></td><td><input type='text' class='form-control advreceipt' name='receipt[]'  id='advreceipt_" + index + "' placeholder='Receipt No'></td><td><input type='text' class='form-control advtotamt' name='totamt[]'  id='advtotamt_" + index + "' placeholder='Amount' readonly></td><td style='display:none;'><input type='text' class='form-control advbilltype' name='billtype[]'  id='advbilltype_" + index + "' ></td><td style='display:none;'><input type='text' class='form-control advcashtype' name='cashtype[]'  id='advcashtype_" + index + "' ></td><td><input type='button' id='ddelete_" + index + "' name='button' class='btn btn-sm btn-danger ddelete' value='x'></button></td></tr>";
				$( '#advance' ).append( html ); document.getElementById('advreceipt_' + index).focus();
			} );
/*delete*/			
			$( document ).on( 'click', '.adelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
			    $( '#salessum' ).val( $( '#salessum' ).val() - $( '#salestotamt_' + index ).val() );
				$( '#gradtot' ).val( $( '#gradtot' ).val() - $( '#salestotamt_' + index ).val() );
				document.getElementById('nettot').value =  document.getElementById('gradtot').value;
				$( this ).closest( 'tr' ).remove();
			} );
			$( document ).on( 'click', '.bdelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
			    $( '#estimatesum' ).val( $( '#estimatesum' ).val() - $( '#esttotamt_' + index ).val() );
				$( '#gradtot' ).val( $( '#gradtot' ).val() - $( '#esttotamt_' + index ).val() );
				document.getElementById('nettot').value =  document.getElementById('gradtot').value;
				$( this ).closest( 'tr' ).remove();
			} );
			$( document ).on( 'click', '.cdelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
			    $( '#s_returnsum' ).val( $( '#s_returnsum' ).val() - $( '#sarettotamt_' + index ).val() );
				 $( '#gradtot' ).val( parseFloat($( '#gradtot' ).val()) + parseFloat($( '#sarettotamt_' + index ).val()) );
				document.getElementById('nettot').value =  document.getElementById('gradtot').value;
				$( this ).closest( 'tr' ).remove();
			} );
			$( document ).on( 'click', '.ddelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
			    $( '#advancesum' ).val( $( '#advancesum' ).val() - $( '#advtotamt_' + index ).val() );
				$( '#gradtot' ).val( parseFloat($( '#gradtot' ).val()) + parseFloat($( '#advtotamt_' + index ).val() ));
				document.getElementById('nettot').value =  document.getElementById('gradtot').value;
				$( this ).closest( 'tr' ).remove();
			} );
</script>
<script type="text/javascript">
  $("#carddetails1").hide();  $("#carddetails2").hide();   $("#carddetails3").hide(); 
  function checkvalue(val)
{
    if(val==="BANK") {
     $("#carddetails1").show();   $("#carddetails2").show();   $("#carddetails3").show();
    }
   else {  $("#carddetails1").hide();  $("#carddetails2").hide();   $("#carddetails3").hide();  }    
}
$( document ).ready( function () {
$('#insert_form').on('submit', function(event){
  event.preventDefault();
  var error = '';
$('.gradtot').each(function(){
   var count = 1;
   if ( $( this ).val() == 0 ) {
	   setTimeout(function(){ window.location.reload(1);}, 1300);
	    $.toast( {
						heading: 'Enter Receipt Number.',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
		} );
		
	   error += "<p>Enter Item Code at " + count + " Row</p>";
	   return false;			
	}
    count = count + 1;
});
$( '.salestotamt,.esttotamt,.sarettotamt,.advtotamt' ).each( function () {			
	if ( $( this ).val() ==0 ) {
	$( this ).closest( 'tr' ).remove();					
	}
} );
$( '.paytype' ).each( function () {      
  if ( $( this ).val() =='BANK' ) {
    if($('.expiry').val() == '' || $('.cardno').val() == '' || $('.bank').val() == '' ){
    $.toast( {
            heading: 'Enter Card No, Bank Name, Expiry Date.',
            text: '',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'error',
            hideAfter: 1200
    } );
    
   }       
  }
} );
 $('.paidamt').each(function(){
   var count = 1;
   if ( $( this ).val() == '' ) {
            
            $.toast( {
            heading: 'Enter Paid Amount.',
            text: '',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'error',
            hideAfter: 1200
          } );
            error += "<p>Enter Item Name at " + count + " Row</p>";
            return false;
          }
   count = count + 1;
  });
  var form_data = $(this).serialize();
  if(error == '')
  {
   $.ajax({
    url:"creation_actions/cash-counter/cash_bill.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
    window.location="cash-counter-print.php";
	 $.toast( {   
					heading: 'Inserted Successfully.',
					text: '',
					position: 'top-right',
					loaderBg: '#04F92D',
					icon: 'success',
					
					hideAfter: 1100
				} );
				
				document.getElementById( "insert_form" ).reset();    $('#sales').find("tr:gt(0)").remove();
				$('#estimate').find("tr:gt(0)").remove();            $('#salesret').find("tr:gt(0)").remove();
			   $('#advance').find("tr:gt(0)").remove();
				 
    }
   });
  }
  else
  {
  }
 });
});

	</script> 


<div class="right-sidebar">
  <div class="slimscrollright">
    <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
    <div class="r-panel-body">
      <ul id="themecolors" class="m-t-20">
        <li><b>With Light sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
        <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
        <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
        <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
        <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
        <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
        <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
        <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
        <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
        <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
      </ul>
      
    </div>
  </div>
</div>
</div>

</div>
</div>
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 
<script src="assets/plugins/tiny-editable/numeric-input-example.js"></script> 
<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script> 
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<?php include ('include/disable_fn.php'); ?>
<script>
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>



</body>
</html>