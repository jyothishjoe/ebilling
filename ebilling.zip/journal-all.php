<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); 
include('db-connect/db.php');
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid' ");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 


if ( isset( $_GET[ 'fdate' ], $_GET[ 'tdate' ] ) ) {
	$dates = $_GET[ 'fdate' ];
	$fdates = date_create( $dates );
	$fdate = date_format( $fdates, 'Y-m-d' );
	$dates = $_GET[ 'tdate' ];
	$tdates = date_create( $dates );
	$tdate = date_format( $tdates, 'Y-m-d' );
} 


?>
<title>All Journals </title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">

<style>
.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}
	
</style>
						<div class="col-md-12">
							<h3 class="text-center">Journals</h3>
							<div class="text-right">
								<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="margin-left:.1em;">Close</button>
							</div>
								<form method="get" action="" autocomplete="off">
									<div class="form-row">
										<?php
										$result = $db->prepare( "SELECT * FROM  date_mask WHERE addby='$userid' AND company_tkn='$user_company' ORDER BY id DESC LIMIT 1" );
										$result->execute();
										$rows = $result->fetch();
										$dateformate = $rows[ 'dateformate' ];
										?>
										<?php if ($dateformate == 'datechoos') { ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">From </label>
											<input type="date" class="form-control" id="fdate" name="fdate" value="<?php echo $start_year; ?>" required>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">To</label>
											<input type="date" class="form-control" id="tdate" name="tdate" value="<?php echo $date_set; ?>" required>
										</div>
										<?php } else { ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">From</label>
											<input type="text" class="form-control date-inputmask" id="fdate" name="fdate" value="<?php echo $start_year; ?>" required>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">To</label>
											<input type="text" class="form-control date-inputmask" id="tdate" name="tdate" value="<?php echo $date_set; ?>" required>
										</div>
										<?php } ?>
										<!-- <input type="text" name="fdate" value="" class="form-control" required id="fdate1" placeholder="dd/mn/yyyy" > -->
										<div class="col-md-2 col-sm-6 col-xs-12">
											<div class="col-md-6">
												<label>&nbsp;</label>
												<input type="submit" value="Search" class="btn btn-sm btn-primary" style="font-size: 15px;">
												<?php if (isset($_GET['fdate'])) { ?>
												<div class="col-md-2" style="position: absolute; left: 35px;bottom: 1px;">
													<a href="journal-all.php" class="btn btn-sm btn-danger" style="margin-left: 48px; font-size: 15px;">&nbsp;Clear&nbsp;</a>
												</div>
												<?php } ?>
											</div>
										</div>
									</div>
								</form>
								<div class="table-responsive m-t-12">
                                <table id="datatb2" class="table display nowrap" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Sl No</th>
                                            <th >Date</th>
                                            <th style="width: 35%;">Purticulars</th>
                                            <th style="width: 15%;">Dr</th>
                                            <th style="width: 15%;">Cr</th>
                                           <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
										$sl=1;
										if ( isset( $_GET[ 'fdate' ], $_GET[ 'tdate' ] ) ) {
										$result_journal = $db->prepare("SELECT * FROM transaction WHERE trn_date >='$fdate' AND  trn_date <='$tdate' AND company_tkn='$user_company' GROUP BY voucher_no DESC");
										$result_journal ->execute();
										}else{
										$result_journal = $db->prepare("SELECT * FROM transaction WHERE company_tkn='$user_company' GROUP BY voucher_no ASC ORDER BY id ASC");
										$result_journal ->execute();
										}
										for($i=0; $rows_journal  = $result_journal ->fetch(); $i++){
										$sum_dr = $rows_journal['debit_amt'];
										$sum_cr = $rows_journal['credit_amt'];
											
										$ledger_name = $rows_journal['ledger_name'];
										$voucher_no = $rows_journal['voucher_no'];
										
										?>
                                        <tr id="1" class="gradeX">
											
                                           <td ><br><br><?php echo $sl++; ?></td>
                                           <td ><br><br><?php $date = new DateTime($rows_journal['trn_date']); echo date_format($date, "d F Y"); ?></td>
                                           <td>
											<?php 
											$result_journal1 = $db->prepare("SELECT * FROM transaction WHERE voucher_no = '$voucher_no' AND company_tkn='$user_company'");
											$result_journal1 ->execute();
											for($i=0; $rows_journal1  = $result_journal1 ->fetch(); $i++){ 
											$ledger = $rows_journal1['ledger_name'];
											if($rows_journal1['typ'] == 'Dr'){ echo '<br><strong>'.ucfirst($ledger).'</strong><br><br><br>'; } 
											if($rows_journal1['typ'] == 'Cr'){ echo '<strong>'.ucfirst($ledger).'</strong><br><br>'; }	
											}
											?>
										   </td>
                                           <td>
										   <?php 
											$result_journal_dr = $db->prepare("SELECT * FROM transaction WHERE voucher_no = '$voucher_no' AND company_tkn='$user_company'");
											$result_journal_dr ->execute();
											for($i=0; $rows_journal_dr  = $result_journal_dr ->fetch(); $i++){ 
											$debit_amount = $rows_journal_dr['debit_amt'];
											if($rows_journal_dr['typ'] == 'Dr'){ echo '<br><strong>'.number_format($debit_amount).'</strong>'; } 
											}
											?>
										   </td>
										   <td>
											<?php
											$result_journal_cr = $db->prepare("SELECT * FROM transaction WHERE voucher_no = '$voucher_no' AND company_tkn='$user_company'");
											$result_journal_cr ->execute();
											for($i1=0; $rows_journal_cr  = $result_journal_cr ->fetch(); $i1++){ 
											$credit_amount = $rows_journal_cr['credit_amt'];
											if($rows_journal_cr['typ'] == 'Cr'){ echo '<br><br><br><strong>'.number_format($credit_amount).'</strong>'; } 
											} 
											?>
											</td>
											
									
                                           <td><br><br><a href="edit_journal_popup.php?edit=<?php echo $rows_journal['voucher_no']; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top"><i class="fa fa-pencil-alt"></i></a>&nbsp;<a id="delete" href="delete_journal.php?delete=<?php echo $rows_journal['voucher_no']; ?>" class="btn btn-sm btn-danger simple-ajax-popup-align-top" ><i class="fas fa-trash-alt"></i>
                                           </a></td>
										
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                  			</div>
      				
<script>
$(document).ready(function() {
$('.simple-ajax-popup-align-top').magnificPopup({
type: 'ajax',
alignTop: false,
closeOnBgClick: false,
openDelay: 800,
overflowY: 'scroll'

});
$('.simple-ajax-popup').magnificPopup({
type: 'ajax'
});

});		
$(document).ready(function() {

$('.fancybox').fancybox({

closeBtn    : false, // hide close button
closeClick  : false, // prevents closing when clicking INSIDE fancybox
helpers     : { 
// prevents closing when clicking OUTSIDE fancybox
overlay : {closeClick: false} 
},
keys : {
// prevents closing when press ESC button
close  : null
}
});

});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });

</script>
<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
<script src="js/toastr.js"></script>
<?php include ('include/disable_fn.php'); ?>