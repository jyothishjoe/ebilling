<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$token = $_GET[ 'delete' ];
$result_cat = $db->prepare( "SELECT * FROM pr_category WHERE cat_tok='$token' " );
$result_cat->execute();
$rows_cat = $result_cat->fetch();
?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #398bf7 !important; color: #fff; opacity: 1; width: 67px; font-size: 17px; height: 40px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #398bf7 !important;}
</style>
<div id="custom-content" class="col-md-4 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden; height: 155px;   background-color: #f2f2f2;">
	<h3 class="text-center"></h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
		<h3 class="text-align: center;" style="margin-bottom: 25px; color: red;">Are You Sure !</h3>
		<div class="form-row">
			<div class="col-md-6 col-sm-4 col-xs-6">
				<a href="product-action/delete-category.php?delete=<?php echo $rows_cat['cat_tok']; ?>" id="delete" class="btn  btn-danger">Delete</a>
			</div>
			<div class="col-md-6 col-sm-4 col-xs-6">
				<button type="button" id="close_fbx" class="btn btn btn-info mfp-close">Cancel</button>
			</div>
		</div>
	</form>
	<script>
		$( '#close_fbx' ).on( 'click', function (){
			parent.jQuery.magnificPopup.close();
		} );
		$( '#delete' ).on( 'click', function () {
			parent.jQuery.magnificPopup.close();
			$.toast( {
				heading: 'Deleted Successfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'success',
				hideAfter: 4500
			} );
		} );
	</script>