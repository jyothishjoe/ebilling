<?php
include( 'include/auth.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];
include( 'db-connect/db.php' );
include( 'include/today.php' );
if ( isset( $_GET[ 'startdate' ], $_GET[ 'enddate' ], $_GET[ 'type' ]) ) {
	$startdate = $_GET[ 'startdate' ];
	$enddate = $_GET[ 'enddate' ];
	$type=$_GET[ 'type' ];
} else {
	$type='---Select--';
	$startdate = '';
	$enddate = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Sales Return Report</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/auto/all.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<style>
		fieldset {
			margin-top: 17px;
			border: 1px solid #999;
			font-size: 12px;
			padding: 0px 10px;
		}
		
		legend {
			margin-left: 10px;
			width: 80px;
			font-size: 12px;
		}
		
		.container {
			display: inline;
			position: relative;
			padding-left: 20px;
			margin-bottom: 12px;
			cursor: pointer;
			font-size: 12px;
			bottom: 5px;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			cursor: pointer;
		}
		
		.checkmark {
			position: absolute;
			top: 0;
			left: 0;
			height: 15px;
			width: 15px;
			border: 1px solid #666;
			border-radius: 50%;
		}
		
		.container input:checked~ .checkmark {
			background-color: #2196F3;
		}
		
		.checkmark:after {
			content: "";
			position: absolute;
			display: none;
		}
		
		.container input:checked~ .checkmark:after {
			display: block;
		}
		
		.container .checkmark:after {
			top: 3px;
			left: 3px;
			width: 7px;
			height: 7px;
			border-radius: 50%;
			background: white;
		}
	</style>
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor" style="float: left;"> Sales Return Report</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
							<li class="breadcrumb-item"><a href="saleshome.php">Sales</a>
							</li>
							<li class="breadcrumb-item active">Sales Return</li>
						</ol>
					</div>
					<div>

					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<div class="col-md-2 col-sm-6 col-xs-12">
											<label for="" class="control-label">Choose Type</label>
											<select class="form-control" id="type" name="type" style="width: 100%; height:36px;" value="<?php echo $types;?>">
										  <option value="<?php echo $type;?>"><?php echo $type;?></option>
										  <option value="Customer Wise">Customer Wise</option>
										  <option value="Product Wise">Product Wise</option>
										  <option value="Tax Wise">Tax Wise</option>
										  <option value="Date Wise">Date Wise</option>
										</select>
										
										</div>
										<div class="col-md-12"></div>
										<?php include("include/datemask.php");?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Show"/>
										</div>
									</div>
								</form>
								<div class="table-responsive m-t-40">
									<?php if(isset ($_GET['startdate'], $_GET['enddate'], $_GET['type'])){
									$datea = date_create($startdate);
									$startdate = date_format($datea,'Y-m-d');
									$dates = date_create($enddate);
									$enddate = date_format($dates,'Y-m-d');
									?>
									<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
										
										<thead>
											<tr>
												<th>#</th>
												<th>Bill No</th>
												<th>Bill Date</th>
												<?php if($type == 'Customer Wise'  || $type == '---Select--'){ ?>
												<th>Customer Name</th>
												<?php }else if ($type == 'Product Wise') { ?>
												<th>Product</th>
												<?php } ?>
												<th>Rate</th>
												<th>Tax Rates</th>
												<th>CGST</th>
												<th>SGST</th>
												<th>CGST Amt</th>
												<th>SGST Amt</th>
												<!--<th>IGST</th>-->
												<th>Total GST</th>
												<th>Other tax</th>
												<th>Net Total</th>
												<?php if( $type == '---Select--'){ ?>
												<th>Action</th>
												<?php }?>
											</tr>
										</thead>
										<tbody>
											<?php 
											 if($type == 'Customer Wise' || $type == 'Tax Wise' ||$type == 'Date Wise' || $type == '---Select--'){
											$result_sales = $db->prepare("SELECT * FROM sales_rtn_invoice a LEFT JOIN customer b ON a.custmr_name=b.acco_name    WHERE a.sales_invdate >= '$startdate' AND a.sales_invdate <= '$enddate' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' GROUP  BY a.bill_no");
											$result_sales ->execute();
											 } else {
											$result_sales = $db->prepare("SELECT * FROM sales_rtn_invoice a LEFT JOIN sales_rtn_prdct_details b ON b.sales_rtnno=a.sales_rtnno  WHERE a.sales_invdate >= '$startdate' AND a.sales_invdate <= '$enddate' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' ");
											$result_sales ->execute();}
											for ($i=0; $rows_sales  = $result_sales ->fetch(); $i++){
											
											//$order_no = $rows_sales['order_no'];
											$bill_no = $rows_sales['sales_rtnno'];
											$norm_date = $rows_sales['sales_invdate'];
											$date = date_create($norm_date);
											$condate = date_format($date,'d-m-Y');
											
											
											?>
											<tr>
												<td>
													<?php echo $i+1; ?>
												</td>
												<td>
													<?php echo $rows_sales['bill_no']; ?>
												</td>
												<td>
													<?php echo $condate; ?><br>
													<?php echo $rows_sales['sales_rtntime']; ?>
												</td>
												<?php if($type == 'Customer Wise'  || $type == '---Select--'){ ?>
												<td>
													<?php if($rows_sales['custmr_name'] !=''){echo $rows_sales['custmr_name'];}else{echo 'Cash';} ?>
												</td>
												<?php }else if ($type == 'Product Wise')  {?>
												<td>
													<?php echo $rows_sales['prdct_name'];?>
												</td>
												<?php } ?>
												
												<?php if($type == 'Tax Wise' ||$type == 'Date Wise' || $type == 'Customer Wise' || $type == '---Select--' ){ ?>
												<td>
													<?php echo $rows_sales['grand_tot'] - $rows_sales['tax_total_amt']; ?>
												</td>
												<?php } else if( $type == 'Product Wise'){ ?>
												<td>
													<?php   echo $rows_sales['rtn_amt'];?>
												</td>
												<?php }?>
												
												<?php if($type == 'Tax Wise' ||$type == 'Date Wise' || $type == 'Customer Wise' || $type == '---Select--' ){ ?>
												<!--Tax-->
												<td>
												<?php 
												$result_gst = $db->prepare("select * from  sales_rtn_prdct_details where company_tkn='$user_company' AND sales_rtnno = '$bill_no'");
												$result_gst->execute();
												for ($e1=0; $rows_gst  = $result_gst ->fetch(); $e1++){
												$rate = $rows_gst['sales_tax'];
												?>
												<?php echo floor($rate); ?>%<br>
												<?php } ?>
												</td>
												<td>
												<?php 
												$result_gst2 = $db->prepare("select * from  sales_rtn_prdct_details where company_tkn='$user_company' AND sales_rtnno = '$bill_no'");
												$result_gst2->execute();
												for ($e1=0; $rows_gst2  = $result_gst2 ->fetch(); $e1++){
												$sgstrate = $rows_gst2['sales_tax'];
												?>
												<?php echo $sgstrate/2; ?>%<br>
												<?php } ?>
												</td>
												<td>
												<?php 
												$result_gst21 = $db->prepare("select * from  sales_rtn_prdct_details where company_tkn='$user_company' AND sales_rtnno = '$bill_no'");
												$result_gst21->execute();
												for ($e1=0; $rows_gst21  = $result_gst21 ->fetch(); $e1++){
												$cgstrate = $rows_gst21['sales_tax'];
												?>
												<?php echo $cgstrate/2; ?>%<br>
												<?php } ?>
												</td>
												<td>
												<?php 
												$result_cgst = $db->prepare("select * from  sales_rtn_prdct_details where company_tkn='$user_company' AND sales_rtnno = '$bill_no'");
												$result_cgst->execute();
												for ($e13=0; $rows_cgst  = $result_cgst ->fetch(); $e13++){
												$cgst = $rows_cgst['gst_amt'];
												?>
												<?php echo $cgst/2; ?><br>
												<?php } ?>
												</td>
												<td>
												<?php 
												$result_sgst = $db->prepare("select * from  sales_rtn_prdct_details where company_tkn='$user_company' AND sales_rtnno = '$bill_no'");
												$result_sgst->execute();
												for ($e13=0; $rows_sgst = $result_sgst ->fetch(); $e13++){
												$sgst = $rows_sgst['gst_amt'];
												?>
												<?php echo $sgst/2; ?><br>
												<?php } ?>
												</td>
												<?php } ?>
												<?php if($type == 'Product Wise'){ ?>
												<td><?php echo floor($rows_sales['sales_tax']); ?>%</td>
												<td><?php echo $rows_sales['sales_tax']/2; ?>%</td>
												<td><?php echo $rows_sales['sales_tax']/2; ?>%</td>
												<td><?php echo $rows_sales['gst_amt']/2; ?></td>
												<td><?php echo $rows_sales['gst_amt']/2; ?></td>
												
												<?php } ?>
												<!--===============================-->
												<?php if($type == 'Tax Wise' ||$type == 'Date Wise' || $type == 'Customer Wise' || $type == '---Select--' ){ ?>
												<td>
													<?php echo $rows_sales['tax_tot']; ?>
												</td>
												<td>
													<?php echo $rows_sales['o_tax_total']; ?>
												</td>
												<?php } else if( $type == 'Product Wise'){ ?>
												<td>
													<?php   echo $rows_sales['gst_amt']; ?>
												</td>
												<td>
													<?php   echo $rows_sales['o_tax_total']; ?>
												</td>
												<?php }?>
												<td>
													<?php echo $rows_sales['grand_tot']; ?>
												</td>
												<?php if( $type == '---Select--' ){ ?>
												<td><a class="btn btn-sm btn-info" href="sales-bill-reprint.php?bill=<?php echo $rows_sales['sbill_no']; ?>"><i class="fas fa-print"></i></a>
												</td>
												<?php }?>
											</tr>
											<?php } ?>
									</table>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b> </li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
							</ul>

						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script>
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		$( '#tbl' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
	</script>

	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
	<script>
		$( document ).keyup( function ( e ) {
			if ( e.altKey && e.which == 49 ) {
				window.location.href = "creation.php";
			} else if ( e.altKey && e.which == 50 ) {
				window.location.href = "purchase-home.php";
			} else if ( e.altKey && e.which == 51 ) {
				window.location.href = "saleshome.php";
			} else if ( e.altKey && e.which == 52 ) {
				window.location.href = "inventory-home.php";
			} else if ( e.altKey && e.which == 53 ) {
				window.location.href = "accounts-home.php";
			} else if ( e.altKey && e.which == 54 ) {
				window.location.href = "cashcounter-home.php";
			} else if ( e.altKey && e.which == 55 ) {
				window.location.href = "anayisis.php";
			} else if ( e.altKey && e.which == 56 ) {
				window.location.href = "setting-home.php";
			}
			//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
			/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
		} );
		var prevScrollpos = window.pageYOffset;
		window.onscroll = function () {
			var currentScrollPos = window.pageYOffset;
			if ( prevScrollpos > currentScrollPos ) {
				document.getElementById( "navbar" ).style.top = "0";
				document.getElementById( "navbar1" ).style.top = "0";
			} else {
				document.getElementById( "navbar" ).style.top = "-70px";
				document.getElementById( "navbar1" ).style.top = "-80px";
			}
			prevScrollpos = currentScrollPos;
		}
	</script>
</body>
</html>