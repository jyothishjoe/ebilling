<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];

$date_set = $today;

?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Purchase Return</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/auto/all.css">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h4 class="text-themecolor" style="float: left;">Purchase Return&nbsp; <strong>(<?php echo $today = date('d-m-Y'); ?>)</strong> </h4>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index.php">Home</a></li>
							<li class="breadcrumb-item active"><a href="purchase-home.php">Purchase</a></li>
						</ol>
					</div>
					<div class="col-md-12">
					<!--<a href="create-ledger.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="openledger">Ledger(F1)</a>
								<a href="add-supplier.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="opensupplier">Add Supplier(F2)</a>
								<a href="add-product.php" class="btn btn-sm btn-info simple-ajax-popup-align-top" id="openproduct">Add Product(F3)</a>-->
					<?php
					$result_bill = $db->prepare("SELECT * FROM purchasereturn_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1 ");
					$result_bill->execute();
					$rows_bill = $result_bill->fetch(); 
					$row_count = $result_bill->rowCount();
					$prefix = 'PR';
					if($row_count == 0){
						$invno = 'PR1';
						$invno1 = '1';
					}else{
					$invno =sprintf( "%s%1s", $prefix, $rows_bill['id'] + 1);
						$invno1 = $rows_bill['id'] + 1;
						}
					?>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<div class="clear"></div>
								<hr/>
								<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
									<div class="form-row">
										<div class="col-md-1 col-sm-6 col-xs-12  mb-3">
											<div class="row">
											</div>
										</div>
										<div class="col-md-5 col-sm-6 col-xs-12"></div>
										<label for="" class="control-label">Return Bill</label>
										<div class="col-md-1 col-sm-6 col-xs-12 mb-2">
										<input type="hidden" class="form-control" name="invno" value="<?php echo $invno; ?>" id="invno" readonly>
											<input type="text" class="form-control" id="invn1o" name="invno1" value="<?php  echo $invno1; ?>" readonly>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-6 mb-2">
											<input type="date" class="form-control" id="order_invdate" name="order_invdate" value="<?= $date_set; ?>" >
										</div>
										<div class="col-md-2 col-sm-6 col-xs-6 mb-2">
											<input type="time" class="form-control" id="order_invtime" name="time" value="<?php echo $current_time;?>" readonly>
										</div>
									</div>
									<input type="hidden" class="form-control" id="addby" name="addby" value="" readonly>
									<div class="form-row">
									<div class="col-md-3 col-sm-6 col-xs-12 mb-2">
									  
										
													<select class="form-control select2" id="billno" name="billno" style="width: 100%; height:36px;">
														<option>Bill No</option>
														<?php
														$result_vendor1 = $db->prepare("SELECT * FROM purchase_invoice ");
														$result_vendor1->execute();
														for ($i = 0; $rows_vendor1 = $result_vendor1->fetch(); $i++) {
														?>
														<option value="<?php echo $rows_vendor1['inv']; ?>">
															<?php echo $rows_vendor1['inv']; ?>
														</option>
														<?php } ?>
													</select>
												
									</div>
									</div>
									<div class="form-row">
									<?php 
									$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid'  ORDER BY id DESC LIMIT 1");
									$result->execute();
									$rows=$result->fetch();
									$dateformate=$rows['dateformate'];
									?>
									<?php if($dateformate == 'datechoos') { ?>
								  	<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
									<input type="date" class="form-control" id="billdate" name="billdate" placeholder="PV Date" value="<?php echo $date_set; ?>" required>
								  	</div>
									<?php } else { ?>
								   	<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
									<input type="text" class="form-control date-inputmask" id="billdate" placeholder="PV Date" value="<?php echo $date_set; ?>" name="billdate" required>
								  	</div>
									<?php } ?>
									    <div class="col-md-3 col-sm-6 col-xs-12  mb-3">
											<div class="form-group row">
												 <div class="col-12">
													<select class="form-control select2" id="v_name" name="v_name" style="width: 100%; height:20px;">
														<option>Supplier Name</option>
														<?php
														$result_vendor = $db->prepare("SELECT * FROM supplier ");
														$result_vendor->execute();
														for ($i = 0; $rows_vendor = $result_vendor->fetch(); $i++) {
														?>
														<option value="<?php echo $rows_vendor['v_name']; ?>">
															<?php echo $rows_vendor['v_name']; ?>
														</option>
														<?php } ?>
													</select>
												</div>
											</div>
											<input type="hidden" class="form-control" name="company" id="company" placeholder="Company">
											<input type="hidden" class="form-control" name="state" id="state" placeholder="Company">
											<input type="hidden" class="form-control" name="supgst" id="supgst" placeholder="supgst">
											<input type="hidden" class="form-control" name="address" id="address" placeholder="Address">
											<input type="hidden" class="form-control" name="userid" id="userid" value="<?php echo $userid; ?>" placeholder="Address">
											<input type="hidden" class="form-control" name="company" id="company" value="<?php echo $user_company; ?>" placeholder="Address">
											<input type="hidden" class="form-control" name="supid" id="supid" placeholder="Supplier Name">
											<input type="hidden" class="form-control" name="suptoken" id="suptoken" placeholder="Supplier token">
											<input type="hidden" class="form-control" name="phone" id="phone"  placeholder="Mobile Number">
											<input type="hidden" class="form-control" name="purchase_ledger" id="purchase_ledger" value="" placeholder="Supplier NTokename">
										</div>
										
										</div>
									  <div class="col-md-6 col-sm-6 col-xs-12">
											<div class="form-group row">
												<textarea type="text" class="form-control" name="remarks" id="remarks"  placeholder="Remarks"></textarea>
											</div>
										</div>
										<div class=" col-md-5"></div>
										<div class=" col-md-12 col-xs-12 no-padding" id="form_data"></div>
										<input type="hidden" class="form-control totalqty" id="totalqty" name="totalqty" readonly>
										<input type="hidden" class="form-control" id="datetym" name="datetym" value="<?php echo $current_date_time;?>">
									<hr/>
									<!----Table-->
									<div class="col-sm-12 col-xs-12 " id="billdata" style="overflow-x: auto; ">
									</div>
									<br>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 112 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "create-ledger.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					});
				}, 200 );
			}
			if ( event . keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#opensupplier').click();
			}
			if ( event . keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#openproduct').click();
			}
			if ( event . keyCode == 115 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#openpurchaseorder').click();
			}
		});
		
			/* table data (Purchase Return bill items)*/
			$( "#v_name" ).change( function () {

				var vendor = $( '#v_name' ).val();
				var bill = $( '#billno' ).val();
				var billdate = $( '#billdate' ).val();
 			 //Checking Bill if its exist Or Not
			if(bill == ''){
				 $.toast( {heading: 'Enter Invoice Number.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1900} );
			 }else if(billdate == ''){
				$.toast( {heading: 'Please Enter Invoice Date.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1900} );
			 }else{
				//setTimeout($('.preloader').show(), 2000);
				 //Fetching Bill Data For Enterd Date And Inv No
				$.ajax( {
					type: 'POST',
					url: 'purchase-return-data.php',
					data: 'vendor=' + vendor + '&bill=' + bill + '&billdate=' + billdate,
					success: function ( r ) {
						$( "#billdata" ).html( r );
						//$('.preloader').hide();
					}
				} );
			 }
			});
		/*Supplier Details Search */
		$( function () {
			$( "#v_name" ).autocomplete( {
				source: "purchase-action/sup_search.php",
				select: function ( event, ui ) {
					event.preventDefault();
					$( "#v_name" ).val( ui.item.value );
				}
			} );
		} );
		
		$( '#v_name' ).change( function () {
			var v_name = $( "#v_name" ).val();
			$.ajax( {
				type: 'POST',
				url: 'purchase-action/sup_phone_change.php',
				data: 'v_name=' + v_name,
				dataType: "JSON",
				success: function ( data ) { $( '#phone' ).val( data.phone ); $( '#supid' ).val( data.sup_id ); $( '#state' ).val( data.state ); $( '#address' ).val( data.address ); $( '#supgst' ).val( data.supgst ); $( '#company' ).val( data.company ); $( '#suptoken' ).val( data.sup_tkn ); $( '#city' ).val( data.city );
				$('#purchase_ledger').val(data.token);
				}
			} );
		} );
		//addRowCount('.js-serial');

		function setFocusToTextBox() {
			document.getElementById( "code_1" ).focus();
		}
	</script>
	<script type="text/javascript">
		var taxable = 0;
		var nontaxable = 0;
	
		$( document ).ready( function () {
				 $( '#billno' ).focus();
				$(document).on( 'keyup', '.qty' , function () {
					var id = this.id;
					var splitid = id.split( '_' );
					var index = splitid[ 1 ];
					//Gross Value
					$('#gross_' + index).val($('#purchprice_' + index).val() * $('#qty_' + index).val());
					//GST Calculation
					$('#gst_' + index).val($('#purchprice_' + index).val() * $('#gstin_' + index).val() / 100 * $('#qty_' + index).val());
					// Other Taxes calculation
					if($('#othertax_amt1_' + index ).val() != 0){
                  	$('#othertax_amount1_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt1_' + index) .val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt2_' + index ).val() != 0){
                  	$('#othertax_amount2_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt2_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt3_' + index ).val() != 0){
                  	$('#othertax_amount3_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt3_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt4_' + index ).val() != 0){
                  	$('#othertax_amount4_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt4_' + index ).val() / 100 * $('#qty_' + index).val() );
					}if($('#othertax_amt5_' + index ).val() != 0){
                  	$('#othertax_amount5_' + index ).val( $('#purchprice_' + index ).val() * $( '#othertax_amt5_' + index ).val() / 100 * $('#qty_' + index).val() );
					}
					//Total AMount of the Produt(Each row Wise total amount)  
					$('#taxrate_amount_' + index ).val(parseFloat($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()));
					$('#total_' + index ).val(parseFloat($('#gross_' + index).val()) + parseFloat($('#gst_' + index).val()) + parseFloat($('#othertax_amount1_' + index).val()) + parseFloat($('#othertax_amount2_' + index).val()) + parseFloat($('#othertax_amount3_' + index).val()) + parseFloat($('#othertax_amount4_' + index).val()) + parseFloat($('#othertax_amount5_' + index).val()) );
					
					//GST For Product And CGST ,SGST Separation
					$('#totalt_' + index).val(parseFloat($('#total_' + index).val()) / parseFloat($('#qty_' + index).val()));
					$('#gstinperc_' + index).val(parseFloat($('#gstin_' + index).val()) / 2);
					$('#gstincgst_' + index).val(parseFloat($('#gstin_' + index).val()) / 2);
					$('#gstincgstamt_' + index).val(parseFloat($('#gst_' + index).val()) / 2);
					$('#gstinsgstamt_' + index).val(parseFloat($('#gst_' + index).val()) / 2);
					//===========================
					var sum = 0; var qtysum = 0; var gst = 0; var tot = 0; var totgst = 0; var taxable = 0;
					var nontaxable = 0; var gstinvalue = $('#gstin_' + index).val(); var qtygst = $('#qty_' + index).val();
					var other_taxtot = 0;
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							sum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(sum);
					
					$('.total').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qtysum += parseFloat(this.value);
						}
					});
					document.getElementById('totalprice').value = Math.round(qtysum);
					
					$('.totalprice').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							tot += parseFloat(this.value);
						}
					});
					document.getElementById('gtotalprice').value = Math.round(tot);
					var qttotal = 0;

					$('.qty').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							qttotal += parseFloat(this.value);
						}
					});
					document.getElementById('qtyt').value = Math.round(qttotal);
					 //=====================================
					//Total GST Amount
					$('.gst').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							totgst += parseFloat(this.value);
						}
					});
					document.getElementById('totalgst').value = totgst;
					//=====================================
				   //Other Tax Total amounts
				    $('.taxrate_amount').each(function () {
						if (!isNaN(this.value) && this.value.length != 0) {
							other_taxtot += parseFloat(this.value);
						}
					});
					document.getElementById('other_tax_total_amount').value = other_taxtot;
					//===============================
					$('#paidamount').keyup(function () {

					$('#balance_amt').val($('#gtotalprice').val() - $('#paidamount').val());
				});
				});
				
			$( '#insert_form' ).on( 'submit', function ( event ) {
			event.preventDefault();
			/* Validation */
			var error = '';
			/* Creating Index WHEN Clicking Add Button Or Enter Button */
			var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
			var split_id = lastname_id.split( '_' );
			// New index
			var index = Number( split_id[ 1 ] ) ;

			$('.qty').each(function(){
				if ($( this ).val() == '') {
				$(this).closest('tr').remove();	
				}
			});
				
			var vendor = $( '#v_name' ).val();
			var bill = $( '#billno' ).val();
			//var paid = $( '#paidamount' ).val();
			var name = $( '#name_' + index ).val();
			var purch = $( '#purchprice_' + index ).val();
			var qty = $( '#qty_' + index ).val();
			var purchqty = $('#retqty_' + index).val();	
			var ledger = $('#purchase_ledger_' + index).val();	
			
			 if(qty == ''){
				 $.toast( {heading: 'Enter Quantity.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500} );error = 1;
			 } if(parseInt(qty) > parseInt(purchqty)){
				 $.toast( {heading: 'Return Quantity Canot Be Greater Than Purchase Qty.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500} );error = 1;
			 }
			
				var form_data = $( this ).serialize();
				if ( error == '' ){
				
					$.ajax({
						url: "purchase-action/purchase_return.php",
						method: "POST",
						data: form_data,
						success: function ( data ) {
						if(data == 'ok'){
						//$('#submit').hide();
						document.getElementById( "insert_form" ).reset();
						$( '#purchase' ).find( "tr:gt(0)" ).remove();
						$.toast( {heading: 'Bill Saved Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 7000,hideMethod: 'fadeOut'} );
						window.location.href="purchase-return-print1.php?bill=<?php echo $invno; ?>"; 
						}else{
						$.toast( {heading: 'Error',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1200});
						}
						}
					});
				 }
			 });
		 });
	</script>
	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
					</li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
					</li>
				</ul>
				
			</div>
		</div>
	</div>
	</div>
	
	</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
    <script src="js/mask.init.js"></script>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<!--select-->
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<?php include ('include/disable_fn.php'); ?>
    <script>
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
		$( function () {
			// Switchery
			var elems = Array.prototype.slice.call( document.querySelectorAll( '.js-switch' ) );
			$( '.js-switch' ).each( function () {
				new Switchery( $( this )[ 0 ], $( this ).data() );
			} );
			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();
			
		
			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
	</script>
	<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			</script>
<script>
			
$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
	<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
</body>

</html>