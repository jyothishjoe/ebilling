<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
$token = $_GET[ 'pro_id' ];
$result_stock = $db->prepare( "SELECT * FROM stocks WHERE pr_code = '$token' " );
$result_stock->execute();
$rows_stock = $result_stock->fetch();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>PHP Barcode Generator Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<body>
	<div class="col-md-12" style="width: 800px;">
		<h2 class="text-center"> BARCODE GENERATOR</h2>
		<form class="form-horizontal" method="post" action="barcode.php" target="_blank">
			<div class="row">
				<div class="form-group" style=" top: 125px;">
					<label class="control-label col-sm-2" for="product">Product:</label>
					<div class="col-md-10">
						<input autocomplete="OFF" type="text" class="form-control" id="name" name="name" value="<?php echo $rows_stock['pr_name']; ?>">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="product_id">Product ID:</label>
					<div class="col-md-10">
						<input autocomplete="OFF" type="text" class="form-control" id="code" name="code" value="<?php echo $rows_stock['pr_name']; ?>">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="rate">MRP Rate</label>
					<div class="col-md-10">
						<input autocomplete="OFF" type="text" class="form-control" id="mrp" name="mrp" value="<?php echo $rows_stock['pr_name']; ?>">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2" for="print_qty">Barcode Quantity</label>
					<div class="col-md-10">
						<input autocomplete="OFF" type="print_qty" class="form-control" id="print_qty" name="print_qty">
					</div>
				</div>
			</div>
			<div class="col-sm-offset-2 col-sm-10">
				<button type="submit" class="btn btn-default">Submit</button>
			</div>
		</form>
		<div class="text-right">
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
		</div>
	</div>
	<script>
		$( '#close_fbx' ).on( 'click', function () {
			parent.jQuery.fancybox.close();
		} );
	</script>
</body>

</html>