<!-- MONTHLY REPORT-->
<div class="modal fade" id="monthly_report" role="dialog">
	<div class="modal-dialog modal-sm">
		<div class="modal-content no-border-radius">
			<div class="modal-header bg-white col-black2 col-xs-12">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title text-center">MONTHLY REPORT<br></h4>
			</div>
			<div class="modal-body bg-white col-black2 col-xs-12">
				<div class="col-xs-12 no-padding">
					<form action="monthly-report.php" method="post" class="col-xs-12 form-inputs">
						<input type="hidden" value="<?php echo $current_invoice_year ?>" name="yr">
						<input type="hidden" value="<?php echo $month ?>" name="mnth">
						<ul class="col-xs-12 action-panel no-padding">
							<center><button type="submit" class="btn btn-success waves-effect text-uppercase">GO WITH <?php echo $current_invoice_year.'/'.$month; ?></button></center>
						</ul>
					</form>
					<font class="text-center col-xs-12">Or</font>
					<form action="monthly-report.php" method="post" class="col-xs-12 form-inputs" style="border:1px solid rgba(0,0,0,.1);padding-top: 0 !important;">
						<div class="col-xs-12">
							<label class="col-black2">SELECT YEAR</label>
							<select name="yr" class="selectpicker" data-show-subtext="true" data-live-search="true"  data-show-subtext="true" required>
								<option value="">-SELECT YEAR-</option>
								<?php
									$result_sales = $db->prepare("SELECT * FROM sales GROUP BY invoice_year");
									$result_sales->execute();
									for($i=0; $rows_sales = $result_sales->fetch(); $i++){
								?>
								<option value="<?php echo $rows_sales['invoice_year']; ?>" data-subtext=""><?php echo $rows_sales['invoice_year']; ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="col-xs-12">
							<label class="col-black2">SELECT MONTH</label>
							<select name="mnth" class="selectpicker" data-show-subtext="true" data-live-search="true"  data-show-subtext="true" required>
								<option value="">-SELECT MONTH-</option>
								<?php
									$result_sales = $db->prepare("SELECT * FROM sales GROUP BY invoice_month ORDER BY id");
									$result_sales->execute();
									for($i=0; $rows_sales = $result_sales->fetch(); $i++){
								?>
								<option value="<?php echo $rows_sales['invoice_month']; ?>" data-subtext=""><?php echo $rows_sales['invoice_month']; ?></option>
								<?php } ?>
							</select>
						</div>
						<ul class="col-xs-12 action-panel no-padding" style="margin-top: 1em;">
							<center><button type="submit" class="btn btn-success waves-effect">VIEW REPORT <i class="fa fa-arrow-circle-right"></i></button></center>
						</ul>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- MONTHLY REPORT 2-->
<div class="modal fade" id="monthly_report2" role="dialog">
	<div class="modal-dialog modal-sm">
		<div class="modal-content no-border-radius">
			<div class="modal-header bg-white col-black2 col-xs-12">
				<h4 class="modal-title text-center">MONTHLY REPORT<br></h4>
			</div>
			<div class="modal-body bg-white col-black2 col-xs-12">
				<div class="col-xs-12 no-padding">
					<form action="monthly-report.php" method="post" class="col-xs-12 form-inputs">
						<input type="hidden" value="<?php echo $current_invoice_year ?>" name="yr">
						<input type="hidden" value="<?php echo $month ?>" name="mnth">
						<ul class="col-xs-12 action-panel no-padding">
							<center><button type="submit" class="btn btn-success waves-effect text-uppercase">GO WITH <?php echo $current_invoice_year.'/'.$month; ?></button></center>
						</ul>
					</form>
					<font class="text-center col-xs-12">Or</font>
					<form action="monthly-report.php" method="post" class="col-xs-12 form-inputs" style="border:1px solid rgba(0,0,0,.1);padding-top: 0 !important;">
						<div class="col-xs-12">
							<label class="col-black2">SELECT YEAR</label>
							<select name="yr" class="selectpicker" data-show-subtext="true" data-live-search="true"  data-show-subtext="true" required>
								<option value="">-SELECT YEAR-</option>
								<?php
									$result_sales = $db->prepare("SELECT * FROM sales GROUP BY invoice_year");
									$result_sales->execute();
									for($i=0; $rows_sales = $result_sales->fetch(); $i++){
								?>
								<option value="<?php echo $rows_sales['invoice_year']; ?>" data-subtext=""><?php echo $rows_sales['invoice_year']; ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="col-xs-12">
							<label class="col-black2">SELECT MONTH</label>
							<select name="mnth" class="selectpicker" data-show-subtext="true" data-live-search="true"  data-show-subtext="true" required>
								<option value="">-SELECT MONTH-</option>
								<?php
									$result_sales = $db->prepare("SELECT * FROM sales GROUP BY invoice_month ORDER BY id");
									$result_sales->execute();
									for($i=0; $rows_sales = $result_sales->fetch(); $i++){
								?>
								<option value="<?php echo $rows_sales['invoice_month']; ?>" data-subtext=""><?php echo $rows_sales['invoice_month']; ?></option>
								<?php } ?>
							</select>
						</div>
						<ul class="col-xs-12 action-panel no-padding" style="margin-top: 1em;">
							<center><button type="submit" class="btn btn-success waves-effect">VIEW REPORT <i class="fa fa-arrow-circle-right"></i></button></center>
						</ul>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>