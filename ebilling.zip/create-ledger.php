<?php
include( 'include/auth.php');
include( 'db-connect/db.php');
include( 'include/today.php');
$userid = $_SESSION['SESS_USERID_AS'];
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-xs-6 col-sm-6  no-padding" style="width: 800px; overflow: hidden;">
	<h3 class="text-center">Ledger</h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" id='insert_form' class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Ledger Name</label>
				<input type="text" class="form-control" id="ledger" name="ledger" value="" placeholder="Ledger Name">
				<input type="hidden" class="form-control" id="date" name="date" value="<?php echo $today; ?>" readonly>
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>" readonly>
				<center>
					<div id="uname_response" class="response"></div>
				</center>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
			  <label for="" class="control-label">Account Group</label>
				<div class="col-12">
					<select class="form-control " id="accname" name="accname" style="width: 100%; height:36px;">
						<option></option>
						<?php		
						$result_acc = $db->prepare( "SELECT * FROM accountgroup ORDER BY name ASC" );
						$result_acc->execute();
						for ( $i = 0; $rows_acc = $result_acc->fetch(); $i++ ) {
							$accgrp = $rows_acc[ 'name' ];
							?>
						<option value="<?php echo $accgrp; ?>">
							<?php echo $accgrp; ?>
						</option>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">GSTIN</label>
				<input type="text" class="form-control" id="gstin" name="gstin" value="" placeholder="GSTIN">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">PAN No</label>
				<input type="text" class="form-control" id="pan" name="pan" value="" placeholder="Pan No">
				<input type="hidden" class="form-control" id="grouphead" name="grouphead" value="" placeholder="Pan No">
				<input type="hidden" class="form-control" id="acc_head" name="acc_head" value="" placeholder="Pan No">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Opening Balance</label>
				<input type="text" class="form-control" id="balance" name="balance" value="0" placeholder="Pan No">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Dr/Cr</label>
				<select class="form-control" name="dr" id="dr">
					<option value="Dr">Dr</option>
					<option value="Cr">Cr</option>
				</select>
			</div>
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Description</label>
				<textarea class="form-control" id="descr" name="descr" value="" placeholder="Description" required></textarea>
			</div>
		</div>
		<div class="text-right">
			<a href="javascript: save_customer()" id="submit" class="btn btn-sm  btn-info">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
		</div>
	</form>
</div>

<script>
	$( '#accname' ).change( function () {
		var accname = $( "#accname" ).val();
		$.ajax( {
			type: 'POST',
			url: 'accounts/autosearch/grouphead.php',
			data: 'accname=' + accname,
			dataType: "JSON",
			success: function ( data ) {
				$( '#grouphead' ).val( data.value );
				$( '#acc_head' ).val( data.acc );
				
			}
		} );
	} );
</script>
<script>
	$(document).ready(function(){
 	$("#ledger").focus();
    $("#accname").change(function(){
        var dr = $(this).val();

        $.ajax({
            url: 'accounts/autosearch/trans_change.php',
            type: 'post',
            data: {depart:dr},
            dataType: 'json',
            success:function(response){

                var len = response.length;

                $("#dr").empty();
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['name'];
					var old1 = 'Dr';
					var old2 = 'Cr';
                    
                    $("#dr").append("<option value='"+id+"'>"+name+"</option>");

                }
            }
        });
    });
		
		//Submit Data
		 $( window ).keydown( function ( event ) {
			if ( event.keyCode == 13 ) {
				event.preventDefault();
				//alert(index);
				document.getElementById( 'submit' ).click(); 
			}
			 if ( event.keyCode == 27 ) {
				event.preventDefault();
				//alert(index);
				parent.jQuery.fancybox.close(); 
			}
			 
		 });
		
		$( "#ledger" ).keyup( function () {
						var name = $( "#ledger" ).val().trim();
						if ( name != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'accounts/ledger_exist/ledger_name.php',
								type: 'post',
								data: {
									name: name
								},
								success: function ( response ) {
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in Use.</span>" );
										$.toast( {
									heading: 'Already In Use.',
									text: '',
									position: 'top-right',
									loaderBg: '#1FDE13',
									icon: 'error',
									hideAfter: 1500
								} );
									
									$( '#submit' ).hide( );
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
									$( '#close_fbx' ).show( );
									$( '#submit' ).show( );
									
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
		

});
	$( '#close_fbx' ).on( 'click', function (){
		parent.jQuery.fancybox.close();
	});
	
	function save_customer(){
		var accname = $( "#accname" ).val();
		var ledger = $( "#ledger" ).val();
		var gstin = $( "#gstin" ).val();
		var pan = $( "#pan" ).val();
		var dr = $( "#dr" ).val();
		var balance = $( "#balance" ).val();
		var descr = $( "#descr" ).val();
		var grouphead = $( "#grouphead" ).val();
		var acchead= $( '#acc_head' ).val();
		var company= $( '#company' ).val();
        
		if ( $( "#accname" ).val() == "" || $( "#ledger" ).val() == "" ){
			$.toast( {
				heading: 'Fill all required fields.',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 500
			});
		} else{
			$.ajax({
				type: 'POST',
				url: "accounts/account_ledger.php",
				data: "accname=" + accname + "&ledger=" + ledger + "&gstin=" + gstin + "&pan=" + pan + "&balance=" + balance + "&dr=" + dr + "&descr=" + descr + "&date=" + date + "&grouphead=" + grouphead + "&acchead=" + acchead + "&company=" + company,
				success: function ( r ) {
					$( "#respond" ).html( r );
					$.toast( {
				heading: 'Added Succeccfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#1FDE13',
				icon: 'success',
				hideAfter: 500
			} );
			 $("#ledger").focus();
			 $("input:text").val("");
				}
			} );
			
			
			return false;
		}
	}
</script>