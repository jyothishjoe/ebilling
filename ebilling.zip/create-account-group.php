<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
?>
<div class="col-xs-12 no-padding" style="width:600px; overflow: hidden;">
	<h3 class="text-center">Account Group</h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Account Group</label>
				<input type="text" class="form-control" id="accname" name="accname" value="" placeholder="Account Group">
				<input type="hidden" class="form-control" id="date" name="date" value="<?php echo $today; ?>" readonly>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Nature Of Group</label>
				<input type="text" class="form-control" id="acc" name="acc" value="" placeholder="Nature Of Group">
			</div>
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Description</label>
				<textarea class="form-control" id="descr" name="descr" value="" placeholder="Description" required></textarea>
			</div>
		</div>
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
		</div>
	</form>
</div>
<script>
	
	$( '#close_fbx' ).on( 'click', function () {
		parent.jQuery.fancybox.close();
	} );

	function save_customer() {
		var accname = $( "#accname" ).val();
		var acc = $( "#acc" ).val();
		var descr = $( "#descr" ).val();

		if ( $( "#accname" ).val() == "" || $( "#acc" ).val() == "" ) {
			$.toast( {
				heading: 'Fill all required fields.',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 4500
			} );
		} else {
			$.ajax( {
				type: 'POST',	
				url: "accounts/acc_group.php",
				data: "accname=" + accname + "&acc=" + acc + "&descr=" + descr + "&date=" + date ,
				success: function ( r ) {
					$( "#respond" ).html( r );
				}
			} );
			parent.jQuery.fancybox.close();
			$.toast( {
				heading: 'Added Succeccfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#1FDE13',
				icon: 'success',
				hideAfter: 4500
			} );
			return false;
		}
	}
</script>