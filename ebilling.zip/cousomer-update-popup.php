<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include('db-connect/db.php');
$token=$_GET['cusid'];
$result_customer = $db->prepare("SELECT * FROM customer WHERE cus_tkn='$token' ");
$result_customer->execute();
$rows_customer = $result_customer->fetch(); 
$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' ORDER BY id DESC LIMIT 1");
$result->execute();
$rows=$result->fetch();
$dateformate=$rows['dateformate'];
?>
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php");?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
</style>
<div id="custom-content"  class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; width:600px; overflow: hidden;  background-color: #f2f2f2;">
<h3 class="text-center">Update Customer</h3>
<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
  <div class="form-row">
    <?php if($dateformate == 'datechoos') { ?>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-1">
      <label for="" class="control-label">Date</label>
      <input type="date" class="form-control" id="date_" name="date_"  value="<?php echo $today;?>" required>
    </div>
    <?php } else { ?>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-1">
      <label for="" class="control-label">Date</label>
      <input type="text" class="form-control date-inputmask" id="date_" name="date_"  value="<?php echo $today;?>" required>
    </div>
    <?php } ?>
    <div class="col-md-12"></div>
    <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Account Name</label>
      <input type="text" class="form-control" name="acco_name" id="acco_name" value="<?php echo $rows_customer['acco_name']; ?>" >
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Customer Name</label>
      <input type="text" class="form-control" name="cus_name" id="cus_name" value="<?php echo $rows_customer['cus_name']; ?>">
      <div id="uname_response" class="response"></div>
    </div>
    <input type="hidden" class="form-control addby" id="addby" name="addby" value="<?php echo $userid; ?>" readonly>
    <input type="hidden" class="form-control" id="cus_no" name="cus_no" value="<?php echo $rows_customer['cus_no']; ?>" readonly>
    <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $rows_customer['id']; ?>" readonly>
    <input type="hidden" class="form-control" id="cus_tkn" name="cus_tkn" value="<?php echo $rows_customer['cus_tkn']; ?>" readonly>
    <input type="hidden" class="form-control"  id="datetym" name="datetym" value="<?php echo $current_date_time;?>" readonly>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Location</label>
      <input type="text" class="form-control" id="location" name="location"  value="<?php echo $rows_customer['location']; ?>">
    </div>
    <div class="col-md-12 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Address</label>
      <textarea class="form-control" id="address"  name="address"><?php echo $rows_customer['addres']; ?></textarea>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Contact No 1</label>
      <input type="text" class="form-control" id="contact_no1" name="contact_no1" value="<?php echo $rows_customer['contact_no1']; ?>">
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Contact No 2</label>
      <input type="text" class="form-control" id="contact_no2" name="contact_no2" value="<?php echo $rows_customer['contact_no2']; ?>">
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Credit Limit</label>
      <input type="text" class="form-control" name="credit_limit" id="credit_limit" value="<?php echo $rows_customer['credit_limit']; ?>">
    </div>
  </div>
  <div class="col-md-12" style="margin-bottom: 18px;">
    <div class="text-right"> <a href="javascript: save_customer()" class="btn btn-sm  btn-info">Update</a>
      <button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
    </div>
  </div>
</form>
<script>
				$( document ).ready( function () {

					$( "#cus_name" ).keyup( function () {
						var cus = $( "#cus_name" ).val().trim();
						if ( cus != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'creation_actions/customer/cusnamesearch.php',
								type: 'post',
								data: {
									cus: cus
								},
								success: function ( response ) {
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in Exit.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										   document.getElementById( 'location' ).value = '';
										  document.getElementById("location").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("location").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
			</script> 
<script>
			                              $( '#close_fbx' ).on( 'click', function () {
		                                  parent.jQuery.magnificPopup.close();
	                                               } );
										function save_customer() {
											var cus_name = $( "#cus_name" ).val();
											var address = $( "#address" ).val();
											var contact_no1 = $( "#contact_no1" ).val();
											var contact_no2 = $( "#contact_no2" ).val();
											var credit_limit = $( "#credit_limit" ).val();
											var location = $( "#location" ).val();
											var id = $( "#id" ).val();
											var datetym = $( "#datetym" ).val();
											var acco_name = $( "#acco_name" ).val();
											var cus_tkn = $( "#cus_tkn" ).val();
											var date_ = $( "#date_" ).val();
											var cus_no = $( "#cus_no" ).val();
											var addby = $( "#addby" ).val();
											
											
											if ( $( "#cus_name" ).val() == "" || $( "#address" ).val() == "" || $( "#contact_no1" ).val() == "" || $( "#contact_no2" ).val() == "" || $( "#credit_limit" ).val() == "" || $( "#location" ).val() == "" || $( "#acco_name" ).val() == "" ) {
												$.toast( {
													heading: 'Fill all required fields.',
													text: '',
													position: 'top-right',
													loaderBg: '#ff6849',
													icon: 'error',
													hideAfter: 4500
												} );
											} else {
												$.ajax({
												type : 'POST',
												url  : "creation_actions/customer/customer_edit.php",
												data: "cus_name="+ cus_name  + "&cus_tkn=" + cus_tkn + "&date_=" + date_ + "&cus_no=" + cus_no + "&id=" + id + "&address=" + address + "&contact_no1=" + contact_no1 + "&contact_no2=" + contact_no2 + "&credit_limit=" + credit_limit + "&location=" + location + "&datetym=" + datetym + "&acco_name=" + acco_name + "&addby=" + addby,
												success : function(r) {						
												$("#respond").html(r);
													}
												});
												parent.jQuery.magnificPopup.close();
												  window.location="customer-all.php";
												$.toast( {
													heading: 'Customer Update Succeccfully.',
													text: '',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1000
												} );
												return false;
											}
										}
									</script>