<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$date = date_create($today);
date_sub($date,date_interval_create_from_date_string("2 days"));
$date1 = date_format($date,"Y-m-d");

if(isset ($_GET['startdate'],$_GET['enddate'])){
$startdates = date_create($_GET['startdate']);
$startdates = date_format($startdates,'Y-m-d');
$enddates = date_create($_GET['enddate']);
$enddates = date_format($enddates,'Y-m-d');
}else{
$startdates = date_create($today);
$startdates = date_format($startdates,'Y-m-d');	
$enddates = date_create($today);
$enddates = date_format($enddates,'Y-m-d');	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Cash Flow Statement</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/auto/all.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor float-left">Cash Flow</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
							<li class="breadcrumb-item"><a href="accounts-home.php">Accounts</a></li>
							<li class="breadcrumb-item active">Report</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datemask.php'); ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 14px;" value="Submit"/>
											<?php if(isset ($_GET['startdate'], $_GET['enddate'])){ ?>
											<a href="cash-flow-statement.php" class="btn btn-sm btn-danger" style="margin-top:30px; font-size: 14px;">Clear&nbsp;</a>
											<?php } ?>
										</div>
									</div>
								</form>
								 <div class="table-responsive m-t-40">
									 <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>Sl.No</th>
												<th>Date</th>
												<th>Purcticulars</th>
												<th>Inflow</th>
												<th>Outflow</th>
											</tr>
										</thead>
										<tbody>
										<?php
										$sl=1;
										$result_acc_group = $db->prepare( "SELECT * FROM accountgroup a LEFT JOIN account_ledger b ON a.name=b.account_group  WHERE b.account_group='CASH IN HAND' AND company_tkn='$user_company' " );
										$result_acc_group->execute();
										for ($i = 0; $rows_acc_group = $result_acc_group->fetch(); $i++ ){
										$ledger_name=$rows_acc_group['ledger_name'];
										$ledger_token=$rows_acc_group['ledger_token'];

                                        $result_cash = $db->prepare( "SELECT * FROM transaction WHERE ledger_token='$ledger_token' AND company_tkn='$user_company' GROUP BY voucher_no  " );
										$result_cash->execute();
										for ($i = 0; $rows_cash = $result_cash->fetch(); $i++ ){
										$voucher=$rows_cash['voucher_no'];
											$credit=$rows_cash['credit_amt'];
											$debit=$rows_cash['debit_amt'];
										$result_cash1 = $db->prepare( "SELECT * FROM transaction WHERE voucher_no='$voucher' AND ledger_name !='$ledger_name' AND trans_type !='tax' AND company_tkn='$user_company' GROUP BY ledger_name " );
										$result_cash1->execute();
										$cash_count = $result_cash->rowCount();
											
										for ($i = 0; $rows_cash1 = $result_cash1->fetch(); $i++ ){	
										$ledger_name_cash=$rows_cash1['ledger_name'];
											$ledger_cash_date=$rows_cash1['trn_date'];	
											$credit_amt=$rows_cash1['credit_amt'];
											$debit_amt=$rows_cash1['debit_amt'];
											?>
										<tr>
											<td><?php echo $sl++; ?> </td>
											<td> <?php echo date('d-m-Y', strtotime($ledger_cash_date));?></td>
											<td><?php echo ucwords($ledger_name_cash); ?></td>
											<?php if($cash_count > 1){  ?>
											<td><?php if($debit_amt == 0 ){ echo $credit_amt; }else{ echo ''; } ?></td>
											<td><?php if($credit_amt == 0 ){ echo $debit_amt; }else{ echo ''; }  ?></td>
											<?php }else{ ?>
											<td><?php if($debit != 0 ){ echo $debit; }else{ echo ''; } ?></td>
											<td><?php if($credit != 0 ){ echo $credit; }else{ echo ''; }  ?></td>
											<?php } ?>
										</tr>
										<?php } } }?>
										</tbody>
										<tfoot>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			<footer class="footer"> � 2019 Admin Pro by wrappixel.com </footer>
		</div>
	</div>
		<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<?php include ('include/disable_fn.php'); ?>

	<script>
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			searching : true,
			fixedHeader: true,
			paging: true,
			info: true,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
			
		} );
		var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	</script>
	

	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>