<?php
include( 'include/auth.php');
include( 'db-connect/db.php');
include( 'include/today.php');
$userid = $_SESSION['SESS_USERID_AS'];
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-xs-6 col-sm-6  no-padding" style="width: 800px; overflow: hidden;">
  <h3 class="text-center">Vendor Payment</h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" id='insert_form' class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
			  <label for="" class="control-label">Vendor Name</label>
					<select class="form-control " id="vendor" name="vendor" >
						<option></option>
						<?php		
						$result_acc = $db->prepare( "SELECT * FROM supplier WHERE company_tkn='$user_company' ORDER BY v_name ASC" );
						$result_acc->execute();
						for ( $i = 0; $rows_acc = $result_acc->fetch(); $i++ ) {
							$accgrp = $rows_acc[ 'v_name' ];
							$supplier_token = $rows_acc[ 'supplier_token' ];
							?>
						<option value="<?php echo $supplier_token; ?>">
							<?php echo $accgrp; ?>
						</option>
						<?php } ?>
					</select>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Bills</label>
				<select class="form-control" name="bills" id="bills">
					<option>Select Bill</option>
				</select>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Total Amount</label>
				<input type="text" class="form-control" id="totalamount" name="totalamount" value="" placeholder="Total Balance" readonly>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Amount</label>
				<input type="text" class="form-control" id="amount" name="amount" value="" placeholder="Amount">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Balance</label>
				<input type="text" class="form-control" id="amountbalance" name="amountbalance" value="" placeholder="Balance" readonly>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Pay Mode</label>
				<select class="form-control" name="pay" id="pay">
					<option value="cash">Cash</option>
					<option value="bank">Bank</option>
				</select>
			</div>
		<div class="col-md-12" style="margin-bottom: 8px; margin-top: 8px;">	
		<div class="text-right" >
			<a href="javascript: save_customer()" id="submit" style="float: right;" class="btn btn-sm  btn-info">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
			</div>
		</div>
	</form>
</div>

<script>
	$(document).ready(function(){
 	$("#ledger").focus();
   $("#vendor").change(function(){
        var token = $(this).val();
	   
        $.ajax({
            url: 'vendor-action/vendor-balance/vendor-bills.php',
            type: 'post',
            data: {token:token},
            dataType: 'json',
            success:function(response){

                var len = response.length;

                //$("#bills").empty();
                for( var i = 0; i<len; i++){
                    var inv = response[i]['inv'];
                    
                    $("#bills").append("<option value='"+inv+"'>"+inv+"</option>");

                }
            }
        });
    });
		//balance amount 
		
		$('#bills').change(function (){
			var token = $("#bills").val();
			$.ajax({
				type: 'POST',
				url: 'vendor-action/vendor-balance/balance-fetch.php',
				data: 'token=' + token,
				dataType: "JSON",
				success: function (data){
					$('#totalamount').val(data.balance);
				}
			});
		});
	
		
		//Submit Data
		 $( window ).keydown( function ( event ){
			if ( event.keyCode == 13 ) {
				event.preventDefault();
				//alert(index);
				document.getElementById( 'submit' ).click(); 
			}
			 if ( event.keyCode == 27 ) {
				event.preventDefault();
				//alert(index);
				parent.jQuery.fancybox.close(); 
			}
			 
		 });
		
		$("#ledger").keyup( function () {
						var name = $( "#ledger" ).val().trim();
						if ( name != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'accounts/ledger_exist/ledger_name.php',
								type: 'post',
								data: {
									name: name
								},
								success: function ( response ) {
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in Use.</span>" );
										$.toast( {
									heading: 'Already In Use.',
									text: '',
									position: 'top-right',
									loaderBg: '#1FDE13',
									icon: 'error',
									hideAfter: 1500
								} );
									
									$( '#submit' ).hide();
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
									$( '#close_fbx' ).show( );
									$( '#submit' ).show( );
									
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
		

});
		//balance calc
		$('#amount').keyup(function (){
			
		$('#amountbalance').val($('#totalamount').val() - $('#amount').val());
		//$("#amountbalance").val()= $('#totalamount').val() - $("#amountbalance").val();
		});
	$('#close_fbx').on( 'click', function (){
		parent.jQuery.fancybox.close();
	});
	
	function save_customer(){
		var vendor = $( "#vendor" ).val();
		var amount = $( "#amount" ).val();
		var bills = $( "#bills" ).val();
		var pay = $( "#pay" ).val();
		
		console.log(pay);
		var amountbalance = $( "#amountbalance" ).val();
		
		
        
		if ( $( "#accname" ).val() == "" || $( "#ledger" ).val() == "" ){
		$.toast( {heading: 'Fill all required fields.', text: '', position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 500});
		}else{
			$.ajax({
				type: 'POST',
				url: "vendor-action/vendor-payment.php",
				data: "pay=" + pay + "&vendor=" + vendor + "&amount=" + amount + "&bills=" + bills + "&amountbalance=" + amountbalance,
				success: function ( r ) {
				$( "#respond" ).html( r );
				$.toast({heading: 'Payment updated.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'success',hideAfter: 1500});
				setTimeout(parent.jQuery.fancybox.close(), 3000);
			}
		});
		return false;
		}
	}
</script>