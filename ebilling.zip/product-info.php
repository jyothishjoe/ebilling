<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$stock_tkn=trim($_GET['product_id']);
$user_company = $_SESSION['SESS_COMPANY_ID'];


$result_company = $db->prepare("select * FROM company WHERE  c_token='$user_company' ");
$result_company->execute();
$rows_company = $result_company->fetch();
$company_name = $rows_company['c_company_name'];
$logo = $rows_company['c_logo'];


$result_stock = $db->prepare("select *  FROM stocks WHERE  stock_tkn='$stock_tkn'  AND company_tkn='$user_company' ");
$result_stock->execute();
$rows_stock = $result_stock->fetch();
$product_name = $rows_stock['pr_name'];

?>
<!doctype html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor float-left">Product Info</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php.php">Home</a></li>
							</li>
							<li class="breadcrumb-item"><a href="inventory-home.php">Inventory</a></li>
							<li class="breadcrumb-item active">Stock</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">	
							<div class="card-body">
								<div class="col-md-12">
								<a href="stock-report.php" style="float: right;" id="close_fbx" class="btn btn-sm btn-info"><i class="fa fa-backward" aria-hidden="true"></i>   Back</a>	
								</div>
								 <div class="table-responsive m-t-0">
 									 <table id="tbl_with_fxd_head" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
									<thead style="font-size: 14px; text-align: center; margin-bottom: 18px;">
									<tr style=" font-size: 15px;  margin-bottom: 18px; border-bottom: 1px 
									#000000">
										<th colspan="6">
											<img src="assets/images/company_logo/<?php echo $logo; ?>" style="width:100px; height:100px; position: absolute; left:28px; margin-bottom: 10px;">
											<center><br>
											<center><h4><b><?php echo $company_name; ?></b></h4></center>
											<h5 style="margin:0px;"><?php echo $rows_company['c_shopaddress']; ?>, <?php echo $rows_company['address_sec']; ?></h5><br>
												<?php echo $rows_company['c_phone']; ?>
										</th>
									</tr>
									</thead>
									<thead style="text-align: right">
									<tr style="font-family: Times New Roman">
										<th colspan="6"  style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px; margin-left: 15px; margin-bottom: 15px; float: left;'> Name : <?php echo"".ucwords(strtolower($product_name)); ?></b><br>
										</th>
										
										<!--<th colspan="3" align="center" style="border-bottom: 1px solid grey;">
											<b style='font-size: 16px;'>Balance Amount :  <?php echo $amount_balance; ?> ₹</b><br>
										</th>-->
									</tr>
									</thead>
										<thead style="font-weight: 600px; text-align: left">
											<tr>
											    
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Date</strong></th>
												<th style="border-bottom: 1px solid grey; width: 35%"><strong>Purcticulars</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Qty</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Party</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Unit Rate</strong></th>
												<th style="border-bottom: 1px solid grey; width: 15%"><strong>Total Cost</strong></th>
											</tr>
										</thead>
										<!--===sales===-->
                                    	<tbody>
										<?php
										$result_stock = $db->prepare("SELECT SUM(qty) AS total_qty, rate AS rate, amount AS amount , sales_invono AS sales_invono, sales_invodate  AS sales_invodate  FROM sales_invoice_prdct_detail  WHERE stock_tkn = '$stock_tkn' GROUP BY sales_invono  ");
										$result_stock ->execute(); 
										$sl = 1;
										for ($i=0; $rows_stock  = $result_stock ->fetch(); $i++){	
										$sales_invono = $rows_stock['sales_invono'];
										$result_cust = $db->prepare("SELECT * FROM sales_invoice  WHERE sales_invono = '$sales_invono' ");
										$result_cust ->execute(); 
										$sl = 1;
										for ($i=0; $rows_cust  = $result_cust ->fetch(); $i++){	
										?>
									<tr>		
										<td><?php echo $rows_stock['sales_invodate']; ?></td>
										<td>Sales</td>
										<td><?php echo $rows_stock['total_qty']; ?></td>
										<td><?php echo $rows_cust['cus_name']; ?></td>	
										<td><?php echo $rows_stock['rate']; ?></td>
										<td><?php echo $rows_stock['amount']; ?></td>
									</tr>
									<?php } } ?>
									<!--===Sales Return===-->
									<?php
										$result_stock_re = $db->prepare("SELECT SUM(rtn_qty) AS total_qty, rtn_rate AS rate, rtn_grand_tot AS amount , sales_rtnno AS sales_rtnno, sales_rtndate  AS sales_rtndate  FROM sales_rtn_prdct_details  WHERE stock_tkn = '$stock_tkn' GROUP BY sales_rtnno  ");
										$result_stock_re ->execute(); 
										$sl = 1;
										for ($i=0; $rows_stock_re  = $result_stock_re ->fetch(); $i++){	
										$sales_rtnno = $rows_stock_re['sales_rtnno'];

										$result_cust_re = $db->prepare("SELECT * FROM sales_rtn_invoice  WHERE sales_rtnno = '$sales_rtnno' ");
										$result_cust_re ->execute(); 
										$sl = 1;
										for ($i=0; $rows_cust_re  = $result_cust_re ->fetch(); $i++){	
										?>
									<tr>		
										<td><?php echo $rows_stock_re['sales_invodate']; ?></td>
										<td>Sales</td>
										<td><?php echo $rows_stock_re['total_qty']; ?></td>
										<td><?php echo $rows_cust_re['custmr_name']; ?></td>	
										<td><?php echo $rows_cust_re['rate']; ?></td>
										<td><?php echo $rows_cust_re['amount']; ?></td>
									</tr>
									<?php } } ?>
										<!--===Purchase===-->
										<?php
										$result_stock1 = $db->prepare("SELECT SUM(qty) AS total_qty, purch_price AS rate, gross AS amount , sup_token AS sup_token, bill_date  AS bill_date  FROM purchase_productdetails  WHERE stock_tkn = '$stock_tkn' GROUP BY invoice  ");
										$result_stock1 ->execute(); 
										$sl = 1;
										for ($i=0; $rows_stock1  = $result_stock1 ->fetch(); $i++){	
										$sup_token = $rows_stock1['sup_token'];
										$result_purch = $db->prepare("SELECT * FROM supplier  WHERE supplier_token = '$sup_token' ");
										$result_purch ->execute(); 
										$sl = 1;
										for ($i=0; $rows_purch  = $result_purch ->fetch(); $i++){	
										?>
									<tr>		
										<td><?php echo $rows_stock1['bill_date']; ?></td>
										<td>Purchase</td>
										<td><?php echo $rows_stock1['total_qty']; ?></td>
										<td><?php echo $rows_purch['v_name']; ?></td>	
										<td><?php echo $rows_stock1['rate']; ?></td>
										<td><?php echo $rows_stock1['amount']; ?></td>
									</tr>
									<?php } } ?>
									<!--===Purchase Return===-->
										<?php
										$result_stock1 = $db->prepare("SELECT SUM(qty) AS total_qty, purch_price AS rate, gross AS amount , sup_token AS sup_token, bill_date  AS bill_date  FROM purchasereturn_productdetails  WHERE stock_tkn = '$stock_tkn' GROUP BY invoice  ");
										$result_stock1 ->execute(); 
										$sl = 1;
										for ($i=0; $rows_stock1  = $result_stock1 ->fetch(); $i++){	
										$sup_token = $rows_stock1['sup_token'];
										$result_purch = $db->prepare("SELECT * FROM supplier  WHERE supplier_token = '$sup_token' ");
										$result_purch ->execute(); 
										$sl = 1;
										for ($i=0; $rows_purch  = $result_purch ->fetch(); $i++){	
										?>
									<tr>		
										<td><?php echo $rows_stock1['bill_date']; ?></td>
										<td>Purchase</td>
										<td><?php echo $rows_stock1['total_qty']; ?></td>
										<td><?php echo $rows_purch['v_name']; ?></td>	
										<td><?php echo $rows_stock1['rate']; ?></td>
										<td><?php echo $rows_stock1['amount']; ?></td>
									</tr>
									<?php } } ?>
									<!--<tfoot>
										<tr>
											<td></td>
											<td></td>
											<td></td>
											<td></td>
											<td style="font-size: 15px;" align="right"><b>Total Amount</b></td>
											<td><b>100</b></td>
										</tr>
									</tfoot>-->
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b> </li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
				</ul>
				
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
		<script>
			$(document).ready(function() {
    $('.open-popup-link').magnificPopup({
        type: 'iframe',
        alignTop: 'true',
		closeOnBgClick: 'false',
		overflowY: 'scroll',

   
       
    });
  });
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: true,
					closeOnBgClick: false,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
			$( function () {

					// For select 2
					$( ".select2" ).select2();
					$( '.selectpicker' ).selectpicker();


					$( ".ajax" ).select2( {
						ajax: {
							url: "https://api.github.com/search/repositories",
							dataType: 'json',
							delay: 250,
							data: function ( params ) {
								return {
									q: params.term, // search term
									page: params.page
								};
							},
							processResults: function ( data, params ) {
								// parse the results into the format expected by Select2
								// since we are using custom formatting functions we do not need to
								// alter the remote JSON data, except to indicate that infinite
								// scrolling can be used
								params.page = params.page || 1;
								return {
									results: data.items,
									pagination: {
										more: ( params.page * 30 ) < data.total_count
									}
								};
							},
							cache: true
						},
						escapeMarkup: function ( markup ) {
							return markup;
						}, // let our custom formatter work
						minimumInputLength: 1,
						//templateResult: formatRepo, // omitted for brevity, see the source of this page
						//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
					} );
				} );
			</script>
			<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
			<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
			<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
			<script src="js/perfect-scrollbar.jquery.min.js"></script>
			<script src="js/waves.js"></script>
			<script src="js/sidebarmenu.js"></script>
			<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
			<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
			
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
			<script src="js/custom.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
			<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
			<script src="js/toastr.js"></script>
			<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
			<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
			<?php include ('include/disable_fn.php'); ?>
</body>

</html>
</html>