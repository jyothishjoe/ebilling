<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
if(isset ($_GET['printer_size'])){
	$printer_width = $_GET['printer_size'];
  if( $printer_width=='a4'){$printerlabel='21cm';} else if( $printer_width=='b5') {$printerlabel='17.6cm';}  else if( $printer_width=='c6') {$printerlabel='16.2cm';}  else if( $printer_width=='a5') {$printerlabel='14.8cm';}  else if( $printer_width=='b6') {$printerlabel='12.5cm';}  else if( $printer_width=='a6') {$printerlabel='10.5cm';}  else if( $printer_width=='b7') {$printerlabel='8.8cm';}  else if( $printer_width=='80mm') {$printerlabel='8cm';}  else if( $printer_width=='a7') {$printerlabel='7.4cm';}  else if( $printer_width=='b8') {$printerlabel='6.2cm';}  else if( $printer_width=='a8') {$printerlabel='5.2cm';}  else if( $printer_width=='b9') {$printerlabel='4.4cm';}  else if( $printer_width=='a9') {$printerlabel='3.7cm';}  else if( $printer_width=='b10') {$printerlabel='3.1cm';}  else if( $printer_width=='a10') {$printerlabel='2.6cm';} else if( $printer_width=='') {$printerlabel='--Select--';} 
} else{
  $printerlabel='--Select--'; $printer_width='';
}

?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
</style>
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<div class="col-xs-12 no-padding" style=" overflow: hidden;">
  <h3 class="text-center avoidtext">Paper Width</h3>
   <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
    <div class="form-row">
      <div class="col-md-2 col-sm-6 col-xs-12 avoidtext  mb-3">
        <label for="" class="control-label">Choose Paper Width</label>
		  <input type="hidden" name="company" id="company" value="<?php echo $user_company; ?>">
        <select class="form-control" id="printer_size" name="printer_size" style="width: 100%; height:36px;">
          <option value="<?php echo $printer_width;?>"><?php echo $printerlabel;?></option>
          <option value="a4">21 cm</option>
          <option value="b5">17.6 cm </option>
          <option value="c6">16.2 cm </option>
          <option value="a5">14.8 cm </option>
          <option value="b6">12.5 cm</option>
          <option value="a6">10.5 cm</option>
          <option value="b7">8.8 cm</option>
          <option value="80mm">8 cm</option>
          <option value="a7">7.4 cm</option>
          <option value="b8">6.2 cm</option>
          <option value="a8">5.2 cm</option>
          <option value="b9">4.4 cm</option>
          <option value="a9">3.7 cm</option>
          <option value="b10">3.1 cm</option>
          <option value="a10">2.6 cm</option>
        </select>
        
      </div>
     <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
     	 <label for="" class="control-label" style="margin-top:45px; "></label>
     <input type="submit" class="btn btn-sm btn-info Preview" style="font-size: 15px;" value ="Preview">
      </div> </div> </form>

      <?php if(isset ($_GET['printer_size'])){?>

<style>
table td {
  height: 15px;
}
 @media print {
.btn {
  display: none;
}
}
.hr {
  border: none;
  border-top: 1px dashed black;
  margin-top:10px;
}
body { font-family:sans-serif !important;}
 <?php if( $printer_width=='a4') { ?>
  table {
  border-collapse: collapse; font-size: 13px !important; font-family:sans-serif !important;
}
table h3{ margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:21cm !important;padding:2em 1em !important;margin:1cm auto 2cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important;}
@page{size:a4;margin:auto;}
@media print{
.printwidth{margin:auto;padding-top:0 !important; border:initial;border-radius:initial;width:initial;min-height:initial;box-shadow:initial;background:initial;page-break-after:always;visibility:visible;}
.avoidtext{display: none; }
}
<?php }  else if( $printer_width=='b5') { ?>
 table {
  border-collapse: collapse; font-size: 13px !important; font-family:sans-serif !important;
}
table h3{ margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:17.6cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:b5;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} <?php } else if( $printer_width=='c6') { ?>
 table {
  border-collapse: collapse; font-size: 13px !important; font-family:sans-serif !important;
}
table h3{font-size: 25px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:16.2cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:162mm;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} <?php }  else if( $printer_width=='a5') { ?>
 table {
  border-collapse: collapse; font-size: 12px !important; font-weight: 400px; font-family:sans-serif !important;
}
table h3{font-size: 23px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 50px ;}
.printwidth{width:14.8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:a5;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} 
<?php } else if( $printer_width=='b6') { ?>
 table {
  border-collapse: collapse; font-size: 12px !important; font-weight: 400px; font-family:sans-serif !important;
}
table h3{font-size: 20px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 180px;}
#address{width: 50%;}
#firsttable{margin-top: 50px ;}
.printwidth{width:12.5cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:125mm;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} 
<?php } else if( $printer_width=='a6') { ?>
 table { 
  border-collapse: collapse; font-size: 11px !important; font-family:sans-serif !important;
}
table h3{font-size: 20px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 180px;}
#address{width: 50%;}
#firsttable{margin-top: 50px ;}
table th { font-size: 14px !important; }
.printwidth{width:10.5cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:a6;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} 
<?php }  else if( $printer_width=='b7') { ?>
table {
  border-collapse: collapse; font-size: 11px !important; font-family:sans-serif !important;
}
table th { font-size: 14px !important; }
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: auto; float: left !important;}
#address{width: auto; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:8.8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden; }
@page{size:88mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} <?php } else if( $printer_width=='80mm') { ?>
table {
  border-collapse: collapse; font-size: 11px !important; font-family:sans-serif !important;
}
table th { font-size: 14px !important; }
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: auto; float: left !important;}
#address{width:auto; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden; }
@page{size:80mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
.avoidtext{display: none; }
} <?php } else if( $printer_width=='a7') {?>
table {
  border-collapse: collapse; font-size: 11px !important; font-weight: 300; font-family:sans-serif !important;
}
table th { font-size: 13px !important; }
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width:auto; float: left !important;}
#address{width: auto; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:7.4cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;}
@page{size:74mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} 
.avoidtext{display: none; }
}
<?php }  else if( $printer_width=='b8') {?>
table {
  border-collapse: collapse; font-size: 11px !important; font-weight: 100; font-family:sans-serif !important;
}
table th { font-size: 13px !important; }
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:6.2cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;}
@page{size:62mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} 
.avoidtext{display: none; }
}
<?php } else if( $printer_width=='a8') { ?>
table {
  border-collapse: collapse; font-size: 11px !important; font-weight: 400;  font-family:sans-serif !important; font-family:sans-serif !important;
}
table th { font-size: 13px !important; }
table h3{ font-size: 16px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:5.2cm !important;padding:50em 50em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:52mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } else if( $printer_width=='b9') { ?>
table {
  border-collapse: collapse; font-size: 11px !important; font-weight: 500;  font-family:sans-serif !important;
}
table th { font-size: 12px !important;  color:black;}
table h3{ font-size: 16px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:4.4cm !important;padding:50em 50em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:44mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php }  else if( $printer_width=='a9') { ?>
table {
  border-collapse: collapse; font-size: 10px !important; color:black;  font-weight: 300; font-family:sans-serif !important;
}
table th { font-size: 10px !important; }
table h3{ font-size: 14px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 80px ;}
.printwidth{width:3.7cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:37mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} 
.avoidtext{display: none; }
}
<?php }  else if( $printer_width=='b10') { ?>
table {
  border-collapse: collapse; font-size: 9px !important; color:black;  font-weight: 500; font-family:sans-serif !important;
}
table th { font-size: 10px !important; }
table h3{ font-size: 14px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 60px ;}
.printwidth{width:3.1cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:37mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } else if( $printer_width=='a10') { ?>
table {
  border-collapse: collapse; font-size: 7.5px !important; color:black;  font-weight: 400; font-family:sans-serif !important;
}
table th { font-size: 10px !important; }
table h3{ font-size: 14px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 60px ;}
.printwidth{width:2.6cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:26mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php }  else if($printer_width=='' ) { ?>
   .billheader, #address,#datetym, #firsttable, #sub{display: none; } 
   @media print{  #noprint{display: none !important;} }
<?php }  ?>
@media print{
.avoidtext{display: none; }
}
</style>
<div class="row">
  <div class=" col-xs-12 printwidth" style="padding:0px 50px;">
    <table style="text-align:center;" width="100%" border="0" class="billheader">
      <tr>
        <th> <h3>Supermarket</h3></th>
      </tr>
      <tr>
        <td>Palakkad</td>
      </tr>
      <tr>
        <td>Ph: 8137010256, Mob: 9865320123</td>
      </tr>
      <tr>
        <th>Sales Invoice</th>
      </tr>
    </table>
    <table style="text-align:left;float:left;" border="0" id ="address">
      <tr>
        <div class="col-md-12" style="padding-bottom: 8px;"></div>
        <td><b>Sold To : Customer Name</td>
      </tr>
      <tr>
        <td>Customer Address<br></td>
      </tr>
      <tr>
        <td>6767676768</td>
      </tr>
      <tr> </tr>
    </table>
    <table style="float:right;text-align:left;" border="0" id="datetym">
      <tr>
        <td><b>Date :</b></td>
        <td>2019-07-26</td>
      </tr>
      <tr>
        <td><b>Bill No :</b></td>
        <td>SAC12345678901</td>
      </tr>
      <tr>
        <td><b>S.Order No:</b></td>
        <td>SAC12345678901</td>
      </tr>
     </table>
  
   <?php  if( $printer_width == ''){?><div id="noprint" style="text-align:center !important; position:relative; color:red; font-size:15px; margin-left:600px !important;">Select Correct Paper width</div><?php }else if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
 <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="30%" style="text-align:left !important;"> Product Name</th>
          <th rowspan="2" width="14%" > Qty</th>
          <th rowspan="2" width="14%" > Rats</th>
          <th rowspan="2" width="14%" >Mrp</th>
          <th rowspan="2" width="14%" >Gst%</th>
		  <th rowspan="2" width="14%" >Cess%</th>
          <th rowspan="2" width="14%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
          <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>   
        <tr>
          <td align="left">Tomato sauce</td>
          <td align="center">1</td>
          <td align="center">39</td>
          <td align="center">40</td>
          <td align="center">12</td>
		  <td align="center">0</td>
          <td align="center">39</td>
        </tr>
         <tr>
          <td align="left">Red-wine vinegar</td>
          <td align="center">2</td>
          <td align="center">500</td>
          <td align="center">500</td>
          <td align="center">28</td>
		  <td align="center">5</td>
          <td align="center">1000</td>
        </tr>
         <tr>
          <td align="left">Mustard</td>
          <td align="center">4</td>
          <td align="center">15</td>
          <td align="center">15</td>
          <td align="center">5</td>
		  <td align="center">3</td>
          <td align="center">60</td>
        </tr>
        <tr>
          <td align="left">Brown rice</td>
          <td align="center">4</td>
          <td align="center">300</td>
          <td align="center">300</td>
          <td align="center">18</td>
		  <td align="center">0</td>
          <td align="center">1200</td>
        </tr>
    <tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
     <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="6">Gst Included  </td>
        </tr>
        <tr>
      <td></td>
          <td  align="left" colspan="2">Sgst 14%</td>
          <td  align="center">150</td>
          <td  align="left" colspan="2">Cgst 14%</td>
          <td  align="center">150</td>
        </tr>
        <tr>
      <td></td>
        <td  align="left" colspan="2">Sgst 9%</td>
        <td  align="center">160</td>
        <td  align="left" colspan="2">Cgst 9%</td>
        <td  align="center">160</td>
      </tr>
      <tr>
      <td></td>
        <td  align="left" colspan="2">Sgst 6%</td>
        <td  align="center">180</td>
        <td  align="left" colspan="2">Cgst 6%</td>
        <td  align="center">180</td>
      </tr>
      <tr>
      <td></td>
        <td  align="left" colspan="2">Sgst 2.5%</td>
        <td  align="center">55</td>
        <td  align="left" colspan="2">Cgst 2.5%</td>
        <td  align="center">55</td>
      </tr>
	<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>  
   <tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
	   <tr>
	   <td></td>
        <td  align="left" colspan="5">Cess 5% </td> <td align="center"> 55.43</td> 
		</tr>
		<tr>
		<td></td>
        <td  align="left" colspan="5">Cess 3% </td><td align="center"> 55.43</td>
      </tr>
   <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr>
        <td>Gst Total  </td><td></td><td></td><td></td><td></td><td></td><td  align="center">300.00</td>
      </tr>
    <tr>
	<tr>
        <td colspan="6">Gst Cess Total  </td><td  align="center">111.00</td>
      </tr>
    <tr>
        <th><b> Grand Total</b> </th><th></th><th></th><td align="center">4</td><th></th><td></td><td   align="center"><b>5000.00</b></td>
      </tr>
      <tr>
    <td colspan="6">Counter  # c1/ name /11:16:59 </td>
      </tr>
      <tr>
        <td  colspan="6">E & OE </td>
      </tr>
      <tr>
        <td  colspan="6">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="6">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
<?php } else if( $printer_width == 'b7' || $printer_width == '80mm' || $printer_width == 'a7'  || $printer_width == 'b8') {?>

    <table border="0" width="100%" id="firsttable">
      <thead>
        <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="21%" > Rats</th>
          <th rowspan="2" width="16%" >Mrp</th>
          <th rowspan="2" width="21%" >Gst%</th>
		  <th rowspan="2" width="14%" >Cess%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
    <tr><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td colspan="5">Tomato sauce</td>
        </tr>
        <tr>
         <td align="center">1</td>
          <td align="center">39</td>
          <td align="center">40</td>
          <td align="center">12</td>
		   <td align="center">0</td>
          <td align="center">39</td>
        </tr>
       <tr>
          <td colspan="5">Red-wine vinegar</td>
        </tr>
        <tr>
          <td align="center">2</td>
          <td align="center">500</td>
          <td align="center">500</td>
          <td align="center">28</td>
		   <td align="center">5</td>
          <td align="center">1000</td>
        </tr>
         <tr>
          <td colspan="5">Mustard</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">15</td>
          <td align="center">15</td>
          <td align="center">5</td>
		   <td align="center">3</td>
          <td align="center">60</td>
        </tr>
         <tr>
          <td colspan="5">Brown rice</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">300</td>
          <td align="center">300</td>
          <td align="center">18</td>
		   <td align="center">0</td>
          <td align="center">1200</td>
        </tr>
    <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="6">Gst Included  </td>
        </tr>
        <tr>
		<td></td>
          <td  align="left" colspan="3">Sgst 14% - 150</td>
          <td  align="left" colspan="3">Cgst 14% - 150</td>
        </tr>
      <tr>
	  <td></td>
        <td  align="left" colspan="3">Sgst 9% - 160</td>
        <td  align="left" colspan="3">Cgst 9% - 160</td>
      </tr>
      <tr>
	  <td></td>
        <td  align="left" colspan="3">Sgst 6% - 180 </td>
        <td  align="left" colspan="3">Cgst 6% - 180</td>
      </tr>
      <tr>
	  <td></td>
        <td  align="left" colspan="3">Sgst 2.5% - 55.43</td>
        <td  align="left" colspan="3">Cgst 2.5% - 55.43</td>
      </tr>
	  <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
     <tr>
	 <td></td>
        <td  align="left" colspan="4">Cess 5% </td><td align="center"> 55.43</td>
		</tr>
		<tr>
		<td></td>
        <td  align="left" colspan="4">Cess 3% </td><td align="center"> 55.43</td>
      </tr>
   <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr>
        <td colspan="3">Gst Total  </td><td></td><td></td><td  align="center">300.00</td>
      </tr>
    <tr>
        <td colspan="5">Gst Cess Total  </td><td  align="center">111.00</td>
      </tr>
    <tr>
        <th colspan="3"> Grand Total </th><td align="center">4</td><th></th><td   align="center"><b>5000.00</b></td>
      </tr>
      <tr>
    <td  colspan="6">Counter  # c1 / name / 11:16:59</td>
      </tr>
      <tr>
        <td  colspan="6">E & OE </td>
      </tr>
      <tr>
        <td  colspan="6">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="6">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } else if ( $printer_width == 'a8' || $printer_width == 'b9') { ?>
  
    <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="16%" >Mrp</th>
          <th rowspan="2" width="21%" >Gst%</th>
		  <th rowspan="2" width="14%" >Cess%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
    <tr><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td colspan="5">Tomato sauce</td>
        </tr>
        <tr>
         <td align="center">1</td>
          <td align="center">40</td>
          <td align="center">12</td>
		   <td align="center">0</td>
          <td align="center">39</td>
        </tr>
       <tr>
          <td colspan="5">Red-wine vinegar</td>
        </tr>
        <tr>
          <td align="center">2</td>
          <td align="center">500</td>
          <td align="center">28</td>
		   <td align="center">5</td>
          <td align="center">1000</td>
        </tr>
         <tr>
          <td colspan="4">Mustard</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">15</td>
          <td align="center">5</td>
		   <td align="center">3</td>
          <td align="center">60</td>
        </tr>
         <tr>
          <td colspan="4">Brown rice</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">300</td>
          <td align="center">18</td>
		   <td align="center">0</td>
          <td align="center">1200</td>
        </tr>
    <tr><td></td><td></td><td></td><td></td><td></td></tr>
        
    <tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="5">Gst Included  </td>
        </tr>
        <tr>
          <td  align="left" colspan="4">Sgst 14%  </td><td align="center">150</td>
		  </tr>
		  <tr>
          <td  align="left" colspan="4">Cgst 14% </td><td align="center"> 150</td>
        </tr>
      <tr>
        <td  align="left" colspan="4">Sgst 9% </td><td align="center"> 160</td>
		</tr>
		  <tr>
        <td  align="left" colspan="4">Cgst 9% </td><td align="center"> 160</td>
      </tr>
      <tr>
        <td  align="left" colspan="4">Sgst 6% </td><td align="center"> 180 </td>
		</tr>
		<tr>
        <td  align="left" colspan="4">Cgst 6% </td><td align="center"> 180</td>
       
      </tr>
      <tr>
        <td  align="left" colspan="4">Sgst 2.5% </td><td align="center"> 55.43</td>
		</tr>
		<tr>
        <td  align="left" colspan="4">Cgst 2.5% </td><td align="center"> 55.43</td>
      </tr>
	  <tr><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
   <tr>
          <td  colspan="5">Other Tax Included  </td>
        </tr>
	 <tr>
        <td  align="left" colspan="4">Cess 5% </td><td align="center"> 55.43</td>
		</tr>
		<tr>
        <td  align="left" colspan="4">Cess 3% </td><td align="center"> 55.43</td>
      </tr> 
	  
   <tr><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
      <tr>
        <td colspan="4">Gst Total  </td><td  align="center">300.00</td>
      </tr>
     <tr>
        <td colspan="4">Gst Cess Total  </td><td  align="center">111.00</td>
      </tr>
    <tr>
        <th colspan="2"> Grand Total </th><td align="center">4</td><td></td><td   align="center"><b>5000.00</b></td>
      </tr>
      <tr>
    <td  colspan="5">Counter  # c1 / name / 11:16:59</td>
      </tr>
      <tr>
        <td  colspan="5">E & OE </td>
      </tr>
      <tr>
        <td  colspan="5">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="5">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } else { ?>
   <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="25%" > Qty</th>
          <th rowspan="2" width="25%" >Mrp</th>
		  <th rowspan="2" width="25%" >Tax%</th>
          <th rowspan="2" width="25%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
	  <tr><td></td><td></td><td></td><td></td></tr>
       <tr>
          <td colspan="5">Tomato sauce</td>
        </tr>
        <tr>
         <td align="center">1</td>
          <td align="center">40</td>
          <td align="center">12</td>
          <td align="center">39</td>
        </tr>
       <tr>
          <td colspan="5">Red-wine vinegar</td>
        </tr>
        <tr>
          <td align="center">2</td>
          <td align="center">500</td>
          <td align="center">33</td>
          <td align="center">1000</td>
        </tr>
         <tr>
          <td colspan="4">Mustard</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">15</td>
          <td align="center">8</td>
          <td align="center">60</td>
        </tr>
         <tr>
          <td colspan="4">Brown rice</td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td align="center">300</td>
          <td align="center">18</td>
          <td align="center">1200</td>
        </tr>
		<tr><td></td><td></td><td></td><td></td></tr>
        
		<tr class="hr"><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="6">Gst Included  </td>
        </tr>
		
         <tr>
          <td  align="left" colspan="3">Sgst 14%  </td><td align="center">150</td>
		  </tr>
		  <tr>
          <td  align="left" colspan="3">Cgst 14% </td><td align="center"> 150</td>
        </tr>
      <tr>
        <td  align="left" colspan="3">Sgst 9% </td><td align="center"> 160</td>
		</tr>
		  <tr>
        <td  align="left" colspan="3">Cgst 9% </td><td align="center"> 160</td>
      </tr>
      <tr>
        <td  align="left" colspan="3">Sgst 6% </td><td align="center"> 180 </td>
		</tr>
		<tr>
        <td  align="left" colspan="3">Cgst 6% </td><td align="center"> 180</td>
       
      </tr>
      <tr>
        <td  align="left" colspan="3">Sgst 2.5% </td><td align="center"> 55.43</td>
		</tr>
		<tr>
        <td  align="left" colspan="3">Cgst 2.5% </td><td align="center"> 55.43</td>
      </tr>
       
	 <tr><td></td><td></td><td></td><td></td></tr>
    <tr class="hr"><td></td><td></td><td></td><td></td></tr>
	<tr>
          <td  colspan="6">Other Tax Included  </td>
        </tr>
			 <tr>
			     
				  <tr>
        <td  align="left" colspan="3">Cess 5% </td><td align="center"> 55.43</td>
		</tr>
		<tr>
        <td  align="left" colspan="3">Cess 3% </td><td align="center"> 55.43</td>
      </tr> 
	  
			 </tr>
			
   <tr><td></td><td></td><td></td><td></td><td></td></tr>

	 <tr class="hr"><td></td><td></td><td></td><td></td></tr>
	
	  <tr>
        <td colspan="3">Gst Total  </td><td  align="center">300.00</td>
      </tr>
     <tr>
        <td colspan="3">Gst Cess Total  </td><td  align="center">111.00</td>
      </tr>
    <tr>
	    <th colspan="3"> Total Items </th><td align="center">4</td>
        
      </tr>
	  <tr>
	   
        <th colspan="3"> Grand Total </th><td   align="center"><b>5000.00</b></td>
      </tr>
      <tr>
	  <td  colspan="4">Co # c1 / name / 11:16:59</td>
      </tr>
      <tr>
        <td  colspan="4">E & OE </td>
      </tr>
      <tr>
        <td  colspan="4">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="4">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } ?>
  </div>
</div>
      <input type="hidden" class="form-control datetym"  id="datetym" name="datetym"  value="<?php echo $current_date_time;?>" readonly>
      <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
    <div class="text-right" id="sub" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info" style=" font-size: 15px !important;">Submit</a>
      <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right" style=" font-size: 15px !important;">Cancel</button>
  </div>
  <script>window.print();</script>
   <?php } ?>
</div>
<script>
					  $( '#close_fbx' ).on( 'click', function () {
						   parent.jQuery.fancybox.close(); 
						   window.parent.location.reload();
	                 } );
          function save_user(){
			var printer_size = $("#printer_size").val();
			var addby = $("#addby").val();
			var datetym = $("#datetym").val();
			  var company = $("#company").val();
				$.ajax({
	            	type : 'POST',
					url  : 'settings-action/printer_size.php',
					data: "printer_size="+ printer_size + "&addby=" + addby + "&datetym=" + datetym + "&company=" + company,
					success : function(r){						
						$("#respond").html(r);
					}
				});
				
				//setTimeout(function(){ window.location.reload(1);}, 1500);
				
												$.toast( {
													heading: 'Paper Width  Select  Succeccfully.',
													text: '',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1500
												} );
                       // parent.jQuery.fancybox.close();
				return false;
		  }

</script>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 

<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script> 
<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="assets/plugins/dff/dff.js" type="text/javascript"></script> 
<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script> 
<?php include("assets/custom/custom.php");?>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>