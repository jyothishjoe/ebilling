<?php 
include ('include/auth.php');
include('db-connect/db.php');
include('datetime_creation/datetime_creation.php');
$userid = $_SESSION['SESS_USERID_AS'];
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-sm-6 col-xs-12 no-padding" style="width:1000px; height: 595px; overflow: hidden;">
						   <center><h4 style="padding-bottom: 4px; ">Add Supplier</h4></center>
							   <center><div id="uname_response" class="response"></div></center>
								   <form method="post" action="" class="forms" name="supplier_form" id="supplier_form" autocomplete="off">
								   <input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
									   <input type="hidden" name="company" id="company" value="<?php echo $user_company; ?>">
									<div class="form-row">
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Vendor Name</label>
												<div class="col-12">
													<input type="text" class="form-control" name="c_name" id="c_name" placeholder="Name" >
												</div>
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											
										</div>
										
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Address</label>
												<div class="col-12">
													<textarea class="form-control" name="address" id="address" placeholder="Address" rows="7" ></textarea>
												</div>
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label col-12">State</label>
												   <div class="col-12" style="padding-bottom: 3px;">
												 	<select class="form-control select2" id="state_name" name="state_name" style="width: 100%; height:36px;">
														<option value="">Select State</option>
														<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
														<option value="Andhra Pradesh">Andhra Pradesh</option>
														<option value="Arunachal Pradesh">Arunachal Pradesh</option>
														<option value="Assam">Assam</option>
														<option value="Bihar">Bihar</option>
														<option value="Chandigarh">Chandigarh</option>
														<option value="Chhattisgarh">Chhattisgarh</option>
														<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
														<option value="Daman and Diu">Daman and Diu</option>
														<option value="Delhi">Delhi</option>
														<option value="Goa">Goa</option>
														<option value="Gujarat">Gujarat</option>
														<option value="Haryana">Haryana</option>
														<option value="Himachal Pradesh">Himachal Pradesh</option>
														<option value="Jammu and Kashmir">Jammu and Kashmir</option>
														<option value="Jharkhand">Jharkhand</option>
														<option value="Karnataka">Karnataka</option>
														<option value="Kerala">Kerala</option>
														<option value="Lakshadweep">Lakshadweep</option>
														<option value="Madhya Pradesh">Madhya Pradesh</option>
														<option value="Maharashtra">Maharashtra</option>
														<option value="Manipur">Manipur</option>
														<option value="Meghalaya">Meghalaya</option>
														<option value="Mizoram">Mizoram</option>
														<option value="Nagaland">Nagaland</option>
														<option value="Orissa">Orissa</option>
														<option value="Pondicherry">Pondicherry</option>
														<option value="Punjab">Punjab</option>
														<option value="Rajasthan">Rajasthan</option>
														<option value="Sikkim">Sikkim</option>
														<option value="Tamil Nadu">Tamil Nadu</option>
														<option value="Tripura">Tripura</option>
														<option value="Uttaranchal">Uttaranchal</option>
														<option value="Uttar Pradesh">Uttar Pradesh</option>
														<option value="West Bengal">West Bengal</option>
													</select>
												</div>
												<label for="validationTooltip01" class="control-label  col-12">Zip Code</label>
												<div class="col-12">
													<input type="text" class="form-control" name="zip" id="zip" placeholder="ZIP" >
												</div>
												<label for="validationTooltip01" class="control-label  col-12">Location</label>
												<div class="col-12">
													<input type="text" class="form-control" name="city" id="city" placeholder="Enter Location" >
												</div>
											</div>
										</div>
										
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
											<label for="validationTooltip01" class="control-label  col-12">Phone</label>
												<div class="col-12">
                                                 <input type="text" class="form-control" name="phone_no" id="phone_no"  placeholder="Phone Number">
												</div>
												<label for="validationTooltip01" class="control-label  col-12">Mobile No</label>
												<div class="col-12">
													<input type="text" class="form-control" name="contact" id="contact" placeholder="Mobile Number" >
												</div>
												<label for="validationTooltip01" class="control-label  col-12">Email</label>
												<div class="col-12">
													 <input type="text" class="form-control" name="email" id="email" placeholder="Enter Email Address">
												</div>
											</div>
										</div>
										
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">PAN No</label>
												<div class="col-12">
													<input type="text" class="form-control" name="pan" id="pan" placeholder="Pan Number" >
												</div>
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">GSTIN</label>
												<div class="col-12">
													<input type="text" class="form-control" name="gstin" id="gstin" placeholder="GSTIN" >
												</div>
												
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Opening Balance</label>
												<div class="col-12">
													<input type="text" class="form-control" name="balance" id="balance" placeholder="Opening Balance" >
												</div>
												
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Credit Limit</label>
												<div class="col-12">
													<input type="date" class="form-control" name="cr_limit" id="cr_limit" placeholder="Credit Limit" >
												</div>
												
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Credit Amount</label>
												<div class="col-12">
													<input type="text" class="form-control" name="cr_amt" id="cr_amt" placeholder="Amount" >
												</div>
												
											</div>
										</div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Discount</label>
												<div class="col-12">
													<input type="text" class="form-control" name="discount" id="discount" placeholder="Discount" >
												</div>
												
											</div>
										</div>
									</div>
									<div class="text-right">
									<button type="submit" id="insert" value="submit" class="btn btn-sm btn-info ">Submit</button>
									<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
									</div>
								<div class="successmsg" id="sa-success"></div>
								</form>
			
				<div id='respond'></div>
				<script>
				$( document ).ready( function () {
					$("#c_name").focus();
					//supplier Search
					$( "#c_name" ).change( function () {
						var name = $( "#c_name" ).val().trim();
						if ( name != '' ) {
							$("#uname_response" ).show();
							$.ajax({
								url: 'vendor-action/vendor_exist/vendor_name.php',
								type: 'post',
								data: {
									name: name
								},
								dataType: "JSON",
								success: function ( data ) {
									if ( data.ledger > 0 || data.cntcode > 0 ) {
										$.toast( {heading: 'Already Exist',text: '',position: 'top-right',loaderBg: '#DC3608',icon: 'error',hideAfter: 1200,hideMethod:'fadeOut'} );
										$( "#uname_response" ).html( "<span class='not-exists' style='color : red;'><strong>* Already Exist.</strong></span>" );
									}else {
										$( "#uname_response" ).html( "<span class='exists' style='color : green;'><strong>Available.</strong></span>" );
									}
								}
							});
						}else {
						$( "#uname_response" ).hide();
						}
					} );
				} );
</script>
				<script>
				/*$( "#c_name" ).change( function () {
				var c_name = $( "#c_name" ).val();
			    $.ajax( {
				type: 'POST',
				url: 'vendor-action/accountname_change.php',
				data: 'c_name=' + c_name,
				dataType: "JSON",
				success: function ( data ){
					$('#v_name').val( data.name);
					$('#ledger_token').val( data.token);
					$('#gstin').val( data.gst);
					$('#pan').val( data.pan);
						}
					} );
				} );*/
					$(window).keydown(function (event){
				if (event.keyCode == 27) {
					location.realod();
				}
				});
					$('#close_fbx' ).on('click', function (){
					location.reload();
					});
				
			   </script>
				<script>
				$('#supplier_form').on('submit', function (event){
					event.preventDefault();
					var error = '';
					var form_data = $( this ).serialize();
					
					var name = $("#v_name").val();
					var phone = $("#phone_no").val();
					var state = $("#state_name").val();
					
					if ( name == ''  ){
                       $.toast( { heading: 'Enter Supplier Name.', text: '', position: 'top-right', loaderBg: '#F13109', icon: 'error', hideAfter: 1200 } );
                    }else if (  phone == '' ){
                       $.toast( { heading: 'Enter Phone No.', text: '', position: 'top-right', loaderBg: '#F13109', icon: 'error', hideAfter: 1200 } );
                    }else if ( state == '' ){
                       $.toast( { heading: 'Select State.', text: '', position: 'top-right', loaderBg: '#F13109', icon: 'error', hideAfter: 1200 } );
                    }else{
					
					$.ajax({
						url: "vendor-action/add_vendor.php",
						method: "POST",
						data: form_data,
						success: function ( data ){
						$( "#respond" ).html(data);
						//document.getElementById( "insert_form" ).reset(); }
					}
					});
					 $( "#insert" ).show();
					}
					});
			</script>
			