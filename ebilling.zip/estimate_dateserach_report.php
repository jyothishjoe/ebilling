<?php include("php_fn/basic.php");
include( "datetime_creation/datetime_creation.php" );
include( 'db-connect/db.php' );
$startdate=$_POST["startdate"]; 
    $enddate=$_POST["enddate"];
	$sta_date = date_create($startdate);
 $startdates=date_format($sta_date,"Y-d-m");
 
$end_date = date_create($enddate);
 $enddates=date_format($end_date,"Y-d-m"); 
$result_sales = $db->prepare("SELECT SUM(grand_tot) AS grand_tot FROM estimate_invoice where estimate_invodate >= '$startdates' AND estimate_invodate <= '$enddates' ");
$result_sales->execute();
$rows_sales = $result_sales->fetch(); 
$sum = $rows_sales['grand_tot'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Supermarket</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
</head>
<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor">Estimate Report</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
								<li class="breadcrumb-item">Reports</li>
							<li class="breadcrumb-item active">Estimate Report</li>
						</ol>
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
							<div class="text-left">
							<a href="estimate-report.php" class="btn btn-danger btn-sm">Back</a>
	                       </div>
						   <form class="" name="addbilldetails" method="post" action="estimate_dateserach_report.php" enctype="multipart/form-data">
                             <div class="form-row">
							  <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
								<label for="" class="control-label">Start Date</label>
								 <input type="text" class="form-control date-inputmask" name="startdate" required>
							  </div>
							  <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
								<label for="" class="control-label">End Date</label>
								<input type="text" class="form-control date-inputmask" id="enddate" name="enddate" required>
							  </div>
							  <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
							 
							 <input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:33px;" value="Submite"/>
							 </div> </div>
							 </form>
									<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>#</th>
												<th>Date and Time</th>
												<th>Estimate No</th>
												<th>Customer Name</th>
												<th>Order Date</th>
												<th>Total</th>
												
											</tr>
										</thead>
										
										<tbody>
				
<?php
							
					//Tution Start
					$sl=0;
					$result = $db->prepare("select * from  estimate_invoice where estimate_invodate >= '$startdates' AND estimate_invodate <= '$enddates' order by estimate_invodate asc");
					$result->execute();
					for($i=0; $row = $result->fetch(); $i++)
						{	 $sl++;?>
						<tr>
						
						<td><?php echo $sl; ?></td>
						<td><?php echo $row['datetym']; ?></td>
						<td><?php echo $row['bill_no']; ?></td>
						<td><?php echo ucfirst($row['cus_name']); ?></td>
						<td><?php echo $row['order_date']; ?></td>
						<td><?php echo $row['grand_tot']; ?></td>
			
					</tr>
						<?php } ?>
											
										</tbody>
										<tfoot>
											<tr>
												<th></th>
												<th></th>
												<th></th>
												<th></th>
												<th>Net Total </th>
												<th>: <?php echo $sum; ?></th>
												<th></th>
												<th></th>
											</tr>
										</tfoot>
										
									</table>
									</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
    <script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
	<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
	<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
	<script>
		$( function () {
			$( '#myTable' ).DataTable();
			$( document ).ready( function () {
				var table = $( '#example' ).DataTable( {
					"columnDefs": [ {
						"visible": false,
						"targets": 2
					} ],
					"order": [
						[ 2, 'asc' ]
					],
					"displayLength": 25,
					"drawCallback": function ( settings ) {
						var api = this.api();
						var rows = api.rows( {
							page: 'current'
						} ).nodes();
						var last = null;
						api.column( 2, {
							page: 'current'
						} ).data().each( function ( group, i ) {
							if ( last !== group ) {
								$( rows ).eq( i ).before( '<tr class="group"><td colspan="5">' + group + '</td></tr>' );
								last = group;
							}
						} );
					}
				} );
				// Order by the grouping
				$( '#example tbody' ).on( 'click', 'tr.group', function () {
					var currentOrder = table.order()[ 0 ];
					if ( currentOrder[ 0 ] === 2 && currentOrder[ 1 ] === 'asc' ) {
						table.order( [ 2, 'desc' ] ).draw();
					} else {
						table.order( [ 2, 'asc' ] ).draw();
					}
				} );
			} );
		} );
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		$( '.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel' ).addClass( 'btn btn-primary mr-1' );
		
		
	</script>
	
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>
									