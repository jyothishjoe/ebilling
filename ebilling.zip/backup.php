<?php
set_time_limit(0);
include("db-connect/db.php");
include("datetime_creation/datetime_creation.php");
$backup_file = $db_database . $today . '.sql';
$command = "E:\\xampp\mysql\bin\mysqldump -h$db_host -u$db_user $db_database> F:\\BACKUPDRIVE\\CODEBUZ\\DB_BACKUPS_SUPERMARKET\\$backup_file"; 
$command = "E:\\xampp\mysql\bin\mysqldump -h$db_host -u$db_user $db_database> E:\\xampp\\htdocs\\CODEBUZ_2019\\supermarket\\Supermarket_AUG_2019_DB_FULL\\Supermarket\\db.sql\\$backup_file"; 
system($command);
setcookie("BCK", true, time() + (3), "/");
header("location:setting-home.php");

?>