<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];

$company_token = $_GET['edit'];
	
$result_user_chk = $db->prepare("SELECT * FROM company WHERE c_token = '$company_token'");
$result_user_chk->execute();	
$rows = $result_user_chk->fetch(); 
$date=$rows['financial_year_from'];  
$old_date = Date_create($date);
$new_date = Date_format($old_date, "Y-m-d");

$logo=$rows['c_logo'];

?>


<style>
fieldset{
	margin-top:17px; border: 1px solid #999; font-size:12px; padding:0px 10px;}
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
	ul, li{
	z-index:9999 !important;  
    width: 180px;
    max-height:150px;/*The important part*/
    overflow-y:auto;/*Also...*/
    overflow-x:hidden;/*And the end of the important part*/
    margin: 0px;
    padding-left:5px;/*Removing the large whitespace to the left of list items*/
    border: 1px solid black;
	}
	#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 28px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
<div id="custom-content" class="col-md-10 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #ffffff;">
	<div class="col-md-12" style="margin-bottom: 10px; margin-top: 12px;">
		<h3 align="center">Edit Company</h3>
	</div>
	<form method="post" action="settings-action/edit-company.php" class="forms" name="insert_form" id="insert_form" autocomplete="off" enctype="multipart/form-data">
<input type="hidden" name="userid" value="<?php echo $userid; ?>"/>
		<input type="hidden" name="typ" value="COMPANY">
	<div class="row">
		<!-- .main -->
		<div class="col-md-7 col-sm-6 text-left">
			<div class="card card-body">
				<div class="row">
					
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">Company Name</label>
								<div class="col-12">
									<input type="text" name="comp_name" id="comp_name" class="form-control" value="<?php echo $rows['c_company_name']; ?>">
									<input type="hidden" name="comp_token" id="comp_token" class="form-control" value="<?php echo $company_token; ?>">
								</div>
							</div>
						</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Address1</label>
									<div class="col-12">
										<input type="text" class="form-control" id="comp_address" name="comp_address" value="<?php echo $rows['c_shopaddress']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Address2</label>
									<div class="col-12">
										<input type="text" class="form-control" id="address1" name="address1" value="<?php echo $rows['address_sec']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Phone</label>
									<div class="col-12">
										<input type="text" class="form-control" id="comp_phone" name="comp_phone" value="<?php echo $rows['c_phone']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Mobile</label>
									<div class="col-12">
										<input type="text" class="form-control" id="comp_mobile" name="comp_mobile" value="<?php echo $rows['c_mobile']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Email</label>
									<div class="col-12">
										<input type="text" class="form-control" id="comp_email" name="comp_email" value="<?php echo $rows['c_email']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Website</label>
									<div class="col-12">
										<input type="text" class="form-control" id="website" name="website" value="<?php echo $rows['website_address']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Fax No</label>
									<div class="col-12">
										<input type="text" class="form-control" id="fax" name="fax" value="<?php echo $rows['fax']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-4  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Finacial Year</label>
									<div class="col-12">
										<input type="date" class="form-control" id="fisc" name="fisc" value="<?php  echo $new_date; ?>">
									</div>
								</div>
							</div>
						
					 <div class="col-md-12 text-left">
					 <div class="row">
					 <div class="col-md-12">
				 
					  <div class="form-row">
               
					<div class="col-md-4 col-sm-6">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">User</label>
							<div class="col-12">
								<select class=" form-control select2" id="user" name="user" style="width: 100%; height:36px;">
									 <?php
									$result_user_types1 = $db->prepare("SELECT * FROM admin_user");
									$result_user_types1->execute();
									$rows_user_types1 = $result_user_types1->fetch();
									?>
									<option value="<?php echo $rows['user_tkn']; ?>"><?php echo $rows_user_types1['user_username']; ?></option>
									 <?php
									$result_user_types = $db->prepare("SELECT * FROM admin_user");
									$result_user_types->execute();
									
									for ($e=0; $rows_user_types = $result_user_types->fetch(); $e++){
									$user_name=$rows_user_types['user_username'];
									$user_token=$rows_user_types['user_tkn'];
									?>
									<option value="<?php echo $user_token;?>"><?php echo $user_name;?></option>
									<?php }  ?>
								</select>
								<input type="hidden" class="form-control" name="user_name" id="user_name" >
								<input type="hidden" class="form-control" name="user_password" id="user_password" >
							</div>
						</div>
					 </div>
						  <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">GSTIN</label>
								<div class="col-12">
									<input type="text" class="form-control" name="gstin" id="gstin" placeholder="GST No" value="<?php echo $rows['c_gst']; ?>">
								</div>
							</div>
						</div>
						  <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">A/c No</label>
								<div class="col-12">
									<input type="text" class="form-control" name="acc_no" id="acc_no" placeholder="Account No" value="<?php echo $rows['c_accno']; ?>">
								</div>
							</div>
						</div>
						   <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Bank Name</label>
								<div class="col-12">
									<input type="text" class="form-control" name="bank" id="bank" placeholder="Bank Name" value="<?php echo $rows['c_bank']; ?>">
								</div>
							</div>
						</div>
						  <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Branch</label>
								<div class="col-12">
									<input type="text" class="form-control" name="branch" id="branch" placeholder="Branch" value="<?php echo $rows['c_branch']; ?>">
								</div>
							</div>
						</div>
						  <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">IFSC</label>
								<div class="col-12">
									<input type="text" class="form-control" name="ifsc" id="ifsc" placeholder="IFSC" value="<?php echo $rows['c_ifsc']; ?>">
								</div>
							</div>
						</div>
	              </div>
	            </div>
	          </div>
	       </div>
	    </div>
	</div>
		<!--	<fieldset>
				<legend class="control-label" style="margin-left:30px; width: 90px; font-size:15px; padding-left:7px; ">Stock Details</legend>
				<div class="row">
				
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Min Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="min" id="min" placeholder="Minimum Stock" value="">
								<input type="hidden" class="form-control" name="dat" value="<?php echo $today; ?>">
								<input type="hidden" class="form-control" name="time" value="<?php echo $current_time; ?>">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Max Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="max" id="max" placeholder="Maximum Stock" value="">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Op Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="opstock" id="opstock" placeholder="Opening Stock" >
							</div>
						</div>
					</div>
				</div>
			</fieldset>-->
			</div>
			<!--Stock-->
		</div>
		<!-- .secondry -->
		<div class="col-md-5 col-sm-6 text-left">
		<fieldset>
				<legend class="control-label" style="margin-left:30px; width: 90px; font-size:15px; padding-left:7px; ">Genral Details</legend>
				<div class="row">
					 <div class="col-md-12">
					  <div class="row">
				  <div class="col-md-6 col-sm-6">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Country</label>
							<div class="col-12">
								<select class=" form-control select2" id="country" name="country" style="width: 100%; height:36px;">
									<option value=""><?php echo $rows['country']; ?></option>
									 <?php
									$result =$db->prepare("SELECT * FROM countries WHERE status = 1 ORDER BY country_name ASC");
									$result->execute();
									while($row = $result->fetch()){
									?>
									<option value="<?php echo $row['country_id'];?>"><?php echo ucwords($row['country_name']);?></option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
						  <div class="col-md-6 col-sm-6">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">State</label>
							<div class="col-12">
								<select class=" form-control select2" id="state" name="state" style="width: 100%; height:36px;">
									<option value=""><?php echo $rows['state']; ?></option>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">City</label>
							<div class="col-12">
								<select class=" form-control select2" id="city" name="city" style="width: 100%; height:36px;">
									<option value=""><?php echo $rows['city']; ?></option>
								</select>
							</div>
						</div>
					</div>
					 <div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Currency</label>
								<div class="col-12">
									<input type="text" class="form-control" name="currency" id="currency" placeholder="Currency" value="<?php echo $rows['currency']; ?>">
								</div>
							</div>
						</div>
					  </div>
				  </div>
				</div>
			<div class="col-md-12" style="margin: 22px 0px; margin-top: 15px;">
				<input type="submit" name="insert" id="insert" class="btn btn-info btn-sm" style="float: right; margin-bottom: 20px;" value="Update">
			</div>
			</form>
			<div class="col-12"></div>
			</fieldset>
			<fieldset style="margin-bottom: 12px;">
				<legend class="control-label" style="margin-left:30px; width: 90px; font-size:15px; padding-left:7px; ">Company Logo</legend>
				<form method="post" action="settings-action/edit-company.php" class="forms" name="form" id="form" autocomplete="off" enctype="multipart/form-data">
					<input type="hidden" name="typ" value="LOGO">
				<div class="row">
					<div class="col-md-6" style="border-right: 1px dashed grey;">
					<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Logo</label>
								<div class="col-12">
									<input type="file" class="form-control" name="logo" id="logo" value="<?php echo $rows['c_logo']; ?>" required>
								</div>
							</div>
					</div>
					<div class="col-md-6">
						<div class="form-group row" style="margin-left: 25px; margin-top: 15px;" >
					<img oncontextmenu="return false;" style="width: 60px;" src="assets/images/company_logo/<?php echo $logo; ?>" alt="user" class="profile-pic"  />
						</div>
					</div>
				</div>
				<div class="col-md-12" style="margin: 2px 0px;">
				<input type="submit" name="insert" id="insert" class="btn btn-info btn-sm" style="float: right;  margin-bottom: 20px; " value="Update">
				<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close" style="float: right; margin-right: 8px; margin-bottom: 20px; ">Cancel</button>
				</div>
				</form>
			</fieldset>
		 <!--<fieldset>
	  <!--<legend class="control-label" style="margin-left:30px; width: 74px; font-size:15px; padding-left:7px;">Bank Details</legend>
				<div class="row">
					 <div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Bank Name</label>
								<div class="col-12">
									<input type="text" class="form-control" name="sellingprice" id="sellingprice" placeholder="Selling Price" value="">
								</div>
							</div>
						</div>
					 <div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Branch</label>
								<div class="col-12">
									<input type="text" class="form-control" name="sellingprice" id="sellingprice" placeholder="Selling Price" value="">
								</div>
							</div>
						</div>
					 <div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Account No</label>
								<div class="col-12">
									<input type="text" class="form-control" name="sellingprice" id="sellingprice" placeholder="Selling Price" value="">
								</div>
							</div>
						</div>
					 <div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">IFSC</label>
								<div class="col-12">
									<input type="text" class="form-control" name="sellingprice" id="sellingprice" placeholder="Selling Price" value="">
								</div>
							</div>
						</div>
				</div>
				</fieldset>-->
			
		</div>
		</div>
		<div class="successmsg" id="respond"></div>
		<script type="text/javascript">
$(document).ready(function(){
	
	$('#country').change(function (){
			var country = $("#country").val();
			$.ajax({
				type: 'POST',
				url: 'settings-action/country_fetch.php',
				data: 'country=' + country,
				dataType: "JSON",
				success: function (data) {
					//$('#country_id').val(data.country_id);
					$('#currency').val(data.currency);
					
				}
			});
		});
	
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'settings-action/add_company.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
					
                    $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'settings-action/add_company.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#city').html(html);
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});

			
//User details
			$('#user').change(function (){
			var user = $("#user").val();
			$.ajax({
				type: 'POST',
				url: 'settings-action/user/user_fetch.php',
				data: 'user=' + user,
				dataType: "JSON",
				success: function (data) {
					$('#user_name').val(data.user_name);
					$('#user_password').val(data.user_password);
					
					
				}
			});
		});
</script>
			<script>
				
			
				$( document ).ready( function (){
					
					$( "#comp_name" ).focus();
					$( "#pr_code" ).keyup( function () {
						var pr_code = $( "#pr_code" ).val().trim();
						if ( pr_code != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'product-action/product_exist_search/productsearch.php',
								type: 'post',
								data: {
									pr_code: pr_code
								},
								success: function ( response ){
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in use.</span>" );
										$.toast( {heading: 'Already In Use',text: '',position: 'top-left',loaderBg: '#F13109',icon: 'error',hideAfter: 3500,hideMethod: 'fadeOut'
										});
										var dis1 = document.getElementById("pr_code");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("name").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										$.toast({heading: 'Available',text: '',position: 'top-left',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1000,hideMethod: 'fadeOut'});
										var dis1 = document.getElementById("pr_code");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("name").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
				
			
			</script>
		
			<script>
				$('#close_fbx').on('click', function(){ parent.jQuery.magnificPopup.close(); });
				

			</script>