<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); include('db-connect/db.php');
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; 

$user_typ=$rows['typ'];
} 
if($user_typ == 'ADMIN'){
$add_user_type=0;  $update_user_type=0;	
}else{
$results_user_three = $db->prepare("select * from  user_type_three where user_tkn = '$user_type_tkn'");
$results_user_three->execute();
for($i=0; $row_user_three = $results_user_three->fetch(); $i++)
{  $add_user_type=$row_user_three['add_user_type'];  $update_user_type=$row_user_three['update_user_type'];} 
}

?>
<style>
label{text-align:left ! important;}
</style>
<title>User Type List</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<style>
.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}
</style>

<div class="col-12"><br>
	<h3 class="text-center"> User Type All </h3>
	<div class="text-right">
		<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="margin-left:.1em;">Close</button>
	</div>
	<div class="col-12 table-responsive">
	<table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%; text-align:center;">
	  <thead>
	    <tr>
	      <th>#</th>
	      <th>User Type</th>
	      <th>Master</th>
		   <th>Purchase</th>
		    <th>Sales</th>
			 <th>Inventory</th>
			  <th>Accounts</th>
			   <th>Cash Counter</th>
			    <th>Analysis</th>
				 <th>Settings</th>
				 
	      <?php if( $add_user_type==0 && $update_user_type==0 ) { ?> <th>Action</th><?php } ?>
	    </tr>
	  </thead>
	  <tbody>
	    <?php 
			$result_user_types = $db->prepare("SELECT * FROM user_type  GROUP BY user_type_name ");
		    $result_user_types->execute();
			$sl = 0;
			for ($e=0; $rows_user_types = $result_user_types->fetch(); $e++) {
				$user_name=$rows_user_types['user_type_name'];
				
			$result_user_type = $db->prepare("SELECT * FROM user_type where  user_type_name='$user_name'");
		    $result_user_type->execute();
			$sl = 0;
			for ($i=0; $rows_user_type = $result_user_type->fetch(); $i++) {
			?>
	    <tr>
	      <td><?php echo $e+1; ?></td>
	      <td><?php echo ucwords($user_name); ?></td>
	     <td style="text-align:left;"><?php if($rows_user_type['master_add_product']==0){?> Add product<br> <?php }  if($rows_user_type['master_update_product']==0){?> Product update & delete<br> <?php }  if($rows_user_type['master_add_customer']==0){?> Add Customer<br>  <?php } if($rows_user_type['master_update_customer']==0){?> Customer update & delete<br> <?php }  if($rows_user_type['master_add_supplier']==0){?> Add supplier<br>  <?php } if($rows_user_type['master_update_supplier']==0){?> Supplier update & delete<br> <?php }  if($rows_user_type['master_add_ledger']==0){?> Add ledger<br> <?php }  if($rows_user_type['master_update_ledger']==0){?> Ledger update & delete<br>  <?php }  if($rows_user_type['master_add_category']==0){?> Add category<br>  <?php }  if($rows_user_type['master_update_category']==0){?> Category update & delete<br> <?php }  if($rows_user_type['master_add_subcategory']==0){?> Add sub category<br>  <?php } if($rows_user_type['master_update_subcategory']==0){?> Sub category update & delete<br>  <?php }  if($rows_user_type['master_add_unit']==0){?> Add unit<br><?php }  if($rows_user_type['master_update_unit']==0){?> Unit  update & delete<br>  <?php }  if($rows_user_type['master_add_bank']==0){?> Add bank<br>  <?php }  if($rows_user_type['master_update_bank']==0){?> Bank  update & delete<br>  <?php } if($rows_user_type['master_add_gst']==0){?> Add gst<br> <?php }  if($rows_user_type['master_update_gst']==0){?> Gst  update & delete<br>  <?php }  if($rows_user_type['master_add_othertax']==0){?> Add other tax<br>  <?php }  if($rows_user_type['master_update_othertax']==0){?> Other tax update & delete<br>  <?php } ?> </td>
		 
		
	     <td style="text-align:left;"><?php if($rows_user_type['add_supplier']==0){?> Add supplier<br> <?php }  if($rows_user_type['update_supplier']==0){?> Supplier update & delete<br> <?php }  if($rows_user_type['Purchase_invo']==0){?> Purchase <br>  <?php } if($rows_user_type['Purchase_order_invo']==0){?> Purchase order <br> <?php }  if($rows_user_type['Purchase_rtn_invo']==0){?> Purchase return <br>  <?php } if($rows_user_type['purchas_rep']==0){?> Purchase report<br> <?php }  if($rows_user_type['purchase_order_rep']==0){?> Purchase order report<br> <?php }  if($rows_user_type['purchase_return_rep']==0){?> Purchase return report<br>  <?php } ?> </td>
		 
		 
		 <td style="text-align:left;"><?php if($rows_user_type['add_customer']==0){?> Add customer<br> <?php }  if($rows_user_type['update_customer']==0){?> Customer update & delete<br> <?php }  if($rows_user_type['sales_order']==0){?> Sales order <br>  <?php } if($rows_user_type['sales_invo']==0){?> Sales bill <br> <?php }  if($rows_user_type['pos_invo']==0){?> Pos <br>  <?php } if($rows_user_type['estimate_invo']==0){?> Estimate <br> <?php }  if($rows_user_type['sales_ret_invo']==0){?> Sales return <br> <?php }  if($rows_user_type['bill_cancel']==0){?> Sales bill cancellation<br>  <?php }  if($rows_user_type['sales_order_rept']==0){ ?> Sales order report<br>  <?php }   if($rows_user_type['sales_rept']==0){?> Sales report<br>  <?php }   if($rows_user_type['sales_ret_rept']==0) {?> Sales return report<br>  <?php } ?> </td>
		 
			<td style="text-align:left;"><?php if($rows_user_type['product']==0){?> Add product<br> <?php }  if($rows_user_type['product_update']==0){?> Product update & delete<br> <?php }  if($rows_user_type['category']==0){?> Add category<br>  <?php }  if($rows_user_type['category_update']==0){?> Category  update & delete<br> <?php }  if($rows_user_type['subcategory']==0){?> Add sub category<br>  <?php } }
			
		    $result_user_type_sec = $db->prepare("SELECT * FROM user_type_second where user_type_name='$user_name'");
		    $result_user_type_sec->execute();
			$sl = 0;
			for ($i=0; $rows_user_type_sec = $result_user_type_sec->fetch(); $i++) {

		if($rows_user_type_sec['subcategory_update']==0){?> Sub category  update & delete<br>  <?php }  if($rows_user_type_sec['unit']==0){?> Add unit<br><?php }  if($rows_user_type_sec['unit_update']==0){?> Unit  update & delete<br>  <?php }  if($rows_user_type_sec['pricing']==0){?> Pricing<br>  <?php }  if($rows_user_type_sec['stock_rept']==0){?> Stock report<br>  <?php } if($rows_user_type_sec['stock_age_rept']==0){?> Stock age report<br> <?php }  if($rows_user_type_sec['stock_move_rept']==0){?> Stock moving report<br>  <?php }  if($rows_user_type_sec['negative_rept']==0){?> Negative stock<br>  <?php } ?> </td>
		
		<td style="text-align:left;"><?php if($rows_user_type_sec['trance_add_cash']==0){?>Cash<br>  <?php }  if($rows_user_type_sec['trance_add_bank']==0){?> Bank (Transactions)<br><?php }  if($rows_user_type_sec['trance_joural']==0){?> Journal<br>  <?php }  if($rows_user_type_sec['add_bank']==0){?> Add bank<br>  <?php }  if($rows_user_type_sec['update_bank']==0){?> Bank update & delete<br>  <?php }  if($rows_user_type_sec['add_ledger']==0){?> Ledger<br> <?php }  if($rows_user_type_sec['update_ledger']==0){?> Ledger update & delete<br>  <?php }  if($rows_user_type_sec['add_transactiontype']==0){?>Transactions type<br>  <?php }  if($rows_user_type_sec['update_transactiontype']==0){?> Transactions type update & delete<br>  <?php }  if($rows_user_type_sec['day_closing']==0){?>Day closing<br>  <?php } if($rows_user_type_sec['general_ledger']==0){?>General ledger<br>  <?php }  if($rows_user_type_sec['general_daybook']==0){?>General day book<br>  <?php }  if($rows_user_type_sec['general_cashflow']==0){?>General cash flow<br>  <?php }   if($rows_user_type_sec['acco_sales']==0){?>Sales <br> <?php }  if($rows_user_type_sec['acco_purchase']==0){ ?>Purchase<br>  <?php } if($rows_user_type_sec['trail_balance']==0){?>Trail balance<br>  <?php }  if($rows_user_type_sec['profit']==0){?>Profit<br>  <?php }  if($rows_user_type_sec['trading_profit_loss']==0){?>Trading and profit & loss<br>  <?php }  if($rows_user_type_sec['balance_sheet']==0){?>Balance sheet<br>  <?php }  if($rows_user_type_sec['account_add_gst']==0){?>Add gst<br>  <?php }  if($rows_user_type_sec['account_update_gst']==0){?>Gst update & delete<br>  <?php }  if($rows_user_type_sec['account_add_othertax']==0){?>Add other tax<br>  <?php }  if($rows_user_type_sec['account_update_othertax']==0){?>Other tax update & delete <br>  <?php }  ?> </td>
		
		
		<td style="text-align:left;"> <?php if($rows_user_type_sec['cash_open']==0){?>Cash open <br><?php }  if($rows_user_type_sec['cash_counter']==0){?>Cash counter <br>  <?php } if($rows_user_type_sec['add_advance_receipt']==0){?>Advanced receipt <br> <?php } if($rows_user_type_sec['cash_closing']==0){?> Cash closing <br>  <?php } if($rows_user_type_sec['round_off']==0){?> Round off <br>  <?php }  ?> </td>
		
		<td style="text-align:left;"> <?php if($rows_user_type_sec['analysis']==0){ ?>Analysis <br> <?php  }  ?> </td>
		
			<td style="text-align:left;"> <?php if($rows_user_type_sec['update_password']==0){ ?>Update password <br> <?php  }  if($rows_user_type_sec['date_picker']==0){ ?>Date picker <br> <?php  } if($rows_user_type_sec['printer']==0){ ?>Printer <br> <?php  } if($rows_user_type_sec['financial_year']==0){ ?>Set financial year <br> <?php  } if($rows_user_type_sec['setting_add_gst']==0){ ?>Add gst<br>  <?php } if($rows_user_type_sec['setting_update_gst']==0){ ?>Gst update & delete<br>  <?php }  }  
			
			$result_user_type_thr = $db->prepare("SELECT * FROM user_type_three where  user_type_name='$user_name'");
		    $result_user_type_thr->execute();
			$sl = 0;
			for ($i=0; $rows_user_type_thr = $result_user_type_thr->fetch(); $i++) {
			
			if($rows_user_type_thr['setting_add_othertax']==0){ ?>Add other tax <br> <?php  } if($rows_user_type_thr['setting_update_othertax']==0){ ?>Other tax update & delete <br> <?php  }  if($rows_user_type_thr['add_season']==0){ ?>Add Season <br> <?php  }  if($rows_user_type_thr['update_season']==0){ ?>Season update & delete <br> <?php  }  if($rows_user_type_thr['add_user_type']==0){ ?>Add user type <br> <?php  }  if($rows_user_type_thr['update_user_type']==0){ ?>User type update & delete<br> <?php  }  if($rows_user_type_thr['add_user']==0){ ?>Add user <br> <?php  }  if($rows_user_type_thr['update_user']==0){ ?>User update & delete<br> <?php  }  if($rows_user_type_thr['backup']==0){ ?>Backup <br> <?php  }  if($rows_user_type_thr['dateset']==0){ ?>Dateset <br> <?php  } ?> </td>
			
		  <?php if( $add_user_type==0 && $update_user_type==0 ) { ?>
	      <td><div class="btn-group-horizontal" align="center"> <span><a href="user-type-update-popup.php?cusid=<?php echo $rows_user_type_thr['user_tkn']; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top "><i class="fa fa-pencil-alt"></i></a></span> <span><a id="delete" href="user-type-delete.php?delete=<?php echo $rows_user_type_thr['user_tkn'];?>"  class="btn btn-sm btn-danger simple-ajax-popup-align-top" ><i class="fas fa-trash-alt"></i></a></span></div></td>
			<?php } }?>
	    </tr>
	    <?php }?>
	  </tbody>
	</table>
	</div>
 </div>
          
     
	<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
				
		});		
$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
							
</script>
<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
<script src="js/toastr.js"></script>
<?php include ('include/disable_fn.php'); ?>