<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$usertyp = $_SESSION['SESS_USERTYPE_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$token = $_SESSION['SESS_USERID_AS'];
?>
<div class="col-xs-12 no-padding" style="width:400px; overflow: hidden;">
	<h3 class="text-center">Add New Category</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Category Name</label>
				<input type="text" class="form-control" id="catname" name="catname" value="" placeholder="Name">
				<input type="hidden" class="form-control" id="token" name="token" value="<?php echo $token; ?>" readonly>
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>" readonly>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Refference Code</label>
				<input type="text" class="form-control" id="reff" name="reff" value="" placeholder="Reff Code" required>
			</div>
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Description</label>
				<textarea class="form-control" id="descr" name="descr" value="" placeholder="Description" required></textarea>
			</div>
		</div>
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" id="catesave">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">CANCEL</button>
		</div>
	</form>
</div>

<script>
	$( '#close_fbx' ).on( 'click', function () {
		parent.jQuery.fancybox.close();
	} );
$(document).ready( function (){
	 $( "#catname" ).focus();
});
	$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 255 ) {
				parent . jQuery . fancybox . close();

				// $( "#custom-content" ).hide();
				$( "#clickadd" ).click();
			}
		if ( event . keyCode == 13 ) {
				// $( "#custom-content" ).hide();
				$( "#catesave" ).click();
			}
	});
	function save_customer() {
		var catname = $( "#catname" ).val();
		//var manufact = $( "#manufact" ).val();
		//var brand = $( "#brand" ).val();
		var reff = $( "#reff" ).val();
		//var department = $( "#department" ).val();
		var descr = $( "#descr" ).val();
		var company = $( "#company" ).val();
		var token = $( "#token" ).val();

		if ( $( "#catname" ).val() == "" ) {
			$.toast( {
				heading: 'Fill all required fields.',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 1200
			} );
		} else {
			$( "#catesave" ).hide();
			$.ajax( {
				type: 'POST',
				url: "product-action/category_creation.php",
				data: "catname=" + catname +  "&reff=" + reff + "&descr=" + descr + "&token=" + token + "&company=" + company,
				success: function ( r ) {
					$( "#respond" ).html( r );
				}
			} );
			//parent.jQuery.fancybox.close();
			document.getElementById( "insert_form" ).reset(); $( "#catesave" ).show(); $( "#catname" ).focus();
			return false;
		}
	}
</script>