<?php include('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$usertyp=$_SESSION['SESS_USERTYPE_AS'];
include( 'db-connect/db.php' ); 
include("datetime_creation/datetime_creation.php");
//Total Sales order invoices
$result_sales_order = $db->prepare( "SELECT * FROM sales_order_invoice  WHERE company_tkn = '$user_company'" );
$result_sales_order->execute();
$no_sales_order = $result_sales_order->rowCount();
//Total Sales invoices
$result_sales = $db->prepare( "SELECT * FROM sales_invoice WHERE company_tkn = '$user_company'" );
$result_sales->execute();
$no_sales = $result_sales->rowCount();
//Total Sales Return invoices
$result_sales_rtn = $db->prepare( "SELECT * FROM sales_rtn_invoice WHERE company_tkn = '$user_company'" );
$result_sales_rtn->execute();
$no_sales_rtn = $result_sales_rtn->rowCount();
//Total Sales Estimate invoices
$result_sales_estimate = $db->prepare( "SELECT * FROM estimate_invoice WHERE company_tkn = '$user_company'" );
$result_sales_estimate->execute();
$no_sales_estimate = $result_sales_estimate->rowCount();
//Total Stock
$result_stock = $db->prepare( "SELECT SUM(pr_stock) AS pr_stock FROM stocks WHERE company_tkn = '$user_company' " );
$result_stock->execute();
$rows_stock = $result_stock->fetch();
$total_stock=$rows_stock['pr_stock'];
//Total Stock
$result_stock_check = $db->prepare( "SELECT SUM(pr_stock) < '10' AS stock_check FROM stocks WHERE company_tkn = '$user_company' " );
$result_stock_check->execute();
$rows_stock_check = $result_stock_check->rowcount();

//Total Purchase Order invoices
$result_purch_order = $db->prepare( "SELECT * FROM purchaseorder_invoice WHERE company_tkn = '$user_company' " );
$result_purch_order->execute();
$no_purch_order = $result_purch_order->rowCount();
//Total Purchase invoices
$result_purch_invoice = $db->prepare( "SELECT * FROM purchase_invoice WHERE company_tkn = '$user_company' " );
$result_purch_invoice->execute();
$no_purch_invoice = $result_purch_invoice->rowCount();
//Total Purchase invoices
$result_purch_invoice_rtn = $db->prepare( "SELECT * FROM purchase_invoice WHERE company_tkn = '$user_company' " );
$result_purch_invoice_rtn->execute();
$no_purch_invoice_rtn = $result_purch_invoice_rtn->rowCount();
//Total Customers
$result_customer = $db->prepare( "SELECT * FROM customer WHERE company_tkn = '$user_company' " );
$result_customer->execute();
$no_customer = $result_customer->rowCount();
//Total Suppliers
$result_supplier = $db->prepare( "SELECT * FROM supplier WHERE company_tkn = '$user_company' " );
$result_supplier->execute();
$no_supplier = $result_supplier->rowCount();
//Users Online
$curren_user = $db->prepare("SELECT * FROM admin_user_log a LEFT JOIN admin_user b ON a.user_token=b.user_tkn WHERE a.in_date='$today' AND a.logout_as='' AND b.typ = 'ADMIN' GROUP BY a.user_token");
$curren_user->execute();
$rows_curren_user = $curren_user->rowCount(); 
//Total Staffs
$result_staff = $db->prepare( "SELECT * FROM admin_user  " );
$result_staff->execute();
$no_staff = $result_staff->rowCount();
//Current Year
$year = date('Y',strtotime($today));
$month = date('F',strtotime($today));
//Total Sales
$result_tot_sales = $db->prepare( "SELECT SUM(net_tot) AS net_tot FROM sales_invoice WHERE company_tkn = '$user_company' " );
$result_tot_sales->execute();
$rows_sales = $result_tot_sales->fetch();
$total_sales=$rows_sales['net_tot'];
//Current Month Total
$result_month_sales = $db->prepare( "SELECT  DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH), SUM(net_tot) AS net_tot FROM sales_invoice WHERE company_tkn = '$user_company' ORDER BY DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH) DESC;" );
$result_month_sales->execute();
$rows_month_sales = $result_month_sales->fetch();
$net_sales = $rows_month_sales['net_tot'];
//Week total
$result_week_sales = $db->prepare( "SELECT  DATE_SUB(DATE(NOW()), INTERVAL 1 WEEK), SUM(net_tot) AS net_tot FROM sales_invoice WHERE company_tkn = '$user_company' ORDER BY DATE_SUB(DATE(NOW()), INTERVAL 1 WEEK) DESC;" );
$result_week_sales->execute();
$rows_week_sales = $result_week_sales->fetch();
$net_sales_week = $rows_week_sales['net_tot'];

$result_company_name = $db->prepare( "SELECT * FROM company WHERE c_token = '$user_company' " );
$result_company_name->execute();
$rows_company_name = $result_company_name->fetch();
$company_name = $rows_company_name['c_company_name'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
    <title>Dashboard</title>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
    <link href="assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="assets/plugins/c3-master/c3.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/pages/dashboard2.css" rel="stylesheet">
    <link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	
    <?php include("include/topnave.php");?>
        <aside class="left-sidebar" id="navbar">
           <?php include("include/bottomnav_home.php");?>
        </aside>
        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-themecolor">Dashboard</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a oncontextmenu="return false;" href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item">Apps</li>
                            <li class="breadcrumb-item active">Dashboard 2</li>
                        </ol>
                    </div>
                    <div class="">
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img src="assets/images/icon/expense.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0" ><strong >Sales Order Invoice</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_sales_order; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3" >
                        <div class="card" >
                            <div class="card-body" >
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img src="assets/images/icon/expense.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Sales Invoice</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_sales; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img style="height: 55px;" src="assets/images/icon/expense.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Purchase Order Invoice</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_purch_order; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					 <div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img  src="assets/images/icon/expense.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Purchase Invoice</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_purch_invoice; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img  src="assets/images/icon/sales-return.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Sales Return</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_sales_rtn; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img  src="assets/images/icon/expense.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Purchase Return</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_purch_invoice_rtn; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img  src="assets/images/icon/estimate.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Estimates</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_sales_estimate; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 ">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block ">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img style="height: 55px;" src="assets/images/icon/team1.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong>Total Customers</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_customer; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img style="height: 55px;" src="assets/images/icon/inventory.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong>Total Suppliers</strong></h6>
                                        <h2 class="m-t-0"></h2><?php echo $no_supplier; ?></strong></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img style="height: 55px;" src="assets/images/icon/online.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong>Users Online</strong></h6>
                                        <h2 class="m-t-0"><?php echo $rows_curren_user; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img src="assets/images/icon/team2.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong>Total Staff</strong></h6>
                                        <h2 class="m-t-0"><?php echo $no_staff; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img style='font-size: 14px;' src="assets/images/icon/stock1.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong>Stock</strong></h6>
                                        <h2 class="m-t-0"><?php echo $total_stock; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-3">
                        <div class="card" >
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div class="m-r-20 align-self-center"><span class="lstick m-r-20"></span><img  src="assets/images/icon/assets.png" alt="Income" /></div>
                                    <div class="align-self-center">
                                        <h6 class="text-muted m-t-3 m-b-0"><strong >Out Of Stock</strong></h6>
                                        <h2 class="m-t-0"><?php echo $rows_stock_check; ?></h2></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex no-block">
                                    <div>
                                        <h3 class="card-title m-b-5"><span class="lstick"></span>Sales Overview </h3>
                                    </div>
                                    <div class="ml-auto">
                                        <select class="custom-select b-0">
                                            <option selected=""><?php echo $month;  ?>-<?php echo $year;  ?></option>
                                            
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="bg-theme stats-bar">
                                <div class="row">
                                    <div class="col-lg-2 col-md-4">
                                        <div class="p-20 active">
                                            <h6 class="text-white">Total Sales</h6>
                                            <h3 class="text-white m-b-0">₹<?php echo number_format($total_sales, 2); ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <div class="p-20">
                                            <h6 class="text-white">This Month</h6>
                                            <h3 class="text-white m-b-0">₹<?php echo number_format($net_sales, 2); ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <div class="p-20">
                                            <h6 class="text-white">This Week</h6>
                                            <h3 class="text-white m-b-0">₹<?php echo number_format($net_sales_week, 2); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>-->
							<!--Chart-->
							<div class="card-body">
								<div class="col-lg-12">
									<div class="card">
											<h4 class="card-title">Monthly Report</h4>
											<div id="bar-chart" style="width:100%; height:400px;"></div>
									</div>
								</div>
							</div>
							<!--Chart-->
                        </div>
                    </div>
					<div class="col-lg-3 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><span class="lstick"></span>Company Wise Sales<br>This Month</h4>
                                <div id="sales" style="height:450px; width:100%;"></div>
                                <table class="table vm font-14 " style="overflow: auto;">
									<?php 
									$result_company= $db->prepare( "select  * FROM company " );
									$result_company->execute();
									for($i=0; $rows_company = $result_company->fetch(); $i++){
									$comp_token = $rows_company['c_token'];
										
									?>
                                    <tr>
                                        <td class="b-0"><?php echo $rows_company['c_company_name']; ?></td>
                                        <td class="text-right font-medium b-0"><?php $result_sales_avrg= $db->prepare( "SELECT SUM(net_tot) AS total_amount , DATE(sales_invodate) AS Date FROM sales_invoice
										WHERE DATE(sales_invodate) >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND company_tkn='$comp_token' GROUP BY company_tkn" );
										$result_sales_avrg->execute();
										for($i1=0; $rows_sales_avrg = $result_sales_avrg->fetch(); $i1++){ 
										$total_monthly_sales= $rows_sales_avrg['total_amount'];  echo $total_monthly_sales; } ?>
										</td>
                                    </tr>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
				</div>
				<div class="row">
                    <div class="col-lg-9">
                        <div class="card">
							<div class="card-body">
                                <div class="d-flex no-block">
                                    <div>
                                        <h3 class="card-title m-b-5"><span class="lstick"></span>Sales Overview </h3>
                                    </div>
                                    <div class="ml-auto">
                                        <select class="custom-select b-0">
                                            <option selected=""><?php echo $month;  ?>-<?php echo $year;  ?></option>
                                            
                                        </select>
                                    </div>
                                </div>
                            </div>
						<div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Line chart</h4>
                                <div id="purchase" style="width:100%; height:400px;"></div>
                            </div>
                        </div>
                    </div>
					</div>
					</div>
					<div class="col-lg-3 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"><span class="lstick"></span>Company Wise Purchase<br>This Month</h4>
                                <div id="purchase_overview" style="height:450px; width:100%;"></div>
                                <table class="table vm font-14 " style="overflow: auto;">
									<?php 
									$result_company= $db->prepare( "select  * FROM company " );
									$result_company->execute();
									for($i=0; $rows_company = $result_company->fetch(); $i++){
									$comp_token = $rows_company['c_token'];
										
									?>
                                    <tr>
                                        <td class="b-0"><?php echo $rows_company['c_company_name']; ?></td>
                                        <td class="text-right font-medium b-0"><?php $result_sales_avrg= $db->prepare( "SELECT SUM(total_price) AS total_amount , DATE(bill_date) AS Date FROM purchase_invoice
										WHERE DATE(bill_date) >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND company_tkn='$comp_token' GROUP BY company_tkn" );
										$result_sales_avrg->execute();
										for($i1=0; $rows_sales_avrg = $result_sales_avrg->fetch(); $i1++){ 
										$total_monthly_sales= $rows_sales_avrg['total_amount'];  echo $total_monthly_sales; } ?>
										</td>
                                    </tr>
                                   <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
				</div>
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme working">4</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme">7</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
	<?php if(isset($_COOKIE['CC']) && $_COOKIE['CC'] == true){ ?> 
<script> $(document).ready(function(){
		$.toast({heading: 'Welcome To <?php echo $company_name; ?>',text: '',position: 'top-right',loaderBg: '#1E25B0',icon: 'info',hideAfter: 2500,hideMethod: 'fadeOut'
		});
	});
</script>
<?php } ?>
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/perfect-scrollbar.jquery.min.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="assets/plugins/d3/d3.min.js"></script>
    <script src="assets/plugins/c3-master/c3.min.js"></script>
	
	 <!-- Chart JS -->
    <script src="assets/plugins/echarts/echarts-all.js"></script>
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/plugins/d3/d3.min.js"></script>
    <script src="assets/plugins/c3-master/c3.min.js"></script>
    <script src="js/dashboard2.js"></script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

	<?php include ('include/disable_fn.php'); ?>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
	<script src="js/toastr.js"></script> 
<script>
	
// ============================================================== 
// Bar chart 
// ============================================================== 
var myChart = echarts.init(document.getElementById('bar-chart'));

// specify chart configuration item and data
option = {
    tooltip : {
        trigger: 'axis'
    },
    legend: {
        data:['Sales','Sales Return']
    },
    toolbox: {
        show : true,
        feature : {
            
            magicType : {show: true, type: ['line', 'bar']},
            restore : {show: true, title:'Restore'},
            saveAsImage : {show: true}
        }
    },
    color: ["#55ce63", "#009efb"],
    calculable : true,
	
    xAxis : [
        {
            type : 'category',
			
            data : [
				  <?php
				$result_monthly_sales= $db->prepare( "select  sum(net_tot) as net_tot, sales_invodate as sales_invodate from sales_invoice WHERE  sales_invodate <= '$today' AND company_tkn ='$user_company' group by  MONTH(sales_invodate)" );
				$result_monthly_sales->execute();
				for($i=0; $rows_monthly_sales = $result_monthly_sales->fetch(); $i++){
				$total_monthly_sales= $rows_monthly_sales['net_tot'];

				echo "'".$sales_month = date('F',strtotime($rows_monthly_sales['sales_invodate']))."',";
				}
				?>
			]
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : [
        {
            name:'Sales',
            type:'bar',
            data:[
				<?php
				$result_monthly_sales= $db->prepare( "select  sum(net_tot) as net_tot, sales_invodate as sales_invodate from sales_invoice WHERE  sales_invodate <= '$today' AND company_tkn='$user_company' group by MONTH(sales_invodate)" );
				$result_monthly_sales->execute();
				for($i=0; $rows_monthly_sales = $result_monthly_sales->fetch(); $i++){
				$total_month_sales=$rows_monthly_sales['net_tot'];
				echo  "".$rows_monthly_sales['net_tot'].",";
				
				}
				?>
			],
            markPoint : {
                data : [
                    {type : 'max', name: 'Max'},
                    {type : 'min', name: 'Min'}
                ]
            },
            markLine : {
                data : [
                    {type : 'average', name: 'Average'}
                ]
            }
        },
        {
            name:'Sales Return',
            type:'bar',
            data:[
				
				<?php
				$result_monthly_sales1= $db->prepare( "select  sum(grand_tot) as grand_tot, sales_rtndate as sales_rtndate from sales_rtn_invoice WHERE  sales_rtndate <= '$today' AND company_tkn='$user_company' group by  MONTH(sales_rtndate)" );
				$result_monthly_sales1->execute();
				for($i=0; $rows_monthly_sales1 = $result_monthly_sales1->fetch(); $i++){
				$total_monthly_sales= $rows_monthly_sales1['grand_tot'];

				echo  "".$rows_monthly_sales1['grand_tot'].",";
				}
				?>
			],
			
            markLine : {
                data : [
                    {type : 'average', name : 'Average'}
                ]
            }
        }
    ]
};
                    
 // ============================================================== 
    // AVG SALES
    // ============================================================== 
    
    var chart = c3.generate({
        bindto: '#sales',
        data: {
            columns: [
				<?php $result_company= $db->prepare( "select  * FROM company" );
				$result_company->execute();
				for($i=0; $rows_company = $result_company->fetch(); $i++){
				$comp_token = $rows_company['c_token'];
			    ?>
				
                [<?php echo "'".$rows_company['c_company_name']."'"; ?>, <?php  $result_sales_avrg= $db->prepare( "SELECT SUM(net_tot) AS total_amount , DATE(sales_invodate) AS Date FROM sales_invoice
				WHERE DATE(sales_invodate) >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND company_tkn='$comp_token' GROUP BY company_tkn" );
				$result_sales_avrg->execute();
				for($i1=0; $rows_sales_avrg = $result_sales_avrg->fetch(); $i1++){ 
				$total_monthly_sales= $rows_sales_avrg['total_amount'];  echo $total_monthly_sales;  } ?>],
				<?php  } ?>
            ],
			
            
            type : 'donut',
            onclick: function (d, i) { console.log("onclick", d, i); },
            onmouseover: function (d, i) { console.log("onmouseover", d, i); },
            onmouseout: function (d, i) { console.log("onmouseout", d, i); }
        },
        donut: {
            label: {
                show: true
              },
            title:"Sales",
            width:35,
            
        },
        
        legend: {
          hide: false
          //or hide: 'data1'
          //or hide: ['data1', 'data2']
        },
        color: {
              pattern: ['#4089FB', '#745af2', '#26c6da', '#1e88e5','#26f98f']
        }
    });
  	  
// ============================================================== 
    // AVG Purchase
    // ============================================================== 
    
    var chart = c3.generate({
        bindto: '#purchase_overview',
        data: {
            columns: [
				<?php $result_company= $db->prepare( "select  * FROM company" );
				$result_company->execute();
				for($i=0; $rows_company = $result_company->fetch(); $i++){
				$comp_token = $rows_company['c_token'];
			    ?>
				
                [<?php echo "'".$rows_company['c_company_name']."'"; ?>, <?php  $result_sales_avrg= $db->prepare( "SELECT SUM(total_price) AS total_amount , DATE(bill_date) AS Date FROM purchase_invoice
				WHERE DATE(bill_date) >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND company_tkn='$comp_token' GROUP BY company_tkn" );
				$result_sales_avrg->execute();
				for($i1=0; $rows_sales_avrg = $result_sales_avrg->fetch(); $i1++){ 
				$total_monthly_sales= $rows_sales_avrg['total_amount'];  echo $total_monthly_sales;  } ?>],
				<?php  } ?>
            ],
			
            
            type : 'donut',
            onclick: function (d, i) { console.log("onclick", d, i); },
            onmouseover: function (d, i) { console.log("onmouseover", d, i); },
            onmouseout: function (d, i) { console.log("onmouseout", d, i); }
        },
        donut: {
            label: {
                show: true
              },
            title:"Purchase",
            width:35,
            
        },
        
        legend: {
          hide: false
          //or hide: 'data1'
          //or hide: ['data1', 'data2']
        },
        color: {
              pattern: ['#55ce63', '#02F4E9', '#26c6da', '#1e88e5','#26f98f']
        }
    });
  	  	
	
	
	
// use configuration item and data specified to show chart
myChart.setOption(option, true), $(function() {
            function resize() {
                setTimeout(function() {
                    myChart.resize()
                }, 300)
            }
            $(window).on("resize", resize), $(".sidebartoggler").on("click", resize)
        });

// ============================================================== 
	
	
// ============================================================== 
// Line chart
// ============================================================== 
var dom = document.getElementById("purchase");
var mytempChart = echarts.init(dom);
var app = {};
option = null;
option = {
   
    tooltip : {
        trigger: 'axis'
    },
    legend: {
        data:['Purchase','Purchase Return']
    },
    toolbox: {
        show : true,
        feature : {
            magicType : {show: true, type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    color: ["#55ce63", "#009efb"],
    calculable : true,
    xAxis : [
        {
            type : 'category',			

            boundaryGap : true,
            data : [<?php
				$result_monthly_sales= $db->prepare( "select  sum(total_price) as net_tot, bill_date as bill_date from purchase_invoice WHERE  bill_date <= '$today' AND company_tkn ='$user_company' group by  MONTH(bill_date)" );
				$result_monthly_sales->execute();
				for($i=0; $rows_monthly_sales = $result_monthly_sales->fetch(); $i++){
				$total_monthly_sales= $rows_monthly_sales['net_tot'];

				echo "'".$sales_month = date('F',strtotime($rows_monthly_sales['bill_date']))."',";
				}
				?>]
        }
    ],
    yAxis : [
        {
            type : 'value',
            axisLabel : {
                formatter: '{value}'
            }
        }
    ],

    series : [
        {
            name:'Purchase',
            type:'line',
            color:['#000'],
            data:[<?php
				$result_monthly_sales= $db->prepare( "select  sum(total_price) as net_tot, bill_date as bill_date from purchase_invoice WHERE  bill_date <= '$today' AND company_tkn='$user_company' group by MONTH(bill_date)" );
				$result_monthly_sales->execute();
				for($i=0; $rows_monthly_sales = $result_monthly_sales->fetch(); $i++){
				$total_month_sales=$rows_monthly_sales['net_tot'];
				echo  "".$rows_monthly_sales['net_tot'].",";
				
				}
				?>],
            markPoint : {
                data : [
                    {type : 'max', name: 'Max'},
                    {type : 'min', name: 'Min'}
                ]
            },
            itemStyle: {
                normal: {
                    lineStyle: {
                        shadowColor : 'rgba(0,0,0,0.3)',
                        shadowBlur: 10,
                        shadowOffsetX: 8,
                        shadowOffsetY: 8 
                    }
                }
            },        
            markLine : {
                data : [
                    {type : 'average', name: 'Average'}
                ]
            }
        },
        {
            name:'Purchase Return',
            type:'line',
            data:[<?php
				$result_monthly_sales1= $db->prepare( "select  sum(total_price) as grand_tot, bill_date as bill_date from purchasereturn_invoice WHERE  bill_date <= '$today' AND company_tkn='$user_company' group by  MONTH(bill_date)" );
				$result_monthly_sales1->execute();
				for($i=0; $rows_monthly_sales1 = $result_monthly_sales1->fetch(); $i++){
				$total_monthly_sales= $rows_monthly_sales1['grand_tot'];

				echo  "".$rows_monthly_sales1['grand_tot'].",";
				} ?>],
            markPoint : {
                data : [
                    {name : 'Week minimum', value : -2, xAxis: 1, yAxis: -1.5}
                ]
            },
            itemStyle: {
                normal: {
                    lineStyle: {
                        shadowColor : 'rgba(0,0,0,0.3)',
                        shadowBlur: 10,
                        shadowOffsetX: 8,
                        shadowOffsetY: 8 
                    }
                }
            }, 
            markLine : {
                data : [
                    {type : 'average', name : 'Average'}
                ]
            }
        }
    ]
};

if (option && typeof option === "object") {
    mytempChart.setOption(option, true), $(function() {
            function resize() {
                setTimeout(function() {
                    mytempChart.resize()
                }, 100)
            }
            $(window).on("resize", resize), $(".sidebartoggler").on("click", resize)
        });
}	
	
</script>
	
	
<script>
$(document).keyup(function(e){
	if ( e.altKey && e.which == 48 ) {window.location.href = "index2.php";
	}else if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "analysis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
</script>
</body>

</html>