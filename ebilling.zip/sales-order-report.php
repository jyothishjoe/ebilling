<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( "datetime_creation/datetime_creation.php" );
include( 'db-connect/db.php' );
if(isset ($_GET['startdate'], $_GET['enddate'])){
	$startdate = $_GET['startdate'];
	$enddate = $_GET['enddate']; 
} else {
  $startdate=''; $enddate='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
<title>Sales Order Report</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
</head>
<body class="fix-header card-no-border fix-sidebar">
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h3 class="text-themecolor">Sales Order Reports</h3>
        </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
            <li class="breadcrumb-item"><a href="saleshome.php">Sales</a></li>
            <li class="breadcrumb-item active">Sales Order Reports</li>
          </ol>
        </div>
        <div>
          
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
                <div class="form-row" style="margin-top: 12px;">
                  <?php include("include/datemask.php");?>
                  <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
                    <input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Show"/>
                  </div>
                </div>
              </form>
              <div class="table-responsive m-t-40" >
                <?php if(isset ($_GET['startdate'], $_GET['enddate'])){
		
													$date = date_create($startdate);
													$startdate = date_format($date,'Y-m-d');
													$dates = date_create($enddate);
													$enddate = date_format($dates,'Y-m-d');
													/*$result_supplier = $db->prepare("SELECT SUM(tot_amt) AS tot_amt FROM sales_order_invoice where order_invdate >= '$startdate' AND  order_invdate <= '$enddate'");
													$result_supplier->execute();
													$rows_supplier = $result_supplier->fetch(); 
													$sum = $rows_supplier['tot_amt'];*/?>
                <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Order Date</th>
                      <th>Order No</th>
                      <th>Customer Name</th>
                      <th>Phone Number</th>
                      <th>Location</th>
                      <th>Total Qty</th>
                      <th>Amount</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
					//Tution Start
					$sl=0;
					$result = $db->prepare("select * from  sales_order_invoice where order_invdate >= '$startdate' AND  order_invdate <= '$enddate' AND company_tkn='$user_company'");
							$result->execute();
					for($i=0; $row = $result->fetch(); $i++)
						{	 $sl++;	$cus_tkn=$row['cus_tkn'];?>
                    <tr>
                      <td><?php echo $sl; ?></td>
                      <td><?php echo date('d-m-Y', strtotime( $row['order_invdate'])); ?><br>
                        <?php echo $row['order_invtime']; ?></td>
                      <td><?php echo $row['bill_no']; ?></td>
                      <td><?php echo ucfirst($row['cus_name']); ?></td>
                      <?php
						$result1 = $db->prepare("select * from  customer where cus_tkn='$cus_tkn' AND company_tkn='$user_company'");
						$result1->execute();  $row1 = $result1->fetch();  ?>
                      <td><?php echo $row1['contact_no1']; ?></td>
                      <td><?php echo ucfirst($row1['location']); ?></td>
                      <td><?php echo $row['tot_qty']; ?></td>
                      <td><?php echo $row['tot_amt']; ?></td>
                      <td><a class="btn btn-sm btn-info" href="sales-order-reprint.php?bill=<?php echo $row['bill_no']; ?>"><i class="fas fa-print"></i></a></td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="right-sidebar">
        <div class="slimscrollright">
          <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
          <div class="r-panel-body">
            <ul id="themecolors" class="m-t-20">
              <li><b>With Light sidebar</b> </li>
              <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
              <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
              <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
              <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
              <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
              <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
              <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
              <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
              <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
              <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
              <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
              <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
              <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
            </ul>
            
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>
<script src="js/auto_js/jquery-3.2.1.min.js"></script> 
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<script src="assets/plugins/bootstrap/js/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/datatables/datatables.min.js"></script> 
<script src="assets/table/js/dataTables.buttons.min.js"></script> 
<script src="assets/table/js/buttons.flash.min.js"></script> 
<script src="assets/table/js/jszip.min.js"></script> 
<script src="assets/table/js/pdfmake.min.js"></script> 
<script src="assets/table/js/vfs_fonts.js"></script> 
<script src="assets/table/js/buttons.html5.min.js"></script> 
<script src="assets/table/js/buttons.print.min.js"></script> 
<?php include ('include/disable_fn.php'); ?>
<script>
	
		$( '#example23' ).DataTable( {
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]
		} );
		$( '.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel' ).addClass( 'btn btn-primary mr-1' );
		
		
	</script> 
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
</body>
</html>