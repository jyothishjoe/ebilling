<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
$token = $_GET[ 'barcode' ];
$result_stock = $db->prepare( "SELECT * FROM item_pricing WHERE pr_barcode = '$token' " );
$result_stock->execute();
$rows_stock = $result_stock->fetch();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Supermarket</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
	<div id="custom-content" class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #f2f2f2;">
		<h3 class="text-center" style="margin-top: 12px; margin-bottom: 12px;">BARCODE GENARATE</h3>
		<form class="form-horizontal" method="post" action="barcode.php" target="_blank">
			<div class="form-row">
				<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
					<label for="" class="control-label">Barcode</label>
					<input type="text" class="form-control" id="code" name="code" value="<?php echo $rows_stock['pr_barcode']; ?>" placeholder="Name" readonly>
					<input type="hidden" class="form-control" id="token" name="token" value="" readonly>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
					<label for="" class="control-label">Product Name</label>
					<input type="text" class="form-control" id="name" name="name" value="<?php echo $rows_stock['pr_name']; ?>" placeholder="Sub Category" readonly>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
					<label for="" class="control-label">MRP Rate</label>
					<input type="text" class="form-control" id="mrp" name="mrp" value="<?php echo $rows_stock['unit_price']; ?>" placeholder="Manufacturer" readonly>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 mb-3">
					<label for="" class="control-label">Barcode Qty</label>
					<input type="text" class="form-control" id="qty" name="qty" value="" placeholder="Qty" required>
				</div>
				<div class="col-md-12" style="float: right; padding-bottom: 25px; padding-top: 15px;">
					<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="float: right;">CANCEL</button>&nbsp;&nbsp;
					<button type="submit" id="close_fbx" class="btn btn-sm btn-info " style="float: right;">PRINT</button>

				</div>
		</form>
		</div>
		<script>
			$( '#close_fbx' ).on( 'click', function () {
				parent.jQuery.magnificPopup.close();
			} );
		</script>
</body>

</html>