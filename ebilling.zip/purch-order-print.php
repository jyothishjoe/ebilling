<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$billid = $_GET[ 'bill' ];
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$result_billitem = $db->prepare( "SELECT * FROM purchaseorder_invoice WHERE po_no = '$billid' " );
$result_billitem->execute();
$rows_billitem = $result_billitem->fetch();
$previous = "javascript:history.go(-1)";
if ( isset( $_SERVER[ 'HTTP_REFERER' ] ) ) {
	$previous = $_SERVER[ 'HTTP_REFERER' ];
}
$user_company = $_SESSION[ 'SESS_COMPANY_ID' ];
$result_user_company = $db->prepare( "SELECT * FROM company WHERE c_token = '$user_company'" );
$result_user_company->execute();
$rows_user_company = $result_user_company->fetch();
$logo = $rows_user_company[ 'c_logo' ];
?>
<html>
<title></title>
<head>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<link href="css/style.css" rel="stylesheet">

	<style>
		table td {
			height: 15px;
		}
		
		@media print {
			.btn {
				display: none;
			}
		}
		
		.hr {
			border: none;
			border-top: 1px solid black;
			margin-top: 10px;
		}
	</style>
	<?php include("include/print_size.php");?>
</head>

<body>
	<?php
	$result_bill = $db->prepare( "SELECT * FROM purchaseorder_invoice WHERE po_no = '$billid' " );
	$result_bill->execute();
	$rows_bill = $result_bill->fetch();
	$supplier = $rows_bill[ 'supplier_id' ];
	?>
	<div class="col-md-12" style="margin-top: 18px;">
		<a href="<?php echo $previous; ?>" </a><button type="button" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:left; margin-right: 25px; margin-top: 10px;"><i class="fa fa-backward"></i> Back</button>
		</a>
		<button type="button" onClick="window.print()" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:right; margin-right: 25px; margin-top: 10px;"><i class="fa fa-print"></i> Print</button>
	</div>
	<div class="row">
		<div class=" col-xs-12 printwidth" style="padding:0px 50px; margin-top: 15px;">
			<table style="line-height: 25px;" class="" width="100%">

				<thead>
					<tr>
						<td colspan="6">
							<strong style="font-size: 20px;">
								<?php echo $rows_user_company['c_company_name']; ?>
							</strong><strong style="float: right;">GSTIN : <?php echo $rows_user_company['c_gst']; ?></strong><br>
							<strong>
								<?php echo $rows_user_company['c_shopaddress']; ?>
							</strong><br>
							<strong>
								<?php echo $rows_user_company['address_sec']; ?>
							</strong><br>
							<strong>Email : <?php echo $rows_user_company['c_email']; ?></strong><br>
							<strong>Phone : +<?php echo $rows_user_company['c_phone']; ?></strong>, <strong>Mobile : +<?php echo $rows_user_company['c_mobile']; ?></strong>
						</td>
					</tr>
				</thead>
				<tr>
					<td colspan="6" class="border-bottom border-top" align="center"><strong><u>Purchase Order</u></strong>
					</td>
				</tr>
				<?php
				$result_sup = $db->prepare( "SELECT * FROM supplier WHERE supplier_token = '$supplier' " );
				$result_sup->execute();
				$rows_sup = $result_sup->fetch();
				?>
				<tr class="border-bottom">
					<td colspan="3" width="50%">
						<b>To:</b><br>
						<b><?php echo $rows_sup['v_name']; ?></b><br>
						<!--<b><?php echo $rows_sup['company']; ?></b><br>-->
						<b><?php echo $rows_sup['address']; ?></b><br>
						<b>Phone: <?php echo $rows_sup['phone']; ?></b><br>
						<strong>GSTIN : <?php echo $rows_sup['gstin']; ?></strong>
					</td>
					<td colspan="3" width="50%" align="right">
						<b class="float-right">Purchase Order No. #<?php echo $rows_bill['po_no']; ?></b><br>
						<b style="margin-right: 31px;">Date: <?php echo $rows_bill['date']; ?></b>
					</td>
				</tr>
				
						<tr class="border-bottom">
							<th class="center">#</th>
							<th>Item</th>
							<th>Unit</th>
							<th>Qty</th>
							<th class="right">Unit Cost</th>

							<th class="right">Total</th>
						</tr>
					
					<tbody>
						<?php
						$sl = 0;
						$result_billitms = $db->prepare( "SELECT * FROM purchaseorder_productdetails WHERE po_no = '$billid' " );
						$result_billitms->execute();
						for ( $i = 0; $rows_billitem = $result_billitms->fetch(); $i++ ) {
							$pri = $rows_billitem[ 'price' ];
							$qt = $rows_billitem[ 'qty' ];
							$tot = $rows_bill[ 'g_total' ];
							?>
						<tr class="border-bottom">
							<td class="center">
								<?php echo ++$sl; ?>
							</td>
							<td class="left strong">
								<?php echo $rows_billitem['pr_name']; ?>
							</td>
							<td class="left">
								<?php echo $rows_billitem['unit']; ?>
							</td>
							<td class="right">
								<?php echo $rows_billitem['price']; ?>
							</td>
							<td class="center">
								<?php echo $rows_billitem['qty']; ?>
							</td>
							<td class="right">
								<?php echo $rows_billitem['total']; ?>
							</td>
						</tr>
						<?php } ?>
						<!--<tr>
							<td colspan="4" ></td>
							<td class="border-bottom" class="right">
								
							</td>
							<td class="right" class="border-bottom" >
								
							</td>
						</tr>-->
						<br>
						<tr>
							<td colspan="4"></td>
							<td class="right" class="border-bottom">
								<strong >Total</strong>
							</td>
							<td class="right" class="border-bottom">
								<strong ><?php echo   $tot; ?></strong>
							</td>
						</tr>
						<tr class=" border-bottom">
							<td align="left" colspan="6">
								<?php 
									   $number =   $tot;
									   $no = round($number);
									   $point = round($number - $no, 2) * 100;
									   $hundred = null;
									   $digits_1 = strlen($no);
									   $i = 0;
									   $str = array();
									   $words = array('0' => '', '1' => 'One', '2' => 'Two',
										'3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
										'7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
										'10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
										'13' => 'Thirteen', '14' => 'Fourteen',
										'15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
										'18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
										'30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
										'60' => 'Sixty', '70' => 'Seventy',
										'80' => 'Eighty', '90' => 'Ninety');
									   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
									   while ($i < $digits_1) {
										 $divider = ($i == 2) ? 10 : 100;
										 $number = floor($no % $divider);
										 $no = floor($no / $divider);
										 $i += ($divider == 10) ? 1 : 2;
										 if ($number) {
											$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
											$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
											$str [] = ($number < 21) ? $words[$number] .
												" " . $digits[$counter] . $plural . " " . $hundred
												:
												$words[floor($number / 10) * 10]
												. " " . $words[$number % 10] . " "
												. $digits[$counter] . $plural . " " . $hundred;
										 } else $str[] = null;
										  }
										  $str = array_reverse($str);
										  $result = implode('', $str);
										  $points = ($point) ?
											"." . $words[$point / 10] . " " . 
												  $words[$point = $point % 10] : ''; ?> In Words :
								<strong>
									<?php echo $result . "Rupees  " . $points . "only"; ?>
								</strong>
							</td>
						</tr>
						<tr>
			<td colspan="6">
				
				
				<br><strong style="float: left;">E & OE</strong>
				

			<b style="float:right">Authorised Signatory<br><br>(with Status & Seal)&nbsp;</b>
				
			</td>
		</tr>
					</tbody>
				</table>
			</div>
		</div>
	<script>$( document ).ready( function () {

			var headstr = "<html><head><title></title></head><body>";
			var footstr = "</body>";

			var oldstr = document.body.innerHTML;
			document.body.innerHTML = headstr + footstr;
			window.print();
			document.body.innerHTML = oldstr;
			//window.location.href="sales-bill.php";

		} );
		window.onafterprint = function() {
		history.go(-1);
		};</script>
</body>
</body>

</html>