<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$token = $_GET[ 'sup_id' ];
$result_supplier = $db->prepare( "SELECT * FROM supplier WHERE supplier_token='$token' " );
$result_supplier->execute();
$rows_supplier = $result_supplier->fetch();
?>
<style>
	#close_fbx {
		margin: 0px;
		position: relative;
		background: #f2382c !important;
		color: #fff;
		opacity: 1;
		width: 60px;
		font-size: 12px;
		height: 30px;
		line-height: 0px;
		padding: 0px !important;
		display: inline;
	}
	#close_fbx:hover {
		background: #f2382c !important;
	}
</style>
<div id="custom-content" class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #f2f2f2;">
	<center>
		<h4 style="padding-bottom: 8px; margin-top: 8px; ">Edit Supplier</h4>
	</center>
	<center>
		<div id="uname_response" class="response"></div>
	</center>
	<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
		<input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
		<div class="form-row">
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Account Name</label>
					<div class="col-12">
						<input type="text" class="form-control" name="accname" id="accname" value="<?php echo $rows_supplier['v_name']; ?>" readonly>
							<input type="hidden" class="form-control" name="token" id="token" value="<?php echo $rows_supplier['supplier_token']; ?>">
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Address</label>
					<div class="col-12">
						<textarea class="form-control" name="address" id="address" rows="7"><?php echo $rows_supplier['address']; ?> </textarea>
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label col-12">State</label>
					<div class="col-12" style="padding-bottom: 3px;">
						<select class="form-control select2" id="state" name="state" style="width: 100%; height:36px;">
							<option value="<?php echo $rows_supplier['state']; ?>"><?php echo $rows_supplier['state']; ?></option>
							<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
							<option value="Andhra Pradesh">Andhra Pradesh</option>
							<option value="Arunachal Pradesh">Arunachal Pradesh</option>
							<option value="Assam">Assam</option>
							<option value="Bihar">Bihar</option>
							<option value="Chandigarh">Chandigarh</option>
							<option value="Chhattisgarh">Chhattisgarh</option>
							<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
							<option value="Daman and Diu">Daman and Diu</option>
							<option value="Delhi">Delhi</option>
							<option value="Goa">Goa</option>
							<option value="Gujarat">Gujarat</option>
							<option value="Haryana">Haryana</option>
							<option value="Himachal Pradesh">Himachal Pradesh</option>
							<option value="Jammu and Kashmir">Jammu and Kashmir</option>
							<option value="Jharkhand">Jharkhand</option>
							<option value="Karnataka">Karnataka</option>
							<option value="Kerala">Kerala</option>
							<option value="Lakshadweep">Lakshadweep</option>
							<option value="Madhya Pradesh">Madhya Pradesh</option>
							<option value="Maharashtra">Maharashtra</option>
							<option value="Manipur">Manipur</option>
							<option value="Meghalaya">Meghalaya</option>
							<option value="Mizoram">Mizoram</option>
							<option value="Nagaland">Nagaland</option>
							<option value="Orissa">Orissa</option>
							<option value="Pondicherry">Pondicherry</option>
							<option value="Punjab">Punjab</option>
							<option value="Rajasthan">Rajasthan</option>
							<option value="Sikkim">Sikkim</option>
							<option value="Tamil Nadu">Tamil Nadu</option>
							<option value="Tripura">Tripura</option>
							<option value="Uttaranchal">Uttaranchal</option>
							<option value="Uttar Pradesh">Uttar Pradesh</option>
							<option value="West Bengal">West Bengal</option>
						</select>
					</div>
					<label for="validationTooltip01" class="control-label  col-12">Zip Code</label>
					<div class="col-12">
						<input type="text" class="form-control" name="zip" id="zip" value="<?php echo $rows_supplier['zip']; ?>">
					</div>
					<label for="validationTooltip01" class="control-label  col-12">Location</label>
					<div class="col-12">
						<input type="text" class="form-control" name="city" id="city" value="<?php echo $rows_supplier['city']; ?>">
					</div>
				</div>
			</div>

			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Phone</label>
					<div class="col-12">
						<input type="text" class="form-control" name="phone" id="phone" value="<?php echo $rows_supplier['phone']; ?>">
					</div>
					<label for="validationTooltip01" class="control-label  col-12">Mobile No</label>
					<div class="col-12">
						<input type="text" class="form-control" name="contact" id="contact" value="<?php echo $rows_supplier['contact']; ?>">
					</div>
					<label for="validationTooltip01" class="control-label  col-12">Email</label>
					<div class="col-12">
						<input type="text" class="form-control" name="email" id="email" value="<?php echo $rows_supplier['email']; ?>">
					</div>
				</div>
			</div>
			
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">PAN No</label>
					<div class="col-12">
						<input type="text" class="form-control" name="pan" id="pan" value="<?php echo $rows_supplier['pan']; ?>">
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">GSTIN</label>
					<div class="col-12">
						<input type="text" class="form-control" name="gstin" id="gstin" value="<?php echo $rows_supplier['gstin']; ?>">
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Opening Balance</label>
					<div class="col-12">
						<input type="text" class="form-control" name="balance" id="balance" value="<?php echo $rows_supplier['balance']; ?>" >
					</div>

				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Credit Limimt</label>
					<div class="col-12">
						<input type="date" class="form-control" name="cr_limit" id="cr_limit" value="<?php echo $rows_supplier['credit_date']; ?>">
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Credit Amount</label>
					<div class="col-12">
						<input type="text" class="form-control" name="cr_amount" id="cr_amount" value="<?php echo $rows_supplier['credit_amount']; ?>">
					</div>
				</div>
			</div>
			<div class="col-md-4  col-sm-6 col-xs-12">
				<div class="form-group row">
					<label for="validationTooltip01" class="control-label  col-12">Discount</label>
					<div class="col-12">
						<input type="text" class="form-control" name="discount" id="discount" value="<?php echo $rows_supplier['discount']; ?>">
					</div>
				</div>
			</div>
		</div>
		<hr/>
		<div class="col-md-12" style="margin-bottom: 18px;">
			<div class="text-right">
				<a href="javascript: save_customer()" class="btn btn-sm  btn-info">Update</a>
				<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close ">CANCEL</button>
			</div>
		</div>
	</form>
</div>
<script>
	$( document ).ready( function () {

		$( "#v_name" ).keyup( function () {
			var name = $( "#v_name" ).val().trim();
			if ( name != '' ) {
				$( "#uname_response" ).show();
				$.ajax( {
					url: 'vendor-action/vendor_exist/vendor_name.php',
					type: 'post',
					data: {
						name: name
					},
					success: function ( response ) {
						if ( response > 0 ) {
							$.toast( {
								heading: 'Already Exist',
								text: '',
								position: 'top-right',
								loaderBg: '#4AD55E',
								icon: 'warning',
								hideAfter: 1500,
								hideMethod: 'fadeOut'
							} );
							$( "#uname_response" ).html( "<span class='not-exists' style='color : red;'><strong>* Already Exist.</strong></span>" );
						} else {
							$( "#uname_response" ).html( "<span class='exists' style='color : green;'><strong>Available.</strong></span>" );
						}
					}
				} );
			} else {
				$( "#uname_response" ).hide();
			}
		} );
	} );
</script>
<script>
	$( "#accname" ).change( function () {
		var accname = $( "#accname" ).val();
		$.ajax( {
			type: 'POST',
			url: 'vendor-action/accountname_change.php',
			data: 'accname=' + accname,
			dataType: "JSON",
			success: function ( data ) {
				$( '#v_name' ).val( data.name );
				$( '#ledger_token' ).val( data.token );
				$( '#gstin' ).val( data.gst );
				$( '#pan' ).val( data.pan );
			}
		} );
	} );
	//$('#close_fbx' ).on( 'click', function () {
	//parent.jQuery.fancybox.close();
	//});
</script>
<script>
			                            $( '#close_fbx' ).on( 'click', function () {
		                                  parent.jQuery.magnificPopup.close();
	                                               } );
										function save_customer() {
											var phone = $( "#phone" ).val();
											var email = $( "#email" ).val();
											var gstin = $( "#gstin" ).val();
											var city = $( "#city" ).val();
											var token = $( "#token" ).val();
											var pan = $( "#pan" ).val();
											var cr_amount = $( "#cr_amount" ).val();
											var cr_limit = $( "#cr_limit" ).val();
											var discount = $( "#discount" ).val();
											var zip = $( "#zip" ).val();
											var state = $( "#state" ).val();
											var address = $( "#address" ).val();
											var contact = $( "#contact" ).val();
											var balance = $( "#balance" ).val();
											
											if($( "#company" ).val() == "" || $( "#name" ).val() == ""  ){
												$.toast( {
													heading: 'Fill all required fields.',
													text: '',
													position: 'top-right',
													loaderBg: '#ff6849',
													icon: 'error',
													hideAfter: 4500
												});
											}else{
												$.ajax({
												type : 'POST',
												url  : "vendor-action/supplier_edit.php",
												data: "address="+ address +  "&phone=" + phone + "&email=" + email + "&gstin=" + gstin + "&city=" + city + "&token=" + token + "&pan=" + pan + "&cr_limit=" + cr_limit + "&cr_amount=" + cr_amount + "&discount=" + discount + "&zip=" + zip + "&state=" + state + "&contact=" + contact + "&balance=" + balance,
												success : function(r) {						
												$("#respond").html(r);
													}
												});
												parent.jQuery.magnificPopup.close();
												$.toast( { heading: 'Updated Succeccfully.', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 4500
												});
												setTimeout(location.reload.bind(location), 600);
												return false;
											}
										}
									</script>