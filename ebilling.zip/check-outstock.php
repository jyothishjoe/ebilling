<?php 
include ('include/auth.php');
include('db-connect/db.php');
include('include/today.php');
?>
<div class="col-xs-12 no-padding" style="width:700px; overflow: hidden;">
	<h3 class="text-center">Out Of Stocks </h3>
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">
				<div class="table-responsive" style="height: 250px; overflow: auto;">
					<table class="table" >
						<thead>
							<tr>
								<th>#</th>
								<th>Item Name</th>
								<th>Code</th>
								<th>HSN</th>
								<th>Unit</th>
								<th>Stock</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$result_stock = $db->prepare("SELECT * FROM stocks WHERE pr_stock < 5 ");
						$result_stock->execute();
						$sl=0;
						for($i=0; $rows_stock = $result_stock->fetch();  $i++){
							$stock = $rows_stock['pr_stock'];
						?>
							<tr>
								<td><?php echo ++$sl; ?></td>
								<td><?php echo $rows_stock['pr_name']; ?></td>
								<td><?php echo $rows_stock['pr_code']; ?></td>
								<td><?php echo $rows_stock['pr_hsn']; ?></td>
								<td><?php echo $rows_stock['pr_unit']; ?></td>
								<?php 
							    if($stock < 0 ) {?>
								<td><strong style="color: red; font-size: 15px;"><?php echo $rows_stock['pr_stock']; ?></strong></td>
								<?php } else{ ?>
								<td><strong style="color: orange; font-size: 15px;"><?php echo $rows_stock['pr_stock']; ?></strong></td>
								<?php } ?>
								<td><span class="label label-sm label-danger">Out of Stock</span>
								</td>
								<td><a href="purchase-product.php?id=<?php echo $rows_stock['pr_code']; ?>" class="btn btn-sm btn-info">Add Stock</a></td>
								
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
			<div class="text-right">

				<button type="button" id="close_fbx" class="btn btn-sm btn-danger"  style="position: absolute; right: 15px; bottom: -30	px;">CANCEL</button>
			</div>
		</div>
	</div>
</div>

<script>
	$( '#close_fbx' ).on( 'click', function () {
		parent.jQuery.fancybox.close();
	} );
</script>