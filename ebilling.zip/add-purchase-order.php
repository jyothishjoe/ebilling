<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'datetime_creation/datetime_creation.php' );
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];

$date_set = $today;

?>
<!doctype html>
<html>
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Purchase Order</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/table/css/switchery.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading..</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h4 class="text-themecolor">Purchase Order&nbsp;<strong>( <?= date('d-m-Y') ?>)</strong></h4>
					</div>
					<div class="col-md-7 align-self-center" style="z-index:9 !important;">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index.php">Home</a>
							</li>
							<li class="breadcrumb-item active"><a href="purchase-home.php">Purchase</a></li>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<a href="create-ledger.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="openledger">Ledger(F1)</a>
								<a href="add-supplier.php" class="btn btn-sm btn-info fancybox fancybox.ajax" id="opensupplier">Add Supplier(F2)</a>
								<a href="add-product.php" class="btn btn-sm btn-info simple-ajax-popup-align-top" id="openproduct">Add Product(F3)</a>
								<div class="clear"></div>
								<hr/>
								<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
								<input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
									<input type="hidden" name="company" id="company" value="<?php echo $user_company; ?>">
									<table style="margin-bottom: 18px;">
										<?php
										$result_bill = $db->prepare( "SELECT * FROM purchaseorder_invoice WHERE company_tkn='$user_company' ORDER BY id DESC LIMIT 1 " );
										$result_bill->execute();
										$rows_bill = $result_bill->fetch(); 
										$row_count = $result_bill->rowCount();
										$prefix = 'PO';
										if($row_count == 0){
											$invno = 'PO1';
											$invno1 = '1';
										}else{
										$invno =sprintf( "%s%1s", $prefix, $rows_bill['id'] + 1);
											$invno1 = $rows_bill['id'] + 1;
											}
										?>
										<tr>
											<div class="col-md-12" style="float: right; margin-bottom: 12px;">
												<td>
												<div class="row"><div class="col-md-6"><label></label><input type="hidden" class="form-control" name="invno" value="<?php echo $invno1; ?>" id="invno" readonly><input type="hidden" class="form-control" name="po_no" 876543a#4
													9=	cb placeholder="PO NO" value="<?php echo $invno; ?>" >
													<input type="text" class="form-control" name="po_no1" id="po_no1" placeholder="PO NO" value="<?php echo $invno1; ?>"  >
													</div></div>
												</td>
												<td align="right" style="position: absolute; left: 950px; margin-bottom: 12px;">
													<input type="date" class="form-control" style="width: 155px; display: inline;" name="date" id="date" value="<?= $date_set;  ?>" > &nbsp;
													<input type="time" class="form-control" style="width: 120px; display: inline;" name="time" id="time" value="<?= date('H:i') ?>" readonly>
													<br>
													<br>
												</td>
											</div>
										</tr>
									</table>
									<div class="form-row">
										<div class="col-md-2 ">
											<div class="form-group row">
												<label for="validationTooltip06" class="control-label  col-md-12">Due Date</label>
												<div class="col-md-12">
												<?php 
												$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' ORDER BY id DESC LIMIT 1");
												$result->execute();
												$rows=$result->fetch();
												$dateformate=$rows['dateformate'];
												?>
												<?php if($dateformate == 'datechoos') { ?>
													<input type="date" class="form-control" name="due_date" value="<?php echo $date_set; ?>" placeholder="Enter Date" value="">
														<?php } else { ?>
													<input type="text" class="form-control date-inputmask" name="due_date" value="<?php echo $date_set; ?>" placeholder="Enter Date" value="">
													<?php } ?>	
													<input type="hidden" class="form-control" name="dat" value="<?php echo $date_set; ?>" placeholder="Enter Date" value="">
												</div>
											</div>
										</div>
										<div class="col-md-3  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label col-12">Supplier</label>
												 <div class="col-12">
													<select class="form-control select2" id="v_name" name="v_name" style="width: 100%; height:36px;">
														<option></option>
														<?php
														$result_vendor = $db->prepare("SELECT * FROM supplier ");
														$result_vendor->execute();
														for ($i = 0; $rows_vendor = $result_vendor->fetch(); $i++) {
														?>
														<option value="<?php echo $rows_vendor['v_name']; ?>">
															<?php echo $rows_vendor['v_name']; ?>
														</option>
														<?php } ?>
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-2  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label col-12">Location</label>
												<div class="col-12">
													<input type="text" class="form-control " id="location" name="location" readonly>
													<input type="hidden" class="form-control " id="company" name="company" readonly>
													<input type="hidden" class="form-control " id="gstin" name="gstin" readonly>
													<input type="hidden" class="form-control " id="phone" name="phone" readonly>
													<input type="hidden" class="form-control"  id="supid" name="supid" readonly>
												</div>
											</div>
										</div>
										<div class="col-md-4"></div>
										<div class="col-md-4  col-sm-6 col-xs-12">
											<div class="form-group row">
												<label for="validationTooltip01" class="control-label  col-12">Address</label>
												<div class="col-12">
													<textarea class="form-control" name="vaddress" id="vaddress" placeholder="Address"></textarea>
												</div>
											</div>
										</div>
										<div class="col-md-3 col-sm-6 col-xs-12">
											<div class="form-group row">
												<div class="col-12">
													<label for="validationTooltip01" class="control-label  col-12">Remarks</label>
													<textarea class="form-control" name="remarks" id="remarks" placeholder="Remarks"></textarea>
												</div>
											</div>
										</div>
										<hr/>
										<div class="col-12">
											<h4>Product Details</h4>
											<hr/>
										</div>
										<!----Table-->
										<div class="col-sm-12 col-xs-12 " style="overflow-x: auto; ">
										<table class="table table-bordered" style="min-width: 1100px;">
											<thead>
												<tr>
													<th>Sl No</th>
													<th>Product Code</th>
													<th>Product Name</th>
													<th>HSN</th>
													<th>Qty</th>
													<th>Unit</th>
													<th>Price</th>
													<th>Total</th>
													<th style="float: right;"><input type="button" id="addmore" name="button" class="btn btn-sm btn-info" value="+">
														</button>
													</th>
												</tr>
											</thead>
											<tbody id="order">
												<tr class='tr_input'>
													<td><input type='text' name="serial" style="width: 40px;" class='form-control serial' value="1" id='serial_1' placeholder='Product Code'>
													</td>
													<td><input type='text' name="code[]" class='form-control code' id='code_1' placeholder='Product Code'>
													</td>
													<td><input type='text' name="name[]" class='form-control name' id='name_1' placeholder='Product Name'>
													</td>
													<td><input type='text' name="hsn[]" class='form-control hsn' id='hsn_1' placeholder='HSN Code'>
													</td>
													<td><input type='text' name="qty[]" class='form-control qty' id='qty_1' placeholder='Qty'>
													</td>
													<td><input type='text' name="unit[]" class='form-control unit' id='unit_1' placeholder='Unit' readonly>
													</td>
													<td><input type='text' name="price[]" class='form-control price' id='price_1' placeholder='Price' >
													</td>
													<td><input type='text' name="total[]" class='form-control total' id='total_1' placeholder='Total' readonly>
													</td>
													<td></td>
												</tr>
											</tbody>
										</table>
										</div>
										<table class="table" >
											<tr>
												<td align="right" class="control-label"></td>
												<td width="150"><input type="hidden" readonly class="form-control" name="discountt" id="discountt" placeholder="Discount" value="0" style="width:120px;">
												</td>
											</tr>
											<tr>
											<div class="col-md-6 col-sm-4 col-xs-12">
												<td align="right" class="control-label">Total Amount:</td>
												<td width="10"><input type="text" readonly class="form-control totalprice" name="totalprice" id="totalprice" style="width:150px;">
												</td>
												</div>
												<td align="right" class="control-label"></td>
												<td width="150"><input type="hidden" readonly class="form-control" name="gtotalprice" id="gtotalprice" placeholder="Grant Total" style="width:120px;">
												</td>
												
												<td align="right" class="control-label"></td>
												<td width="150"><input type="hidden" class="form-control" name="paidamount" id="paidamount" onKeyUp="calculatedicounttotal(2)" placeholder="Paying Amount" style="width:120px;">
												</td>
											</tr>
											<tr>
												<td align="right" class="control-label"></td>
												<td width="150"><input type="hidden" readonly class="form-control" value="0" name="balance" id="balance" placeholder="Balance" style="width:120px;">
												</td>
											</tr>
										</table>
									</div>
									</div>
									<div class="form-group" align="right" style="padding-right:30px;">
										<label for="input-help-block" class="col-sm-2 control-label"></label>
										<div class="">
											<input type="submit" name="submit" style="float: right; margin-top: 25px;" class="btn btn-sm btn-info" value="Save & Print"/>
										</div>
								</form>
								</div>
							</div>
							<hr/>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php  if(isset($_COOKIE['PR']) && $_COOKIE['PR'] == true){ ?> <script> $(document).ready(function(){
						
						//$("#clickadd").click();
						var url = 'add-product.php';
						 $.ajax({
						type: "POST",
						url: url,
						success: function(result) {
							$('.simple-ajax-popup-align-top').magnificPopup({
								 midClick: true,
								  mainClass: 'mfp-fade',
								  closeOnBgClick: false, 
								items: {
									src: result,
									
								}
							}).magnificPopup('open');
						},
					});
						$.toast({heading: 'Product Created Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
						});
						}); </script><?php } ?>
<script>
	//addRowCount( '.js-serial' );

	function setFocusToTextBox() {
		$( "#code_1" ).focus();
	}
</script>
<script>
	$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 112 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "create-ledger.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					});
				}, 200 );
			}
			if ( event . keyCode == 113 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#opensupplier').click();
			}
			if ( event . keyCode == 114 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#openproduct').click();
			}
			if ( event . keyCode == 115 ) {
				//parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				$('#openpurchaseorder').click();
			}
		});
		
	$( '#v_name' ).change( function () {
		var v_name = $( "#v_name" ).val();
		$.ajax( {
			type: 'POST',
			url: 'purchase-action/autosearch_purchase_order/autofill_vendor_gst.php',
			data: 'v_name=' + v_name,
			dataType: "JSON",
			success: function ( data ) {
				$( '#gstin' ).val( data.value );
				$( '#vaddress' ).val( data.address );
				$( '#supid' ).val( data.supid );
				$( '#company' ).val( data.company );
				$( '#phone' ).val( data.phone );
				$( '#location' ).val( data.city );
			}
		} );
	} );
</script>
<script type="text/javascript">
	$( document ).ready( function () {

		$( document ).on( 'keydown', '.code', function () {

			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];

			$( '#' + id ).autocomplete( {
				source: function ( request, response ) {
					$.ajax( {
						url: "purchase-action/autosearch_purchase_order/purchaseorderfill.php",
						type: 'post',
						dataType: "json",
						data: {
							search: request.term,
							request: 1
						},
						success: function ( data ) {
							response( data );
						}
					} );
				},
				select: function ( event, ui ) {
					$( this ).val( ui.item.label ); // display the selected text
					var pr_code = ui.item.value;
					// selected id to input
					// AJAX
					$.ajax( {
						url: 'purchase-action/autosearch_purchase_order/purchaseorderfill.php',
						type: 'post',
						data: {
							pr_code: pr_code,
							request: 2
						},
						dataType: 'json',
						success: function ( response ) {

							var len = response.length;

							if ( len > 0 ) {
								var pr_code = response[ 0 ][ 'pr_code' ];
								var pr_name = response[ 0 ][ 'pr_name' ];
								var pr_unit = response[ 0 ][ 'pr_unit' ];
								var price = response[ 0 ]['pr_purch_price' ];
								var hsn = response[ 0 ][ 'hsn' ];

								document.getElementById( 'name_' + index ).value = pr_name;
								document.getElementById( 'unit_' + index ).value = pr_unit;
								document.getElementById( 'price_' + index ).value = price;
								document.getElementById( 'hsn_' + index ).value = hsn;
								document.getElementById( 'qty_' + index ).focus();
							}
						}
					} );
					return false;
				}
			} );
			$( '.qty' ).keyup( function () {
				$( '#total_' + index ).val( $( '#price_' + index ).val() * $( '#qty_' + index ).val() );
				/*net sum */
				var sum = 0;
				var qtysum = 0;
				var gst = 0;
				//iterate through each textboxes and add the values
				$( '.total' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						sum += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'totalprice' ).value = Math.round( sum );
				/*qty sum*/
				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qtysum += parseFloat( this.value );
					}
				} );
				/*net total*/
				document.getElementById( 'gtotalprice' ).value = Math.round( qtysum );
			} );
			$( '.coolie' ).keyup( function () {
				var sum = 0;
				var qtysum = 0;
				var cool = 0;
				//iterate through each textboxes and add the values
				$( '.coolie' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						cool += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'gtotalprice' ).value = Math.round( cool - $( '#coolie' ).val() );
				/*qty sum*/
				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qtysum += parseFloat( this.value );
					}
				} );
				/*net total*/
				document.getElementById( 'gtotalprice' ).value = Math.round( qtysum );
			} );
		} );
		$( document ).on( 'keydown', '.name', function () {
			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];
			$( '#' + id ).autocomplete( {
				source: function ( request, response ) {
					$.ajax( {
						url: "purchase-action/autosearch_purchase_order/purchaseorderfill.php",
						type: 'post',
						dataType: "json",
						data: {
							search: request.term,
							request: 3
						},
						success: function ( data ) {
							response( data );
						}
					} );
				},
				select: function ( event, ui ) {
					$( this ).val( ui.item.label ); // display the selected text
					var pr_name = ui.item.valuename;
					// selected id to input
					// AJAX
					$.ajax( {
						url: 'purchase-action/autosearch_purchase_order/purchaseorderfill.php',
						type: 'post',
						data: {
							pr_name: pr_name,
							request: 4
						},
						dataType: 'json',
						success: function ( response ) {

							var len = response.length;

							if ( len > 0 ) {
								var pr_code = response[ 0 ][ 'pr_code' ];
								var pr_name = response[ 0 ][ 'pr_name' ];
								var pr_unit = response[ 0 ][ 'pr_unit' ];
								var price = response[ 0 ][ 'pr_purch_price' ];
								var hsn = response[ 0 ][ 'hsn' ];
								document.getElementById( 'code_' + index ).value = pr_code;
								document.getElementById( 'name_' + index ).value = pr_name;
								document.getElementById( 'unit_' + index ).value = pr_unit;
								document.getElementById( 'price_' + index ).value = price;
								document.getElementById( 'hsn_' + index ).value = hsn;
								document.getElementById( 'qty_' + index ).focus();
							}
						 }
					} );
					return false;
				 }
			} );

			$( '.qty' ).keyup( function () {
				$( '#total_' + index ).val( $( '#price_' + index ).val() * $( '#qty_' + index ).val() );
				/*net sum */
				var sum = 0;
				var qtysum = 0;
				var gst = 0;
				//iterate through each textboxes and add the values
				$( '.total' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						sum += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'totalprice' ).value = Math.round( sum );
				/*qty sum*/
				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qtysum += parseFloat( this.value );
					}
				} );
				/*net total*/
				document.getElementById( 'gtotalprice' ).value = Math.round( qtysum );
			} );
			$( '.coolie' ).keyup( function () {
				var sum = 0;
				var qtysum = 0;
				var cool = 0;
				//iterate through each textboxes and add the values
				$( '.coolie' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						cool += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'gtotalprice' ).value = Math.round( cool - $( '#coolie' ).val() );
				/*qty sum*/
				$( '.total' ).each( function () {
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						qtysum += parseFloat( this.value );
					}
				} );
				/*net total*/
				document.getElementById( 'gtotalprice' ).value = Math.round( qtysum );
			} );
		} );
		
		
			$(window).keydown(function (event){
				if (event.keyCode == 109) {
					event.preventDefault();
					$('#delete').click();
					
				}
			});
		
		// Add more
		$( window ).keydown( function ( event ){
			if ( event.keyCode == 107 ) {
				event.preventDefault();
				// Get last id 
				var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				// New index
				var index = Number( split_id[ 1 ] ) + 1;
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text'  class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder='Product Code'></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder='Product Code'></td><td><input type='text' class='form-control name' placeholder='Product Name' name='name[]' id='name_" + index + "' ></td><td><input type='text' class='form-control hsn' placeholder='HSN Code' name='hsn[]' id='hsn_" + index + "' ></td><td><input type='text' placeholder='Qty' class='form-control qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text' placeholder='Unit' class='form-control unit' name='unit[]' id='unit_" + index + "' readonly ></td><td><input type='text' placeholder='Price' class='form-control price' name='price[]' id='price_" + index + "'  ></td><td><input type='text' class='form-control total' name='total[]' placeholder='Total' id='total_" + index + "' readonly ></td><td><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
				// Append data
				$( '#order' ).append( html );
				
			}
			$( document ).on( 'click', '.delete', function (){
				$( this ).closest( 'tr' ).remove();
				$('#totalprice').val() - $('#total_' + index).val();
				} );
			$( '#code_' + index ).focus();
		} );
		// Add more
		$( '#addmore' ).click( function (){
			// Get last id 
			var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
			var split_id = lastname_id.split( '_' );
			// New index
			var index = Number( split_id[ 1 ] ) + 1;
			// Create row with input elements
			var html = "<tr class='tr_input'><td><input type='text'  class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder='Product Code'></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder='Product Code'></td><td><input type='text' class='form-control name' placeholder='Product Name' name='name[]' id='name_" + index + "' ></td><td><input type='text' class='form-control hsn' placeholder='HSN Code' name='hsn[]' id='hsn_" + index + "' ></td><td><input type='text' placeholder='Qty' class='form-control qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text' placeholder='Unit' class='form-control unit' name='unit[]' id='unit_" + index + "' readonly ></td><td><input type='text' placeholder='Price' class='form-control price' name='price[]' id='price_" + index + "'  ></td><td><input type='text' class='form-control total' name='total[]' placeholder='Total' id='total_" + index + "' readonly ></td><td><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
			// Append data
			$( '#order' ).append( html );
			$( document ).on( 'click', '.delete', function () {
				$( this ).closest( 'tr' ).remove();
			console.log("l");
					
					//$('#gtotalprice').val() - $('#total_' + index).val();
				
			});
		});
		$( '#insert_form' ).on( 'submit', function ( event ) {
			event.preventDefault();
			/* Validation */
			var error = '';
			/* Creating Index WHEN Clicking Add Button Or Enter Button */
			var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
			var split_id = lastname_id.split( '_' );
			// New index
			var index = Number( split_id[ 1 ] ) ;
			
			/* Supplier Details Validation */
			var vendor = $( '#v_name' ).val();
			var po1 = $( '#po_no1' ).val();
			var address = $( '#address' ).val();
			/* Multiple Input Row Form validation */
			var name = $( '#name_' + index ).val();
			var qty = $( '#qty_' + index ).val();
			
			 if( vendor == ''  ){
				 $.toast( {heading: 'Select A Supplier.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500} ); error = 1;
			 }else if( address == '' ){
				 $.toast( { heading: 'Enter Delivery Address.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1500 } ); error = 1;
			 }else if( name == '' ){
				 $.toast( { heading: 'Enter Product Name.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1500 } ); error = 1;
 			 }else if( qty == '' ){
				 $.toast( { heading: 'Enter Quantity.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1500 } ); error = 1;
 			 }
			var form_data = $( this ).serialize();
			if ( error == '' ) {
				$.ajax( {
					url: "purchase-action/add_purchase_order.php",
					method: "POST",
					data: form_data,
					success: function ( data ) {
						if ( data == 'ok' ) {
							$.toast( {
								heading: 'Purchase Saved Successfully',
								text: '',
								position: 'top-right',
								loaderBg: '#4AD55E',
								icon: 'success',
								hideAfter: 4500,
								hideMethod: 'fadeOut'
							} );
							
							window.location.href = "purch-order-print.php?bill="+po1;
							//document.getElementById( "insert_form" ).reset();
							//$( '#order' ).find( "tr:gt(0)" ).remove();
						} else {
							$.toast( {
								heading: 'Error',
								text: '',
								position: 'top-right',
								loaderBg: '#F13109',
								icon: 'error',
								hideAfter: 4500
							} );
						}
					}
				} );
			}
		} );
	} );
	var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
</script>
	<div class="right-sidebar">
		<div class="slimscrollright">
			<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
			<div class="r-panel-body">
				<ul id="themecolors" class="m-t-20">
					<li><b>With Light sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
					</li>
					<li class="d-block m-t-30"><b>With Dark sidebar</b>
					</li>
					<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
					</li>
					<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
					</li>
				</ul>
				
			</div>
		</div>
	</div>
	</div>
	
	</div>
	</div>
	<script src="assets/plugins/popper/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>

	<script>
		//For validation with custom styles
		( function () {
			'use strict';
			window.addEventListener( 'load', function () {
				// Fetch all the forms we want to apply custom Bootstrap validation styles to
				var forms = document.getElementsByClassName( 'needs-validation' );
				// Loop over them and prevent submission
				var validation = Array.prototype.filter.call( forms, function ( form ) {
					form.addEventListener( 'submit', function ( event ) {
						if ( form.checkValidity() === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
						form.classList.add( 'was-validated' );
					}, false );
				} );
			}, false );
		} )();
	</script>
	<!-- This page plugins -->
	<!-- ============================================================== -->
	<!--select-->
	<?php include ('include/disable_fn.php'); ?>
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<!--multiple selection-->
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>

	<script>
		$( function () {
			// Switchery
			var elems = Array.prototype.slice.call( document.querySelectorAll( '.js-switch' ) );
			$( '.js-switch' ).each( function () {
				new Switchery( $( this )[ 0 ], $( this ).data() );
			} );
			// For select 2
			$( ".select2" ).select2();
			$( '.selectpicker' ).selectpicker();
			
			$( ".ajax" ).select2( {
				ajax: {
					url: "https://api.github.com/search/repositories",
					dataType: 'json',
					delay: 250,
					data: function ( params ) {
						return {
							q: params.term, // search term
							page: params.page
						};
					},
					processResults: function ( data, params ) {
						// parse the results into the format expected by Select2
						// since we are using custom formatting functions we do not need to
						// alter the remote JSON data, except to indicate that infinite
						// scrolling can be used
						params.page = params.page || 1;
						return {
							results: data.items,
							pagination: {
								more: ( params.page * 30 ) < data.total_count
							}
						};
					},
					cache: true
				},
				escapeMarkup: function ( markup ) {
					return markup;
				}, // let our custom formatter work
				minimumInputLength: 1,
				//templateResult: formatRepo, // omitted for brevity, see the source of this page
				//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
			} );
		} );
	</script>

	<!-- ============================================================== -->
	<!-- Style switcher -->
	<!-- ============================================================== -->
	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>


	<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			</script>
<script>
			
$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
	<script>
$(document).keyup(function(e){
	if(e.altKey && e.which == 49){  window.location.href = "creation.php";
	} else if(e.altKey && e.which == 50){  window.location.href = "purchase-home.php";
	} else if(e.altKey && e.which == 51){  window.location.href = "saleshome.php";
	} else if(e.altKey && e.which == 52){  window.location.href = "inventory-home.php";
	} else if(e.altKey && e.which == 53){  window.location.href = "accounts-home.php";
	} else if(e.altKey && e.which == 54){  window.location.href = "cashcounter-home.php";
	} else if(e.altKey && e.which == 55){  window.location.href = "anayisis.php";
	} else if(e.altKey && e.which == 56){  window.location.href = "setting-home.php";
	} 
	
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
</script>

</body>

</html>