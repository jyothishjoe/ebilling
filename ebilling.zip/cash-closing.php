<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid' ");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $counter=$rows['counter']; }


$date_set = $today;


$resultsa = $db->prepare("SELECT  SUM(sales_tot) AS sales_tot FROM cash_invoice where date_ = '$date_set' AND addby='$userid' AND company_tkn='$user_company' AND satus='1'");
$resultsa->execute();
for($i=0; $rowsa = $resultsa->fetch(); $i++){  
$sales_tot=$rowsa['sales_tot'];}

$resultret = $db->prepare("SELECT  SUM(sales_ret_tot) AS sales_ret_tot FROM cash_invoice where date_ = '$date_set' AND company_tkn='$user_company' AND addby='$userid'  AND satus='1'");
$resultret->execute();
for($i=0; $rowret = $resultret->fetch(); $i++){  
$sales_ret_tot=$rowret['sales_ret_tot'];}

$resultret = $db->prepare("SELECT  SUM(disc) AS disc FROM cash_invoice where date_ = '$date_set' AND addby='$userid' AND company_tkn='$user_company'  AND satus='1'");
$resultret->execute();
for($i=0; $rowret = $resultret->fetch(); $i++){  
$disc_tot=$rowret['disc'];}

$resultret = $db->prepare("SELECT  SUM(adv_amt_tot) AS adv_amt_tot FROM cash_invoice where date_ = '$date_set' AND addby='$userid' AND company_tkn='$user_company'  AND satus='1'");
$resultret->execute();
for($i=0; $rowret = $resultret->fetch(); $i++){  
$adv_amt_ret=$rowret['adv_amt_tot'];}

$resultadv = $db->prepare("SELECT  SUM(adv_amt) AS adv_amt FROM advanced_receipt where date_ = '$date_set' AND addby='$userid' AND cashclose='1'");
$resultadv->execute();
for($i=0; $rowadv = $resultadv->fetch(); $i++){  
$adv_amt_tot=$rowadv['adv_amt'];}

$resultroff = $db->prepare("SELECT  SUM(round_off) AS round_off FROM round_off where date_ = '$date_set' AND addby='$userid' AND company_tkn='$user_company' AND status='1'");
$resultroff->execute();
for($i=0; $rowroff = $resultroff->fetch(); $i++){  
$round_off_tot=$rowroff['round_off'];}

$resultop = $db->prepare("SELECT  SUM(open_balance) AS open_balance FROM open_balance where date_ = '$date_set' AND company_tkn='$user_company' AND addby='$userid' AND status='1'");
$resultop->execute();
for($i=0; $rowop = $resultop->fetch(); $i++){  
$open_balance_tot=$rowop['open_balance'];}
/*sales amt*/
$sales_tots = $sales_tot - $disc_tot;
/* net tot*/
$net_sum = $sales_tots +  $adv_amt_tot + $open_balance_tot - $sales_ret_tot - $round_off_tot - $adv_amt_ret;
$result_date = $db->prepare( "select * from  date_set WHERE status= 'pending' AND company_tkn='$user_company' ");
$result_date->execute();
for($i=0; $rows_date = $result_date->fetch(); $i++){
$date_set = $today;
}
?>
<div class="col-xs-12 no-padding" style="width:600px; overflow: hidden;">
<h3 class="text-center">Cash Closing</h3>
<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
  <div class="form-row">
  <div class="col-md-4 col-sm-6 col-xs-12 mb-1">
      <label for="" class="control-label">Date</label>
      <input type="date" class="form-control" id="date_" name="date_"   value="<?php echo $date_set;?>">
    </div>
	<div class="col-md-12"></div>
	<div class="col-md-4 col-sm-6 col-xs-12 mb-1">
      <label for="" class="control-label">Opening Balance</label>
      <input type="text" class="form-control" id="open_balance" name="open_balance" readonly  value="<?php echo $open_balance_tot;?>">
    </div>
	    <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
	  <input type="hidden" class="form-control"  id="company" name="company" value="<?php echo $user_company;?>" readonly>
	    <input type="hidden" class="form-control"  value="<?php echo $counter;?>" name="counter"  id="counter" readonly>
		<input type="hidden" class="form-control"  value="<?php echo $disc_tot;?>" name="disc"  id="disc" readonly>
    <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Advanced Recived</label>
      <input type="text" class="form-control " name="advace_amt" id="advace_amt" value="<?php echo $adv_amt_tot;?>" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label"> Advanced Cleared</label>
      <input type="text" class="form-control " name="adv_amt_ret" id="adv_amt_ret" value="<?php echo $adv_amt_ret;?>" readonly>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Total Sales </label>
      <input type="text" class="form-control" name="sales_amt" id="sales_amt" value="<?php echo $sales_tots;?>" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Total Sales Return</label>
      <input type="text" class="form-control" name="salesret_amt" id="salesret_amt" value="<?Php echo $sales_ret_tot;?>" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Round Off</label>
      <input type="text" class="form-control" name="roundoff_amt" id="roundoff_amt" value="<?php echo $round_off_tot;?>" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Closing Balance</label>
      <input type="text" class="form-control" name="close_amt" id="close_amt" value="<?php echo $net_sum;?>" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Balance</label>
      <input type="text" class="form-control" name="balance" id="balance" readonly>
    </div>
	 <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Cash</label>
      <input type="text" class="form-control red_cash" name="red_cash" id="red_cash" placeholder="Enter Amount" autofocus>
    </div>
  </div>
  <div class="text-right" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
    <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right">CANCEL</button>
  </div>
</form>

<script> 
$(".red_cash").keyup(function () {

  $('#balance').val($('#close_amt').val() - $('#red_cash').val());
});

		  $( '#close_fbx' ).on( 'click', function () {
		   parent.jQuery.fancybox.close();
	        } );
          function save_user(){
			var open_balance = $("#open_balance").val();
			var red_cash = $("#red_cash").val();
			var addby = $("#addby").val();
			var counter = $("#counter").val();
			var date_ = $("#date_").val();
			var advace_amt = $("#advace_amt").val();
			var sales_amt = $("#sales_amt").val();
			var salesret_amt = $("#salesret_amt").val();
			var roundoff_amt = $("#roundoff_amt").val();
			  var adv_amt_ret = $("#adv_amt_ret").val();
			var close_amt = $("#close_amt").val();
			  var company = $("#company").val();
			var disc = $("#disc").val();
			 if($("#red_cash").val() == ""){$.toast( {heading: 'Enter  Amount.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
			} else if( close_amt != red_cash ) {$.toast( {heading: 'Closing Amount And Cash amount Are Not Equal.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
		    } else {	$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/cash-counter/cash_closing.php',
					data: "open_balance="+ open_balance + "&date_=" + date_ + "&addby=" + addby + "&counter=" + counter + "&red_cash=" + red_cash + "&advace_amt=" + advace_amt + "&sales_amt=" + sales_amt + "&salesret_amt=" + salesret_amt + "&roundoff_amt=" + roundoff_amt + "&close_amt=" + close_amt + "&disc=" + disc + "&adv_amt_ret=" + adv_amt_ret + "&company=" + company,
					success : function(r) {						
						$("#respond").html(r);
					}
				});
				parent.jQuery.fancybox.close();
				//setTimeout(function(){ window.location.reload(1);}, 1500);
				$.toast( {
				heading: 'Cash Closing  Add Succeccfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#1FDE13',
				icon: 'success',
				hideAfter: 1000
				} );
				return false;
			}
		}

</script>