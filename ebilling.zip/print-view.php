
<?php
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$printer_width =$_GET['printer_size'];
?>
<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php"); include('db-connect/db.php'); 
        ?>
<html>
<title></title>
<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<style>
table td {
	height: 15px;
}
 @media print {
.btn {
	display: none;
}
}
.hr {
	border: none;
	border-top: 1px dashed black;
	margin-top:10px;
}
 <?php if( $printer_width=='a4') { ?>
  table {
  border-collapse: collapse; font-size: 13px !important;
}
table h3{ margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:21cm !important;padding:2em 1em !important;margin:1cm auto 2cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important;}
@page{size:a4;margin:auto;}
@media print{
.printwidth{margin:auto;padding-top:0 !important; border:initial;border-radius:initial;width:initial;min-height:initial;box-shadow:initial;background:initial;page-break-after:always;visibility:visible;} }
<?php }  else if( $printer_width=='b5') { ?>
 table {
  border-collapse: collapse; font-size: 13px !important;
}
table h3{ margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:17.6cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:b5;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} <?php } else if( $printer_width=='c6') { ?>
 table {
  border-collapse: collapse; font-size: 13px !important;
}
table h3{font-size: 25px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 70px ;}
.printwidth{width:16.2cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:162mm;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} <?php }  else if( $printer_width=='a5') { ?>
 table {
  border-collapse: collapse; font-size: 11px !important; font-weight: 400px;
}
table h3{font-size: 23px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 200px;}
#address{width: 40%;}
#firsttable{margin-top: 50px ;}
.printwidth{width:14.8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:a5;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} 
<?php } else if( $printer_width=='b6') { ?>
 table {
  border-collapse: collapse; font-size: 10px !important; font-weight: 400px;
}
table h3{font-size: 20px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 150px;}
#address{width: 40%;}
#firsttable{margin-top: 50px ;}
.printwidth{width:10.5cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:125mm;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} 
<?php } else if( $printer_width=='a6') { ?>
 table {
  border-collapse: collapse; font-size: 10px !important;
}
table h3{font-size: 20px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 150px;}
#address{width: 40%;}
#firsttable{margin-top: 50px ;}
.printwidth{width:10.5cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center;}
@page{size:a6;margin:0 !important; padding: 0 !important;}
@media print{
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} 
<?php }  else if( $printer_width=='b7') { ?>
table {
  border-collapse: collapse; font-size: 9px !important;
}
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:8.8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden; }
@page{size:88mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} <?php } else if( $printer_width=='80mm') { ?>
table {
  border-collapse: collapse; font-size: 9px !important;
}
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:8cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden; }
@page{size:80mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;}
} <?php } else if( $printer_width=='a7') {?>
table {
  border-collapse: collapse; font-size: 10px !important;
}
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:7.4cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;}
@page{size:74mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php }  else if( $printer_width=='b8') {?>
table {
  border-collapse: collapse; font-size: 10px !important;
}
table h3{font-size: 18px !important;  margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:6.2cm !important;padding:1.5em 1em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;}
@page{size:62mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } else if( $printer_width=='a8') { ?>
table {
  border-collapse: collapse; font-size: 9px !important;
}
table h3{ font-size: 16px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:5.2cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:52mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } else if( $printer_width=='b9') { ?>
table {
  border-collapse: collapse; font-size: 8.5px !important; font-weight: 600;
}
table h3{ font-size: 16px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 50%; float: left !important;}
#address{width: 50%; overflow: hidden !important;}
#firsttable{margin-top: 50px ;}
.printwidth{width:4.4cm !important;padding:26em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:44mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php }  else if( $printer_width=='a9') { ?>
table {
  border-collapse: collapse; font-size: 7px !important; color:black;  font-weight: 500;
}
table h3{ font-size: 14px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 80px ;}
.printwidth{width:3.7cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:37mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } /* else if( $printer_width=='a10') { ?>
table {
  border-collapse: collapse; font-size: 5px !important; color:black;  font-weight: 900;
}
table h3{ font-size: 14px !important; margin:0 !important; padding: 0px !important; }
#datetym{width: 100%; float: left !important;}
#address{width: 100%; overflow: hidden !important;}
#firsttable{margin-top: 80px ;}
.printwidth{width:2.6cm !important;padding:2em 19em !important;margin:1cm auto 1cm;background:#fff !important;box-shadow:0 0 5px rgba(0, 0, 0, 0.1);height:auto !important; text-align: center; overflow-x:hidden;  font-size:.1px !important; }
@page{size:26mm;margin:0 !important; padding: 0 !important;}
@media print{ 
.printwidth{padding:0em !important; margin-left:2cm !important; margin-top: 0cm !important; width:initial; min-height:initial; box-shadow:initial;background:initial;page-break-after:always;visibility:visible; position: relative; bottom: 1em !important;} }
<?php } */ ?>
</style>
</head>
<body>
<div class="col-md-12" style="margin-top: 18px;"><a href="sales-bill.php" class="btn btn-sm btn-danger" style="font-size: 15px; float: left;">Back</a> </div>
<div class="row">
  <div class=" col-xs-12 printwidth" style="padding:0px 50px;">
    <table style="text-align:center;" width="100%" border="0">
      <tr>
        <th> <h3>Supermarket</h3></th>
      </tr>
      <tr>
        <td>Palakkad</td>
      </tr>
      <tr>
        <td>Ph: 8137010256, Mob: 9865320123</td>
      </tr>
      <tr>
        <th>Sales Invoice</th>
      </tr>
    </table>
    <table style="text-align:left;float:left;" border="0" id ="address">
      <tr>
        <div class="col-md-12" style="padding-bottom: 8px;"></div>
        <td><b>Sold To : Customer Name</td>
      </tr>
      <tr>
        <td>Customer Address<br></td>
      </tr>
      <tr>
        <td>6767676768</td>
      </tr>
      <tr> </tr>
    </table>
    <table style="float:right;text-align:left;" border="0" id="datetym">
      <tr>
        <th>Date :</th>
        <td>2019-07-26</td>
      </tr>
      <tr>
        <th>Bill No :</th>
        <td>SAB55</td>
      </tr>
      <tr>
        <th>Sales Order No:</th>
        <td>SAB55</td>
      </tr>
     </table>
  
   <?php if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
 <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="30%" style="text-align:left !important;"> Product Name</th>
          <th rowspan="2" width="14%" > Qty</th>
          <th rowspan="2" width="14%" > Rats</th>
          <th rowspan="2" width="14%" >Mrp</th>
          <th rowspan="2" width="14%" >Gst%</th>
          <th rowspan="2" width="14%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
          <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>   
        <tr>
          <td align="left">Tomato sauce</td>
          <td align="center">1</td>
          <td align="center">39</td>
          <td align="center">40</td>
          <td align="center">12</td>
          <td align="center">39</td>
        </tr>
         <tr>
          <td align="left">Red-wine vinegar</td>
          <td align="center">2</td>
          <td align="center">500</td>
          <td align="center">500</td>
          <td align="center">28</td>
          <td align="center">1000</td>
        </tr>
         <tr>
          <td align="left">Mustard</td>
          <td align="center">4</td>
          <td align="center">15</td>
          <td align="center">15</td>
          <td align="center">5</td>
          <td align="center">60</td>
        </tr>
        <tr>
          <td align="left">Brown rice</td>
          <td align="center">4</td>
          <td align="center">300</td>
          <td align="center">300</td>
          <td align="center">18</td>
          <td align="center">1200</td>
        </tr>
    <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
     <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="5">Gst Included  </td>
        </tr>
        <tr>
      <td></td>
          <td  align="center">Sgst 14%</td>
          <td  align="center">150</td>
          <td  align="center">Cgst 14%</td>
          <td  align="center">150</td>
        </tr>
        <tr>
      <td></td>
        <td  align="center">Sgst 9%</td>
        <td  align="center">160</td>
        <td  align="center">Cgst 9%</td>
        <td  align="center">160</td>
      </tr>
      <tr>
      <td></td>
        <td  align="center">Sgst 6%</td>
        <td  align="center">180</td>
        <td  align="center">Cgst 6%</td>
        <td  align="center">180</td>
      </tr>
      <tr>
      <td></td>
        <td  align="center">Sgst 2.5%</td>
        <td  align="center">55</td>
        <td  align="center">Cgst 2.5%</td>
        <td  align="center">55</td>
      </tr>
   <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
   <tr class="hr"><td></td><td></td><td></td><td></td><td></td><td></td></tr>
      <tr>
        <td>Gst Total  </td><td></td><td></td><td></td><td></td><td  align="center"></td>
      </tr>
    <tr>
        <th> Grand Total </th><th></th><td align="center">4</td><th></th><td></td><td   align="center"><b>5000</b></td>
      </tr>
      <tr>
    <td>Counter  # counter no/ name </td>
      </tr>
      <tr>
        <td  colspan="">E & OE </td>
      </tr>
      <tr>
        <td  colspan="6">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="6">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
<?php } else {?>

    <table border="0" width="100%" id="firsttable">
      <thead>
        <tr style="text-align:center;" class="hr">
          <th rowspan="2" width="21%" > Qty</th>
          <th rowspan="2" width="21%" > Rats</th>
          <th rowspan="2" width="16%" >Mrp</th>
          <th rowspan="2" width="21%" >Gst%</th>
          <th rowspan="2" width="21%" > Amount</th>
        </tr>
      </thead>
      <tbody  class="hr">
	  <tr><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td colspan="5"></td>
        </tr>
        <tr>
          <td align="center"></td>
          <td align="center"></td>
          <td align="center"></td>
          <td align="center"></td>
          <td align="center"></td>
        </tr>
       
		<tr><td></td><td></td><td></td><td></td><td></td></tr>
        
		<tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
        <tr>
          <td  colspan="5">Gst Included  </td>
        </tr>
        <tr>
		  <td></td>
          <td  align="center" colspan="2">Sgst 14% - </td>
          <td></td>
          <td  align="center" colspan="2">Cgst 14% - </td>
        </tr>
      <tr>
	    <td></td>
        <td  align="center" colspan="2">Sgst 9% - </td>
        <td></td>
        <td  align="center" colspan="2">Cgst 9% - </td>
      </tr>
      <tr>
	    
        <td  align="center" colspan="2">Sgst 6% - </td>
        <td ></td>
        <td  align="center" colspan="2">Cgst 6% - </td>
       
      </tr>
      <tr>
	    <td></td>
        <td  align="center" colspan="2">Sgst 2.5% - </td>
        <td></td>
        <td  align="center" colspan="2">Cgst 2.5% - </td>
      </tr>
	 <tr><td></td><td></td><td></td><td></td><td></td></tr>
	 <tr class="hr"><td></td><td></td><td></td><td></td><td></td></tr>
      <tr>
        <td colspan="2">Gst Total  </td><td></td><td></td><td  align="center"></td>
      </tr>
		
		<tr>
        <th colspan="2"> Grand Total </th><td align="center">10</td><th></th><td   align="center"><b>30000</b></td>
      </tr>
      <tr>
	  <td  colspan="5">Counter  # counter no / name</td>
      </tr>
      <tr>
        <td  colspan="">E & OE </td>
      </tr>
      <tr>
        <td  colspan="5">Please check items before leaving the counter.</td>
      </tr>
      <tr>
        <td  colspan="5">Thank you for shopping at (suppermarket name)</td>
      </tr>
      </tbody>
      
    </table>
  <?php } ?>
  </div>
</div>
<script>window.print();</script>
</body>
</html>