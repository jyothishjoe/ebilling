<?php
session_start();
if(isset($_SESSION['SESS_USERID_AS']) && (trim($_SESSION['SESS_USERID_AS']) != '')) { header("location: index2.php"); }else{
setcookie('_nhb', "", -1, '/');
setcookie('_vhb', "", -1, '/');
$name_cuki = sha1(mt_rand(100000000,999999999));
$value_cuki = sha1(mt_rand(100000000,999999999));
setcookie('_nhb', $name_cuki, time() + (86400 * 30), "/");
setcookie('_vhb', $value_cuki, time() + (86400 * 30), "/");
}
if(isset($_COOKIE['log_f0']) && $_COOKIE['log_f0'] == true){$alert_msg = "error2";}
else if(isset($_COOKIE['log_f1']) && $_COOKIE['log_f1'] == true){$alert_msg = "error2";}
else if(isset($_COOKIE['log_f2']) && $_COOKIE['log_f2'] == true){$alert_msg = "error1";}
else if(isset($_COOKIE['log_f3']) && $_COOKIE['log_f3'] == true){$alert_msg = "error3";}
else if(isset($_COOKIE['log_f4']) && $_COOKIE['log_f4'] == true){$alert_msg = "error5";}
else if(isset($_COOKIE['log_f6']) && $_COOKIE['log_f6'] == true){$alert_msg = "error6.";}
else if(isset($_COOKIE['log_f7']) && $_COOKIE['log_f7'] == true){$alert_msg = "error7.";}
else if(isset($_COOKIE['suc_0']) && $_COOKIE['suc_0'] == true){$alert_msg = "error4";}
include('db-connect/db.php');
include('include/today.php');
?>
<!DOCTYPE html>
<html lang="en">

	<head>
		
		<meta charset="utf-8" />
		<title>Codebuz Billing Master2 | Login </title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Roboto:300,400,500,600,700">
		<link href="assets/login/css/pages/login/login-2.css" rel="stylesheet" type="text/css" />
		<link href="assets/login/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<link href="assets/login/css/skins/header/base/light.css" rel="stylesheet" type="text/css" />
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/spinners.css" rel="stylesheet">
		<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
		<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
		<script src="assets/plugins/jquery/jquery.min.js"></script>
		<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
		<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
		<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
		<style>
		.no-scrollbar::-webkit-scrollbar {
width: 0 !important
}
.no-scrollbar {
	overflow: -moz-scrollbars-none;
}
.no-scrollbar {
	-ms-overflow-style: none;
}
		</style>
	</head>

<body class="fix-header card-no-border fix-sidebar no-scrollbar">

	<!--<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Loading</p>
		</div>
	</div>-->
	<!-- begin:: Page -->

	<?php if(isset($alert_msg)){  ?>
	<input type="hidden" value="<?php echo $alert_msg ?>" name="<?php echo $alert_msg ?>" id="error_msg"/>
	<?php } ?>

	<div class="kt-grid kt-grid--ver kt-grid--root" id="wrapper">
		<div class="kt-grid kt-grid--hor kt-grid--root kt-login kt-login--v2 kt-login--signin" id="kt_login">
			<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" style="background-image: url('assets/login/media/bg/bg-2.jpg'); ">
				<div class="kt-grid__item kt-grid__item--fluid kt-login__wrapper">
					<div class="kt-login__container">
						<div class="kt-login__logo animated fadeInUp faster">
							<a href="#">
									<img src="assets/images/billing-master-logo.png" style="width: 250px;margin-bottom: 3em;">
								</a>
						</div>
						<div class="kt-login__signin">
							<!--<div class="kt-login__head">
								<h3 class="kt-login__title">Sign In</h3>
							</div>-->
							<form class="kt-form" action="login.php" method="POST">
								<input type="hidden" value="<?php echo $value_cuki ?>" name="<?php echo $name_cuki ?>"/>
								
								<div class="input-group animated fadeInUp faster kt-mb-10" style="display: none">
									<?php
									$result_user_company_exist = $db->prepare("SELECT * FROM company");
									$result_user_company_exist->execute();
									$company_count = $result_user_company_exist->rowcount();
									   if($company_count > 0){
									?>
									<select class=" form-control" id="company" name="company" style="width: 100%; ">
									
									<?php
									$result_user_company = $db->prepare("SELECT * FROM company");
									$result_user_company->execute();
									
									for ($e=0; $rows_user_company = $result_user_company->fetch(); $e++){
									$company_token=$rows_user_company['c_token'];
									$company_name=$rows_user_company['c_company_name'];
									?>
									<option value="<?php echo $company_token;?>"><?php echo $company_name;?></option>
									<?php }  ?>
								</select>
									<?php } ?>
								</div>
								<div class="input-group animated fadeInUp faster kt-mb-10">
									<input class="form-control" type="text" placeholder="username" name="username" id="username" value="<?php if(isset($_COOKIE[" username "])) { echo $_COOKIE["username "]; } ?>" autocomplete="off">
								</div>
								<div class="input-group animated fadeInUp faster kt-mb-10">
									<input class="form-control" type="password" placeholder="password" id="password" value="<?php if(isset($_COOKIE[" password "])) { echo $_COOKIE["password "]; } ?>" name="password">
								</div>
								<!--<div class="row kt-login__extra" style="visibility: hidden;">
									<div class="col">
										<label class="kt-checkbox">
												<input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["username"])) { ?> checked <?php } ?> > Remember me
												<span></span>
											</label>
									</div>
								</div>-->
								<input type="hidden" class="days_left" id="days_left" name="days_left">
								<div class="kt-login__actions animated fadeInUp faster">
									<a href="product-key-popup.php" id='opendata' style="visibility: hidden;" class="btn btn-rounded btn-outline btn-light m-t-10 font-14  simple-ajax-popup-align-top "></a>
									<button type="submit" id="kt_login_signin_submit" class="btn btn-pill kt-login__btn-primary">Sign In</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-md-12 p-0 animated slideInRight faster" style="position: fixed;right: 1em;bottom:.2em; text-align: right;">
					<span>Powered by <a href="http://codebuz.in/" target="_blank"><img src="assets/images/CODEBUZ_TEXT.png" style="width: 100px;margin-bottom:10px;"></a></span>
				</div>
			</div>
		</div>
	</div>
	
		
		
		<div class="kt-grid kt-grid--ver kt-grid--root" id="new_key">
		<div class="kt-grid kt-grid--hor kt-grid--root kt-login kt-login--v2 kt-login--signin" id="kt_login">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" style="background-image: url('assets/login/media/bg/bg-2.jpg'); ">
				<div class="kt-grid__item kt-grid__item--fluid kt-login__wrapper">
					<div class="kt-login__container">
						<div class="kt-login__logo animated fadeInUp faster" >
							<a href="#">
									<img src="assets/images/billing-master-logo.png" style="width: 250px;margin-bottom: 3em;">
								</a>
						</div>
						<div class="kt-login__signin">
							<div class="kt-login__head">
								<h3 class="kt-login__title animated fadeInUp faster">Product Expired!</h3>
							</div>
							<form class="kt-form" action="login.php" method="POST">
							  <div class="row">
								<div class="input-group animated fadeInUp faster" >
									<a href="product-key-popup.php" class="btn btn-block btn-lg btn-success btn-rounded simple-ajax-popup-align-top ">Enter Key</a>
									<a href="https://www.codebuz.in" target="_blank" class="btn btn-block btn-lg btn-primary btn-rounded">Contact Us</a>
								</div>
								</div>
								<div class="input-group">
								</div>
								<div class="row kt-login__extra">
									<div class="col">
									</div>
								</div>
								<div class="kt-login__actions">
								</div>
							</form>
						</div>
						
					</div>
				<div class="col-md-12 p-0 animated slideInRight faster" style="position: fixed;right: 1em;bottom:.2em; text-align: right;">
					<span>Powered by <a href="http://codebuz.in/" target="_blank"><img src="assets/images/CODEBUZ_TEXT.png" style="width: 100px;margin-bottom:10px;"></a></span>
				</div>
				</div>
			</div>
		</div>
	</div>

	<input type="hidden" id="today" value="<?php echo $today; ?>">
	<input type="hidden" id="status">
	<input type="hidden" id="key">
	<input type="hidden" id="daysleft">
	<input type="hidden" id="expair">
	
	<script>
$( document ).ready( function (){
	$( '#wrapper' ).hide();
	$( '#new_key' ).hide();
	//$('body,html').css("overflow","hidden");
	//window.onscroll = function () { window.scrollTo(0, 0); };
	/*$( '#kt_login_signin_submit' ).on( 'click', function () {
	var username = $('#username').val();
	var password =  $('#password').val();
	
	if(username == ''){
	$.toast( {heading: 'Username required.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1600});	
	}else if(password == ''){
	$.toast( {heading: 'Password required.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1600});		
	}
	});*/
	var error_message = $( "#error_msg" ).val();
		if ( error_message == 'error1' ) {
		$.toast( {heading: 'Incorrect login details, Please try again.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});
		} else if ( error_message == 'error2' ) {
		$.toast( {heading: 'Something went wrong, Please try again..',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});
		} else if ( error_message == 'error3' ) {
		$.toast( {heading: 'Something went wrong,<br>please contact Admin for more details.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter:2500});
		} else if ( error_message == 'error4' ) {
		$.toast( {heading: 'Please signin with your new password.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});
		}else if ( error_message == 'error6.' ) {
		$.toast( {heading: 'Pls Select a Company.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});
		}else if ( error_message == 'error7.' ) {
		$.toast( {heading: 'Invalid Company.',text: '',position: 'top-right',loaderBg: '#e60000',icon: 'error',hideAfter: 1800});
		}
	var today = $( '#today' ).val();
	var request = '1';
	$('#loading-image').show();
	$.ajax({
		type: "POST",
		url: "post_item.php",
		datatype: "json",
		data: {
			request: request
		},
		success: function (data){

			var result = JSON.parse(data);
			var notification =  result.notific;
			//console.log(error);
			if( notification == '5'){
			alert('error 0xe00012');
			}
			var status = $( '#status' ).val( result.status );
			var key = $( '#key' ).val( result.softwarekey );
			var daysleft = $( '#days_left' ).val( result.daysleft );
			var total_days = parseInt($('#days_left').val().replace(/[^0-9.]/g, ""))

			
			
			$('#loading-image').hide();
			//console.log( total_days);
			
			
			if ( result.status == '0' ){
				$( '#wrapper' ).hide();
				$( '#new_key' ).hide();
				$( '#opendata' ).click();
				$('#loading-image').show();
				$.toast( {heading: 'Enter Product Key To Continue...!',text: '',position: 'top-right',loaderBg: '#DC3608',icon: 'error',hideAfter: 1600,hideMethod:'fadeOut'
				});
				$('#loading-image').hide();
			}else{
				//===============================================
				//Check Servere
				//===============================================
			 	var softwarekey = $( '#key' ).val();
				var action = '4';
				$('#loading-image').show();
				$.ajax({
					url: 'update_jason.php',
					type: 'POST',
					data: {
						softwarekey: softwarekey,action: action,
						
					},
					dataType: 'json',
					success: function ( upresponse){
					var result = upresponse;	
					var software_key = result.software_key;
					var date = result.date;
					var action = '2';
				
				$.ajax({
					type: "POST",
					url: "update_jason.php",
					datatype: "json",
					data:{
						 software_key: software_key,date: date, action: action,
					},
					success: function (json_arr){
						
					}
					});	
					$('#loading-image').hide();	
					}
				});
				var action = '5';
				var software_key = result.softwarekey;
				var date = result.date;
				$.ajax({
					url: 'update_jason.php',
					type: 'POST',
					data: {
					    software_key: software_key,action: action,
						
					},
					dataType: 'json',
					success: function ( response_date ){
						var result =  response_date;
						var software_key = result.software_key;
						var end_date = result.expairy_date;
						var today = $( '#today' ).val();
						console.log(today);
						$( '#expair' ).val(result.expairy_date);
						var exp = $( '#expair' ).val( result.expairy_date );
						
						//Checking Expairy	
						if (today > end_date){
							
						$('#loading-image').hide();	
						$( '#wrapper' ).hide();
						$( '#new_key' ).show();
					
						$.toast({ heading: 'Software Expaired!', text: 'Contact Or Enter New Product Key', position: 'top-right', loaderBg: '#DC3608',icon: 'error',hideAfter: 1800,hideMethod: 'fadeOut'});
							
						}else{
							
						$( '#wrapper' ).show();
						$( '#new_key' ).hide();
							
						}
					  }
				   });
				 }
			   }
		   });
		});
</script>

<script>
	$( document ).ready( function () {
		$( '.simple-ajax-popup-align-top' ).magnificPopup( {
			type: 'ajax',
			alignTop: false,
			closeOnBgClick: false,
			openDelay: 800,
			overflowY: 'scroll'

		} );
		$( '.simple-ajax-popup' ).magnificPopup( {
			type: 'ajax'
		} );
	} );
	$(function(){"use strict";$(function(){$(".preloader").fadeOut()})});
</script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
	<?php include ('include/disable_fn.php'); ?>
		<!-- end:: Page -->

		<!-- begin::Global Config(global config for global JS sciprts) -->
		<script>
			var KTAppOptions = {
				"colors": {
					"state": {
						"brand": "#5d78ff",
						"dark": "#282a3c",
						"light": "#ffffff",
						"primary": "#5867dd",
						"success": "#34bfa3",
						"info": "#36a3f7",
						"warning": "#ffb822",
						"danger": "#fd3995"
					},
					"base": {
						"label": [
							"#c5cbe3",
							"#a1a8c3",
							"#3d4465",
							"#3e4466"
						],
						"shape": [
							"#f0f3ff",
							"#d9dffa",
							"#afb4d4",
							"#646c9a"
						]
					}
				}
			};
		</script>
	
</body>
</html>