<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<style>
ul, li{z-index:9999 !important;}
</style>
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-ui.min.js"></script>
<div class="col-md-12 col-sm-6 col-xs-12" style="width: 600px; overflow: hidden;">
	<h3 class="text-center">Add User</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">User Name </label>
				<input type="text" class="form-control" id="user_name" name="user_name" placeholder="User Name">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">User Type </label>
				<input type="text" class="form-control user_type" id="user_type" name="user_type" value="" placeholder="User Type">
				<input type="hidden" class="form-control" id="user_type_tkn" name="user_type_tkn">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">User Password</label>
				<input type="text" class="form-control" id="user_password" name="user_password" placeholder="User Password">
				
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Counter</label>
				<input type="text" class="form-control" id="counter" name="counter" placeholder="Counter">
			</div>
		</div>
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" id="gstsave">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger ">Cancel</button>
		</div>
	</form>
	<script>
	 $( document ).ready( function () {
  $( document ).on( 'keydown keyup', '.user_type', function () {
	  $( '#user_type' ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "settings-action/user_type_autosearch.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
									select: function ( event, ui ) {
						$(  '#user_type' ).val( ui.item.label ); // display the selected text
				      $(  '#user_type_tkn' ).val( ui.item.tkn );
						var user_type = ui.item.value; // selected id to input
										}
             });
  });
	 });
	</script>
	<script>
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		function save_customer() {
	
			var user_name = $("#user_name").val();
			var user_password = $("#user_password").val();
			var user_type_tkn = $("#user_type_tkn").val();
			var user_type = $("#user_type").val();
			var counter = $("#counter").val();
			var userid = $("#userid").val();
			var company = $("#company").val();
			
			if ( $("#user_name").val() == "" || $("#user_password").val() == "" || $("#user_type_tkn").val() == "" || $("#user_type").val() == "" || $("#counter").val() == "") {
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 4500} );
			}else{
				$( "#gstsave" ).hide();
				$.ajax({
					type: 'POST',
					url: "settings-action/add_user.php",
					data: "user_name=" + user_name + "&userid=" + userid + "&user_password=" + user_password + "&user_type_tkn=" + user_type_tkn  + "&user_type=" + user_type + "&counter=" + counter + "&company=" + company,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				//parent.jQuery.fancybox.close(); 
				document.getElementById( "insert_form" ).reset(); $( "#gstsave" ).show();
				return false;
			}
		}
	</script>