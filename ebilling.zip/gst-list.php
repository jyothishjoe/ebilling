<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php"); include('db-connect/db.php');
$results = $db->prepare("select * from  admin_user where user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++){ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type where user_tkn = '$user_type_tkn'");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{ $master_update_gst=$row_user['master_update_gst'];  $master_add_gst=$row_user['master_add_gst']; } 

$results_user_second = $db->prepare("select * from  user_type_second where user_tkn = '$user_type_tkn'");
$results_user_second->execute();
for($i=0; $row_user_second = $results_user_second->fetch(); $i++)
{ $setting_update_gst=$row_user_second['setting_update_gst']; $account_update_gst=$row_user_second['account_update_gst']; $account_add_gst=$row_user_second['account_add_gst']; $setting_add_gst=$row_user_second['setting_add_gst'];  }

?>
<title>GST List</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<style>
.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}
		
</style>
<div class="col-md-12">
	<h3 class="text-center">GST List</h3>
	<div class="text-right">
		<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="margin-left:.1em;">Close</button>
	</div>
					<div class="table-responsive m-t-40">
                                <table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%">
                                    <thead>
                                        <tr style="text-align:center">
                                            <th width='10px;'>Sl No</th>
                                            <th width='105px;'>ID</th>
                                            <th width="100px;">GST Rate</th>
                                             <?php if( $setting_update_gst==0 && $setting_add_gst==0 || $master_update_gst==0 && $master_add_gst==0 || $account_update_gst==0 &&  $account_add_gst==0) { ?> <th>Action</th><?php } ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
										$result_cat = $db->prepare("SELECT * FROM gst_tax WHERE company_tkn='$user_company'");
										$result_cat ->execute(); 
										$sl = 0;
										for ($i=0; $rows_cat  = $result_cat ->fetch(); $i++){
										?>
                                        <tr id="1" class="gradeX" style="text-align:center">
                                           <td width="25px;"><?php echo $i+1; ?></td>
                                           <td width='105px;'><?php echo $rows_cat['id']; ?></td>
                                           <td width="105px;"><?php echo $rows_cat['gst_rate']; ?></td>
										   <?php if( $setting_update_gst==0 && $setting_add_gst==0 || $master_update_gst==0 && $master_add_gst==0 || $account_update_gst==0 &&  $account_add_gst==0) { ?> 
                                           <td><a href="edit-gst.php?edit=<?php echo $rows_cat['gst_token']; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top"><i class="fa fa-pencil-alt"></i></a>&nbsp;<a id="delete" href="delete-gst.php?delete=<?php echo $rows_cat['gst_token']; ?>"  class="btn btn-sm btn-danger simple-ajax-popup-align-top" ><i class="fas fa-trash-alt"></i>
                                           </a></td>
										   <?php } ?>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                  </div>
      </div>
		<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});	
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
			</script>
			
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
<script src="js/toastr.js"></script>
<?php include ('include/disable_fn.php'); ?>