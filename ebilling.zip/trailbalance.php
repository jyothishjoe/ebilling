<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( "datetime_creation/datetime_creation.php" );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];

	$date_set = $today;

$result_fin = $db->prepare("SELECT * FROM  company WHERE c_token='$user_company'  ");
$result_fin->execute();	
for($i=0; $rows_fin = $result_fin->fetch(); $i++){ $start_year=$rows_fin['financial_year_from']; }
if ( isset( $_GET[ 'fdate' ], $_GET[ 'tdate' ] ) ) {
	$dates = $_GET[ 'fdate' ];
	$fdates = date_create( $dates );
	$fdate = date_format( $fdates, 'Y-m-d' );
	$dates = $_GET[ 'tdate' ];
	$tdates = date_create( $dates );
	$tdate = date_format( $tdates, 'Y-m-d' );
} else {
	$dates = $start_year;
	$fdates = date_create( $start_year );
	$fdate = date_format( $fdates, 'Y-m-d' );
	$date = $today;
	$tdates = date_create( $date );
	$tdate = date_format( $tdates, 'Y-m-d' );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Trailbalance</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="assets/auto/all.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<style>
		.panel-body {
			border: none !important;
		}
		
		@media print {
			
		#div_print {
        background-color: black;
        height: 100%;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        margin: 0;
        padding: 15px;
        font-size: 14px;
        line-height: 18px;
    }
		}
		
		fieldset {
			margin-top: 17px;
			border: 1px solid #999;
			font-size: 12px;
			padding: 0px 10px;
		}
		
		legend {
			margin-left: 10px;
			width: 80px;
			font-size: 12px;
		}
		
		.container {
			display: inline;
			position: relative;
			padding-left: 20px;
			margin-bottom: 12px;
			cursor: pointer;
			font-size: 12px;
			bottom: 5px;
			-webkit-user-select: none;
			-moz-user-select: none;
			-ms-user-select: none;
			user-select: none;
			cursor: pointer;
		}
		
		.checkmark {
			position: absolute;
			top: 0;
			left: 0;
			height: 15px;
			width: 15px;
			border: 1px solid #666;
			border-radius: 50%;
		}
		
		.container input:checked~.checkmark {
			background-color: #2196F3;
		}
		
		.checkmark:after {
			content: "";
			position: absolute;
			display: none;
		}
		
		.container input:checked~.checkmark:after {
			display: block;
		}
		
		.container .checkmark:after {
			top: 3px;
			left: 3px;
			width: 7px;
			height: 7px;
			border-radius: 50%;
			background: white;
		}
		
		@page {
			margin: 10mm;
			margin: 15mm;
		}
		
	</style>
</head>

<body class="fix-header fix-sidebar card-no-border">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php"); ?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php"); ?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor">Trail Balance</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a> </li>
							<li class="breadcrumb-item active"><a href="accounts-home.php">Accounts</a>
							</li>
						</ol>
					</div>
					<div class="">
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
								<form method="get" action="" autocomplete="off">
									<div class="form-row">
										<?php
										$result = $db->prepare( "SELECT * FROM  date_mask WHERE addby='$userid' AND company_tkn='$user_company' ORDER BY id DESC LIMIT 1" );
										$result->execute();
										$rows = $result->fetch();
										$dateformate = $rows[ 'dateformate' ];
										?>
										<?php if ($dateformate == 'datechoos') { ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">From </label>
											<input type="date" class="form-control" id="fdate" name="fdate" value="<?php echo $start_year; ?>" required>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">To</label>
											<input type="date" class="form-control" id="tdate" name="tdate" value="<?php echo $date_set; ?>" required>
										</div>
										<?php } else { ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">From</label>
											<input type="text" class="form-control date-inputmask" id="fdate" name="fdate" value="<?php echo $start_year; ?>" required>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<label for="" class="control-label">To</label>
											<input type="text" class="form-control date-inputmask" id="tdate" name="tdate" value="<?php echo $date_set; ?>" required>
										</div>
										<?php } ?>
										<!-- <input type="text" name="fdate" value="" class="form-control" required id="fdate1" placeholder="dd/mn/yyyy" > -->
										<div class="col-md-4 col-sm-6 col-xs-12">
											<div class="col-md-4">
												<label>&nbsp;</label>
												<div class="col-md-2">
													<input type="submit" value="Search" class="btn btn-sm btn-info" style="font-size: 15px;">
													<a href="trailbalance.php" class="btn btn-sm btn-danger" style="margin-left: 75px; position: absolute; font-size: 15px; top:-1px;">&nbsp;Clear&nbsp;</a>
												</div>
											</div>
										</div>
									</div>
								</form>
								<div class=" col-md-12 text-right" style="margin-top:40px;" >
							 	<a href="#" id="pdf" class="btn btn-info btn-sm"  /><i class="fa fa-file-pdf" aria-hidden="true"></i>  PDF</a>
								<a href="#" name="b_print"   class="btn btn-info btn-sm"   onClick="printdiv('div_print');" ><i class="fa fa-print" aria-hidden="true"></i> Print</a>  
								<!--<a href="#" class="btn btn-info btn-sm" id="csv"><i class="fa fa-file-excel" aria-hidden="true"></i> CSV</a>-->
								<button id="btnExport" class="btn btn-info btn-sm" onclick="fnExcelReport();"><i class="fa fa-file-excel" aria-hidden="true"></i> Excel</button>
							  </div>
								<div id="div_print">
								<div class="table-responsive m-t-40" id="print_pdf">
									<table id="example28" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0">
										<thead>
										<tr>
										<th colspan="3" style="text-align: center;   border-bottom: 1px dotted #0D0D0D;">
											<img oncontextmenu="return false;" src="assets/images/company_logo/<?php echo $logo; ?>" style="width:85px; height:75px;  "><br>
											<center>
												<strong><?php echo $company_name; ?></strong><br>
												<b>Trail Balance As on
												<?php echo date("d-m-Y",strtotime($fdate)); ?></b>
											</center><br>
										</th>
							     	  </tr>
									  <tr style="font-family: Times New Roman">
										<th colspan="3"  style="text-align: center; border-top: 1px dotted #000000; border-bottom: 1px solid black;">
											<b>From Date :   <?php echo date("d-m-Y",strtotime($fdate));?>   </b><b>To Date:  <?php echo date("d-m-Y",strtotime($tdate));?></b>
										</th>
										
									   </tr>
										</thead>
										<thead>
											<tr class="text-uppercase">
												<th style="text-align: left; font-size: 16px; border-bottom: 1px solid black;"><strong>Particulars</strong></th>
												<th style="text-align: right; font-size: 16px; border-bottom: 1px solid black;"><strong>Debit</strong></th>
												<th style="text-align: right; font-size: 16px; border-bottom: 1px solid black;"><strong>Credit</strong></th>
											</tr>
										</thead>
										<tbody>
											<?php
											$dr_led_total = $cr_led_total = 0;
											$result_ledger1 = $db->prepare( "SELECT * FROM accountgroup" );
											$result_ledger1->execute();
											for ( $i = 0; $row_ledger = $result_ledger1->fetch(); $i++ ) {
												$result_ledger2 = $db->prepare( "SELECT * FROM account_ledger WHERE  account_group = '" . $row_ledger[ 'name' ] . "'" );
												$result_ledger2->execute();
												$closingledger_bal_tot = 0;
												$closingledger_bal_tot_cr = 0;
												$closingledger_bal_tot_dr = 0;
												$echo_ledger_dr = 0;
												$echo_ledger_cr = 0;
												$debit_amt = $credit_amt = 0;
												for ( $i1 = 0; $row_ledger2 = $result_ledger2->fetch(); $i1++ ) {
													$closingledger_bal = 0;
													$ledger_name = $row_ledger2[ "ledger_name" ];
													$ledger_type = $row_ledger2[ "trans" ];


													$result_trans12 = $db->prepare( "SELECT SUM(debit_amt) AS debit_amt FROM transaction a LEFT JOIN account_ledger b ON a.ledger_name=b.ledger_name where a.trn_date >='$fdate' AND a.trn_date <='$tdate' AND a.ledger_name = '$ledger_name' OR a.trans_type !='tax' AND b.account_group='DUTIES AND TAXES' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company'" );
													$result_trans12->execute();
													$row_trans12 = $result_trans12->fetch();

													$result_trans21 = $db->prepare( "SELECT SUM(credit_amt) AS credit_amt FROM transaction a LEFT JOIN account_ledger b ON a.ledger_name=b.ledger_name WHERE a.trn_date >='$fdate' AND a.trn_date <='$tdate' AND a.ledger_name = '$ledger_name' OR a.trans_type !='tax' AND b.account_group='DUTIES AND TAXES' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' AND b.account_group !='STOCK' " );
													$result_trans21->execute();
													$row_trans21 = $result_trans21->fetch();

													$result_balance = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company' AND ledger_name='$ledger_name' AND balance !=0 AND account_group !='STOCK'" );
													$result_balance->execute();
													$rows_balance = $result_balance->fetch();
													if(empty($rows_balance['balance'])){
														$opening_balance = '0';
													}else{
														$opening_balance = $rows_balance[ 'balance' ];
													}
													


													$totled_ledger_dr = $row_trans12[ 'debit_amt' ];
													$totled_ledger_cr = $row_trans21[ 'credit_amt' ];

													$result_led2 = $db->prepare( "SELECT * FROM transaction WHERE company_tkn='$user_company' AND ledger_name='$ledger_name'" );
													$result_led2->execute();
													$row_led2 = $result_led2->fetch();
													if(empty($row_led2['typ'])){
														$acctype1 = '';
													}else{
														$acctype1 = $row_led2['typ'];
													}
													

													
													
													//=======Op_stock=====//
													$result_trading = $db->prepare( "SELECT balance AS closing_balance FROM account_ledger WHERE company_tkn='$user_company' AND account_group='STOCK'");
													$result_trading->execute();
													$rows_trading = $result_trading->fetch();
													
											
													$closing_stock = $rows_trading['closing_balance'];
													
													
													if ( $ledger_type == 'Dr' ) {

														$closingledger_bal = $totled_ledger_dr - $totled_ledger_cr + $opening_balance;
														$echo_ledger_dr = $closingledger_bal;

													} else if ( $ledger_type == 'Cr' ) {

														$closingledger_bal = $totled_ledger_cr - $totled_ledger_dr + $opening_balance;
														$echo_ledger_cr = $closingledger_bal;

													}

													if ( $ledger_type == 'Dr' ) {

														$closingledger_bal_tot_dr = $echo_ledger_dr - $echo_ledger_cr;

													} else if ( $ledger_type == 'Cr' ) {

														$closingledger_bal_tot_cr = $echo_ledger_cr - $echo_ledger_dr;

													}

													$debit_amt = $closingledger_bal_tot_dr;
													$credit_amt = $closingledger_bal_tot_cr;
													
													
													if($credit_amt < 0){ $debit_amt = abs($credit_amt); $ledger_type = 'Dr'; }
													
													if($debit_amt < 0){ $credit_amt = abs($debit_amt); $ledger_type = 'Cr'; }

											if($debit_amt > 0 || $credit_amt > 0){
											?>
											<tr style=" cursor: pointer;">
												<td>
											    <a target="_blank" style="color: #0A0A0A; text-decoration:none; cursor: pointer;" href="journal-report.php?ledgername=<?php echo $row_ledger2['ledger_name']; ?>"><?php echo strtoupper($row_ledger2['ledger_name']); ?></a>
												</td>
												<?php if ($ledger_type == 'Dr') { ?>
												<td class="text-right">
												<?php if($debit_amt > 0){echo round($debit_amt, 2); $dr_led_total +=$debit_amt; } ?>
												</td>
												<td class="text-right"></td>
												<?php } ?>
												<?php if ($ledger_type == 'Cr') { ?>
												<td class="text-right"></td>
												<td class="text-right"> <?php if($credit_amt > 0){ echo round($credit_amt, 2);  $cr_led_total+=$credit_amt; } ?></td>
												<?php } ?>
											</tr>
											<?php } } } if($closing_stock > 0){ ?>
											<tr>
												<td>STOCK</td>
												<td class="text-right"><?php echo $closing_stock; ?></td>
												<td></td>
											</tr>	
											<?php } if($closing_stock > 0){ ?>
											<tr>
												<td>Difference In Amount</td>
												<td></td>
												<td class="text-right"><?php echo $closing_stock; ?></td>
											</tr>
											<?php } ?>
											<tr>
												<td colspan="3"></td>
											</tr>
										 </tbody>
										<tfoot>
											<tr>
												<td><strong style="font-size: 18px;">Total</strong></td>
												<td align="right" style="font-size: 15px; border-top: 1px solid black; border-bottom: 1px solid black;">
													<strong><?php echo number_format($dr_led_total + $closing_stock, 2); ?></strong>
												</td>
												<td align="right" style="font-size: 15px; border-top: 1px solid black; border-bottom: 1px solid black;">
													<strong>
														<?php echo number_format($cr_led_total + $closing_stock, 2); ?>
													</strong>
												</td>
											</tr>
										</tfoot>
									</table>
								</div>
							   </div>
							</div>
						</div>
					</div>
					
					<div class="right-sidebar">
						<div class="slimscrollright">
							<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
							<div class="r-panel-body">
								<ul id="themecolors" class="m-t-20">
									<li><b>With Light sidebar</b>
									</li>
									<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
									</li>
									<li class="d-block m-t-30"><b>With Dark sidebar</b>
									</li>
									<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
									</li>
									<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
									</li>
								</ul>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
	</div>
	<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
	<script src="js/mask.init.js"></script>
	<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/perfect-scrollbar.jquery.min.js"></script>
	<script src="js/waves.js"></script>
	<script src="js/sidebarmenu.js"></script>
	<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
	<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
	<script src="js/custom.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/table/js/dataTables.buttons.min.js"></script>
	<script src="assets/table/js/buttons.flash.min.js"></script>
	<script src="assets/table/js/jszip.min.js"></script>
	<script src="assets/table/js/pdfmake.min.js"></script>
	<script src="assets/table/js/vfs_fonts.js"></script>
	<script src="assets/table/js/buttons.html5.min.js"></script>
	<script src="assets/table/js/buttons.print.min.js"></script>
	<script src="assets/jquery/dist/jquery.PrintArea.js"></script>
	<!--select-->
	<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
	<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
	<?php include ('include/disable_fn.php'); ?>
	<script type="text/javascript" src="assets/convert/pdfmake.min.js"></script>
    <script type="text/javascript" src="assets/convert/html2canvas.min.js"></script>
	<script src="js/table2csv.js"></script>
	<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
	<script src="js/toastr.js"></script>
    <script type="text/javascript">
	var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
	/*day detailse pdf*/
        $("body").on("click", "#pdf", function () {
			 //$('.non_pdf').hide(); 
            html2canvas($('#print_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("<?php echo $company_name; ?>_<?php echo $fdate; ?>_To_<?php echo $tdate; ?>.pdf");
					if(data !=''){
				$.toast( { heading: 'PDF Exported..', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 1500} ); 	
				}
                }
            }); 
     setTimeout(location.reload.bind(location), 1200);			
        }); //$('.non_pdf').show();
	 

function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
    
//excel
		function fnExcelReport() {
			var tab_text = "<table border='2px'><tr bgcolor='#87AFC6'>";
			var textRange;
			var j = 0;
			tab = document.getElementById( 'example28' ); // id of table

			for ( j = 0; j < tab.rows.length; j++ ) {
				tab_text = tab_text + tab.rows[ j ].innerHTML + "</tr>";
				//tab_text=tab_text+"</tr>";
			}

			tab_text = tab_text + "</table>";
			tab_text = tab_text.replace( /<A[^>]*>|<\/A>/g, "" ); //remove if u want links in your table
			tab_text = tab_text.replace( /<img[^>]*>/gi, "" ); // remove if u want images in your table
			tab_text = tab_text.replace( /<input[^>]*>|<\/input>/gi, "" ); // reomves input params

			var ua = window.navigator.userAgent;
			var msie = ua.indexOf( "MSIE " );

			if ( msie > 0 || !!navigator.userAgent.match( /Trident.*rv\:11\./ ) ) // If Internet Explorer
			{
				txtArea1.document.open( "txt/html", "replace" );
				txtArea1.document.write( tab_text );
				txtArea1.document.close();
				txtArea1.focus();
				sa = txtArea1.document.execCommand( "SaveAs", true, "Say Thanks to Sumit.xls" );
			} else //other browser not tested on IE 11
				sa = window.open( 'data:application/vnd.ms-excel,' + encodeURIComponent( tab_text ) );

			return ( sa );
			window.close();
			$.toast( { heading: 'PDF Exported..', text: '', position: 'top-right', loaderBg: '#1FDE13', icon: 'success', hideAfter: 1500} );
		}
	
		
$('#csv').on('click',function(){
    $('#print_pdf').table2csv({
      file_name: '<?php echo $company_name; ?>_<?php echo $fdate; ?>_To_<?php echo $tdate; ?>.csv',
      header_body_space: 0
    });
  })
		
		</script>
	<script>
		
		
		
		$( '#example28' ).DataTable( {
			dom: 'Bfrtip',
			bSort: false,
			paging: false,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			]

		} );

	</script>


	<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>