<?php
include ('include/auth.php');
include('db-connect/db.php');
include('datetime_creation/datetime_creation.php');
$userid = $_SESSION['SESS_USERID_AS'];

$date_set = $today;

?>
<div id="custom-content" class="col-md-10 col-sm-6 col-xs-12" style="margin: 109px; auto; overflow: hidden;  background-color: #ffffff;">
							<div class="col-md-12"><strong><h3 style="text-align: center; padding-top: 12px;">Bank</h3></strong></div>
								<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
								<input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
									<div class="form-row">
										<?php
										$result_bill = $db->prepare("SELECT * FROM payment_bank ORDER BY bn_no DESC LIMIT 1 ");
										$result_bill->execute();
										$rows_bill = $result_bill->fetch();
										$row_count = $result_bill->rowCount();
										$prefix = 'BKN';
										if($row_count == 0){
										$invno = 'BKN1';
											$invno1 = '1';
										}else{
										$invno =sprintf( "%s%1s", $prefix, $rows_bill['bn_no'] + 1);
											$invno1 = $rows_bill['bn_no'] + 1;
										}
										?>
										<div class="col-md-8"></div>
											<div class="col-md-4" style="float: right; margin-bottom: 12px;">
												<div class="row"><div class="col-md-6"><label></label><input type="hidden" class="form-control" name="invno" value="<?php echo $invno; ?>" id="invno" readonly><input type="hidden" class="form-control" name="inv_no" value="<?php echo $invno1; ?>" id="inv_no" readonly></div></div>
													<input type="date" class="form-control" style="width: 155px; display: inline;" name="date" id="date" value="<?= $date_set; ?>" > &nbsp;
													<input type="time" class="form-control" style="width: 120px; display: inline;" name="time" id="time" value="<?= date('H:i') ?>" readonly>
											</div>
									</div>
									<div class="col-md-8">
									<div class="form-row">
									<div class="col-md-3  col-sm-6 col-xs-12">
											<div class="form-group row">
											<label for="validationTooltip01" class="control-label  col-12" style="text-align: left;">Transaction Code</label>
												<div class="col-12">
													<select class="form-control select2" id="trans" name="trans" style="width: 100%; height:36px;">
													<option></option>
														<?php
														$result_bank = $db->prepare("SELECT * FROM bank");
														$result_bank->execute();
														for ($i = 0; $rows_bank = $result_bank->fetch(); $i++){
														?>
														<option value="BANKTRN<?php echo $rows_bank['bank_code']; ?>">
														BANKTRN<?php echo $rows_bank['bank_code']; ?>
														</option>
														<?php } ?>
													</select>
												</div>
											</div>
										</div>
										<div class="col-md-2 col-sm-6 col-xs-12 ">
											<div class="form-group row">
											<input type="hidden" class="form-control" name="invno" value="<?php echo $invno; ?>" id="invno" readonly>
												<label for="validationTooltip01" class="control-label  col-12" style="text-align: left;">Voucher No</label>
												<div class="col-12">
													<input type="text" class="form-control" name="vno1" 876543a#4
													9=	cb placeholder="PO NO" value="<?php echo $invno1; ?>" readonly >
													<input type="hidden" class="form-control" name="vno" 876543a#4
													9=	cb placeholder="PO NO" value="<?php echo $invno; ?>" readonly >
												</div>
											</div>
										</div>
									</div>
									</div>
										<hr/>
										<!----Table-->
										<div class="col-sm-12 col-xs-12 " style="overflow-x: auto; height: 155px;">
										<table class="table table-bordered" style="min-width: 900px;">
											<thead>
												<tr>
													<th>Sl No</th>
													<th>Account</th>
													<th>Narration</th>
													<th>Check No</th>
													<th>Dr</th>
													<th>Cr</th>
													<th style="float: right;"><input type="button" id="addmore" name="button" class="btn btn-sm btn-info" value="+"></button>
													</th>
												</tr>
											</thead>
											<tbody id="order">
												<tr class='tr_input'>	
													<td><input type='text' name="serial" style="width: 40px;" class='form-control serial' value="1" id='serial_1' placeholder='Product Code'></td>
													<td><input type='text' name="account[]" class='form-control account' id='account_1' placeholder='Account Name'><input type='hidden' name="ledger_token[]" class='form-control ledger_token' id='ledger_token_1' placeholder='Token'></td>
													<td><input type='text' name="narration[]"  class='form-control narration' id='narration_1' placeholder='Narration'></td>
													<td><input type='text' name="checkno[]" class='form-control checkno' id='checkno_1' placeholder='Check No'></td>
													<td><input type='text' name="dr[]" class='form-control dr' id='dr_1' placeholder='Dr' value=""></td>
													<td><input type='text' name="cr[]" class='form-control cr' id='cr_1' placeholder='Cr' value=""></td>
													<td></td>
												</tr>
											</tbody>
										  </table>
										</div>
										<input type="hidden" name="totalamt" class="form-control totalamt" id="totalamt">
										<input type="hidden" name="totalamtdr" class="form-control tottotalamtdralamt" id="totalamtdr">
									<div class="col-md-12" style="margin: 22px 0px;">
								<input type="submit" name="insert" id="insert" class="btn btn-info btn-sm" style="float: right; margin-bottom: 20px;" value="Submit">
							<button type="button" id="close_fbx" class="btn btn-sm btn-danger" style="float: right; margin-right: 8px; margin-bottom: 20px;">Cancel</button>
						</div>
					<div class="col-12"></div>
				</form>
			<script>
$( "select[name='typ']" ).change(function (){
    var typ = $(this).val();
    if(typ) {
        $.ajax({
            url: "accounts/autosearch/transaction_change1.php",
            dataType: 'Json',
            data: {'id':typ},
            success: function(data){
                $('select[name="trans"]').empty();
                $.each(data, function(key, value) {
						$('select[name="trans"]').append('<option value="'+ key +'">BANKTRN'+ value +'TRN</option>');
                });
            }
        });
    }else{
        $('select[name="trans"]').empty();
    }
});
</script>
<script>
	//addRowCount('.js-serial');
	function setFocusToTextBox(){
		$("#account_1").focus();
	}
</script>
<script type="text/javascript">
	$('#close_fbx').on('click', function(){ parent.jQuery.magnificPopup.close(); });
	$(document).ready(function (){

		$(document).on('keydown', '.account', function(){

			var id = this.id;
			var splitid = id.split('_');
			var index = splitid[ 1 ];

			$('#' + id).autocomplete({
				source: function (request, response){
					$.ajax({
						url: "accounts/autosearch/accgroup.php",
						type: 'post',
						dataType: "json",
						data:{
							search: request.term,
							request: 1
						},
						success: function (data){
							response(data);
						}
					});
				},
				select: function (event, ui){
					$(this).val(ui.item.label); // display the selected text
					var account = ui.item.value;
					// selected id to input
					$.ajax({
						url: 'accounts/autosearch/accgroup.php',
						type: 'post',
						data: {
							account: account,
							request: 2
						},
						dataType: 'json',
						success: function ( response ) {

							var len = response.length;

							if ( len > 0 ) {
								var ledger_token = response[ 0 ][ 'ledger_token' ];

								document.getElementById( 'ledger_token_' + index ).value = ledger_token;
							}
						}
					} );
				}
			});
			//credit Total	
			$( '.cr' ).keyup( function () {
				/*net sum */
				var sum = 0;
				var qtysum = 0;
				var gst = 0;
				//iterate through each textboxes and add the values
				$( '.cr' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						sum += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'totalamt' ).value = Math.round( sum );
			} );
				//Debit Total
			$( '.dr' ).keyup( function () {
				/*net sum */
				var sum = 0;
				var qtysum = 0;
				var gst = 0;
				//iterate through each textboxes and add the values
				$( '.dr' ).each( function () {
					//add only if the value is number
					if ( !isNaN( this.value ) && this.value.length != 0 ) {
						sum += parseFloat( this.value );
					}
				} );
				//.toFixed() method will roundoff the final sum to 2 decimal places
				document.getElementById( 'totalamtdr' ).value = Math.round( sum );
			} );
		});
		// Add more
		$(window).keydown(function (event){
			if (event.keyCode == 13){
				event.preventDefault();
				// Get last id 
				var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
				var split_id = lastname_id.split('_');
				// New index
				var index = Number(split_id[ 1 ]) + 1;
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text'  class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder=''></td><td><input type='text' class='form-control account' name='account[]'  id='account_" + index + "' placeholder='Account'><input type='hidden' class='form-control ledger_token' name='ledger_token[]'  id='ledger_token_" + index + "' placeholder='Account'></td><td><input type='text' placeholder='Narration' class='form-control narration' name='narration[]' id='narration_" + index + "' ></td><td><input type='text' placeholder='checkno' class='form-control checkno' name='checkno[]' id='checkno_" + index + "' ></td><td><input type='text' placeholder='Dr' class='form-control dr' name='dr[]' id='dr_" + index + "' ></td><td><input type='text' placeholder='Cr' class='form-control cr' name='cr[]' id='cr_" + index + "' ></td><td><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
				// Append data
				$('#order').append(html);
				$(document).on('click', '.delete', function (){
					$(this).closest('tr').remove();
				});
			}
			$('#code_' + index).focus();
		});
		// Add more
		$('#addmore').click(function (){
			// Get last id 
			var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
			var split_id = lastname_id.split('_');
			// New index
			var index = Number(split_id[ 1 ]) + 1;
			// Create row with input elements
			var html = "<tr class='tr_input'><td><input type='text'  class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder=''></td><td><input type='text' class='form-control account' name='account[]'  id='account_" + index + "' placeholder='Account'><input type='hidden' class='form-control ledger_token' name='ledger_token[]'  id='ledger_token_" + index + "' placeholder='Account'></td><td><input type='text' placeholder='Narration' class='form-control narration' name='narration[]' id='narration_" + index + "' ></td><td><input type='text' placeholder='checkno' class='form-control checkno' name='checkno[]' id='checkno_" + index + "' ></td><td><input type='text' placeholder='Dr' class='form-control dr' name='dr[]' id='dr_" + index + "' ></td><td><input type='text' placeholder='Cr' class='form-control cr' name='cr[]' id='cr_" + index + "' ></td><td><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='x'></button></td></tr>";
			// Append data
			$('#order').append(html);
			$(document).on('click', '.delete', function (){
				$(this).closest('tr').remove();
			});
		});
		$('#insert_form').on('submit', function (event){
			event.preventDefault();
			/* Validation */
			var error = '';
			/* Creating Index WHEN Clicking Add Button Or Enter Button */
			var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
			var split_id = lastname_id.split('_');
			// New index
			var index = Number(split_id[ 1 ]) ;
			/* Supplier Details Validation */
			var account = $('#account_' + index).val();
			var from = $('#from').val();
			/* Multiple Input Row Form validation */
			var dr = $('#totalamtdr').val();
			var cr = $('#totalamt').val();
			//var check = $('#checkno_' + index).val();
			
			 if(from == ''){
				 $.toast({heading: 'Select Account.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1500}); error = 1;
			 }else if(account == ''){
				 $.toast({ heading: 'Enter Account Name.', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1500 }); error = 1;
			 }
			else if(dr != cr){
				 $.toast({ heading: 'Dr & Cr Should Be Equal', text: '', position: 'top-right', loaderBg: '#ff6849', icon: 'error', hideAfter: 1500 }); error = 1;
 			 }else
 			 
			var form_data = $(this).serialize();
			if (error == ''){
				$.ajax({
					url: "accounts/bank_journal.php",
					method: "POST",
					data: form_data,
					success: function (data){
						if (data == 'ok'){
							$.toast({
								heading: 'Payment Saved Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1000,hideMethod: 'fadeOut'
							});
						
							document.getElementById( "bankclick" ).click();
						}else{
							$.toast({heading: 'Error',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500});
						}
					}
				});
			}
		});
	});
</script>
