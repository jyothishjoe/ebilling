// autocomplet : this function will be executed every time we change the text
function autocomplet() {
	var min_length = 0; // min caracters to display the autocomplete
	var keyword = $('#name').val();
	if (keyword.length >= min_length) {
		$.ajax({
			url: 'purchase-action/search.php',
			type: 'POST',
			data: {keyword:keyword},
			success:function(data){
				$('#name').show();
				$('#name').html(data);
			}
		});
	} else {
		$('#name').hide();
	}
}

// set_item : this function will be executed when we select an item
function set_item(item) {
	// change input value
	$('#name').val(item);
	// hide proposition list
	$('#name').hide();
}