$(document).ready(function () {
	"use strict";
	//$('.select2').select2();
	$('#datatbl').DataTable();
	$('#datatb2').DataTable({
		paging: false,
		lengthChange: false,
		searching: true,
		ordering: true,
		//info: true,
		autoWidth: false,
		//pageLength: 10
	});
	$('#tbl_with_fxd_head').DataTable({
		fixedHeader: true,
		paging: true,
		lengthChange: true,
		searching: true,
		ordering: true,
		info: true,
		autoWidth: true,
		pageLength: 10,
		scrollX: true
	});
	$('#tbl_with_fxd_head_nopg').DataTable({
		fixedHeader: true,
		paging: false,
		lengthChange: false,
		searching: true,
		ordering: true,
		info: true,
		autoWidth: true,
		pageLength: 10,
		scrollX: true
	});
	
	$('#example24').DataTable({
		dom: 'Bfrtip',
		fixedHeader: true,
		paging: false,
		buttons: [
			'copy', 'csv', 'excel', 'pdf', 'print'
		]
	});
});