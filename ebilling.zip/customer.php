<?php include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
include( 'db-connect/db.php' );
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
<title>Supermarket</title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<style>
.not-exists {
	color:#FF4633;
	font-weight: bold;
}
.exists {
	color:#34D908;
	font-weight: bold;
}
</style>
</head>
<body class="fix-header fix-sidebar card-no-border">
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Admin Pro</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h3 class="text-themecolor">Add Customer</h3>
        </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Master</a> </li>
            <li class="breadcrumb-item active">Customer</li>
          </ol>
        </div>
        <div class="">
          
        </div>
      </div>
      <?php 
				$result =$db->prepare("SELECT * FROM  customer ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				$cus_no=$rows['cus_no'] + 1;
				?>
      <div class="row">
        <div class="col-md-121 col-sm-10 col-xs-12">
          <div class="card">
            <div class="card-body">
              <form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
                <div class="form-row">
                  <div class="col-md-3 col-sm-12 col-xs-12  mb-1">
                    <label for="" class="control-label">Customer Id</label>
                    <input type="text" class="form-control"   id="cus_no"  name="cus_no"  value="<?php echo $cus_no;?>" readonly>
                    <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
                    <input type="hidden" class="form-control"  id="cus_tkn" name="cus_tkn" value="<?php echo create_token();?>" readonly>
                  </div>
                  <div class="col-md-3 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Date/Time</label>
                    <input type="text" class="form-control datetym"  id="datetym" name="datetym"  value="<?php echo $current_date_time;?>" readonly>
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12  mb-1">&nbsp;</div>
                  <div class="col-md-6 col-sm-12 col-xs-12  mb-1">
                    <label for="" class="control-label">Account Name</label>
                    <input type="text" class="form-control acco_name"  name="acco_name" id="acco_name" placeholder="Enter Account Name" autofocus>
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12  mb-1">&nbsp;</div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Customer Name</label>
                    <input type="text" class="form-control cus_name " id="cus_name" name="cus_name" placeholder="Enter Customer Name" >
                    <div id="uname_response" class="response"></div>
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Location</label>
                    <input type="text" class="form-control location" id="location" name="location"  placeholder="Enter Location" >
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Address</label>
                    <textarea class="form-control addres" id="addres" name="addres" rows="2"  placeholder="Required address"></textarea>
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Contact No</label>
                    <div class="col-md-12 col-sm-12 col-xs-12 mb-1">
                      <input type="text" class="form-control contact_no1" id="contact_no1" name="contact_no1"  placeholder="Enter Contact Number 1">
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 ">
                      <input type="text" class="form-control contact_no2" id="contact_no2" name="contact_no2"  placeholder="Enter Contact Number 2">
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1">
                    <label for="" class="control-label">Credit Limit</label>
                    <input type="text" class="form-control credit_limit" id="credit_limit" name="credit_limit"  placeholder="Enter Credit Limit">
                  </div>
                  <div class="col-md-6 col-sm-12 col-xs-12 mb-1 text-right"> <br>
                    <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a> </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
				$( document ).ready( function () {

					$( "#cus_name" ).keyup( function () {
						var cus = $( "#cus_name" ).val().trim();
						if ( cus != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'creation_actions/customer/cusnamesearch.php',
								type: 'post',
								data: {
									cus: cus
								},
								success: function ( response ) {
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in Exit.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										   document.getElementById( 'location' ).value = '';
										  document.getElementById("location").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("location").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
			</script> 
    <script>
          function save_user(){
			var cus_no = $("#cus_no").val();
			
			var addby = $("#addby").val();
			var datetym = $("#datetym").val();
			var acco_name = $("#acco_name").val();
			var cus_name = $("#cus_name").val();
				var cus_tkn = $("#cus_tkn").val();
			var location = $("#location").val();
			var addres = $("#addres").val();
			var contact_no1 = $("#contact_no1").val();
			var contact_no2 = $("#contact_no2").val();
			var credit_limit = $("#credit_limit").val();
				if($("#acco_name").val() == ""){ $.toast( {	heading: 'Fill Account Name.',	text: '',	position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
			} else if($("#cus_name").val() == ""){$.toast( {heading: 'Fill customer name.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
			} else if($("#location").val() == ""){	$.toast( {	heading: 'Fill Location.',	text: '',	position: 'top-right',loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#addres").val() == ""){	$.toast( {	heading: 'Fill Address.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',icon: 'error',hideAfter: 1500	} );
			} else if($("#contact_no1").val() == ""){$.toast( {	heading: 'Fill Contact Number.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#contact_no2").val() == ""){	$.toast( {	heading: 'Fill Contact Number.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#credit_limit").val() == ""){	$.toast( {	heading: 'Fill credit limit.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else {	$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/customer/customer_save.php',
					data: "cus_no="+ cus_no + "&addby=" + addby + "&datetym=" + datetym + "&acco_name=" + acco_name + "&cus_name=" + cus_name + "&location=" + location + "&contact_no1=" + contact_no1 + "&contact_no2=" + contact_no2 + "&credit_limit=" + credit_limit + "&addres=" + addres + "&cus_tkn=" + cus_tkn,
					success : function(r) {						
						$("#respond").html(r);
					}
				});
				window.location="customer.php";
												$.toast( {
													heading: 'Customer Add Succeccfully.',
													text: '',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1000
												} );
				return false;
			}
		}

</script>
    <div class="right-sidebar">
      <div class="slimscrollright">
        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
        <div class="r-panel-body">
          <ul id="themecolors" class="m-t-20">
            <li><b>With Light sidebar</b> </li>
            <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
            <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
            <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
            <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
            <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
            <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
            <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
            <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
            <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
            <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
            <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
            <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
            <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
          </ul>
          <ul class="m-t-20 chatonline">
            <li><b>Chat option</b> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/1.jpg" alt="user-img" class="img-circle"> <span>Varun Dhavan <small class="text-success">online</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/2.jpg" alt="user-img" class="img-circle"> <span>Genelia Deshmukh <small class="text-warning">Away</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/3.jpg" alt="user-img" class="img-circle"> <span>Ritesh Deshmukh <small class="text-danger">Busy</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/4.jpg" alt="user-img" class="img-circle"> <span>Arijit Sinh <small class="text-muted">Offline</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/5.jpg" alt="user-img" class="img-circle"> <span>Govinda Star <small class="text-success">online</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/6.jpg" alt="user-img" class="img-circle"> <span>John Abraham<small class="text-success">online</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/7.jpg" alt="user-img" class="img-circle"> <span>Hritik Roshan<small class="text-success">online</small></span></a> </li>
            <li> <a href="javascript:void(0)"><img src="assets/images/users/8.jpg" alt="user-img" class="img-circle"> <span>Pwandeep rajan <small class="text-success">online</small></span></a> </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  
</div>
</div>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>
</html>