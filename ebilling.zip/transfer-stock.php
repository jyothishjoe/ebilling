<?php 
include ('include/auth.php');
include('db-connect/db.php');
include('include/today.php');
$token=$_GET['tok'];
$company=$_SESSION['SESS_COMPANY_ID'];
$result_stock = $db->prepare("SELECT * FROM stocks WHERE stock_tkn='$token' AND company_tkn='$company' ");
$result_stock->execute();
$rows_stock = $result_stock->fetch(); 
$location = $rows_stock['location_name'];
?>
<div id="custom-content"  class="col-md-4 col-sm-6 col-xs-12" style="margin: 80px auto; overflow: hidden; height: 350px; background-color: #f2f2f2;">
	<h3 class="text-center" style="margin-bottom : 12px; margin-top : 12px;">Stock Transfer</h3>
	   <form autocomplete="off" method="post" id="insert_form" action="" enctype="multipart/form-data" class="forms">
		  <h3 class="text-align: center;" style="margin-bottom: 25px; color: Green;"></h3>
			<div class="form-row" style="margin-bottom:12px;">
				<div class="col-md-12">
					<label for="validationTooltip01" class="control-label  col-12" style="text-align: left;">Current Location</label>
					<input type="text" class="form-control"  name="from_stock" id="from_stock" value="<?php echo $rows_stock['location_name']; ?>" placeholder="From" readonly>
					<input type="hidden" class="form-control"  name="token" id="token" value="<?php echo $token; ?>" placeholder="Enter Qty"> 
				</div>
			</div>
		   <div class="form-row">
			  <div class="col-12">
				<label for="validationTooltip01" class="control-label  col-12" style="text-align: left;">Transfer To</label>
					<select class="form-control" id="location_to" name="location_to">
						<option></option>
						<?php
						$result_vendor = $db->prepare("SELECT * FROM location WHERE company_tkn='$company' AND location_name !='$location' ");
						$result_vendor->execute();
						for ($i = 0; $rows_vendor = $result_vendor->fetch(); $i++) {
						?>
						<option value="<?php echo $rows_vendor['location_name']; ?>">
							<?php echo $rows_vendor['location_name']; ?>
						</option>
						<?php } ?>
					</select>
				</div>
			</div>
		   <div class="form-row" style="margin-bottom:12px;">
				<div class="col-md-12">
					<label for="validationTooltip01" class="control-label  col-12" style="text-align: left;">Qty</label>
					<input type="text" class="form-control"  name="qty" id="qty"  placeholder="Change Qty">
					<input type="hidden" class="form-control"  name="available" id="available"  value="<?php echo $rows_stock['pr_stock']; ?>" >
				</div>
			</div>
		   <div class="form-row" style="margin-bottom:12px; margin-top: 15px;">
			   <div class="col-md-12">
			   <input type="submit" class="btn btn-sm btn-info" id="submit" style="float: right;" value="Transfer">
				</div>
		   </div>
				
		</form>	
	<div id='respond'></div>
		<script>
		$( '#qty' ).on( 'keyup', function (){
			var qty = $( "#qty" ).val();
			var available = $( "#available" ).val();
			var from_stock = $( "#from_stock" ).val();
				if(qty > available){
					console.log('sds');
				$.toast( {heading: 'Qty Should Be less or equal',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1800});	
				}
		});
			
				
			$( '#insert_form' ).on( 'submit', function (event){
					event.preventDefault();
				   	var qty = $( "#qty" ).val();
					var location_to = $( "#location_to" ).val();
					var token = $( "#token" ).val();
					var from_stock = $( "#from_stock" ).val();

					if ( $( "#qty" ).val() == "" ) {
						$.toast( {heading: 'Choose a location.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1800});
					}else if ( $( "#qty" ).val() == "" ) {
						$.toast( {heading: 'Enter Stock Qty .',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1800});
					} else {
						$.ajax({
						type : 'POST',
						url  : "product-action/stock-transfer.php",
						data: "qty="+ qty + "&token=" + token + "&location_to=" + location_to + "&from_stock=" + from_stock,
						success : function(r) {						
						$("#respond").html(r);
							}
						});
						//parent.jQuery.magnificPopup.close();
						
						//location.reload();
						return false;
					}
				});

			</script>