<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
?>
<div class="col-md-12 col-sm-6 col-xs-12" style="overflow: hidden;">
	<h3 class="text-center">Add Tax</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Tax Type </label>
				<input type="text" class="form-control" id="tax_typ" name="tax_typ" value="" placeholder="Tax Type">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company; ?>">
			</div>
		</div>
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Tax Rate </label>
				<input type="text" class="form-control" id="tax_rate" name="tax_rate" value="" placeholder="Tax Rate">
	    	</div>
		</div>
    	 <!--<div class="form-row">
	       <div class="col-md-12" style="margin-top: 18px; margin-bottom: 12px;">
              <div class="btn-group" data-toggle="buttons">
				<span class="btn btn-sm btn-info">
					<input type="checkbox" id="purchase" class="filled-in chk-col-light-blue" name="purchase" value="purchase">
					<label class="" for="md_checkbox_21">Purchase</label>
				</span>
				<label class="btn btn-sm btn-info">
					<input type="checkbox" id="sales" class="filled-in chk-col-light-blue" name="sales" value="sales">
					<label class="" for="md_checkbox_22">&nbsp;&nbsp;&nbsp;Sales&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				</label>
			</div>
		</div>
                  </div>-->
		<div class="text-right">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" style="margin-bottom: 12px; margin-top: 26px;">Save</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger " style="margin-bottom: 12px; margin-top: 26px;">Cancel</button>
		</div>
	</form>
</div>
	<script>
		$(document).ready( function (){
		$('#tax_typ').focus();
		});
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 255 ) {
				parent . jQuery . fancybox . close();

				// $( "#custom-content" ).hide();
				$( "#clickadd" ).click();
			}
		if ( event . keyCode == 13 ) {
				// $( "#custom-content" ).hide();
				$( "#catesave" ).click();
			}
	});
		function save_customer() {

          /*  if( $("input[name='purchase']:checked").val()){
				 var purchase='purchase';
			} else {var purchase='';}
          if( $("input[name='sales']:checked").val()){
				 var sales='sales';
			} else {var sales='';}*/
			var tax_typ = $("#tax_typ").val();
			var tax_rate = $("#tax_rate").val();
			var userid = $("#userid").val();
			var company = $("#company").val();
			if ( $("#tax_rate").val() == ""   ) {
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 1200} );
			}else{
				$.ajax({
					type: 'POST',
					url: "product-action/tax_creation.php",
					data: "tax_typ=" + tax_typ + "&tax_rate=" + tax_rate + "&userid=" + userid + "&company=" + company,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				document.getElementById( "insert_form" ).reset(); $('#tax_typ').focus();
				//parent.jQuery.fancybox.close();
				/*$.toast( {heading: 'Added Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 1200} );*/
				return false;
			}
		}
	</script>