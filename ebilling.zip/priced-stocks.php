<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );

$date = date_create($today);
date_sub($date,date_interval_create_from_date_string("2 days"));
$date1 = date_format($date,"Y-m-d");

if(isset ($_GET['startdate'], $_GET['enddate'])){
$startdates = date_create($_GET['startdate']);
$startdates = date_format($startdates,'Y-m-d');
	
$enddates= date_create($_GET['enddate']);
$enddates = date_format($enddates,'Y-m-d');
}
$userid=$_SESSION['SESS_USERID_AS'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>Priced Stocks</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/datatables.net-bs/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="assets/datatables.net-bs/css/fixedHeader.bootstrap.min.css">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
				<div class="row page-titles">
					<div class="col-md-5 align-self-center">
					<h3 class="text-themecolor float-left">Priced Items</h3>
					</div>
					<div class="col-md-7 align-self-center">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="index1.php">Home</a></li>
							</li>
						<li class="breadcrumb-item"><a href="inventory-home.php">Inventory</a></li>
							<li class="breadcrumb-item active">Priced Stocks</li>
						</ol>
					</div>
					<div class="col-md-12">
					</div>
					<div>
						
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-body">
							 <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
									<div class="form-row" style="margin-top: 12px;">
										<?php include('include/datemask.php'); ?>
										<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
											<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 15px;" value="Submit"/>
										</div>
									</div>
								</form>
								<div class="table-responsive m-t-40">
								<?php if(isset ($_GET['startdate'], $_GET['enddate'])){ ?>
									<table id="tbl_with_fxd_head" class="table display nowrap" style="width:100%">
										<thead>
											<tr>
												<th>Sl.No</th>
												<th>Date</th>
												<th>Barcode</th>
												<th>Item Name</th>
												<th>HSN</th>
												<th>Tax Rate</th>
												<th>Mrp</th>
												<th>Stock</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$result_stock = $db->prepare("SELECT * FROM item_pricing WHERE price_date >= '$startdates' AND price_date <='$enddates' ");
											$result_stock ->execute(); 
											$sl = 1;
											for ($i=0; $rows_stock  = $result_stock ->fetch(); $i++){
												$norm_date = $rows_stock['bill_date'];
												$date = date_create($norm_date);
												$condate = date_format($date,'d-m-Y');
											?>
											<tr class='tr_input'>
												<td><?= $sl++; ?></td>
												<td><?php echo $condate; ?><br><?php echo $rows_stock['time']; ?></td>
												<td><?= $rows_stock['pr_barcode']; ?></td>
												<td><?= $rows_stock['pr_name']; ?></td>
												<td><?php echo $rows_stock['pr_hsn']; ?></td>
												<td><?php echo $rows_stock['sales_tax']; ?>%</td>
												<td> ₹ <?php echo $rows_stock['pr_saleprice']; ?></td>
												<td><?php echo $rows_stock['pr_stock']; ?></td>
												<td><a href="barcode_genarate.php?barcode=<?php echo $rows_stock['pr_barcode']; ?>" class="btn btn-sm btn-info simple-ajax-popup-align-top"><i class="fas fa-barcode"></i>&nbsp;Print</a></td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
									<?php } ?>
								</div>
						</div>
					</div>
				</div>
			</div>		
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
						<div class="r-panel-body">
							<ul id="themecolors" class="m-t-20">
								<li><b>With Light sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
								</li>
								<li class="d-block m-t-30"><b>With Dark sidebar</b>
								</li>
								<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
								</li>
								<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
								</li>
							</ul>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>

			<script>
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: true,
					closeOnBgClick: false,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : null
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });
			$( function () {

					// For select 2
					$( ".select2" ).select2();
					$( '.selectpicker' ).selectpicker();


					$( ".ajax" ).select2( {
						ajax: {
							url: "https://api.github.com/search/repositories",
							dataType: 'json',
							delay: 250,
							data: function ( params ) {
								return {
									q: params.term, // search term
									page: params.page
								};
							},
							processResults: function ( data, params ) {
								// parse the results into the format expected by Select2
								// since we are using custom formatting functions we do not need to
								// alter the remote JSON data, except to indicate that infinite
								// scrolling can be used
								params.page = params.page || 1;
								return {
									results: data.items,
									pagination: {
										more: ( params.page * 30 ) < data.total_count
									}
								};
							},
							cache: true
						},
						escapeMarkup: function ( markup ) {
							return markup;
						}, // let our custom formatter work
						minimumInputLength: 1,
						//templateResult: formatRepo, // omitted for brevity, see the source of this page
						//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
					} );
				} );
				var prevScrollpos = window.pageYOffset;
				window.onscroll = function() {
				var currentScrollPos = window.pageYOffset;
				  if (prevScrollpos > currentScrollPos) {
					document.getElementById("navbar").style.top = "0";
					   document.getElementById("navbar1").style.top = "0";
				  } else {
					document.getElementById("navbar").style.top = "-70px";
					  document.getElementById("navbar1").style.top = "-80px";
				  }
				  prevScrollpos = currentScrollPos;
				}
			</script>
			<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
			<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
			<script src="js/perfect-scrollbar.jquery.min.js"></script>
			<script src="js/waves.js"></script>
			<script src="js/sidebarmenu.js"></script>
			<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
			<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
			
			<script src="assets/datatables.net-bs/js/jquery.dataTables.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.fixedHeader.min.js"></script>
			<script src="js/custom.min.js"></script>
			<script src="assets/datatables.net-bs/js/dataTables.init.js"></script>
			<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
			<script src="js/toastr.js"></script>
			<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
			<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
			<?php include ('include/disable_fn.php'); ?>
</body>

</html>