<?php
include( 'include/auth.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( 'db-connect/db.php' );
include( "php_fn/basic.php" );
include( "datetime_creation/datetime_creation.php" );
?>
<style>
	.not-exists {
		color: #FF4633;
		margin-top: 20px;
	}
	
	.exists {
		color: #34D908;
		margin-top: 20px;
	}
	
	ul,
	li {
		z-index: 9999 !important;
	}
</style>
<div class="col-xs-12 no-padding" style="width:400px; overflow: hidden;">
	<h3 class="text-center">Add Date</h3><br>
	<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-1">
				<?php 
				$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' AND company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
				$result->execute();
				$rows=$result->fetch();
				$dateformate=$rows['dateformate'];
				?>
				<?php if($dateformate == 'datechoos') { ?>
				<div class="col-md-12 col-sm-6 col-xs-12 mb-1">
					<label for="" class="control-label"> Date</label>
					<input type="date" class="form-control" id="startdate" name="startdate" value="<?php echo $startdate;?>" required>
				</div>
				<?php } else { 
					 $dates = date_create($today);
  					$startdate = date_format($dates,'d-m-Y'); ?>
				<div class="col-md-12 col-sm-6 col-xs-12">
					<label for="" class="control-label"> Date</label>
					<input type="text" class="form-control date-inputmask" id="startdate" name="startdate" value="<?php echo $startdate;?>" required>
				</div>
				<?php } ?>
			</div>
		</div>
		<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid;?>" required>
		<input type="hidden" class="form-control" id="company" name="company" value="<?php echo $user_company;?>" required>
		<div class="text-right" style="margin-bottom:25px; margin-top: 15px; margin-right: 12px;"> 
			<a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger " >CANCEL</button>
		</div>
	</form>
</div>
<div id="respond"></div>

<script>
	$( '#close_fbx' ).on( 'click', function () {
		parent.jQuery.fancybox.close();
	});

	function save_user() {
		var userid = $( "#userid" ).val();
		var date = $( "#startdate" ).val();
		var company = $( "#company" ).val();

		if ( $( "#startdate" ).val() == "" ){
			$.toast( {
				heading: 'Choose Date',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 1500
			} );

		} else {
			$.ajax( {
				type: 'POST',
				url: 'accounts/create-date.php',
				data: "date=" + date + "&userid=" + userid + "&company=" + company,
				success: function ( r ) {
					$( "#respond" ).html( r );
					parent.jQuery.fancybox.close();
				}
			} );
			//setTimeout(function(){ window.location.reload();}, 100);
			
			return false;
		}
	}
</script>
