<?php
include( "include/auth.php" );
include( "db-connect/db.php" );
include( 'datetime_creation/datetime_creation.php' );
include( 'php_fn/basic.php' );
$company=$_SESSION['SESS_COMPANY_ID'];
for ( $count = 0; $count < count( $_POST[ "code" ] ); $count++ ){
	$price_token = create_token();
	$newst = $_POST[ 'qty' ];
	
	$result_stock = $db->prepare( 'SELECT * FROM item_pricing WHERE  pr_code=:code AND unit_price=:mrp AND company_tkn=:company' );
	$result_stock->execute( array(
		':code' => $_POST[ "code" ][ $count ],
		':company' => $company,
		':mrp' => $_POST[ "mrprate" ][ $count ]
	) );
	$rows_stock = $result_stock->fetch();
	$mrp = $rows_stock[ 'unit_price' ];
	$token = $rows_stock[ 'pr_token' ];
	
	if(isset($_POST['prch_barcode'][ $count ]) == $rows_stock['pr_barcode'] && $rows_stock[ 'pr_mrp' ] == $_POST[ "mrprate" ][ $count ])
	{
	$sql = "UPDATE item_pricing SET  unit_price= :mrp WHERE pr_code=:code AND pr_token = :pr_token AND pr_unit = :unit AND company_tkn=:company";
	$q = $db->prepare( $sql );
	$q->execute( array(
		':code' => $_POST[ "code" ][$count],
		':company' => $company,
		':unit' => $_POST[ "unit" ][ $count],
		':pr_token' => $token,
		':mrp' => "$mrp"
	));
		$sql = "UPDATE purchase_productdetails SET status='0' WHERE p_id=:code AND invoice=:purchinvoice AND company_tkn=:company";
	$q = $db->prepare( $sql );
	$q->execute( array(
		':purchinvoice' => $_POST[ "purchinvoice" ][ $count ],
		':code' => $_POST[ "code" ][ $count ],
		':company' => $company
	) );
	}else{
	$query = "INSERT INTO item_pricing 
	 (pr_token, sup_token, sup_name, purch_invoice, supplier_inv, sup_phone, bill_date, price_date, time,  pr_barcode, pr_code, pr_name, pr_hsn, pr_stock, pr_saleprice, pr_updateddate, pr_unit, sales_tax, gst_amt, tax_total, unit_price, pr_mrp, pr_purch_price, company_tkn ) 
	 VALUES (:token, :vid, :vendor_name, :purchinvoice, :purchbill, :phone, :billdate, :price_date, :time, :prch_barcode, :code, :name, :hsn, :qty, :mrp, :date, :unit, :salesgstin, :gstinamt, :tax_total, :mrprate, :mrp, :purchprice, :company)";
	$statement = $db->prepare( $query );
	$statement->execute(
		array(
		    ':token' => $price_token,
		    ':prch_barcode' => $_POST[ "prch_barcode" ][ $count ],
		    ':code' => $_POST[ "code" ][ $count ],
			':name' => $_POST[ "name" ][ $count ],
			':company' => $company,
		    ':hsn' => $_POST[ "hsn" ][ $count ],
			':unit' => $_POST[ "unit" ][ $count ],
			':purchprice' => $_POST[ "purchprice" ][ $count ],
			':salesgstin' => $_POST[ "salesgstin" ][ $count ],
			':qty' => $_POST[ "qty" ][ $count ],
			':mrp' => $_POST[ "mrp" ][ $count ],
			':mrp' => $_POST[ "mrp" ][ $count ],
		    ':vid' => $_POST[ "vid" ][ $count ],
		    ':vendor_name' => $_POST[ "vendor_name" ][ $count ],
			':purchinvoice' => $_POST[ "purchinvoice" ][ $count ],
			':phone' => $_POST[ "phone" ][ $count ],
			':date' => $_POST[ "date" ][ $count ],
			':price_date' => $_POST['date'],
			':time' => $current_time,
			':purchbill' => $_POST[ "purchbill" ][ $count ],
		    ':mrprate' => $_POST[ "mrprate" ][ $count ],
		    ':gstinamt' => $_POST[ "gstinamt" ][ $count ],
		    ':tax_total' => $_POST[ "tax_total" ][ $count ],
			':billdate' => $_POST[ "billdate" ][ $count ]
		)
	);
	$sql = "UPDATE stocks SET   pr_selling_price=:mrp, pr_barcode=:prch_barcode, pr_mrp=:mrp, sales_tax=:salesgstin, unit_price=:mrp, gst_amt=:gstinamt WHERE pr_code=:code AND company_tkn=:company AND stock_tkn=:stock_tkn";
	$q = $db->prepare( $sql );
	$q->execute( array(
		':prch_barcode' => $_POST[ "prch_barcode" ][ $count ],
		':stock_tkn' => $_POST[ "stock_tkn" ][ $count ],
		':mrp' => $_POST[ "mrp" ][ $count ],
		':company' => $company,
		':salesgstin' => $_POST[ "salesgstin" ][ $count ],
		':gstinamt' => $_POST[ "gstinamt" ][ $count ],
		':mrprate' => $_POST[ "mrprate" ][ $count ],
		':code' => $_POST[ "code" ][ $count ]
	) );
	/*$sql = "UPDATE purchase_productdetails SET status='0' WHERE p_id=:code AND invoice=:purchinvoice AND company_tkn=:company";
	$q = $db->prepare( $sql );
	$q->execute( array(
		':purchinvoice' => $_POST[ "purchinvoice" ][ $count ],
		':company' => $company,
		':code' => $_POST[ "code" ][ $count ]
	) );*/
	
	}
}
?>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
	@media print{
.btn{display:none;}
}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */
    }
</style>


<body onload="window.print(); window.onfocus=function(){ window.close();}">
	<a href="product-pricing.php" class="btn btn-sm btn-info" style="float:left;">Back</a>
	<div style="margin-left: 5%">
		
		<?php
		include 'barcode128.php';
		if (isset($_POST['code'])) 
		{
				for ( $count = 0; $count < count( $_POST[ "code" ] ); $count++ ) {
				$product = $_POST['name'][ $count ];
				$product_id = $_POST['prch_barcode'][ $count ];
				$rate = $_POST['mrp'][ $count ];

				for($i=1;$i<=$_POST['qty'][ $count ];$i++){
					echo "<p class='inline'><span ><b> $product</b></span>".bar128(stripcslashes($_POST['prch_barcode'][ $count ]))."<span ><b>Price: ".round($rate,2)." </b><span></p>&nbsp&nbsp	&nbsp&nbsp";
			}
				}
					}
		?>
	</div>
	
