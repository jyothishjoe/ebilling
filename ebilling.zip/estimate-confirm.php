<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$date = $_GET[ 'date' ];
$no = $_GET[ 'no' ];
?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #398bf7 !important; color: #fff; opacity: 1; width: 67px; font-size: 17px; height: 40px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #398bf7 !important;}
</style>
<div id="custom-content" class="col-md-4 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden; height: 235px;   background-color: #f2f2f2;">
	<h3 class="text-center"></h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" class="forms">
		<h4 class="text-align: center;" style="margin-bottom: 35px; color: green;">Bill Saved</h4>
		<div class="row">
			<div class="col-md-7"><strong style="font-weight: 600">PE No   : </strong></div><div class="col-md-2"><h4 style="font-weight: 900"><?php echo $no; ?></h4></div>
		</div>
		<hr/>
		<div class="row">
			<div class="col-md-7"><strong style="font-weight: 600">PE Date : </strong></div><div class="col-md-4"><h4 style="font-weight: 900"><?php echo $date; ?></h4></div>
		</div>
		<div class="col-md-4" style="margin-bottom: 12px;"></div>
		<div class="form-row">
			<div class="col-md-12 col-sm-4 col-xs-6">
				<center><a href="purchase-estimate.php" id="purch" class="btn btn-info" style="padding-left: 22px; padding-right: 22px; border: 1px solid gre#F0B3EC">OK</a></center>
			</div>
			<div class="col-md-6 col-sm-4 col-xs-6" style="display: none">
				<button type="button" id="close_fbx" class="btn btn btn-info mfp-close">Cancel</button>
			</div>
		</div>
	</form>
	<script>
		$(window).keydown(function (event){
		if (event.keyCode == 13) {
			$('#purch').click();
		}
		});
		$( '#close_fbx' ).on( 'click', function () {
			parent.jQuery.magnificPopup.close();
		} );
	</script>