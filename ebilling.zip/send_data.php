<?php
if(isset($_POST[ 'prdct_token' ] )){

$key = $_POST['prdct_token'];
	
$software_key = $_POST['software_key'];

$handle = curl_init();
 // SERVER URL
$url = "check_details.php?prdct_token=$key&software_key=$software_key";

// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
 
$response = curl_exec($handle);
 
curl_close($handle);
	
echo $response;
	
}
?>