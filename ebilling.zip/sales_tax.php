<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include("datetime_creation/datetime_creation.php");
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
if(isset ($_GET['startdate'], $_GET['type'], $_GET['enddate'])){
$startdate = $_GET['startdate'];
$enddate = $_GET['enddate']; $type = $_GET['type'];} else{
	$startdate ='';
  $enddate=''; $type='---Select--';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
	<title>Sales Tax Report</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link href="assets/auto/all.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<script src="js/auto_js/jquery-ui.min.js"></script>
</head>

<body class="fix-header card-no-border fix-sidebar">
	<div class="preloader">
		<div class="loader">
			<div class="loader__figure"></div>
			<p class="loader__label">Admin Pro</p>
		</div>
	</div>
	<div id="main-wrapper">
		<?php include("include/topnave.php");?>
		<aside class="left-sidebar" id="navbar">
			<?php include("include/bottomnav.php");?>
		</aside>
		<div class="page-wrapper">
			<div class="container-fluid">
					<div class="row page-titles">
						<div class="col-md-5 align-self-center">
						<h3 class="text-themecolor" style="float: left;">Sales  Reports</h3>
						</div>
						<div class="col-md-7 align-self-center">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="index.php">Home</a></li>
								</li>
								<li class="breadcrumb-item"><a href="accounts-home.php">Accounts</a></li>
								<li class="breadcrumb-item active">Sales  Reports</li>
							</ol>
						</div>
						<div>
							
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body">
									 <form class="" name="addbilldetails" method="get" action="" enctype="multipart/form-data">
										<div class="form-row" style="margin-top: 12px;">
										 <div class="col-md-2 col-sm-6 col-xs-12">
											<label for="" class="control-label">Choose Type</label>
											<select class="form-control" id="type" name="type" style="width: 100%; height:36px;" value="<?php echo $types;?>">
											  <option value="<?php echo $type;?>"><?php echo $type;?></option>
											  <option value="Catecory Wise">Catecory Wise</option>
											  <option value="Subcatecory Wise">Subcatecory Wise</option>
											  <option value="Customer Wise">Customer Wise</option>
											  <option value="Tax Wise">Tax Wise</option>
											</select>
										  </div>
											<?php include('include/datemask.php'); ?>
											<div class="col-md-2 col-sm-6 col-xs-12 mb-1">
												<input type="submit" name="" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Filter"/>
											</div>
										</div>
									</form>
									<div class="table-responsive m-t-40">
								<?php if(isset ($_GET['startdate'], $_GET['enddate'])){ 
								$datea = date_create($startdate);
								$startdate = date_format($datea,'Y-m-d');
								$dates = date_create($enddate);
								$enddate = date_format($dates,'Y-m-d'); ?>
                                    <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">							<thead>
												<tr>
													<th>#</th>
													<th>Bill Date</th>
													<?php if($type == 'Customer Wise' || $type=='Tax Wise' ) { ?><th>Bill No</th><?Php } ?>
													<?php if($type == 'Subcatecory Wise') {?><th>Subcatecory Name</th><?php } else if($type == 'Catecory Wise') { ?><th>'Catecory Name</th><?php } else if($type == 'Customer Wise') { ?><th> Customer Name</th><?php } ?>
													<?php if($type == 'Tax Wise'){ ?><th>CGST</th><?php }?>
													<?php if($type == 'Tax Wise'){ ?><th>SGST</th><?php }?>
													<?php /*if($type == 'Catecory Wise') {?><th>Qty Total</th><?php }*/ ?>
													<?php if($type == 'Customer Wise' || $type == 'Catecory Wise' || $type == 'Subcatecory Wise' ) {?><th>Tax Total</th><th>Amount</th><?Php } else if($type == 'Customer Wise') { ?><th>Discount</th><th>Net Total</th><?Php }?>
													
												</tr>
											</thead>
											<tbody>
											<?php 
							            	if($type=='Tax Wise' || $type=='Customer Wise'){
												$result_sales = $db->prepare("SELECT * FROM sales_invoice  WHERE sales_invodate >= '$startdate' AND sales_invodate <= '$enddate' AND status=0 AND status !='cancel' AND company_tkn='$user_company' ");
											$result_sales->execute();
											
											} else if($type=='Catecory Wise'){
											$result_sales = $db->prepare("SELECT * FROM sales_invoice_prdct_detail  WHERE sales_invodate >= '$startdate' AND sales_invodate <= '$enddate' AND status=0 AND company_tkn='$user_company' GROUP BY catname,sales_invodate");	
											$result_sales->execute();

											} else if($type == 'Subcatecory Wise'){
											$result_sales = $db->prepare("SELECT * FROM sales_invoice_prdct_detail  WHERE sales_invodate >= '$startdate' AND sales_invodate <= '$enddate' AND status=0 AND company_tkn='$user_company' GROUP BY subcat,sales_invodate");	
											$result_sales->execute();
											}
											$sl = 0;
											for ($i=0; $rows_sales  = $result_sales ->fetch(); $i++){
											if($type=='Catecory Wise') {
											$catname = $rows_sales['catname'];  $salesdate=$rows_sales['sales_invodate']; 
										    $resultret = $db->prepare("SELECT  COALESCE(SUM(amount), 0) AS catamount FROM sales_invoice_prdct_detail where catname='$catname' AND sales_invodate='$salesdate' AND company_tkn='$user_company' ");
											$resultret->execute();
											for($i=0; $rowrets = $resultret->fetch(); $i++){  
											$catamount=$rowrets['catamount'];}
											
											 $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS gst_amttot FROM sales_invoice_prdct_detail where catname='$catname' AND sales_invodate='$salesdate' AND company_tkn='$user_company'");
											$resultret->execute();
											for($i=0; $rowrets = $resultret->fetch(); $i++){  
											$gst_amttot=$rowrets['gst_amttot'];} 
											
											/* $resultret = $db->prepare("SELECT  COALESCE(SUM(qty), 0) AS qtytotal FROM sales_invoice_prdct_detail where catname='$catname'");
											$resultret->execute();
											for($i=0; $rowrets = $resultret->fetch(); $i++){  
											$qtytotal=$rowrets['qtytotal'];}*/
										    }
											if($type == 'Subcatecory Wise'){
											$subcat = $rows_sales['subcat'];  $salesdate=$rows_sales['sales_invodate']; 
											
										    $resultret = $db->prepare("SELECT  COALESCE(SUM(amount), 0) AS catamount FROM sales_invoice_prdct_detail where subcat='$subcat' AND sales_invodate='$salesdate' AND company_tkn='$user_company'");
											$resultret->execute();
											for($i=0; $rowrets = $resultret->fetch(); $i++){  
											$catamount=$rowrets['catamount'];}
											
											 $resultret = $db->prepare("SELECT  COALESCE(SUM(gst_amt), 0) AS gst_amttot FROM sales_invoice_prdct_detail where subcat='$subcat'  AND sales_invodate='$salesdate' AND company_tkn='$user_company'");
											$resultret->execute();
											for($i=0; $rowrets = $resultret->fetch(); $i++){  
											$gst_amttot=$rowrets['gst_amttot'];}
											}
											
										    if($type=='Tax Wise' || $type=='Customer Wise'){
											$billid = $rows_sales['sbill_no']; $status = $rows_sales['status'];  
											$salesdate=$rows_sales['sales_invodate']; 
											$tax=$rows_sales['tax_tot']; $cus_name=$rows_sales['cus_name'];  $grand_tot=$rows_sales['grand_tot']; $bill_type_sales=$rows_sales['bill_type'];  
											
											if($bill_type_sales=='pos'){ $decsamt=$rows_sales['disc'];} else {
										    $result_disc = $db->prepare("SELECT * FROM cash_invoice_recpt_details  WHERE receipt_no='$billid' AND company_tkn='$user_company'");
											$result_disc->execute();
											for ($i=0; $rows_disc  = $result_disc ->fetch(); $i++){
											$bill_no = $rows_disc['bill_no']; $decs = $rows_disc['decs']; }
											$result = $db->prepare("SELECT * FROM cash_invoice_recpt_details WHERE bill_no = '$bill_no' AND bill_type='sales' AND company_tkn='$user_company'");
											$result->execute();	
											$rowc = $result->rowcount();
											if($rowc==1){$decsamt=$decs;} else {$decsamt=$decs/$rowc;} }}
											?>
										<tr>
													<td><?php echo ++$sl; ?></td>
													<td><?php echo date('d-m-Y', strtotime( $salesdate)); ?></td>
													<?php if($type == 'Customer Wise' || $type=='Tax Wise' ) { ?><td><?php echo $billid; ?></td><?php } ?>
													<?php if($type == 'Customer Wise') { ?><td><?php echo $cus_name; ?></td><?php } else if($type == 'Catecory Wise') { ?><td><?php echo $catname; ?></td><?php } else if($type == 'Subcatecory Wise'){?><td><?php echo $subcat; ?></td><?php } ?>
											        <?php if($type=='Tax Wise') { ?> <td><?php echo $tax/2; ?></td><?php } ?>
											        <?php if($type=='Tax Wise') { ?><td><?php echo $tax/2; ?></td><?php } ?>
												    <?php /* if($type=='Catecory Wise') { ?> <td><?php echo $qtytotal; ?></td><?php } */?>
													<?php if($type=='Catecory Wise' || $type == 'Subcatecory Wise') { ?> <td><?php echo $gst_amttot; ?></td> <td><?php echo $catamount; ?></td><?php } ?>
													<?php if($type == 'Customer Wise') { ?><td><?php echo $tax;?></td><td><?php echo $grand_tot;?></td><td><?php echo number_format($decsamt,2);?></td><td><?php echo number_format($grand_tot - $decsamt) ;?></td><?php } ?>
													
													
											</tr>
											<?php 	}  } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right-sidebar">
					<div class="slimscrollright">
						<div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
									<div class="r-panel-body">
										<ul id="themecolors" class="m-t-20">
											<li><b>With Light sidebar</b>
											</li>
											<li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a>
											</li>
											<li class="d-block m-t-30"><b>With Dark sidebar</b>
											</li>
											<li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a>
											</li>
											<li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a>
											</li>
										</ul>
										
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
				<script src="js/mask.init.js"></script>
				<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
				<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
				<script src="js/perfect-scrollbar.jquery.min.js"></script>
				<script src="js/waves.js"></script>
				<script src="js/sidebarmenu.js"></script>
				<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
				<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
				<script src="js/custom.min.js"></script>
				<script src="assets/plugins/datatables/datatables.min.js"></script>
				<script src="assets/table/js/dataTables.buttons.min.js"></script>
				<script src="assets/table/js/buttons.flash.min.js"></script>
				<script src="assets/table/js/jszip.min.js"></script>
				<script src="assets/table/js/pdfmake.min.js"></script>
				<script src="assets/table/js/vfs_fonts.js"></script>
				<script src="assets/table/js/buttons.html5.min.js"></script>
				<script src="assets/table/js/buttons.print.min.js"></script>
				<?php include ('include/disable_fn.php'); ?>
				<script>
				$( '#example23' ).DataTable( {
					dom: 'Bfrtip',
					buttons: [
						'copy', 'csv', 'excel', 'pdf', 'print'
					]
				} );
				var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
				</script>
			<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>