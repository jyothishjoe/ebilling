<?php
include( 'include/auth.php');
include( 'db-connect/db.php');
include( 'include/today.php');
$token = $_GET[ 'edit' ];
$result_ledger = $db->prepare( "SELECT * FROM account_ledger  WHERE ledger_token = '$token'" );
$result_ledger->execute();
$rows_ledger = $result_ledger->fetch();
?>
<style>
#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 30px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>
<div id="custom-content" class="col-md-6 no-padding" style="margin: 50px auto; overflow: hidden;  background-color: #f2f2f2;">
	<h3 class="text-center">Edit Ledger</h3>
	<form autocomplete="off" method="post" action="" enctype="multipart/form-data" id='insert_form' class="forms">
		<div class="form-row">
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Ledger Name</label>
				<input type="text" class="form-control" id="ledger" name="ledger"  placeholder="Ledger Name" value="<?php echo $rows_ledger['ledger_name']; ?>">
				<input type="hidden" class="form-control" id="token" name="token" value="<?php echo $token; ?>" readonly>
				<center>
					<div id="uname_response" class="response"></div>
				</center>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Account Group</label>
				<div class="col-12">
					<select class="form-control " id="accname" name="accname" style="width: 100%; height:36px;">
						<?php		
						$result_acc = $db->prepare("SELECT * FROM accountgroup a left join account_ledger b on a.name=b.account_group WHERE b.ledger_token = '$token'" );
						$result_acc->execute();
						 $rows_acc = $result_acc->fetch(); 
							$accgrp = $rows_acc[ 'name' ];
							?>
						<option value="<?php echo $accgrp; ?>"><?php echo $accgrp; ?></option>
						<?php $result_acc1 = $db->prepare("SELECT * FROM accountgroup " );
						$result_acc1->execute();
						for ( $i = 0; $rows_acc1= $result_acc1->fetch(); $i++ ) {
							$accgrp1 = $rows_acc1[ 'name' ];
							?>
							<option value="<?php echo $accgrp1; ?>"><?php echo $accgrp1; ?></option>
						<?php } ?>
					</select>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">GSTIN</label>
				<input type="text" class="form-control" id="gstin" name="gstin" placeholder="GSTIN" value="<?php echo $rows_ledger['gstin']; ?>">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">PAN No</label>
				<input type="text" class="form-control" id="pan" name="pan"  placeholder="Pan No" value="<?php echo $rows_ledger['pan']; ?>">
				<input type="hidden" class="form-control" id="grouphead" name="grouphead" value="<?php echo $rows_ledger['group_head']; ?>"  placeholder="Pan No">
				<input type="hidden" class="form-control" id="acc_head" name="acc_head" value="<?php echo $rows_ledger['acc_head']; ?>"  placeholder="Pan No">
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Opening Balance</label>
				<input type="text" class="form-control" id="balance" name="balance" value="<?php echo $rows_ledger['balance']; ?>" placeholder="Pan No" >
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Dr/Cr</label>
				<select class="form-control" name="dr" id="dr">
				<option value="<?php echo $rows_ledger['trans']; ?>"><?php echo $rows_ledger['trans']; ?></option>
					<option value="Dr">Dr</option>
					<option value="Cr">Cr</option>
				</select>
			</div>
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Description</label>
				<textarea class="form-control" id="descr" name="descr"  placeholder="Description" required><?php echo $rows_ledger['descr']; ?></textarea>
			</div>
		</div>
		<div class="text-right" style="padding-bottom: 12px;">
			<a href="javascript: save_customer()" id="submit" class="btn btn-sm  btn-info">Submit</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close">CANCEL</button>
		</div>
	</form>

<script>
	$( '#accname' ).change( function () {
		var accname = $( "#accname" ).val();
		$.ajax( {
			type: 'POST',
			url: 'accounts/autosearch/grouphead.php',
			data: 'accname=' + accname,
			dataType: "JSON",
			success: function ( data ) {
				$( '#grouphead' ).val( data.value );
				$( '#acc_head' ).val( data.acc );
				
			}
		} );
	} );
</script>
<script>
	$( "#ledger" ).keyup( function (){
		var name = $( "#ledger" ).val().trim();
		if ( name != '' ) {
			$( "#uname_response" ).show();
			$.ajax( {
				url: 'vendor-action/vendor_exist/vendor_name.php',
				type: 'post',
				data: {
					name: name
				},
				success: function ( response ){
					if ( response > 0 ) {
						$( "#uname_response" ).html( "<span class='not-exists' style='color : red;'><strong>* Already Exist.</strong></span>" );
						$( "#submit" ).hide();
					} else {
						$( "#uname_response" ).html( "<span class='exists' style='color : green;'><strong>Available.</strong></span>" );
						$( "#submit" ).show();
					}
				}
			} );
		} else {
			$( "#uname_response" ).hide();
		}
	} );
	$( '#close_fbx' ).on( 'click', function () {
		parent.jQuery.magnificPopup.close();
	} );


	
	function save_customer() {
		var accname = $( "#accname" ).val();
		var ledger = $( "#ledger" ).val();
		var gstin = $( "#gstin" ).val();
		var pan = $( "#pan" ).val();
		var dr = $( "#dr" ).val();
		var balance = $( "#balance" ).val();
		var descr = $( "#descr" ).val();
		var grouphead = $( "#grouphead" ).val();
		var acchead= $( '#acc_head' ).val();
        var token= $( '#token' ).val();
		if ( $( "#accname" ).val() == "" || $( "#ledger" ).val() == "" ) {
			$.toast( {
				heading: 'Fill all required fields.',
				text: '',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 4500
			});
		} else {
			$.ajax( {
				type: 'POST',
				url: "accounts/edit_ledger.php",
				data: "accname=" + accname + "&ledger=" + ledger + "&gstin=" + gstin + "&pan=" + pan + "&balance=" + balance + "&dr=" + dr + "&descr=" + descr + "&token=" + token + "&grouphead=" + grouphead + "&acchead=" + acchead,
				success: function ( r ) {
					$( "#respond" ).html( r );
				}
			} );
			
			$.toast( {
				heading: 'Added Succeccfully.',
				text: '',
				position: 'top-right',
				loaderBg: '#1FDE13',
				icon: 'success',
				hideAfter: 4500
			} );
			location.reload();
			//document.getElementById( "insert_form" ).reset();
			return false;
		}
	}
</script>