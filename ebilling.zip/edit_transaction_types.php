<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$token = $_GET[ 'edit' ];
$result_trans_type = $db->prepare( "SELECT * FROM transaction_types  WHERE tax_token = '$token'" );
$result_trans_type->execute();
$rows_trans_type = $result_trans_type->fetch();
?>
<style>

fieldset {
	margin-top:17px;
	border: 1px solid #999;
	font-size:12px;
	padding:0px 10px;
}
legend {
	margin-left:10px;
	width: 95px;
	font-size:12px; padding-left:7px;
}
.container {
	display: inline;
	position: relative;
	padding-left: 20px;
	margin-bottom: 12px;
	cursor: pointer;
	font-size: 12px;
	bottom:5px;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	cursor: pointer;
}
.checkmark {
	position: absolute;
	top: 0;
	left: 0;
	height: 15px;
	width: 15px;
	border:1px solid #666;
	border-radius: 50%;
}
.container input:checked ~ .checkmark {
 background-color: #2196F3;
}
.checkmark:after {
	content: "";
	position: absolute;
	display: none;
}
.container input:checked ~ .checkmark:after {
 display: block;
}
.container .checkmark:after {
	top: 3px;
	left: 3px;
	width: 7px;
	height: 7px;
	border-radius: 50%;
	background: white;
}
</style>
<div id="custom-content" class="col-md-4 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #ffffff;">
	<h3 class="text-center">Edit Transaction Types</h3>
	<form autocomplete="off" method="post" action="" id="insert_form" enctype="multipart/form-data" class="forms">
		<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Transaction Name</label>
				<input type="text" class="form-control" id="trans_name" name="trans_name" value="<?php echo $rows_trans_type['trans_name']; ?>" placeholder="Transaction Name">
				<input type="hidden" class="form-control" id="userid" name="userid" value="<?php echo $userid; ?>">
				<input type="hidden" class="form-control" id="token" name="token" value="<?php echo $token; ?>">
			</div>
			</div>
			<div class="form-row">
			<div class="col-md-12 col-sm-6 col-xs-12 mb-3">
				<label for="" class="control-label">Transaction Code</label>
				<input type="text" class="form-control" id="trans_code" name="trans_code" value="<?php echo $rows_trans_type['trans_code']; ?>" placeholder="Transaction Code">
	    	</div>
	    	</div>
		<div class="text-right" style="margin-bottom: 12px;">
			<a href="javascript: save_customer()" class="btn btn-sm  btn-info" style="margin-top: 15px;">Save</a>
			<button type="button" id="close_fbx" class="btn btn-sm btn-danger " style="margin-top: 15px;">Cancel</button>
		</div>
	</form>
	<script>
		$('#close_fbx').on('click', function (){
			parent.jQuery.fancybox.close();
		});
		function save_customer() {
			var trans_name = $("#trans_name").val();
			var trans_code = $("#trans_code").val();
			var userid = $("#userid").val();
			var token = $("#token").val();
			
			if ($("#trans_code").val() == ""){
			$.toast( {heading: 'Fields Are Required.',text: '',position: 'top-right',loaderBg: '#ff6849',icon: 'error',hideAfter: 4500} );
			}else{
				$.ajax({
					type: 'POST',
					url: "accounts/edit_trans_type.php",
					data: "trans_name=" + trans_name + "&trans_code=" + trans_code + "&userid=" + userid + "&token=" + token ,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				document.getElementById( "insert_form" ).reset();
				//parent.jQuery.fancybox.close();
				window.location('trans_type_list.php');
				$.toast( {heading: 'Updated Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 4500} );
				return false;
			}
		}
	</script>