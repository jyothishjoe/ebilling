<?php
include ('include/auth.php');
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
$userid = $_SESSION['SESS_USERID_AS'];
$sbill_no = $_GET[ 'bill' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
$result_user_company = $db->prepare("SELECT * FROM company WHERE c_token = '$user_company'");
$result_user_company->execute();	
$rows_user_company = $result_user_company->fetch(); 
$logo=$rows_user_company['c_logo'];
$addres=$rows_user_company["c_shopaddress"];
$previous = "javascript:history.go(-1)";
if ( isset( $_SERVER[ 'HTTP_REFERER' ] ) ) {
	$previous = $_SERVER[ 'HTTP_REFERER' ];
}
?>
<html>
<title>Sales Order Print</title>
<head>
	<script src="js/auto_js/jquery-3.2.1.min.js"></script>
	<style>
		table td {
			height: 15px;
		}
		
		@media print {
			.btn {
				display: none;
			}
		}
		.hr {
			border: none;
			border-top: 1px solid black;
			margin-top: 10px;
		}
	</style>
	<?php include("include/print_size.php");?>
</head>
<body>
<div class="col-md-12" style="padding-top: 18px;">
		<a href="<?php echo $previous; ?>" </a><button type="button" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:left; margin-right: 25px; margin-top: 10px;"><i class="fa fa-backward"></i> Back</button>
		</a>
		<button type="button" onClick="window.location.reload()" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:right; margin-right: 25px; margin-top: 10px;"><i class="fa fa-print"></i> Print</button>
</div>
<?php
$result = $db->prepare( "SELECT * FROM sales_order_invoice where bill_no='$sbill_no'" );
$result->execute();
$row_count = $result->rowcount();
for ( $i = 0; $rows = $result->fetch(); $i++ ){
$order_invno = $rows[ "order_invno" ];
$datetym = $rows[ "datetym" ];
$cus_name = $rows[ "cus_name" ];
$cus_tkn = $rows[ "cus_tkn" ]; $tax_tot=$rows["tax_tot"];  $cess_total=$rows["o_tax_total"];}
$result1 = $db->prepare( "SELECT * FROM customer where acco_tkn='$cus_tkn'" );
		$result1->execute();
		$row_count1 = $result1->rowcount();
		$rows_user = $result1->fetch();
		$cus_address = $rows_user['addres'];
?>

  <div class="printwidth">
	  <div class="actual_printwidth">
		<table style="width:100%;">
			<thead>
				<tr>
					<th colspan="5" align="center">
						<h2>SALES ORDER</h2>
					</th>
				</tr>
			</thead>
			<tr>
				<th colspan="3" align="left">
					<p>Name:
						<?php if($row_count1 > 0 ){ echo ucwords($cus_name); } ?>
					</p>
					<p>Address:
						<?php if($row_count1 > 0 ){ echo ucwords($cus_address); } ?>
					</p>
				</th>
				<th colspan="2" align="right">
					<p>Order No:
						<?php echo strtoupper($sbill_no);?>
					</p>
					<p>Date:
						<?php echo $datetym;?>/
						<?php echo $current_time;?>
					</p>
				</th>
			</tr>
    
    <?php if( $printer_width == 'a4' || $printer_width == 'b5' || $printer_width == 'c6'  || $printer_width == 'a5' ||  $printer_width == 'b6' || $printer_width == 'a6') { ?>
		<tr class="top-border bottom-border">
				<th align="left" width="10%">
					<p>S.N</p>
				</th>
				<th align="left" width="40%">
					<p>Description Of Goods</p>
				</th>
				<th align="right" width="15%">
					<p>Qty</p>
				</th>
				<th align="right" width="15%">
					<p>Rate</p>
				</th>
				<th align="right" width="20%">
					<p>Amount</p>
				</th>
			</tr>
      
      <tbody >
        <?php      
				 $result= $db->prepare("SELECT * FROM sales_order_prdct_details where order_invno ='$order_invno'");
				 $result->execute();
				 for($e=0; $rows= $result->fetch(); $e++){
					$prdct_tkn = $rows['prdct_tkn'];
					$qty = $rows['qty'];
					$rate = $rows['rate'];
					$sales_tax = $rows['sales_tax'];
					$gst_amt = $rows['gst_amt'];
					$pr_hsn = $rows['pr_hsn'];
					$mrp = $rows['mrp'];
					$prdct_name = $rows['prdct_name'];
					$amount = $rows['amount'];
					$grand_tot = $rows['grand_tot'];
					$units = $rows['units'];
					  $gstcess_amt = $rows['o_tax_amt'];
					  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_order_otax_detail where prdct_tkn='$prdct_tkn' AND order_invno ='$order_invno'");
					  $resulotax->execute();
					  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
					  $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr>
		  <td width="10%"><p><?php echo $e+1;?></p></td>
          <td width="40%" align="left"><p><?php echo ucfirst($prdct_name); ?>-[<?php echo $pr_hsn; ?>]</p> </td>
          <td align="right" width="15%"><p><?php echo $qty;?></p></td>
          <td align="right" width="15%"><p><?php echo $rate;?></p></td>
          <td align="right" width="20%"><p><?php echo $amount;?></p></td>
        </tr>
        <?php } ?>
    	 <tr class="top-border bottom-border">
				<th colspan="4" align="right">
					<p>Grand Total</p>
				</th>
				<th align="right" colspan="1">
					<p><?php echo  $grand_tot;?></p>
				</th>
			</tr>
      </tbody>
    </table>
<?php } else if( $printer_width == 'b7' || $printer_width == '80mm' || $printer_width == 'a7'  || $printer_width == 'b8') { ?>

    	<tr style="text-align:center;" class="hr">
		<th rowspan="2"  style="text-align:left !important;"><strong>S.N</strong></th>
		<th rowspan="2"  style="text-align:left !important;"><strong>Description Of Goods</strong></th>
		<th rowspan="2"> <strong>Qty</strong></th>
		<th rowspan="2"> <strong>Rate</strong></th>
		<th rowspan="2"> <strong>Amount</strong></th>
		</tr>
      
      <tbody  class="hr">
        <?php      
				 $result= $db->prepare("SELECT * FROM sales_order_prdct_details where order_invno ='$order_invno'");
				 $result->execute();
				 for($e=0; $rows= $result->fetch(); $e++){
					$prdct_tkn = $rows['prdct_tkn'];
					$qty = $rows['qty'];
					$rate = $rows['rate'];
					$sales_tax = $rows['sales_tax'];
					$gst_amt = $rows['gst_amt'];
					$pr_hsn = $rows['pr_hsn'];
					$mrp = $rows['mrp'];
					$prdct_name = $rows['prdct_name'];
					$amount = $rows['amount'];
					$grand_tot = $rows['grand_tot'];
					$units = $rows['units'];
					  $gstcess_amt = $rows['o_tax_amt'];
					  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_order_otax_detail where prdct_tkn='$prdct_tkn' AND order_invno ='$order_invno'");
					  $resulotax->execute();
					  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
					  $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr>
		  <td align="center"><?php echo $prdct_tkn;?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    
      </tbody>
      <tfoot>
	   <tr>
		   <th></th><th colspan="2">Grand Total </th><th></th><th colspan="3"><center><b><?php echo  $grand_tot;?></b></center></th>
      </tr>
	 </tfoot>
    </table>
  <?php } else if ( $printer_width == 'a8' || $printer_width == 'b9') { ?>
  <tr style="text-align:center;" class="hr">
		<th rowspan="2"  style="text-align:left !important;"><strong>S.N</strong></th>
		<th rowspan="2"  style="text-align:left !important;"><strong>Description Of Goods</strong></th>
		<th rowspan="2"> <strong>Qty</strong></th>
		<th rowspan="2"> <strong>Rate</strong></th>
		<th rowspan="2"> <strong>Amount</strong></th>
		</tr>
      
      <tbody  class="hr">
        <?php      
				 $result= $db->prepare("SELECT * FROM sales_order_prdct_details where order_invno ='$order_invno'");
				 $result->execute();
				 for($e=0; $rows= $result->fetch(); $e++){
					$prdct_tkn = $rows['prdct_tkn'];
					$qty = $rows['qty'];
					$rate = $rows['rate'];
					$sales_tax = $rows['sales_tax'];
					$gst_amt = $rows['gst_amt'];
					$pr_hsn = $rows['pr_hsn'];
					$mrp = $rows['mrp'];
					$prdct_name = $rows['prdct_name'];
					$amount = $rows['amount'];
					$grand_tot = $rows['grand_tot'];
					$units = $rows['units'];
					  $gstcess_amt = $rows['o_tax_amt'];
					  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_order_otax_detail where prdct_tkn='$prdct_tkn' AND order_invno ='$order_invno'");
					  $resulotax->execute();
					  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
					  $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr>
		  <td align="center"><?php echo $prdct_tkn;?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    
      </tbody>
      <tfoot>
	   <tr>
		   <th></th><th colspan="2">Grand Total </th><th></th><th colspan="3"><center><b><?php echo  $grand_tot;?></b></center></th>
      </tr>
	 </tfoot>
    </table>
  <?php } else { ?>
  <tr style="text-align:center;" class="hr">
		<th rowspan="2"  style="text-align:left !important;"><strong>S.N</strong></th>
		<th rowspan="2"  style="text-align:left !important;"><strong>Description Of Goods</strong></th>
		<th rowspan="2"> <strong>Qty</strong></th>
		<th rowspan="2"> <strong>Rate</strong></th>
		<th rowspan="2"> <strong>Amount</strong></th>
		</tr>
      
      <tbody  class="hr">
        <?php      
				 $result= $db->prepare("SELECT * FROM sales_order_prdct_details where order_invno ='$order_invno'");
				 $result->execute();
				 for($e=0; $rows= $result->fetch(); $e++){
					$prdct_tkn = $rows['prdct_tkn'];
					$qty = $rows['qty'];
					$rate = $rows['rate'];
					$sales_tax = $rows['sales_tax'];
					$gst_amt = $rows['gst_amt'];
					$pr_hsn = $rows['pr_hsn'];
					$mrp = $rows['mrp'];
					$prdct_name = $rows['prdct_name'];
					$amount = $rows['amount'];
					$grand_tot = $rows['grand_tot'];
					$units = $rows['units'];
					  $gstcess_amt = $rows['o_tax_amt'];
					  $resulotax = $db->prepare("SELECT  COALESCE(SUM(o_tax_rate), 0) AS otaxrate FROM sales_order_otax_detail where prdct_tkn='$prdct_tkn' AND order_invno ='$order_invno'");
					  $resulotax->execute();
					  for($i=0; $rowotax = $resulotax->fetch(); $i++){  
					  $otaxrate=$rowotax['otaxrate'];}
              ?>
            
        <tr>
		  <td align="center"><?php echo $prdct_tkn;?></td>
          <td align="left"><?php echo ucfirst($prdct_name); ?>
            -[<?php echo $pr_hsn; ?>] </td>
          <td align="center"><?php echo $qty;?></td>
          <td align="center"><?php echo $rate;?></td>
          <td align="center"><?php echo $amount;?></td>
        </tr>
        <?php } ?>
    
      </tbody>
      <tfoot>
	   <tr>
		   <th></th><th colspan="2">Grand Total </th><th></th><th colspan="3"><center><b><?php echo  $grand_tot;?></b></center></th>
      </tr>
	 </tfoot>
    </table>
  <?php } ?>
  </div>
</div>
<script>
		$(document).ready(function () {

		var headstr = "<html><head><title></title></head><body>";
		var footstr = "</body>";

		var oldstr = document.body.innerHTML;
		document.body.innerHTML = headstr+footstr;
		window.print();
		document.body.innerHTML = oldstr;	

		});
		window.onafterprint = function() {
		history.go(-1);
		};
	
	</script>
</body>
</html>