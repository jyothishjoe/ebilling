<?php include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( 'db-connect/db.php' );
$results = $db->prepare("select * from  admin_user where  user_tkn = '$userid'");
$results->execute();
for($i=0; $rows = $results->fetch(); $i++)
{ $user_type_tkn=$rows['user_type']; } 
$results_user = $db->prepare("select * from  user_type_second where user_tkn = '$user_type_tkn' ");
$results_user->execute();
for($i=0; $row_user = $results_user->fetch(); $i++)
{ $update_password=$row_user['update_password']; $date_picker=$row_user['date_picker']; $printer=$row_user['printer']; $financial_year=$row_user['financial_year']; $setting_add_gst=$row_user['setting_add_gst']; $setting_update_gst=$row_user['setting_update_gst']; } 

$results_user_three = $db->prepare("select * from  user_type_three where user_tkn = '$user_type_tkn' ");
$results_user_three->execute();
for($i=0; $row_user_three = $results_user_three->fetch(); $i++)
{ $setting_add_othertax=$row_user_three['setting_add_othertax'];  $setting_update_othertax=$row_user_three['setting_update_othertax']; $add_season=$row_user_three['add_season']; $update_season=$row_user_three['update_season']; $add_user_type=$row_user_three['add_user_type']; $update_user_type=$row_user_three['update_user_type']; $add_user=$row_user_three['add_user']; $dateset=$row_user_three['dateset']; $backup=$row_user_three['backup'];
$notification=$row_user_three['show_hide_notific'];
$company_show=$row_user_three['company'];
 
} 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
	<title>Settings Home</title>
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css"/>
	<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
	<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
	<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css"/>
	<link href="css/style.css" rel="stylesheet">
	<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
	<link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css">
	<script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="assets/fancybox/jquery.fancybox.pack.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>
	<script src="assets/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
	<link rel="stylesheet" href="assets/Magnific-Popup-master/dist/magnific-popup.css">
	<script src="js/auto_js/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
	
</head>
<style>
.totalprice {
	font-size: 20px !important;
}

fieldset {
	margin-top:17px;
	border: 1px solid #999;
	font-size:12px;
	padding:0px 10px;
}
legend {
	margin-left:10px;
	width: 95px;
	font-size:12px; padding-left:7px;
}
.container {
	display: inline;
	position: relative;
	padding-left: 20px;
	margin-bottom: 12px;
	cursor: pointer;
	font-size: 12px;
	bottom:5px;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	cursor: pointer;
}
.checkmark {
	position: absolute;
	top: 0;
	left: 0;
	height: 15px;
	width: 15px;
	border:1px solid #666;
	border-radius: 50%;
}
.container input:checked ~ .checkmark {
 background-color: #2196F3;
}
.checkmark:after {
	content: "";
	position: absolute;
	display: none;
}
.container input:checked ~ .checkmark:after {
 display: block;
}
.container .checkmark:after {
	top: 3px;
	left: 3px;
	width: 7px;
	height: 7px;
	border-radius: 50%;
	background: white;
}
</style>
<body class="fix-header fix-sidebar card-no-border">
<div class="preloader" id="load">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label">Loading..</p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav_home.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h4 class="text-themecolor"> Settings</h4>
        </div>
        <div class="col-md-7 align-self-center" style="z-index: 9 !important;">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a oncontextmenu="return false;" href="javascript:void(0)">Home</a> </li>
            <li class="breadcrumb-item active">Settings</li>
          </ol>
        </div>
        <div class="">
          <!--<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-palette text-white"></i></button>-->
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
				
              <form class="needs-validation" novalidate>
                <div class="form-row">
				<?php if($update_password==0) { ?>
                <div class="col-lg-3">
                  <div class="card bg- text-white" style="background-color: #5795C4">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Privacy</h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="update-password.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Update Password</a> </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($date_picker==0) { ?>
                <div class="col-lg-3">
                  <div class="card bg- text-white" style="background-color: #e07281">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">More</h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="datepick-popup.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Date Picker</a> 
						  <a class="right-side-toggle waves-effect waves-light btn btn-rounded btn-outline btn-light m-t-10 font-14">Theme</a>
						  </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
					<?php } if($printer==0) { ?>
                 <div class="col-lg-3">
                  <div class="card bg- text-white" style="background-color: #0A4D80">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Printer</h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="printersize-popup.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">Printer</a> 
						  <?php 
							$result =$db->prepare("SELECT * FROM  printer_width WHERE addby='$userid' AND company_tkn='$user_company' ORDER BY id DESC LIMIT 1");
							$result->execute();
							$rows=$result->fetch();
							$printer_width=$rows['printer_width'];
							if( $printer_width=='a4'){$printerlabel='21cm';} else if( $printer_width=='b5') {$printerlabel='17.6cm';}  else if( $printer_width=='c6') {$printerlabel='16.2cm';}  else if( $printer_width=='a5') {$printerlabel='14.8cm';}  else if( $printer_width=='b6') {$printerlabel='12.5cm';}  else if( $printer_width=='a6') {$printerlabel='10.5cm';}  else if( $printer_width=='b7') {$printerlabel='8.8cm';}  else if( $printer_width=='80mm') {$printerlabel='8cm';}  else if( $printer_width=='a7') {$printerlabel='7.4cm';}  else if( $printer_width=='b8') {$printerlabel='6.2cm';}  else if( $printer_width=='a8') {$printerlabel='5.2cm';}  else if( $printer_width=='b9') {$printerlabel='4.4cm';}  else if( $printer_width=='a9') {$printerlabel='3.7cm';}  else if( $printer_width=='b10') {$printerlabel='3.1cm';}  else if( $printer_width=='a10') {$printerlabel='2.6cm';} else if( $printer_width=='') {$printerlabel='--Select--';} 
						?>
						  <div   class="btn btn-rounded btn-outline btn-light m-t-10 font-14" style="cursor: none !important; font-size:12px !important;">Paper Width- <?php echo $printerlabel;?> </div>
						  </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($setting_add_gst==0) { ?>
                <div class="col-lg-3">
                  <div class="card bg- text-white" style="background-color: #873839">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Tax</h4>
                          <h6 class="text-white"></h6>
                         <a oncontextmenu="return false;" href="add-gst.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax ">GST</a><a oncontextmenu="return false;" href="gst-list.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">list</a>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div></div>
				<?php } if($setting_add_othertax==0) { ?>
				 <div class="col-lg-3">
                  <div class="card  bg-success text-white">
                    <div class="card-body">
                      <div class="d-flex" style="color: aliceblue;">
                        <div class="stats">
                          <h4 class="text-white">Other Tax</h4>
                          <h6 class="text-white"></h6>
                          <a oncontextmenu="return false;" href="add-tax.php" id="clic" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Other Tax</a><a oncontextmenu="return false;" href="othertax-list.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe"> list</a>
                           </div>
                        <div class="stats-icon text-right"></div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } if($add_season==0) { ?>
				 <div class="col-lg-3">
					<div class="card bg-primary text-white">
					  <div class="card-body">
					    <div class="d-flex">
						<div class="stats">
						<h4 class="text-white">Season</h4>
						<h6 class="text-white"></h6>
						<a oncontextmenu="return false;" href="create-season.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax"> Create Season</a>
						<a oncontextmenu="return false;" href="season-list.php"  class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">List</a>
						</div>
					<div class="stats-icon text-right ml-auto"></div>
					</div>
					</div>
					</div>
				</div>
					<?php } if($dateset==0) { ?>
             <!--<div class="col-lg-3">
					<div class="card bg-primary text-white">
					  <div class="card-body">
					    <div class="d-flex">
						<div class="stats">
						<h4 class="text-white">Date Set</h4>
						<h6 class="text-white"></h6>
						<a oncontextmenu="return false;" href="create-date.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Date Set</a>
						</div>
					<div class="stats-icon text-right ml-auto"></div>
					</div>
					</div>
					</div>
				</div>-->
				<?php }if($notification==0){ ?>
		 <div class="col-lg-3">
			<div class="card  text-white" style="background-color: #36AAA8" >
				<div class="card-body">
					<div class="d-flex">
						<div class="stats">
							<h4 class="text-white">Show/Hide Notification</h4>
							<h6 class="text-white"></h6>
							<a oncontextmenu="return false;" href="show-hide-notification.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">Change</a> 
						</div>
						<div class="stats-icon text-right ml-auto"></div>
					</div>
				</div>
			</div>
		</div>
		<?php } if($backup==0) { ?>
           <div class="col-lg-3">
			<div class="card  text-white" style="background-color: #5b7876" >
				<div class="card-body">
					<div class="d-flex">
						<div class="stats">
							<h4 class="text-white">Backup</h4>
							<h6 class="text-white"></h6>
							<a oncontextmenu="return false;" href="backup/dbbkup.php" id="backup" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">Backup</a>
						</div>
						<div class="stats-icon text-right ml-auto"></div>
					</div>
				</div>
			</div>
		</div>
		<?php } if($add_user==0 || $add_user_type==0) { ?>
		
		 <div class="col-lg-5">
			<div class="card  text-white" style="background-color: #36AAA8" >
				<div class="card-body">
					<div class="d-flex">
						<div class="stats">
							<h4 class="text-white">User</h4>
							<h6 class="text-white"></h6>
							<a oncontextmenu="return false;" href="user-type.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax">User Type</a> 
							<a oncontextmenu="return false;" href="add-user.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.ajax ">Add User</a>
							<a oncontextmenu="return false;" href="user-type-all.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">User Type list</a>
							<a oncontextmenu="return false;" href="user-all.php" class="btn btn-rounded btn-outline btn-light m-t-10 font-14 fancybox fancybox.iframe">User list</a>
						</div>
						<div class="stats-icon text-right ml-auto"></div>
					</div>
				</div>
			</div>
		</div>
		
		<?php }if($company_show == 0){ ?>
		 <div class="col-lg-3">
			<div class="card  text-white" style="background-color: #823AD1" >
				<div class="card-body">
					<div class="d-flex">
						<div class="stats">
							<h4 class="text-white">Create Company</h4>
							<h6 class="text-white"></h6>
							<a oncontextmenu="return false;" href="add-company.php" id='company' class="btn btn-rounded btn-outline btn-light m-t-10 font-14 simple-ajax-popup-align-top">Create Company</a>
							<a oncontextmenu="return false;" href="all-company.php" id='company_list' class="btn btn-rounded btn-outline btn-light m-t-10 font-14 ">List</a>
						</div>
						<div class="stats-icon text-right ml-auto"></div>
					</div>
				</div>
			</div>
		</div>
		<?php } ?>
              </form>
            </div>
            <div class="col-md-12">
              <div class="card" style="text-align: center;"> </div>
            </div>
          </div>
        </div>
      </div>
      <div class="right-sidebar">
        <div class="slimscrollright">
          <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
          <div class="r-panel-body">
            <ul id="themecolors" class="m-t-20">
              <li><b>With Light sidebar</b> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
              <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
              <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
            </ul>
            
          </div>
        </div>
      </div>
    </div></div></div>
    
  </div>
</div>
	<?php if(isset($_COOKIE['SC']) && $_COOKIE['SC'] == true){ ?> <script> $(document).ready(function(){
		$("#company_list").click();
		$.toast({
			heading: 'Company Created Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	});</script>
	<?php }else if(isset($_COOKIE['C']) && $_COOKIE['C'] == true){ ?>
	<script> $(document).ready(function(){
		$("#company_list").click();
		$.toast({
			heading: 'User already Assigned',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'error',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	}); </script>
	<?php }else if(isset($_COOKIE['CE']) && $_COOKIE['CE'] == true){ ?>
	<script> $(document).ready(function(){
		$("#company_list").click();
		$.toast({
			heading: 'Company Already Exist',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'error',hideAfter: 1500,hideMethod: 'fadeOut'
		});
	}); </script>
	<?php }else if(isset($_COOKIE['BCK']) && $_COOKIE['BCK'] == true){ ?>
	<script> $(document).ready(function(){
		$.toast({
			heading: 'Backup Successfull.',text: 'Backup Data Moved To Downloads.',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 2500,hideMethod: 'fadeOut'
		});
	}); </script>
	<?php } ?>
	
<script>

	 $( window ).keydown( function ( event ) {
			
			 if ( event.keyCode == 27 ) {
				event.preventDefault();
				//alert(index);
				parent.jQuery.fancybox.close(); 
			}
			 
		 });
	
	
			$(document).ready(function() {
				$('.simple-ajax-popup-align-top').magnificPopup({
					type: 'ajax',
					alignTop: false,
					closeOnBgClick: false,
					openDelay: 800,
					overflowY: 'scroll'
					 
				});
				$('.simple-ajax-popup').magnificPopup({
					type: 'ajax'
				});
			});
			$(document).ready(function() {
             
   $('.fancybox').fancybox({
 
    closeBtn    : false, // hide close button
    closeClick  : false, // prevents closing when clicking INSIDE fancybox
    helpers     : { 
        // prevents closing when clicking OUTSIDE fancybox
        overlay : {closeClick: false} 
    },
    keys : {
        // prevents closing when press ESC button
        close  : true
    }
   });
 
});
$('#close_fbx').on('click', function(){ parent.jQuery.fancybox.close(); });	
		</script>
		<script>	
		
	$(document).keyup(function(e){
	
	if(e.altKey && e.which == 83){ $('#load').show(); window.location.href='backup/dbbkup.php'; } $('#load').hide();
	//if(e.altKey && e.which == 56){ $("#add_modal").modal("show"); }
	/*{window.open('customer.php','myNewWinsr','width=620,height=800,toolbar=0,menubar=no,status=no,resizable=yes,location=no,directories=no');}*/
});
</script>
<script src="assets/plugins/popper/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script> 
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/inputmask/dist/min/jquery.inputmask.bundle.min.js"></script> 
<script src="js/mask.init.js"></script> 
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script> 
<script src="js/toastr.js"></script> 

<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script> 
<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="assets/plugins/dff/dff.js" type="text/javascript"></script> 
<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script> 
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<?php include ('include/disable_fn.php'); ?>
</body>
</html>