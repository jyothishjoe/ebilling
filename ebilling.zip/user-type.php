<?php
include( 'include/auth.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( 'db-connect/db.php' );
include( "php_fn/basic.php" );
include( "datetime_creation/datetime_creation.php" );

?>

<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<script src="assets/plugins/jquery/jquery.min.js"></script>
<div class="col-xs-12 no-padding" style=" overflow: hidden; padding-left:30px; width:600px;">
	<h3 class="text-center ">Add User Type</h3>
	<form class="" name="addbilldetails" method="post" action="" id="insert_form" enctype="multipart/form-data" autocomplete="off" >
		<div class="form-row">
			<div class="col-md-3 col-sm-6 col-xs-12   mb-3">
			<label  class="control-label ">User Type</label>
				<input type="text" name="user_type" id="user_type" placeholder="Enter user type">
			</div>
			</div>
			<label  class="control-label ">Privilege</label>
			
			
			<div class="col-md-12 col-sm-12 col-xs-12" style=" padding:10px;  margin-right:10px; ">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:15px; font-weight:600;" id="master_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:15px; font-weight:600;" id="master_hide" value="-">
			<input type="checkbox"  class="filled-inmast"  id="masterall" />
            <label for="masterall" style="color:#0A4D80;" >Master</label>
			<div style="padding-left:30px;" id="master">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:15px; font-weight:600;" id="product_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:15px; font-weight:600;" id="product_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="productall" />
            <label for="productall" style="font-size:15px;">Product</label>
			<div style="padding-left:55px;" id="product">
			<input type="checkbox" id="basic_checkbox_a1" class="filled-inmast master product" name="master_add_product"/>
            <label for="basic_checkbox_a1">Add Product</label><br>
			<input type="checkbox" id="basic_checkbox_a2" class="filled-inmast master product" name="master_update_product"/>
            <label for="basic_checkbox_a2">Product Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="customer_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="customer_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="customerall" />
            <label for="customerall">Customer</label>
			<div style="padding-left:55px;" id="customer">
			<input type="checkbox" id="basic_checkbox_a3" class="filled-inmast master customer" name="master_add_customer" />
            <label for="basic_checkbox_a3">Add Customer</label><br>
			<input type="checkbox" id="basic_checkbox_a4" class="filled-inmast master customer" name="master_update_customer" />
            <label for="basic_checkbox_a4">Customer Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="supplier_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="supplier_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="supplierall" />
            <label for="supplierall">Supplier</label>
			<div style="padding-left:55px;" id="supplier">
			<input type="checkbox" id="basic_checkbox_a5" class="filled-inmast master supplier" name="master_add_supplier" />
            <label for="basic_checkbox_a5">Add Supplier</label><br>
			<input type="checkbox" id="basic_checkbox_a6" class="filled-inmast master supplier" name="master_update_supplier" />
            <label for="basic_checkbox_a6">Supplier Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="ledger_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="ledger_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="ledgerall" />
            <label for="ledgerall">Ledger</label>
			<div style="padding-left:55px;" id="ledger">
			<input type="checkbox" id="basic_checkbox_a7" class="filled-inmast master ledger" name="master_add_ledger" />
            <label for="basic_checkbox_a7">Add Ledger</label><br>
			<input type="checkbox" id="basic_checkbox_a8" class="filled-inmast master ledger" name="master_update_ledger" />
            <label for="basic_checkbox_a8">Ledger Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="category_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="category_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="categoryall" />
            <label for="categoryall">Category</label>
			<div style="padding-left:55px;" id="category">
			<input type="checkbox" id="basic_checkbox_a9" class="filled-inmast master category" name="master_add_category" />
            <label for="basic_checkbox_a9">Add Category</label><br>
			<input type="checkbox" id="basic_checkbox_a10" class="filled-inmast master category" name="master_update_category" />
            <label for="basic_checkbox_a10">Category Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="subcategory_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="subcategory_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="subcategoryall" />
            <label for="subcategoryall">Sub Category</label>
			<div style="padding-left:55px;" id="subcategory">
			<input type="checkbox" id="basic_checkbox_a11" class="filled-inmast master subcategory" name="master_add_subcategory" />
            <label for="basic_checkbox_a11">Add Sub Category</label><br>
			<input type="checkbox" id="basic_checkbox_a12" class="filled-inmast master subcategory" name="master_update_subcategory" />
            <label for="basic_checkbox_a12">Sub Category Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="unit_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="unit_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="unitall" />
            <label for="unitall">Unit</label>
			<div style="padding-left:55px;" id="unit">
			<input type="checkbox" id="basic_checkbox_a13" class="filled-inmast master unit" name="master_add_unit" />
            <label for="basic_checkbox_a13">Add Unit</label><br>
			<input type="checkbox" id="basic_checkbox_a14" class="filled-inmast master unit" name="master_update_unit" />
            <label for="basic_checkbox_a14">Unit  Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="bank_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="bank_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="bankall" />
            <label for="bankall">Bank</label>
			<div style="padding-left:55px;" id="bank">
			<input type="checkbox" id="basic_checkbox_a15" class="filled-inmast master bank " name="master_add_bank" />
            <label for="basic_checkbox_a15">Add Bank</label><br>
			<input type="checkbox" id="basic_checkbox_a16" class="filled-inmast master bank" name="master_update_bank" />
            <label for="basic_checkbox_a16">Bank Update & Delete</label>
			</div>
			<div></div>
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="tax_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="tax_hide" value="-">
			<input type="checkbox"  class="filled-inmast master"  id="taxall" />
            <label for="taxall">Tax</label>
			<div style="padding-left:55px;" id="tax">
			<input type="checkbox" id="basic_checkbox_a17" class="filled-inmast master tax" name="master_add_gst" />
            <label for="basic_checkbox_a17">Add Gst</label><br>
			<input type="checkbox" id="basic_checkbox_a18" class="filled-inmast master tax" name="master_update_gst" />
            <label for="basic_checkbox_a18">Gst Update & Delete</label><br>
			<input type="checkbox" id="basic_checkbox_a17a" class="filled-inmast master tax" name="master_add_othertax" />
            <label for="basic_checkbox_a17a">Add Other Tax</label><br>
			<input type="checkbox" id="basic_checkbox_a18a" class="filled-inmast master tax" name="master_update_othertax" />
            <label for="basic_checkbox_a18a">Other Tax Update & Delete</label>
			</div>
			</div>
<!--purchase-->			
			<div></div>
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="purchase_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="purchase_hide" value="-">
			<input type="checkbox"  class="filled-inp"  id="purchaseall" />
            <label for="purchaseall" style="color:#0A4D80;" >Purchase</label>
			<div style="padding-left:30px;" id="purchase">
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="psupplier_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="psupplier_hide" value="-">
			<input type="checkbox"  class="filled-inp purchase"  id="psupplierall" />
            <label for="psupplierall">Supplier</label>
			<div style="padding-left:55px;" id="psupplier">
			<input type="checkbox" id="basic_checkbox_a19" class="filled-inp purchase psupplier" name="add_supplier" />
            <label for="basic_checkbox_a19">Add Supplier</label><br>
			<input type="checkbox" id="basic_checkbox_a20" class="filled-inp purchase psupplier" name="update_supplier" />
            <label for="basic_checkbox_a20">Supplier Update & Delete</label>
			</div>
			<div></div>
			
			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a21" class="filled-inp purchase" name="Purchase_invo" />
            <label for="basic_checkbox_a21">Purchase </label>
			<div></div>
			
			<input type="checkbox" id="basic_checkbox_a22" class="filled-inp purchase" name="Purchase_order_invo" />
            <label for="basic_checkbox_a22">Purchase Order </label>
			<div></div>
			
			<input type="checkbox" id="basic_checkbox_a23" class="filled-inp purchase" name="Purchase_rtn_invo" />
            <label for="basic_checkbox_a23">Purchase Return </label>
			</div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="purchase_report_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="purchase_report_hide" value="-">
			<input type="checkbox"  class="filled-inp purchase"  id="purchase_reportall" />
            <label for="purchase_reportall">Reports</label>
			<div style="padding-left:55px;" id="purchase_report">
			<input type="checkbox" id="basic_checkbox_a24" class="filled-inp purchase preport" name="purchas_rep" />
            <label for="basic_checkbox_a24">Purchase</label><br>
			<input type="checkbox" id="basic_checkbox_a25" class="filled-inp purchase preport" name="purchase_order_rep" />
            <label for="basic_checkbox_a25">Purchase Order</label><br>
			<input type="checkbox" id="basic_checkbox_a26" class="filled-inp  purchase preport" name="purchase_return_rep" />
            <label for="basic_checkbox_a26">Purchase Return</label>
			</div>
			<div></div>
			</div>
			<div></div>
		<!--sales-->	
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="sales_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="sales_hide" value="-">
			<input type="checkbox"  class="filled-ins"  id="salesall" />
            <label for="salesall" style="color:#0A4D80;" >Sales</label>
			<div style="padding-left:30px;" id="sales">

			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="scustomer_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="scustomer_hide" value="-">
			<input type="checkbox"  class="filled-ins sales"  id="scustomerall" />
            <label for="scustomerall">Customer</label>
			<div style="padding-left:55px;" id="scustomer">
			<input type="checkbox" id="basic_checkbox_a27" class="filled-ins sales scustomer" name="add_customer" />
            <label for="basic_checkbox_a27">Add Customer</label><br>
			<input type="checkbox" id="basic_checkbox_a27a" class="filled-ins sales scustomer" name="update_customer" />
            <label for="basic_checkbox_a27a">Customer Update & Delete</label>
			</div>
			<div></div>
			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a28" class="filled-ins sales" name="sales_order" />
            <label for="basic_checkbox_a28">Sales Order </label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a29" class="filled-ins sales" name="sales_invo" />
            <label for="basic_checkbox_a29">Sales Bill </label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a30" class="filled-ins sales" name="pos_invo" />
            <label for="basic_checkbox_a30">Pos </label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a31" class="filled-ins sales" name="estimate_invo" />
            <label for="basic_checkbox_a31">Estimate </label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a32" class="filled-ins sales" name="sales_ret_invo" />
            <label for="basic_checkbox_a32">Sales Return </label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a33" class="filled-ins sales" name="bill_cancel" />
            <label for="basic_checkbox_a33">Sales Bill Cancellation</label>
			<div></div>
			</div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="sales_report_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="sales_report_hide" value="-">
			<input type="checkbox"  class="filled-ins sales"  id="sales_reportall" />
            <label for="sales_reportall">Reports</label>
			<div style="padding-left:55px;" id="sales_report">
			<input type="checkbox" id="basic_checkbox_a34" class="filled-ins sales sales_report" name="sales_order_rept" />
            <label for="basic_checkbox_a34">Sales Order</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a35" class="filled-ins sales sales_report" name="sales_rept" />
            <label for="basic_checkbox_a35">Sales</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a36" class="filled-ins sales sales_report" name="sales_ret_rept" />
            <label for="basic_checkbox_a36">Sales Return</label>
			<div></div>
			</div>
			</div><div></div>
	<!--inventory-->		
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="inventory_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="inventory_hide" value="-">
			<input type="checkbox"  class="filled-inventory"  id="inventoryall" />
            <label for="inventoryall" style="color:#0A4D80;">Inventory</label>
			<div style="padding-left:35px;" id="inventory">
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invproduct_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invproduct_hide" value="-">
			<input type="checkbox"  class="filled-inventory inventory "  id="invproductall" />
            <label for="invproductall">Product</label>
			<div style="padding-left:55px;" id="invproduct">
			<input type="checkbox" id="basic_checkbox_a37" class="filled-inventory inventory iproduct" name="product" />
            <label for="basic_checkbox_a37">Add Product</label><br>
			<input type="checkbox" id="basic_checkbox_a38" class="filled-inventory inventory iproduct" name="product_update" />
            <label for="basic_checkbox_a38">Product Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invcategory_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invcategory_hide" value="-">
			<input type="checkbox"  class="filled-inventory inventory"  id="invcategoryall" />
            <label for="invcategoryall">Category</label>
			<div style="padding-left:55px;" id="invcategory">
			<input type="checkbox" id="basic_checkbox_a39" class="filled-inventory inventory icategory" name="category" />
            <label for="basic_checkbox_a39">Add Category</label><br>
			<input type="checkbox" id="basic_checkbox_a40" class="filled-inventory inventory icategory" name="category_update" />
            <label for="basic_checkbox_a40">Category Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invsubcategory_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invsubcategory_hide" value="-">
			<input type="checkbox"  class="filled-inventory inventory"  id="invsubcategoryall" />
            <label for="invsubcategoryall">Sub Category</label>
			<div style="padding-left:55px;" id="invsubcategory">
			<input type="checkbox" id="basic_checkbox_a41" class="filled-inventory inventory isubcategory" name="subcategory" />
            <label for="basic_checkbox_a41">Add Sub Category</label><br>
			<input type="checkbox" id="basic_checkbox_a42" class="filled-inventory inventory isubcategory" name="subcategory_update" />
            <label for="basic_checkbox_a42">Sub Category Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invunit_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="invunit_hide" value="-">
			<input type="checkbox"  class="filled-inventory inventory"  id="invunitall" />
            <label for="invunitall">Unit</label>
			<div style="padding-left:55px;" id="invunit">
			<input type="checkbox" id="basic_checkbox_a43" class="filled-inventory inventory iunit " name="unit" />
            <label for="basic_checkbox_a43">Add Unit</label><br>
			<input type="checkbox" id="basic_checkbox_a44" class="filled-inventory inventory  iunit" name="unit_update" />
            <label for="basic_checkbox_a44">Unit Update & Delete</label>
			</div>
			<div></div>
			
			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a45" class="filled-inventory inventory " name="pricing" />
            <label for="basic_checkbox_a45">Pricing</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="inv_report_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="inv_report_hide" value="-">
			<input type="checkbox"  class="filled-inventory inventory"  id="inv_reportall" />
            <label for="inv_reportall">Reports</label>
			<div style="padding-left:55px;" id="inv_report">
			<input type="checkbox" id="basic_checkbox_a46" class="filled-inventory inventory inv_report" name="stock_rept" />
            <label for="basic_checkbox_a46">Stock Report</label><br>
			<input type="checkbox" id="basic_checkbox_a47" class="filled-inventory inventory inv_report" name="stock_age_rept" />
            <label for="basic_checkbox_a47">Stock Age Report</label><br>
			<input type="checkbox" id="basic_checkbox_a48" class="filled-inventory inventory inv_report " name="stock_move_rept" />
            <label for="basic_checkbox_a48">Stock Moving Report</label><br>
			<input type="checkbox" id="basic_checkbox_a49" class="filled-inventory inventory inv_report " name="negative_rept" />
            <label for="basic_checkbox_a49">Negative Stock</label>
			</div>
			</div>
			<div></div>
	<!--account-->
	
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="account_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="account_hide" value="-">
			<input type="checkbox"  class="filled-account"  id="accountall" />
            <label for="accountall" style="color:#0A4D80;" >Accounts</label>
			<div style="padding-left:30px;" id="account">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="transaction_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="transaction_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="transactionall" />
            <label for="transactionall">Transactions</label>
			<div style="padding-left:55px;" id="transaction">
			<input type="checkbox" id="basic_checkbox_a50" class="filled-account accounts transaction" name="trance_add_cash"/>
            <label for="basic_checkbox_a50">Cash</label><br>
			<input type="checkbox" id="basic_checkbox_a52" class="filled-account accounts transaction" name="trance_add_bank"/>
            <label for="basic_checkbox_a52">Bank</label><br>
			<input type="checkbox" id="basic_checkbox_a53" class="filled-account accounts transaction" name="trance_joural"/>
            <label for="basic_checkbox_a53">Journal</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_bank_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_bank_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="acco_bankall" />
            <label for="acco_bankall">Bank</label>
			<div style="padding-left:55px;" id="acco_bank">
			<input type="checkbox" id="basic_checkbox_a54" class="filled-account accounts abank " name="add_bank" />
            <label for="basic_checkbox_a54">Bank</label><br>
			<input type="checkbox" id="basic_checkbox_a55" class="filled-account accounts abank" name="update_bank" />
            <label for="basic_checkbox_a55">Bank Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_ledger_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_ledger_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="acco_ledgerall" />
            <label for="acco_ledgerall">Ledger</label>
			<div style="padding-left:55px;" id="acco_ledger">
			<input type="checkbox" id="basic_checkbox_56" class="filled-account accounts aledger" name="add_ledger" />
            <label for="basic_checkbox_56">Add Ledger</label><br>
			<input type="checkbox" id="basic_checkbox_57" class="filled-account accounts aledger" name="update_ledger" />
            <label for="basic_checkbox_57">Ledger Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="transaction_type_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="transaction_type_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="transaction_typeall" />
            <label for="transaction_typeall">Transaction Types</label>
			<div style="padding-left:55px;" id="transaction_type">
			<input type="checkbox" id="basic_checkbox_a58" class="filled-account accounts transaction_type" name="add_transactiontype" />
            <label for="basic_checkbox_a58">Add Transaction Types</label><br>
			<input type="checkbox" id="basic_checkbox_a59" class="filled-account accounts transaction_type" name="update_transactiontype" />
            <label for="basic_checkbox_a59">Transaction Types Update & Delete</label>
			</div>
			<div></div>
			
			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a60" class="filled-account accounts" name="day_closing" />
            <label for="basic_checkbox_a60">Day Closing</label>
			</div>
			<div></div> 
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="general_rept_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="general_rept_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="general_reptall" />
            <label for="general_reptall">General Reports</label>
			<div style="padding-left:55px;" id="general_rept">
			<input type="checkbox" id="basic_checkbox_a61" class="filled-account accounts general_rept" name="general_ledger" />
            <label for="basic_checkbox_a61">Ledger</label><br>
			<input type="checkbox" id="basic_checkbox_a62" class="filled-account accounts general_rept" name="general_daybook" />
            <label for="basic_checkbox_a62">Daybook</label><br>
			<input type="checkbox" id="basic_checkbox_a63" class="filled-account accounts general_rept" name="general_cashflow" />
            <label for="basic_checkbox_a63">Cash Flow</label>
			</div>
			<div></div>
			
			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a64" class="filled-account accounts " name="acco_sales" />
            <label for="basic_checkbox_a64">Sales</label><br>
			<input type="checkbox" id="basic_checkbox_a64" class="filled-account accounts " name="acco_purchase" />
            <label for="basic_checkbox_a64">Purchase</label>
			</div>
			<div></div> 
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="final_acco_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="final_acco_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="final_accoall" />
            <label for="final_accoall">Final Accounts</label>
			<div style="padding-left:55px;" id="final_acco">
			<input type="checkbox" id="basic_checkbox_a65" class="filled-account accounts final_acco" name="trail_balance" />
            <label for="basic_checkbox_a65">Trail Balance</label><br>
			<input type="checkbox" id="basic_checkbox_a66" class="filled-account accounts final_acco" name="profit" />
            <label for="basic_checkbox_a66">Profit</label><br>
			<input type="checkbox" id="basic_checkbox_a67" class="filled-account accounts accounts final_acco" name="trading_profit_loss" />
            <label for="basic_checkbox_a67">Trading & Profit & Loss</label><br>
			<input type="checkbox" id="basic_checkbox_a68" class="filled-account accounts final_acco" name="balance_sheet" />
            <label for="basic_checkbox_a68">Balance Sheet</label>
			</div>
			<div></div>

			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_tax_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="acco_tax_hide" value="-">
			<input type="checkbox"  class="filled-account accounts"  id="acco_taxall" />
            <label for="acco_taxall">Tax</label>
			<div style="padding-left:55px;" id="acco_tax">
			<input type="checkbox" id="basic_checkbox_a69" class="filled-account accounts atax" name="account_add_gst" />
            <label for="basic_checkbox_a69">Add Gst</label><br>
			<input type="checkbox" id="basic_checkbox_a70" class="filled-account accounts atax" name="account_update_gst" />
            <label for="basic_checkbox_a70">Gst Update & Delete</label><br>
			<input type="checkbox" id="basic_checkbox_a71" class="filled-account accounts atax" name="account_add_othertax" />
            <label for="basic_checkbox_a71">Add Other Tax</label><br>
			<input type="checkbox" id="basic_checkbox_a72" class="filled-account accounts atax" name="account_update_othertax" />
            <label for="basic_checkbox_a72">Other Tax Update & Delete</label>
			</div>
			</div>
			<div></div>
	<!--cash counter-->	
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="cashcounter_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="cashcounter_hide" value="-">
			<input type="checkbox"  class="filled-incash"  id="cashcounterall" />
            <label for="cashcounterall" style="color:#0A4D80;">Cash Counter</label>
			<div style="padding-left:30px;" id="cashcounter">
			<div style="padding-left:30px;">
			<input type="checkbox" id="basic_checkbox_a73" class="filled-incash counter" name="cash_open" />
            <label for="basic_checkbox_a73">Cash Open</label><br>
			<input type="checkbox" id="basic_checkbox_a74" class="filled-incash counter" name="cash_counter"/>
            <label for="basic_checkbox_a74">Cash Counter</label><br>
			<input type="checkbox" id="basic_checkbox_a75" class="filled-incash counter" name="add_advance_receipt"/>
            <label for="basic_checkbox_a75">Advanced Receipt</label><br>
			</div>
			
			<!--<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="advance_receipt_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="advance_receipt_hide" value="-">
			<input type="checkbox"  class="filled-incash counter"  id="advance_receiptall" />
            <label for="advance_receiptall">Advanced Receipt</label>
			<div style="padding-left:55px;" id="advance_receipt">
			<input type="checkbox" id="basic_checkbox_a75" class="filled-incash counter advance_receipt" name="add_advance_receipt"/>
            <label for="basic_checkbox_a75">Advanced Receipt</label><br>
			<input type="checkbox" id="basic_checkbox_a75a" class="filled-incash counter advance_receipt" name="update_advance_receipt"/>
            <label for="basic_checkbox_a75a">Advanced Receipt Update & Delete</label><br>
			</div>-->
			
			<div style="padding-left:28px;">
			<input type="checkbox" id="basic_checkbox_a76" class="filled-incash counter" name="cash_closing"/>
            <label for="basic_checkbox_a76">Cash Closing</label><br>
			<input type="checkbox" id="basic_checkbox_a77" class="filled-incash counter" name="round_off"/>
            <label for="basic_checkbox_a77">Round Off</label>
			</div>
			</div>
			
<!--analysis-->
            <div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a78a" class="filled-analysis" name="analysis" />
            <label for="basic_checkbox_a78a"  style="color:#0A4D80;">Analysis</label><br>
            </div>			
	<!--settings-->
	         
			 <input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_hide" value="-">
			<input type="checkbox"  class="filled-inset"  id="settingall" />
            <label for="settingall" style="color:#0A4D80;" >Settings</label>
			<div style="padding-left:30px;" id="setting">

			<div style="padding-left:27px;">
			<input type="checkbox" id="basic_checkbox_a78" class="filled-inset setup" name="update_password" />
            <label for="basic_checkbox_a78">Update Password</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a79" class="filled-inset setup" name="date_picker" />
            <label for="basic_checkbox_a79">Date Picker</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a80" class="filled-inset setup" name="printer" />
            <label for="basic_checkbox_a80">Printer</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a81" class="filled-inset setup" name="financial_year" />
            <label for="basic_checkbox_a81">Set Financial Year</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a81a" class="filled-inset setup" name="dateset" />
            <label for="basic_checkbox_a81a">Date Set</label>
			<div></div>
			<input type="checkbox" id="basic_checkbox_a82" class="filled-inset setup" name="backup" />
            <label for="basic_checkbox_a82">Backup</label>
				<div></div>
				<input type="checkbox" id="basic_checkbox_a82a" class="filled-inset setup" name="notification" />
            <label for="basic_checkbox_a82a">Notification</label>
				<div></div>
				<input type="checkbox" id="basic_checkbox_a82b" class="filled-inset setup" name="company_show" />
            <label for="basic_checkbox_a82b">Company</label>
			<div></div>
			</div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_tax_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_tax_hide" value="-">
			<input type="checkbox"  class="filled-inset setup"  id="setting_taxall" />
            <label for="setting_taxall">Tax</label>
			<div style="padding-left:55px;" id="setting_tax">
			<input type="checkbox" id="basic_checkbox_a83" class="filled-inset setup stax" name="setting_add_gst" />
            <label for="basic_checkbox_a83">Add Gst</label><br>
			<input type="checkbox" id="basic_checkbox_a84" class="filled-inset setup stax" name="setting_update_gst" />
            <label for="basic_checkbox_a84">Gst Update & Delete</label><br>
			<input type="checkbox" id="basic_checkbox_a85" class="filled-inset setup stax" name="setting_add_othertax" />
            <label for="basic_checkbox_a85">Add Other Tax</label><br>
			<input type="checkbox" id="basic_checkbox_a86" class="filled-inset setup stax" name="setting_update_othertax" />
            <label for="basic_checkbox_a86">Other Tax Update & Delete</label>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_season_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_season_hide" value="-">
			<input type="checkbox"  class="filled-inset setup"  id="setting_seasonall" />
            <label for="setting_seasonall">Season</label>
			<div style="padding-left:55px;" id="setting_season">
			<input type="checkbox" id="basic_checkbox_a89" class="filled-inset setup season" name="add_season" />
            <label for="basic_checkbox_a89">Add Season</label><br>
			<input type="checkbox" id="basic_checkbox_a90" class="filled-inset setup season" name="update_season" />
            <label for="basic_checkbox_a90">Season Update & Delete</label><br>
			</div>
			<div></div>
			
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_user_show" value="+">
			<input type="button" style="border:none; background-color:#f9f9f9; font-size:Master; font-weight:600;" id="setting_user_hide" value="-">
			<input type="checkbox"  class="filled-inset setup"  id="setting_userall" />
            <label for="setting_userall">User</label>
			<div style="padding-left:55px;" id="setting_user">
			<input type="checkbox" id="basic_checkbox_a91" class="filled-inset setup user" name="add_user_type" />
            <label for="basic_checkbox_a91">Add User Type</label><br>
			<input type="checkbox" id="basic_checkbox_a92" class="filled-inset setup user" name="update_user_type" />
            <label for="basic_checkbox_a92">User Type Update & Delete</label><br>
			<input type="checkbox" id="basic_checkbox_a93" class="filled-inset setup user" name="add_user" />
            <label for="basic_checkbox_a93">Add User</label><br>
			<input type="checkbox" id="basic_checkbox_a94" class="filled-inset setup user" name="update_user" />
            <label for="basic_checkbox_a94">User Update & Delete</label><br>
			</div>
			<div></div>
			</div>
			
			</div>

			<input type="hidden" name="userid" id="userid" value="<?php echo $userid;?>">
		<input type="hidden" name="company" id="company" value="<?php echo $user_company;?>">
			<div class="text-right" id="sub" style="margin-bottom:0px;">
				<label for="" class="control-label" style="margin-top:55px; "></label>
				<a href="javascript: save_user()" class="btn btn-sm  btn-info" style="margin-bottom: 12px; font-size: 15px; margin-top: 12px;">Save</a>
				<button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right" style=" font-size: 15px !important;">Cancel</button>
			</div>
	
	</form>
</div>
<script type="text/javascript" src="assets/checkall/jquery.min.js"></script>
 <?php include("privilag-include/user_type_js.php");?>

<script>
		$('#close_fbx').on('click', function (){
			//parent.jQuery.fancybox.close(); 
			window.location="setting-home.php";
		});
		function save_user() {
            if( $("input[name='master_add_product']:checked").val()) { var master_add_product=0; } else { var master_add_product=1; }
            if( $("input[name='master_update_product']:checked").val()) { var master_update_product=0; } else { var master_update_product=1; }
		    if( $("input[name='master_add_customer']:checked").val()) { var master_add_customer=0; } else { var master_add_customer=1; }
            if( $("input[name='master_update_customer']:checked").val()) { var master_update_customer=0; } else { var master_update_customer=1; }
            if( $("input[name='master_add_supplier']:checked").val()) {  var master_add_supplier=0; } else { var master_add_supplier=1; }
		    if( $("input[name='master_update_supplier']:checked").val()) {  var master_update_supplier=0; } else { var master_update_supplier=1; }
			if( $("input[name='purchase_report']:checked").val()) {  var purchase_report=0; } else { var purchase_report=1; }
			if( $("input[name='master_add_ledger']:checked").val()) {  var master_add_ledger=0; } else { var master_add_ledger=1; }
			if( $("input[name='master_update_ledger']:checked").val()) {  var master_update_ledger=0; } else { var master_update_ledger=1; }
			if( $("input[name='master_add_category']:checked").val()) {  var master_add_category=0; } else { var master_add_category=1; }
			if( $("input[name='master_update_category']:checked").val()) {  var master_update_category=0; } else { var master_update_category=1; }
			if( $("input[name='master_add_subcategory']:checked").val()) {  var master_add_subcategory=0; } else { var master_add_subcategory=1; }
			if( $("input[name='master_update_subcategory']:checked").val()) {  var master_update_subcategory=0; } else { var master_update_subcategory=1; }
			if( $("input[name='master_add_unit']:checked").val()) {  var master_add_unit=0; } else { var master_add_unit=1; }
			if( $("input[name='master_update_unit']:checked").val()) {  var master_update_unit=0; } else { var master_update_unit=1; }
			if( $("input[name='master_add_bank']:checked").val()) {  var master_add_bank=0; } else { var master_add_bank=1; }
			if( $("input[name='master_update_bank']:checked").val()) {  var master_update_bank=0; } else { var master_update_bank=1; }
			if( $("input[name='master_add_gst']:checked").val()) {  var master_add_gst=0; } else { var master_add_gst=1; }
			if( $("input[name='master_update_gst']:checked").val()) {  var master_update_gst=0; } else { var master_update_gst=1; }
			if( $("input[name='master_add_othertax']:checked").val()) {  var master_add_othertax=0; } else { var master_add_othertax=1; }
			if( $("input[name='master_update_othertax']:checked").val()) {  var master_update_othertax=0; } else { var master_update_othertax=1; }
			
			if( $("input[name='add_supplier']:checked").val()) {  var add_supplier=0; } else { var add_supplier=1; }
			if( $("input[name='update_supplier']:checked").val()) {  var update_supplier=0; } else { var update_supplier=1; }
			if( $("input[name='Purchase_invo']:checked").val()) {  var Purchase_invo=0; } else { var Purchase_invo=1; }
			if( $("input[name='Purchase_order_invo']:checked").val()) {  var Purchase_order_invo=0; } else { var Purchase_order_invo=1; }
			if( $("input[name='Purchase_rtn_invo']:checked").val()) {  var Purchase_rtn_invo=0; } else { var Purchase_rtn_invo=1; }
			if( $("input[name='purchas_rep']:checked").val()) {  var purchas_rep=0; } else { var purchas_rep=1; }
			if( $("input[name='purchase_order_rep']:checked").val()) {  var purchase_order_rep=0; } else { var purchase_order_rep=1; }
			if( $("input[name='purchase_return_rep']:checked").val()) {  var purchase_return_rep=0; } else { var purchase_return_rep=1; }
			
			if( $("input[name='add_customer']:checked").val()) {  var add_customer=0; } else { var add_customer=1; }
			if( $("input[name='update_customer']:checked").val()) {  var update_customer=0; } else { var update_customer=1; }
			if( $("input[name='sales_order']:checked").val()) {  var sales_order=0; } else { var sales_order=1; }
			if( $("input[name='sales_invo']:checked").val()) {  var sales_invo=0; } else { var sales_invo=1; }
			if( $("input[name='pos_invo']:checked").val()) {  var pos_invo=0; } else { var pos_invo=1; }
			if( $("input[name='estimate_invo']:checked").val()) {  var estimate_invo=0; } else { var estimate_invo=1; }
			if( $("input[name='sales_ret_invo']:checked").val()) {  var sales_ret_invo=0; } else { var sales_ret_invo=1; }
			if( $("input[name='bill_cancel']:checked").val()) {  var bill_cancel=0; } else { var bill_cancel=1; }
			if( $("input[name='sales_order_rept']:checked").val()) {  var sales_order_rept=0; } else { var sales_order_rept=1; }
			if( $("input[name='sales_rept']:checked").val()) {  var sales_rept=0; } else { var sales_rept=1; }
			if( $("input[name='sales_ret_rept']:checked").val()) {  var sales_ret_rept=0; } else { var sales_ret_rept=1; }
			
			if( $("input[name='product']:checked").val()) {  var product=0; } else { var product=1; }
			if( $("input[name='product_update']:checked").val()) {  var product_update=0; } else { var product_update=1; }
			if( $("input[name='category']:checked").val()) {  var category=0; } else { var category=1; }
			if( $("input[name='category_update']:checked").val()) {  var category_update=0; } else { var category_update=1; }
			if( $("input[name='subcategory']:checked").val()) {  var subcategory=0; } else { var subcategory=1; }
			if( $("input[name='subcategory_update']:checked").val()) {  var subcategory_update=0; } else { var subcategory_update=1; }
			if( $("input[name='unit']:checked").val()) {  var unit=0; } else { var unit=1; }
			if( $("input[name='unit_update']:checked").val()) {  var unit_update=0; } else { var unit_update=1; }
			if( $("input[name='pricing']:checked").val()) {  var pricing=0; } else { var pricing=1; }
			if( $("input[name='stock_rept']:checked").val()) {  var stock_rept=0; } else { var stock_rept=1; }
			if( $("input[name='stock_age_rept']:checked").val()) {  var stock_age_rept=0; } else { var stock_age_rept=1; }
			if( $("input[name='stock_move_rept']:checked").val()) {  var stock_move_rept=0; } else { var stock_move_rept=1; }			
			if( $("input[name='negative_rept']:checked").val()) {  var negative_rept=0; } else { var negative_rept=1; }	
			
			if( $("input[name='trance_add_cash']:checked").val()) {  var trance_add_cash=0; } else { var trance_add_cash=1; }	
			if( $("input[name='trance_add_bank']:checked").val()) {  var trance_add_bank=0; } else { var trance_add_bank=1; }	
			if( $("input[name='trance_joural']:checked").val()) {  var trance_joural=0; } else { var trance_joural=1; }	
			if( $("input[name='add_bank']:checked").val()) {  var add_bank=0; } else { var add_bank=1; }	
			if( $("input[name='update_bank']:checked").val()) {  var update_bank=0; } else { var update_bank=1; }	
			if( $("input[name='add_ledger']:checked").val()) {  var add_ledger=0; } else { var add_ledger=1; }	
			if( $("input[name='update_ledger']:checked").val()) {  var update_ledger=0; } else { var update_ledger=1; }	
			if( $("input[name='add_transactiontype']:checked").val()) {  var add_transactiontype=0; } else { var add_transactiontype=1; }	
			if( $("input[name='update_transactiontype']:checked").val()) {  var update_transactiontype=0; } else { var update_transactiontype=1; }	
			if( $("input[name='day_closing']:checked").val()) {  var day_closing=0; } else { var day_closing=1; }	
			if( $("input[name='general_ledger']:checked").val()) {  var general_ledger=0; } else { var general_ledger=1; }	
			if( $("input[name='general_daybook']:checked").val()) {  var general_daybook=0; } else { var general_daybook=1; }	
			if( $("input[name='general_cashflow']:checked").val()) {  var general_cashflow=0; } else { var general_cashflow=1; }	
			if( $("input[name='acco_sales']:checked").val()) {  var acco_sales=0; } else { var acco_sales=1; }	
			if( $("input[name='acco_purchase']:checked").val()) {  var acco_purchase=0; } else { var acco_purchase=1; }	
			if( $("input[name='trail_balance']:checked").val()) {  var trail_balance=0; } else { var trail_balance=1; }	
			if( $("input[name='profit']:checked").val()) {  var profit=0; } else { var profit=1; }	
			if( $("input[name='trading_profit_loss']:checked").val()) {  var trading_profit_loss=0; } else { var trading_profit_loss=1; }	
			if( $("input[name='balance_sheet']:checked").val()) {  var balance_sheet=0; } else { var balance_sheet=1; }	
			if( $("input[name='account_add_gst']:checked").val()) {  var account_add_gst=0; } else { var account_add_gst=1; }	
			if( $("input[name='account_update_gst']:checked").val()) {  var account_update_gst=0; } else { var account_update_gst=1; }	
			if( $("input[name='account_add_othertax']:checked").val()) {  var account_add_othertax=0; } else { var account_add_othertax=1; }	
			if( $("input[name='account_update_othertax']:checked").val()) {  var account_update_othertax=0; } else { var account_update_othertax=1; }	
			
			if( $("input[name='cash_open']:checked").val()) {  var cash_open=0; } else { var cash_open=1; }	
			if( $("input[name='cash_counter']:checked").val()) {  var cash_counter=0; } else { var cash_counter=1; }	
			if( $("input[name='add_advance_receipt']:checked").val()) {  var add_advance_receipt=0; } else { var add_advance_receipt=1; }	
			//if( $("input[name='update_advance_receipt']:checked").val()) {  var update_advance_receipt=0; } else { var update_advance_receipt=1; }	
			if( $("input[name='cash_closing']:checked").val()) {  var cash_closing=0; } else { var cash_closing=1; }	
			if( $("input[name='round_off']:checked").val()) {  var round_off=0; } else { var round_off=1; }	
			
			if( $("input[name='analysis']:checked").val()) {  var analysis=0; } else { var analysis=1; }
			
			if( $("input[name='update_password']:checked").val()) {  var update_password=0; } else { var update_password=1; }	
			if( $("input[name='date_picker']:checked").val()) {  var date_picker=0; } else { var date_picker=1; }	
			if( $("input[name='printer']:checked").val()) {  var printer=0; } else { var printer=1; }	
			if( $("input[name='financial_year']:checked").val()) {  var financial_year=0; } else { var financial_year=1; }	
			if( $("input[name='setting_add_gst']:checked").val()) {  var setting_add_gst=0; } else { var setting_add_gst=1; }	
			if( $("input[name='setting_update_gst']:checked").val()) {  var setting_update_gst=0; } else { var setting_update_gst=1; }	
			if( $("input[name='setting_add_othertax']:checked").val()) {  var setting_add_othertax=0; } else { var setting_add_othertax=1; }	
			if( $("input[name='setting_update_othertax']:checked").val()) {  var setting_update_othertax=0; } else { var setting_update_othertax=1; }	
			if( $("input[name='add_season']:checked").val()) {  var add_season=0; } else { var add_season=1; }	
			if( $("input[name='update_season']:checked").val()) {  var update_season=0; } else { var update_season=1; }	
			if( $("input[name='add_user_type']:checked").val()) {  var add_user_type=0; } else { var add_user_type=1; }	
			if( $("input[name='update_user_type']:checked").val()) {  var update_user_type=0; } else { var update_user_type=1; }	
			if( $("input[name='add_user']:checked").val()) {  var add_user=0; } else { var add_user=1; }	
			if( $("input[name='update_user']:checked").val()) {  var update_user=0; } else { var update_user=1; }	
			if( $("input[name='dateset']:checked").val()) {  var dateset=0; } else { var dateset=1; }	
			if( $("input[name='backup']:checked").val()) {  var backup=0; } else { var backup=1; }
			if( $("input[name='notification']:checked").val()) {  var notification=0; } else { var notification=1; }
			if( $("input[name='company_show']:checked").val()) {  var company_show=0; } else { var company_show=1; }
			
			
			
			var user_type = $("#user_type").val();
			var company = $("#company").val();
			var userid = $("#userid").val();
			 if($("#user_type").val() == ""){ $.toast( {heading: 'Fill User Type.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1200} ); } 
			 else if( $("input:checkbox[class=filled-inmast]:checked").val() || $("input:checkbox[class=filled-inp]:checked").val() || $("input:checkbox[class=filled-ins]:checked").val() || $("input:checkbox[class=filled-inventory]:checked").val()|| $("input:checkbox[class=filled-account]:checked").val() ||  $("input:checkbox[class=filled-incash]:checked").val() || $("input:checkbox[class=filled-inset]:checked").val() || $("input:checkbox[class=master]:checked").val() || $("input:checkbox[class=purchase]:checked").val() || $("input:checkbox[class=sales]:checked").val() || $("input:checkbox[class=inventory]:checked").val() || $("input:checkbox[class=accounts]:checked").val() || $("input:checkbox[class=counter]:checked").val() || $("input:checkbox[class=setup]:checked").val() || $("input:checkbox[class=filled-analysis]:checked").val() || $("input[name='master_add_product']:checked").val() || $("input[name='master_add_customer']:checked").val() || $("input[name='master_add_supplier']:checked").val() || $("input[name='master_add_ledger']:checked").val() || $("input[name='master_add_category']:checked").val() || $("input[name='master_add_subcategory']:checked").val() || $("input[name='master_add_unit']:checked").val() || $("input[name='master_add_bank']:checked").val() || $("input[name='master_add_gst']:checked").val() ||  $("input[name='master_add_othertax']:checked").val() || $("input[name='add_supplier']:checked").val() || $("input[name='Purchase_invo']:checked").val() || $("input[name='Purchase_order_invo']:checked").val() || $("input[name='Purchase_rtn_invo']:checked").val() || $("input[name='purchas_rep']:checked").val() || $("input[name='purchase_order_rep']:checked").val() || $("input[name='purchase_return_rep']:checked").val() || $("input[name='add_customer']:checked").val() || $("input[name='sales_order']:checked").val() ||  $("input[name='sales_invo']:checked").val() || ("input[name='estimate_invo']:checked").val() || $("input[name='sales_ret_invo']:checked").val() || $("input[name='bill_cancel']:checked").val() || $("input[name='sales_order_rept']:checked").val() ||  $("input[name='sales_rept']:checked").val() || $("input[name='sales_ret_rept']:checked").val() || $("input[name='product']:checked").val() ||  $("input[name='category']:checked").val() ||  $("input[name='subcategory']:checked").val() ||  $("input[name='unit']:checked").val() || $("input[name='pricing']:checked").val() || $("input[name='stock_rept']:checked").val() ||  $("input[name='stock_age_rept']:checked").val() || $("input[name='stock_move_rept']:checked").val() || $("input[name='negative_rept']:checked").val() || $("input[name='trance_add_cash']:checked").val() || $("input[name='trance_add_bank']:checked").val() || $("input[name='trance_joural']:checked").val() ||  $("input[name='add_bank']:checked").val() || $("input[name='add_ledger']:checked").val()  || $("input[name='add_transactiontype']:checked").val()	 || $("input[name='day_closing']:checked").val()  || $("input[name='general_ledger']:checked").val() ||  $("input[name='general_daybook']:checked").val()	|| $("input[name='general_cashflow']:checked").val() ||  $("input[name='acco_sales']:checked").val() ||  $("input[name='acco_purchase']:checked").val() || $("input[name='trail_balance']:checked").val() ||  $("input[name='profit']:checked").val() || $("input[name='trading_profit_loss']:checked").val() ||  $("input[name='balance_sheet']:checked").val() || $("input[name='account_add_gst']:checked").val() || $("input[name='account_add_othertax']:checked").val()
			|| $("input[name='cash_open']:checked").val() || $("input[name='cash_counter']:checked").val()	|| $("input[name='add_advance_receipt']:checked").val()
			|| $("input[name='cash_closing']:checked").val() ||  $("input[name='round_off']:checked").val() || $("input[name='analysis']:checked").val() || $("input[name='update_password']:checked").val() ||  $("input[name='date_picker']:checked").val() || $("input[name='printer']:checked").val() || $("input[name='financial_year']:checked").val() ||  $("input[name='setting_add_gst']:checked").val() || $("input[name='setting_add_othertax']:checked").val() || $("input[name='add_season']:checked").val() || $("input[name='add_user_type']:checked").val() || $("input[name='add_user']:checked").val() || $("input[name='dateset']:checked").val() ||  $("input[name='backup']:checked").val() || $("input[name='notification']:checked").val() || $("input[name='company_show']:checked").val()  ){
				$.ajax({
					type: 'POST',
					url: "settings-action/user_type.php",
					data: "user_type=" + user_type + "&userid=" + userid + "&master_add_product=" + master_add_product + "&master_update_product=" + master_update_product + "&master_add_customer=" + master_add_customer + "&master_update_customer=" + master_update_customer + "&master_add_supplier=" + master_add_supplier + "&master_update_supplier=" + master_update_supplier + "&master_add_ledger=" + master_add_ledger + "&master_update_ledger=" + master_update_ledger + "&master_add_category=" + master_add_category + "&master_update_category=" + master_update_category + "&master_add_subcategory=" + master_add_subcategory + "&master_update_subcategory=" + master_update_subcategory + "&master_add_unit=" + master_add_unit + "&master_update_unit=" + master_update_unit + "&master_add_bank=" + master_add_bank + "&master_update_bank=" + master_update_bank + "&master_add_gst=" + master_add_gst + "&master_update_gst=" + master_update_gst + "&master_add_othertax=" + master_add_othertax + "&master_update_othertax=" + master_update_othertax + "&add_supplier=" + add_supplier + "&update_supplier=" + update_supplier + "&Purchase_invo=" + Purchase_invo + "&Purchase_order_invo=" + Purchase_order_invo + "&Purchase_rtn_invo=" + Purchase_rtn_invo + "&purchas_rep=" + purchas_rep + "&purchase_order_rep=" + purchase_order_rep + "&purchase_return_rep=" + purchase_return_rep + "&add_customer=" + add_customer + "&update_customer=" + update_customer + "&sales_order=" + sales_order + "&sales_invo=" + sales_invo + "&pos_invo=" + pos_invo + "&estimate_invo=" + estimate_invo + "&sales_ret_invo=" + sales_ret_invo + "&bill_cancel=" + bill_cancel + "&sales_order_rept=" + sales_order_rept + "&sales_rept=" + sales_rept + "&sales_ret_rept=" + sales_ret_rept+ "&product=" + product + "&product_update=" + product_update + "&category=" + category + "&category_update=" + category_update + "&subcategory=" + subcategory  + "&subcategory_update=" + subcategory_update + "&unit=" + unit + "&unit_update=" + unit_update + "&pricing=" + pricing + "&stock_rept=" + stock_rept + "&stock_age_rept=" + stock_age_rept + "&stock_move_rept=" + stock_move_rept + "&negative_rept=" + negative_rept + "&trance_add_cash=" + trance_add_cash + "&trance_add_bank=" + trance_add_bank  + "&trance_joural=" + trance_joural + "&add_bank=" + add_bank + "&update_bank=" + update_bank + "&add_ledger=" + add_ledger + "&update_ledger=" + update_ledger + "&add_transactiontype=" + add_transactiontype + "&update_transactiontype=" + update_transactiontype + "&day_closing=" + day_closing + "&general_ledger=" + general_ledger + "&general_daybook=" + general_daybook + "&general_cashflow=" + general_cashflow + "&acco_sales=" + acco_sales + "&acco_purchase=" + acco_purchase + "&trail_balance=" + trail_balance + "&profit=" + profit + "&trading_profit_loss=" + trading_profit_loss + "&balance_sheet=" + balance_sheet + "&account_add_gst=" + account_add_gst + "&account_update_gst=" + account_update_gst + "&account_add_othertax=" + account_add_othertax + "&account_update_othertax=" + account_update_othertax + "&cash_open=" + cash_open + "&cash_counter=" + cash_counter + "&add_advance_receipt=" + add_advance_receipt + "&cash_closing=" + cash_closing + "&round_off=" + round_off + "&analysis=" + analysis + "&update_password=" + update_password + "&date_picker=" + date_picker + "&printer=" + printer + "&financial_year=" + financial_year + "&setting_add_gst=" + setting_add_gst + "&setting_update_gst=" + setting_update_gst + "&setting_add_othertax=" + setting_add_othertax + "&setting_update_othertax=" + setting_update_othertax + "&add_season=" + add_season + "&add_user_type=" + add_user_type + "&update_user_type=" + update_user_type + "&add_user=" + add_user + "&update_user=" + update_user + "&dateset=" + dateset + "&update_season=" + update_season + "&backup=" + backup + "&notification=" + notification + "&company_show=" + company_show +  "&company=" + company,
					success: function (r) {
					$( "#respond" ).html(r);
					}
				});
				//document.getElementById( "insert_form" ).reset();
			     parent.jQuery.fancybox.close();
				/*$.toast( {heading: 'Added Succeccfully.',text: '',position: 'top-right',loaderBg: '#1FDE13',icon: 'success',hideAfter: 1200} );*/
				return false;
			}
			
			else {
	          $.toast( {
						heading: 'Select Privilag',
						text: '',
						position: 'top-right',
						loaderBg: '#ff6849',
						icon: 'error',
						hideAfter: 1200
					} );
	
}
		}
	</script>
	<div id="respond"></div>
<script src="assets/plugins/popper/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="js/perfect-scrollbar.jquery.min.js"></script>
<script src="js/waves.js"></script>
<script src="js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/mask.init.js"></script>
<script src="assets/plugins/toast-master/js/jquery.toast.js"></script>
<script src="js/toastr.js"></script>
<?php include("assets/custom/custom.php");?>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>