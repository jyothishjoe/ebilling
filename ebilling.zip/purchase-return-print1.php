<?php
include ('include/auth.php');
include( 'db-connect/db.php' );
include( 'include/today.php' );
$billid = $_GET[ 'bill' ];
$userid=$_SESSION['SESS_USERID_AS'];
$result_billitem = $db->prepare( "SELECT * FROM purchasereturn_invoice a LEFT JOIN purchasereturn_productdetails b ON a.purch_token=b.purch_token  WHERE a.inv = '$billid' " );
$result_billitem->execute();
$rows_billitem = $result_billitem->fetch();
$previous = "javascript:history.go(-3)";
if(isset($_SERVER['HTTP_REFERER'])) {
$previous = $_SERVER['HTTP_REFERER'];
}
$user_company = $_SESSION['SESS_COMPANY_ID'];
$result_user_company = $db->prepare("SELECT * FROM company WHERE c_token = '$user_company'");
$result_user_company->execute();	
$rows_user_company = $result_user_company->fetch(); 
$logo=$rows_user_company['c_logo'];
?>
<html>
<title>Purchase Return Print</title>
<head>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="js/auto_js/jquery-3.2.1.min.js"></script>
<link href="css/style.css" rel="stylesheet">
	
<style>
table td {
	height: 15px;
}
 @media print {
.btn {
	display: none;
}
}
.hr {
	border: none;
	border-top: 1px solid black;
	margin-top:10px;
}
</style>
	<?php include("include/print_size.php");?>
</head>
<body>
	<?php
	$result_bill = $db->prepare( "SELECT * FROM purchasereturn_invoice a LEFT JOIN purchasereturn_productdetails b ON a.purch_token=b.purch_token WHERE a.inv = '$billid' " );
	$result_bill->execute();
	$rows_bill = $result_bill->fetch();
	$sup=$rows_bill["sup_token"];
	?>
	<div class="col-md-12" style="margin-top: 18px;">
	 <a href="<?php echo $previous; ?>"</a><button type="button" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:left; margin-right: 25px; margin-top: 10px;"><i class="fa fa-backward"></i> Back</button></a>
	<a href="#"</a><button type="button" onClick="window.print()" class="btn btn-info btn-addon m-b-sm btn-sm" style="float:right; margin-right: 25px; margin-top: 10px;"><i class="fa fa-print"></i> Print</button></a>
	</div>
<?php
$result_sup=$db->prepare( "SELECT * FROM supplier WHERE supplier_token='$sup'");
$result_sup->execute();
$rows_sup=$result_sup->fetch();
?>
	
	<div class="row">
  <div class=" col-xs-12 printwidth" style="padding:0px 50px; margin-top: 15px;">
	<table style="line-height: 25px;" class="table table-bordered" width="100%" >
		<thead>
		<tr>
			<th colspan="11">
				<strong style="font-size: 20px;"><?php echo $rows_user_company['c_company_name']; ?></strong><strong style="float: right">GSTIN : <?php echo $rows_user_company['c_gst']; ?></strong><br>
				<?php echo $rows_user_company['c_shopaddress']; ?><br>
				Ph: <?php echo $rows_user_company['c_phone']; ?>, Mob: <?php echo $rows_user_company['c_mobile']; ?>
				
			</th>
		</tr>
	   </thead>
		
		
		
		<tr>
			<th colspan="11"><center><strong><u style="font-size:16px;">Debit Note</u></strong></center></th>
		</tr>
		<tr style="line-height: 25px;">
			<td colspan="4" width="50%">
			<strong>To,</strong><br>
			<!--<strong>C.Name :</strong><?= $rows_sup['company'] ?><br>-->
			<strong>Name :</strong>		<?php echo $rows_sup['v_name'] ?><br>	
			<strong>Address:</strong><?= $rows_sup['address'] ?><br>
			<strong>GSTIN No. :</strong> <?= $rows_sup['gstin'] ?><br>
			<strong>Ph:</strong> <?= $rows_sup['phone'] ?><br>	
			</td>
			<td colspan="7" width="50%">
				<strong>Purchase Invoice :</strong> <?=$rows_bill["bill_no"]?><br>
				<strong>Debit Note No. :</strong> <?=$rows_bill["inv"]?><br>
				<strong>Dated :</strong><?=date('d-m-Y H:i', strtotime($rows_bill["bill_date"]))?>
			</td>
		</tr>
	
		<tr>
			<th rowspan="2" width="50px" style bgcolor="#999999"> SI No</th>
			<th rowspan="2" bgcolor="#999999">ITEM NAME</th>
			<th rowspan="2" width="10%" bgcolor="#999999">UNIT PRICE</th>
			<th rowspan="2" width="15%" bgcolor="#999999">TOTAL QTY</th>
			<th colspan="2" width="15%" bgcolor="#999999">CGST</th>
			<th colspan="2" width="15%" bgcolor="#999999">SGST</th>
			<th colspan="2" width="15%" bgcolor="#999999">IGST</th>
			<th rowspan="2" width="15%" bgcolor="#999999"> TOTAL PRICE</th>
		</tr>
		<tr>
			<th>Rate</th>
			<th>Amt.</th>
			<th>Rate</th>
			<th>Amt.</th>
			<th>Rate</th>
			<th>Amt.</th>
		</tr>
		<?php
		$i = 1;
		$result_billitems = $db->prepare( "SELECT * FROM purchasereturn_invoice a LEFT JOIN purchasereturn_productdetails b ON a.purch_token=b.purch_token WHERE a.inv = '$billid' " );
		$result_billitems->execute();
		for ( $i = 0; $rowitm = $result_billitems->fetch(); $i++ ) {
			$tot = $rowitm[ 'total_price' ];
			$grand = $rowitm[ 'grand_total' ];
			$disco = $rowitm[ 'discount_total' ];
			$coolie = $rowitm[ 'frieght' ];
			$other_tax = $rowitm[ 'other_taxtotal' ];
			?>
		<tr>
			<td align="center">
				<?php echo ++$i; ?>
			</td>
			<td>
				<?php
				echo $rowitm[ "pr_name" ];
				?>
			</td>

			<td align="center">
				<?=$rowitm["purch_price"]?>
			</td>
			<td align="center">
				<?=$rowitm["qty"]?>
			</td>
			<!--<td align="center"></td>-->
			<td>
				<?php echo $rowitm["cgstrate"]; ?>
			</td>
			<td>
				<?php echo $rowitm["csgtamt"]; ?>
			</td>
			<td>
				<?php echo $rowitm["sgstrate"]; ?>
			</td>
			<td>
				<?php echo $rowitm["sgstamt"]; ?>
			</td>
			<td>
				<?php echo $rowitm["igstrate"]; ?>
			</td>
			<td>
				<?php echo $rowitm["igstamt"]; ?>
			</td>
			<td align="center">
				<?php echo $rowitm["total"]; ?>
			</td>
		</tr>
		<?php } ?>
		<tr>
			<td colspan="10" align="right">TOTAL</td>
			<td align="center">
				<?php echo $grand; ?>
			</td>
		</tr>
		<?php if($disco > 0){ ?>
		<tr>
			<td colspan="10" align="right">DISCOUNT</td>
			<td align="center">
				<?php echo $disco; ?>
			</td>
		</tr>
		<?php } ?>
		<?php if($coolie > 0){ ?>
		<tr>
			<td colspan="10" align="right">FREIGHT</td>
			<td align="center">
				<?php echo $coolie; ?>
			</td>
		</tr>
		<?php } ?>
		<?php if($other_tax > 0){ ?>
		<tr>
			<td colspan="10" align="right">OTHER TAX AMOUNT</td>
			<td align="center">
				<?php echo $other_tax; ?>
			</td>
		</tr>
		<?php } ?>
		<tr>
			<tr>
				<td colspan="10" align="right">GRAND TOTAL</td>
				<td align="center">
					<?php echo $tot; ?>
				</td>
			</tr>
			<td colspan="11">
			<?php 
		   $number =   $tot;
		   $no = round($number);
		   $point = round($number - $no, 2) * 100;
		   $hundred = null;
		   $digits_1 = strlen($no);
		   $i = 0;
		   $str = array();
		   $words = array('0' => '', '1' => 'One', '2' => 'Two',
			'3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
			'7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
			'10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
			'13' => 'Thirteen', '14' => 'Fourteen',
			'15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
			'18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
			'30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
			'60' => 'Sixty', '70' => 'Seventy',
			'80' => 'Eighty', '90' => 'Ninety');
		   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
		   while ($i < $digits_1) {
			 $divider = ($i == 2) ? 10 : 100;
			 $number = floor($no % $divider);
			 $no = floor($no / $divider);
			 $i += ($divider == 10) ? 1 : 2;
			 if ($number) {
				$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
				$hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
				$str [] = ($number < 21) ? $words[$number] .
					" " . $digits[$counter] . $plural . " " . $hundred
					:
					$words[floor($number / 10) * 10]
					. " " . $words[$number % 10] . " "
					. $digits[$counter] . $plural . " " . $hundred;
			 } else $str[] = null;
		  }
		  $str = array_reverse($str);
		  $result = implode('', $str);
		  $points = ($point) ?
			"." . $words[$point / 10] . " " . 
				  $words[$point = $point % 10] : ''; ?>
			Grand Total(in words) :  <strong><?php echo $result . "Rupees  " . $points . "only"; ?></strong>
			  </td>
		</tr>
		<tr>
			<td colspan="11">
				
				
				<strong style="float: left;">E & OE</strong>
				

			<b style="float:right">Authorised Signatory<br><br>(with Status & Seal)&nbsp;</b>
				
			</td>
		</tr>
	</table>
</div>
</div>
<script>$( document ).ready( function () {

			var headstr = "<html><head><title></title></head><body>";
			var footstr = "</body>";

			var oldstr = document.body.innerHTML;
			document.body.innerHTML = headstr + footstr;
			window.print();
			document.body.innerHTML = oldstr;
			//window.location.href="sales-bill.php";

		} );
		window.onafterprint = function() {
		history.go(-1);
		};</script>
</body>
</body>

</html>