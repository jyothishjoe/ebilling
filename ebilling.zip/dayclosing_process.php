<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");

$resultop = $db->prepare("SELECT * FROM account_ledger WHERE company_tkn='$user_company'");
$resultop->execute();
for($i=0; $rowop = $resultop->fetch(); $i++){  
$open_balance_tot=$rowop['closing_balance'];
$ledger_name=$rowop['ledger_name'];
$trans_typ=$rowop['trans'];
}
$resulamount = $db->prepare("SELECT  SUM(debit_amt) AS dr_amt FROM transaction a LEFT JOIN account_ledger b ON a.ledger_name=b.ledger_name WHERE  a.trn_date='$today' AND b.trans='Dr' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company' ");
$resulamount->execute();
for($i=0; $rowsamount = $resulamount->fetch(); $i++){  
$dr=$rowsamount['dr_amt'];
}
$resulamount1 = $db->prepare("SELECT  SUM(credit_amt) AS cr_amt FROM transaction a LEFT JOIN account_ledger b ON a.ledger_name=b.ledger_name WHERE  a.trn_date='$today' AND b.trans='Cr' AND a.company_tkn='$user_company' AND b.company_tkn='$user_company'");
$resulamount1->execute();
for($i=0; $rowsamount1 = $resulamount1->fetch(); $i++){  
$cr=$rowsamount1['cr_amt'];
}

$date_set = $today;

?>

<div id="main" class="col-md-12 no-padding" style="width: 600px;  overflow: hidden;">
	<h3 class="text-center" id="h">Day Closing</h3>
	<style>
		#myProgress {
			width: 100%;
			background-color: #ddd;
		}
		
		#myBar {
			width: 10%;
			height: 15px;
			background-image: linear-gradient(to right, rgba(0, 255, 100, 0.00), rgba(0, 255, 124, 1.00));
			border-radius: 2px;
			text-align: center;
			line-height: 15px;
			color: white;
			box-shadow: 0 2px 3px rgba(0, 0, 0, 0.25) inset;
		}
	</style>

	<body>

		
		<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
			<div class="form-row">
				<div class="col-md-6 col-sm-6 col-xs-12 mb-1">
					<label for="" id='lab' class="control-label">Date</label>
					<input type="date" class="form-control" id="date" name="date"  value="<?php echo $date_set;?>">
					<input type="hidden" class="form-control" id="company" name="company"  value="<?php echo $user_company;?>">
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12 mb-1">
					<label for="" id='lab12' class="control-label">Time</label>
					<input type="text" class="form-control" id="time" name="date" readonly value="<?php echo $current_time;?>">
				</div>
		</div> 
			<div class="col-md-6" style="margin-top: 12px;">
			<div class="form-row">
				<table class="table table-bordered table-hover table-light" id='count1'>
					<tr>
						<td><strong style="font-weight: 600px;">Counter</strong></td>
						<td><strong style="font-weight: 600px;">User</strong></td>
					</tr>
					<?php $curren_user = $db->prepare("SELECT * FROM admin_user_log a LEFT JOIN admin_user b ON a.user_token=b.user_tkn WHERE a.in_date='$today' AND a.logout_as='' GROUP BY a.user_token");
					$curren_user->execute();
					for($i=0; $rows_curren_user = $curren_user->fetch(); $i++){  
					$users=$rows_curren_user['user_username']; $counter=$rows_curren_user['counter']; ?>
					<tr>
						<td><h5 id='current2'><strong ><?php echo $counter; ?></strong></h5></td>
						<td><h5 id='current1'><strong ><?php echo $users; ?></strong></h5></td>
					</tr>
					<?php } ?>	
				</table>
			</div>
			<div class="form-row">
				<div class="col-md-12" id="margin" >
					<div class="vd" style="position: inherit; left: 427px;">
					<a href="javascript: save_user()" id="save_user" class="btn btn-sm btn-info">Submit</a>
					<a href="#" class="btn btn-sm  btn-danger" id="close_fbx">Close</a>
					</div>
				</div>
			</div>
		</form>
		</div>
		<div class="col-md-12" id="respond"></div>
		<script> 
		  $( '#close_fbx' ) . on( 'click', function () {parent . jQuery . fancybox . close();} );

		  function save_user() {
		  	var date = $( "#date" ) . val();
		  	$ . ajax({
		  		type: 'POST',
		  		url: 'accounts/dayclosing.php',
		  		data: "date=" + date,
		  		success: function ( r ){
		  		$( "#respond" ) . html( r );
		  		}
		  	});
			  
		
		}
</script>