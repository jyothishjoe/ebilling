<?php include("php_fn/basic.php");?>
<?php include("datetime_creation/datetime_creation.php"); include('db-connect/db2.php');?>
<html>
<title></title>
<head> 

<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	
	<link href="css/style.css" rel="stylesheet">
<style>

</style></head>
<body onLoad="window.print()" onfocus="window.close()">

<div class="row">
                    <div class="col-md-12">
                      <div class="card card-body">
                            <h3><b>Bill No</b> <span class="pull-right">#5669626</span></h3>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="text-center">
                                        <address>
                                            <h3> &nbsp;<b class="text-danger">Material Pro Admin</b></h3>
                                            <p class="text-muted m-l-5">E 104, Dharti-2,
                                                <br/> Nr' Viswakarma Temple,
                                              
                                        </address>
                                    </div>
                                    <div class="pull-right text-left">
                                        <address>
                                           
                                            <h4 class="font-bold">Gaala & Sons,</h4>
                                            <p class="text-muted m-l-30">E 104, Dharti-2,
                                                <br/> Nr' Viswakarma Temple,
                                                <br/> Talaja Road,
                                                <br/> Bhavnagar - 364002</p>
                                            <p class="m-t-30"><b>Sales Order Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2017</p>
                                            
                                        </address>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="table-responsive m-t-40" style="clear: both;">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">#</th>
                                                    <th>Description</th>
                                                    <th class="text-right">Quantity</th>
                                                    <th class="text-right">Unit Cost</th>
                                                    <th class="text-right">Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                 <?php       
                            $result= $db->prepare("SELECT * FROM sales_invoice_prdct_detail ");
							$result->execute();
							for($i=0; $rows= $result->fetch(); $i++){
								$id = $rows['id'];
								$prdct_tkn = $rows['prdct_tkn'];
								$qty = $rows['qty'];
								$rate = $rows['rate'];
								$amount = $rows['amount'];
							  
							   
								
					    ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $id;?></td>
                                                    <td><?php echo $prdct_tkn;?></td>
                                                    <td class="text-right"><?php echo $qty;?> </td>
                                                    <td class="text-right"><?php echo $rate;?></td>
                                                   <td class="text-right"><?php echo $amount;?></td>
                                                </tr>
                                               
							<?php }?>
                                               
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="pull-right m-t-30 text-right">
                                        <p>Sub - Total amount: $13,848</p>
                                        <p>vat (10%) : $138 </p>
                                        <hr>
                                        <h3><b>Total :</b> $13,986</h3>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="text-right">
                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                        <button  class="btn btn-default btn-outline" type="button" onclick="printFn()" title="print"> <span><i class="fa fa-print"></i> Print</span> </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
</body>
</html>