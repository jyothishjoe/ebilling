<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$order_no = $_POST[ 'order_no' ];
$result_purch_order = $db->prepare( "SELECT * FROM   purchaseorder_productdetails  WHERE po_no = '$order_no'" );
$result_purch_order->execute();
$rows_order = $result_purch_order->fetch();
$rows_count = $result_purch_order->rowcount();
if ( $rows_count > 0 ) {
	?>

	<table class="table table-bordered" style="min-width: 1100px;">
		<thead>
			<tr>
				<th style="width: 58px;">Sl No</th>
				<th style="width: 100px;">Code</th>
				<th style="width: 135px;">Item Name</th>
				<th style="width: 135px;">Location</th>
				<th style="width: 75px;">Batch</th>
				<th style="width: 75px;">Expairy</th>
				<th style="width: 75px;">HSN</th>
				<th style="width: 100px;">Unit</th>
				<th style="width: 85px;">Rate</th>
				<th style="width: 70px;">GST%</th>
				<th style="width: 75px;">Qty</th>
				<th style="width: 70px;">Disc%</th>
				<!--<th>Gross</th>
			<th>GST</th>
			<th>Other Tax</th>-->
				<th style="width: 140px;">Total</th>
				<th style="float: right;"><input type="button" id="addmore" name="button" class="btn btn-sm btn-info" value="+">
					</button>
				</th>
			</tr>
		</thead>
		<tbody id="purchase">
			<?php
			$k = 1;
			$result_purch_order = $db->prepare( "SELECT * FROM   purchaseorder_productdetails  WHERE po_no = '$order_no'" );
			$result_purch_order->execute();
			for ( $i = 0; $rows_order = $result_purch_order->fetch(); $i++ ) {
				$rows_count = $result_purch_order->rowcount();
				$pr_code = $rows_order[ 'pr_code' ];
				$result_taxable = $db->prepare( "SELECT * FROM   product_master a LEFT JOIN account_ledger b ON a.purch_ledger=b.ledger_token WHERE a.pr_code='$pr_code'" );
				$result_taxable->execute();
				for ( $i1 = 0; $rows_taxable = $result_taxable->fetch(); $i1++ ) {
					$gst = $rows_taxable[ 'tax_type' ];
					$ledger_token = $rows_taxable[ 'ledger_token' ];
					$ledger_name = $rows_taxable[ 'ledger_name' ];
				}
				?>
			<tr class='tr_input'>
				<td><input type='text' style="width: 40px;" class="form-control serial" name="serial" id='serial_<?php echo $i+1; ?>' value="<?php echo $i+1; ?>" placeholder='Product Code'>
					<input type="hidden" name="check" id="check" value="<?php echo $rows_count; ?>">
				</td>
				<td><input type='text' class="form-control code" name="code[]" id='code_<?php echo $i+1; ?>' placeholder=' Code' value="<?php echo $rows_order['pr_code'];?>">
				</td>
				<td><input type='text' class="form-control name" name="name[]" id='name_<?php echo $i+1; ?>' placeholder='Product Name' value="<?php echo $rows_order['pr_name'];?>">
				</td>
				<td><input type='text' class="form-control location_name" id="location_name_<?php echo $i+1; ?>" name="location_name[]">
					<input type='hidden' class="form-control location_tkn" id="location_tkn_<?php echo $i+1; ?>" name="location_tkn[]">
				</td>
				<td><input type='text' class="form-control batch" name="batch[]" id='batch_1' placeholder='Batch'>
				</td>
				<td><input type='date' class="form-control expairy" name="expairy[]" id='expairy_<?php echo $i+1; ?>'>
				</td>
				<td><input type='text' class="form-control hsn" name="hsn[]" id='hsn_<?php echo $i+1; ?>' placeholder='HSN' value="<?php echo $rows_order['pr_hsn']; ?>">
				</td>
				<td><input type='text' class="form-control unit" name="unit[]" id='unit_<?php echo $i+1; ?>' placeholder='Unit' value="<?php echo $rows_order['unit'];?>">
				</td>
				<td><input type='text' class="form-control purchprice" name="purchprice[]" id='purchprice_<?php echo $i+1; ?>' placeholder='Purchase Price' value="<?php echo $rows_order['price'];?>">
				</td>
				<td><input type='text' class="form-control gstin" name="gstin[]" id='gstin_<?php echo $i+1; ?>' placeholder='GST%' value="<?php echo $gst; ?>">
					<input type='hidden' class="form-control gstinperc" name="gstinperc[]" id='gstinperc_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstincgst" name="gstincgst[]" id='gstincgst_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstincgstamt" name="gstincgstamt[]" id='gstincgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control gstinsgstamt" name="gstinsgstamt[]" id='gstinsgstamt_<?php echo $i+1; ?>' placeholder='GST%'>
					<!--Other Tax Amounts-->
					<input type='hidden' class="form-control othertax_amount1" name="othertax_amount1[]" id='othertax_amount1_<?php echo $i+1; ?>' value="0">
					<input type='hidden' class="form-control othertax_amount2" name="othertax_amount2[]" id='othertax_amount2_<?php echo $i+1; ?>' value="0">
					<input type='hidden' class="form-control othertax_amount3" name="othertax_amount3[]" id='othertax_amount3_<?php echo $i+1; ?>' value="0">
					<input type='hidden' class="form-control othertax_amount4" name="othertax_amount4[]" id='othertax_amount4_<?php echo $i+1; ?>' value="0">
					<input type='hidden' class="form-control othertax_amount5" name="othertax_amount5[]" id='othertax_amount5_<?php echo $i+1; ?>' value="0">
					<!--IGST-->
					<input type='hidden' class="form-control igstamt" name="igstperc[]" id='igstperc_<?php echo $i+1; ?>' placeholder='GST%'>
					<input type='hidden' class="form-control igstamt" name="igstamt[]" id='igstamt_<?php echo $i+1; ?>' placeholder='GST%'>
					<!--Taxable Non Taxable-->

					<input type='hidden' class="form-control purchase_token" name="purchase_token[]" id='purchase_token_<?php echo $i+1; ?>' value="<?php echo $ledger_token; ?>">
					<input type='hidden' class="form-control ledger_name" name="ledger_name[]" id='ledger_name_<?php echo $i+1; ?>' value="<?php echo $ledger_name; ?>">
					<!--Other Tax -->
					<?php 
					 $result_other_tax = $db->prepare("SELECT * FROM product_master_taxdetails WHERE pr_code = '$pr_code'");
					 $result_other_tax->execute();
					 for($i1=0; $rows_other_tax = $result_other_tax->fetch(); $i1++){  $o_tax_type=$rows_other_tax['o_tax_type']; $o_tax_rate=$rows_other_tax['tax_rate'];?>
					<input type='hidden' class="form-control othertax_amt<?php echo $i1+1; ?>" name="othertax_amt<?php echo $i1+1; ?>[]" id='othertax_amt<?php echo $i1+1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_rate; ?>">
					<input type='hidden' class="form-control othertax_typ<?php echo $i1 + 1; ?>" name="othertax_typ<?php echo $i1 + 1; ?>[]" id='othertax_typ<?php echo $i1 + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_type;  ?>">
					<?php } for($i2=$i1; $i2<=4;  $i2++){ $o_tax_type=0; $o_tax_rate=0;?>

					<!--Other Tax Type-->
					<input type='hidden' class="form-control othertax_amt<?php echo $i2+1; ?>" name="othertax_amt<?php echo $i2+1; ?>[]" id='othertax_amt<?php echo $i2+1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_rate; ?>">
					<input type='hidden' class="form-control othertax_typ<?php echo $i2 + 1; ?>" name="othertax_typ<?php echo $i2 + 1; ?>[]" id='othertax_typ<?php echo $i2 + 1; ?>_<?php echo $i+1; ?>' value="<?php echo $o_tax_type;  ?>">
					<?php } ?>
				</td>
				<td><input type='text' class="form-control qty" name="qty[]" id='qty_<?php echo $i+1; ?>' placeholder='Qty' value="<?php echo $rows_order['qty']; ?>" </td>
					<td><input type='text' class="form-control discount" name="discount[]" id='discount_<?php echo $i+1; ?>' placeholder='Discount'>
						<input type='hidden' class="form-control discounttotal" name="discounttotal" id='discounttotal_<?php echo $i+1; ?>' placeholder='Discount'>
						<input type='hidden' class="form-control totalcost" name="totalcost[]" id='totalcost_<?php echo $i+1; ?>' placeholder=''>
						<input type='hidden' class="form-control unitprice" name="unitprice[]" id='unitprice_<?php echo $i+1; ?>' placeholder=''>

						<input type='hidden' class="form-control gross" name="gross[]" id='gross_<?php echo $i+1; ?>' placeholder='Gross'>
						<input type='hidden' class="form-control gst" name="gst[]" id='gst_<?php echo $i+1; ?>' placeholder='GST'>
						<input type='hidden' class="form-control taxrate_amount" name="taxrate_amount[]" value="0" id='taxrate_amount_<?php echo $i+1; ?>'>
					</td>
					<td>
						<input type='text' class="form-control total" name="total[]" id='total_<?php echo $i+1; ?>' placeholder='Total'>
						<input type='hidden' class="form-control totalt" name="totalt" id='totalt_<?php echo $i+1; ?>' placeholder='Unit Cost'>
					</td>
					<td></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
	<table class="table">
		<tr>
			<td align="right" class="control-label">Discount:</td>
			<td width="70">
				<input type="text" readonly class="form-control" name="discountt" id="discountt" placeholder="Discount" style="width:120px;">
				<input type="hidden" readonly class="form-control" name="discounttt" id="discounttt" placeholder="Discount" value="0" style="width:120px;">
			</td>
			<td align="right" class="control-label">GST Total:</td>
			<td width="50"><input type="text" readonly class="form-control totalgst" name="totalgst" id="totalgst">
			</td>

			<td align="right" class="control-label">Grand Total:</td>
			<td width="150"><input type="text" readonly class="form-control totalprice" name="totalprice" id="totalprice">
			</td>
		</tr>
		<tr>
			<td style=" font-stretch:expanded;" align="right" class="control-label">Freight:</td>
			<td width="100">
				<input type="text" value="0" class="form-control" name="coolie" id="coolie" placeholder="Coolie" style="width:120px;">
				<input type="hidden" value="0" class="form-control" name="qtyt" id="qtyt" placeholder="Qtytotal" style="width:120px;">
				<input type="hidden" value="0" class="form-control" name="fright" id="fright" placeholder="frighttotal" style="width:120px;">
			</td>
			<td style=" font-stretch:expanded;" align="right" class="control-label">Other Tax:</td>
			<td width="50">
				<!--Other Tax  Total SUM-->
				<input type="text" readonly class="form-control other_tax_total_amount" name="other_tax_total_amount" id="other_tax_total_amount" value="0">
				<input type="hidden" readonly class="form-control taxable" name="taxable" id="taxable">
				<input type="hidden" readonly class="form-control nontaxable" name="nontaxable" id="nontaxable">
			</td>
			<td align="right" class="control-label">Net Amount:</td>
			<td width="100"><input type="text" readonly class="form-control" value="0" name="gtotalprice" id="gtotalprice" placeholder="Grant Total" style="width:150px;">
			</td>
			<tr id="show1" style="">
				<td align="right" class="control-label">Balance:</td>
				<td style="width:150px;"><input type="text" readonly class="form-control" name="balance_amt" id="balance_amt" placeholder="Balance" value="0" style="width:120px;">
					<td align="right" class="control-label">Paid Amount:</td>
					<td width="100"><input type="text" class="form-control" name="paidamount" id="paidamount" placeholder="Paid Amount" value="0" style="width:150px;">
						<td align="right" class="control-label">Pay Mode:</td>
						<td width="100">
							<select class="form-control" id="paymode" name="paymode" style="width: 100%; height:33px;">
								<option value="cash">Cash</option>
								<option value="bank">Bank</option>
							</select>
						</td>
					</td>
			</tr>
		</tr>
		<tr>
			<td align="right" class="control-label"></td>
			<td width="100"><input type="hidden" readonly class="form-control" value="0" name="balance" id="balance" placeholder="Balance" style="width:120px;">
			</td>
			<td align="right" class="control-label"></td>
			<td width="150">
			</td>
		</tr>
	</table>

	<script type="text/javascript">
		//=================================================
		/*Auto calculate On load Data */
		//=================================================
		$( document ).ready( function () {

			$( function () {
				var e = $.Event( "keydown" );
				e.which = 17;
				$( '.code' ).trigger( e );
			} );
			$( '.code' ).on( 'keypress', function ( e ) {
				if ( e.which == 17 )
					console.log( 'j' );
			} );
			$( function () {
				var e = $.Event( "keyup" );
				e.which = 17;
				$( '.qty' ).trigger( e );
			} );
			$( '.qty' ).on( 'keypress', function ( e ) {
				if ( e.which == 17 )
					console.log( 'j' );
			} );
		} );
		// Add more With Button
			$('#addmore').click(function (){
				
				// Get last id 
				var lastname_id = $('.tr_input input[type=text]:nth-child(1)').last().attr('id');
				var split_id = lastname_id.split('_');
				// New index
				var index = Number(split_id[1]) + 1;
				
				// Create row with input elements
				var html = "<tr class='tr_input'><td><input type='text' tabindex='-1' class='form-control serial' style='width: 40px;' name='serial' value=" + index + "  id='serial_" + index + "' placeholder=''></td><td><input type='text' class='form-control code' name='code[]'  id='code_" + index + "' placeholder=' Code'></td><td><input type='text' class='form-control name' name='name[]' id='name_" + index + "' placeholder='Product Name' ></td><td><input type='text' class='form-control location_name' id='location_name_" + index +"' name='location_name[]' ><input type='hidden' class='form-control location_tkn' id='location_tkn_" + index +"' name='location_tkn[]' ></td><td><input type='text' class='form-control batch' name='batch[]' id='batch_" + index + "' placeholder='Batch'></td><td><input type='date' class='form-control expairy' name='expairy[]' id='expairy_" + index +"'></td><td><input type='text' class='form-control hsn' name='hsn[]' id='hsn_" + index + "' placeholder='HSN' ></td><td><input type='text' class='form-control unit' name='unit[]' id='unit_" + index + "' placeholder='Unit' ></td><td><input type='text' class='form-control  purchprice' placeholder='Purchase Price' name='purchprice[]' id='purchprice_" + index + "' ></td><td><input type='text' placeholder='GST%'  class='form-control gstin' name='gstin[]' id='gstin_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstinperc' name='gstinperc[]' id='gstinperc_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstincgst' name='gstincgst[]' id='gstincgst_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstincgstamt' name='gstincgstamt[]' id='gstincgstamt_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control gstinsgstamt' name='gstinsgstamt[]' id='gstinsgstamt_" + index + "' ><input type='hidden' class='form-control othertax_amount1' name='othertax_amount1[]' id='othertax_amount1_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amount2' name='othertax_amount2[]' id='othertax_amount2_" + index +"' value='0'><input type='hidden' class='form-control othertax_amount3' name='othertax_amount3[]' id='othertax_amount3_" + index +"' value='0' ><input type='hidden' class='form-control othertax_amount4' name='othertax_amount4[]' id='othertax_amount4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amount5' name='othertax_amount5[]' id='othertax_amount5_" + index + "' value='0' ><input type='hidden' placeholder='GST%'  class='form-control igstperc' name='igstperc[]' id='igstperc_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control igstamt' name='igstamt[]' id='igstamt_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control purchase_token' name='purchase_token[]' id='purchase_token_" + index + "' ><input type='hidden' placeholder='GST%'  class='form-control ledger_name' name='ledger_name[]' id='ledger_name_" + index + "' ><input type='hidden' class='form-control othertax_amt1' name='othertax_amt1[]' id='othertax_amt1_" + index + "' placeholder='Gst Cess %' value='0'><input type='hidden' class='form-control othertax_amt2' name='othertax_amt2[]' id='othertax_amt2_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt3' name='othertax_amt3[]' id='othertax_amt3_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt4' name='othertax_amt4[]' id='othertax_amt4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_amt5' name='othertax_amt5[]' id='othertax_amt5_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ1' name='othertax_typ1[]' id='othertax_typ1_" + index + "' value='0'><input type='hidden' class='form-control othertax_typ2' name='othertax_typ2[]' id='othertax_typ2_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ3' name='othertax_typ3[]' id='othertax_typ3_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ4' name='othertax_typ4[]' id='othertax_typ4_" + index + "' value='0' ><input type='hidden' class='form-control othertax_typ5' name='othertax_typ5[]' id='othertax_typ5_" + index + "' value='0' ></td><td><input type='text'  class='form-control qty' placeholder='Qty' name='qty[]' id='qty_" + index + "' ></td><td><input type='text' placeholder='Discount'  class='form-control discount' name='discount[]' id='discount_" + index + "' ><input type='hidden' placeholder='Discount'  class='form-control discounttotal' name='discounttotal' id='discounttotal_" + index + "' ><input type='hidden' placeholder=''  class='form-control totalcost' name='totalcost[]' id='totalcost_" + index + "' ><input type='hidden' placeholder=''  class='form-control unitprice' name='unitprice[]' id='unitprice_" + index + "' ><input type='hidden' placeholder='gross'  class='form-control gross' name='gross[]' id='gross_" + index + "' ><input type='hidden' placeholder='GST' class='form-control gst' name='gst[]' id='gst_" + index + "' ><input type='hidden' class='form-control taxrate_amount' name='taxrate_amount[]' value='0' id='taxrate_amount_" + index + "'></td><td><input type='text'  class='form-control total' name='total[]' placeholder='Total' id='total_" + index + "' ></td><td><input type='hidden'  class='form-control totalt' name='totalt' placeholder='Unit Price' id='totalt_" + index + "' ><input type='button' id='delete' name='button' class='btn btn-sm btn-danger delete' value='-'></button></td></tr>";
				// Append data
				$('#code_' + index).focus();
				$('#purchase').append(html);
				$(document).on('click', '.delete', function (){
					$('#code_' + index).focus()
					$(this).closest('tr').remove();
					$('#total_' + index).val() - $('#total_' + index).val();
				});
			});
	</script>
	<script>
		$.toast( {
			heading: 'Purchase Order Data.',
			text: '',
			position: 'top-right',
			loaderBg: '#F13109',
			icon: 'success',
			hideAfter: 1200
		} );
	</script>
	<?php } else { setcookie("SC", true, time() + (3), "/"); ?>
	<script>
		window.location.reload();
	</script>
	<?php } ?>