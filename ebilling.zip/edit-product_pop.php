<?php
include( 'include/auth.php' );
include( 'db-connect/db.php' );
include( 'include/today.php' );
$token=$_GET['edit'];
$user_company=$_SESSION['SESS_COMPANY_ID'];
$result_product = $db->prepare( "SELECT * FROM product_master WHERE pr_token='$token' AND company_tkn='$user_company'" );
$result_product->execute();
$rows_product = $result_product->fetch();
$userid = $_SESSION[ 'SESS_USERID_AS' ];
$sales_ledger_token=$rows_product['sales_ledger'];
$purchase_ledger_token=$rows_product['purch_ledger'];
$ledger_token_token=$rows_product['purch_ledger'];
$sales_token=$rows_product['sales_ledger'];
$result_ledger1 = $db->prepare( "SELECT * FROM account_ledger WHERE ledger_token='$ledger_token_token' AND company_tkn='$user_company' " );
$result_ledger1->execute();
$rows_ledger1 = $result_ledger1->fetch();
$ledger_name=$rows_ledger1['ledger_name'];

$result_ledger12 = $db->prepare( "SELECT * FROM account_ledger WHERE ledger_token='$sales_token' AND company_tkn='$user_company' " );
$result_ledger12->execute();
$rows_ledger12 = $result_ledger12->fetch();
$sales_ledger=$rows_ledger12['ledger_name'];
?>
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-ui.min.js"></script>
<style>
	
fieldset{
	margin-top:17px; border: 1px solid #999; font-size:12px; padding:0px 10px;}
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
	ul, li{
	z-index:9999 !important;  
    width: 180px;
    max-height:150px;/*The important part*/
    overflow-y:auto;/*Also...*/
    overflow-x:hidden;/*And the end of the important part*/
    margin: 0px;
    padding-left:5px;/*Removing the large whitespace to the left of list items*/
    border: 1px solid black;
	}
	#close_fbx { margin: 0px; position: relative;  background: #f2382c !important; color: #fff; opacity: 1; width: 60px; font-size: 12px; height: 28px;  line-height: 0px; padding: 0px !important; display: inline; }
#close_fbx:hover {background: #f2382c !important;}
</style>
<div id="custom-content" class="col-md-10 col-sm-6 col-xs-12" style="margin: 50px auto; overflow: hidden;  background-color: #ffffff;">
	<div class="col-md-12" style="margin-bottom: 10px; margin-top: 12px;">
		<h3 align="center">Add Product</h3>
	</div>
	<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
	  <input type="hidden" name="addby" value="<?php echo $userid; ?>"/>
		<input type="hidden" name="company" value="<?php echo $user_company; ?>"/>
	<div class="row">
		<!-- .main -->
		<div class="col-md-7 col-sm-6">
			<div class="card card-body">
				<div class="row">
					<div class="col-md-4 col-sm-3 text-center">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Product Code</label>
							<div class="col-12">
								<input type="text" name="pr_code" id="pr_code" class="form-control textbox" value="<?php echo $rows_product['pr_code']; ?>" readonly>
								<input type="hidden" name="token" id="token" class="form-control textbox" value="<?php echo $token; ?>" readonly>
								<div id="uname_response" class="response"></div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">Product Name</label>
								<div class="col-12">
									<input type="text" name="name" id="name" class="form-control" value="<?php echo $rows_product['pr_name']; ?>" >
								</div>
							</div>
						</div>
						<div class="col-md-6  col-sm-6 col-xs-12">
								<div class="form-group row">
									<label for="validationTooltip01" class="control-label col-12">Brand</label>
									<div class="col-12">
										<input type="text" class="form-control" id="brand" name="brand" value="<?php echo $rows_product['brand']; ?>">
									</div>
								</div>
							</div>
						<div class="col-md-3 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Sub Category</label>
								<div class="col-12">
									<select class="form-control select2" id="subcatname" name="subcatname" style="width: 100%; height:36px;">
										<option value="<?php echo $rows_product['sub_cat']; ?>"><?php echo $rows_product['sub_cat']; ?></option>
										<?php
										$result_cat = $db->prepare( "SELECT * FROM pr_subcategory WHERE company_tkn='$user_company'");
										$result_cat->execute();
										for ( $i = 0; $rows_cat = $result_cat->fetch(); $i++ ){
											$sub_cat = $rows_cat[ 'sub_catname' ];
											?>
										<option value="<?php echo $sub_cat; ?>">
											<?php echo $sub_cat; ?>
										</option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">Product Category</label>
								<div class="col-12">
									<input type="text" tabindex='-1' class="form-control" name="cat_name" value="<?php echo $rows_product['cat_name']; ?>" id="cat_name" readonly>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">Unit</label>
								<div class="col-12">
									<input type="text" tabindex='-1' class="form-control" name="unit" value="<?php echo $rows_product['pr_unit']; ?>" id="unit" readonly>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">HSN</label>
								<div class="col-12">
									<input type="text" class="form-control" name="hsn" id="hsn" value="<?php echo $rows_product['pr_hsn']; ?>">
									<div id="uname_response" class="response"></div>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label  col-12">Mrp</label>
								<div class="col-12">
									<input type="text" class="form-control" name="hsn" id="hsn" value="<?php echo $rows_product['pr_mrp']; ?>">
									<div id="uname_response" class="response"></div>
								</div>
							</div>
						</div>
					 <div class="col-md-12 text-left">
					 <div class="row">
					 
					 <div class="col-md-12">
				  <fieldset>
				<legend class="control-label" style="margin-left:30px; width: 80px; font-size:15px; padding-left:7px;">Other Tax</legend>
                 <div class="table-responsive col-md-12 col-sm-12 col-xs-12" style="height:140px; overflow-y:auto;">
                    <table border='0' class="table table-bordered  mb-0" id="sales_data">
                      <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>Tax Types</th>
                          <th>Tax Rate</th>
                          <th><input type="button" id="salesaddmore" name="button" class="btn btn-sm btn-info" value="+">
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody id="sales">
                       <?php 
						$sl=0;
					  	$result1 =$db->prepare("SELECT * FROM  product_master_taxdetails WHERE product_tkn='$token' ");
						$result1->execute();
						while($row1 = $result1->fetch()){
						  ?>
                        <tr class='tr_input'>
                          <td width="50"><input type='text' class="form-control aslno" name="aslno[]" id='aslno_<?php echo $sl+1; ?>' value="1"></td>
                          <td><input type='text' class="form-control taxtype" name="taxtype[]" id='taxtype_<?php echo $sl+1; ?>' value="<?php echo $row1['o_tax_type']; ?>" placeholder='Tax Types'><input type='hidden' class="form-control tax_tkn" name="tax_tkn[]" id='tax_tkn_<?php echo $sl+1; ?>' value="<?php echo $row1['tax_tkn']; ?>" placeholder='Tax tkn'>
                          <input type='hidden' class="form-control tax_pref1" name="tax_pref1[]" id='tax_pref1_<?php echo $sl+1; ?>' value='<?php echo $sl+1; ?>' placeholder='Tax tkn'>
                          <input type='hidden' class="form-control tax_pref2" name="tax_pref2[]" id='tax_pref2_<?php echo $sl+1; ?>' value="<?php echo $sl+1; ?>" placeholder='Tax tkn'>
                          </td>
                          <td width="120"><input type='text' class="form-control taxrate" name="taxrate[]" id='taxrate_<?php echo $sl+1; ?>' value="<?php echo $row1['tax_rate']; ?>" placeholder='Tax Rate' readonly></td>
                          <td><input type='button' id='adelete_1' name='button' class='btn btn-sm btn-danger adelete' value='x' style="display:none;">
                           </button></td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
				</fieldset>
				</div></div>
				  </div>
	
					</div>
				</div>
		<!--	<fieldset>
				<legend class="control-label" style="margin-left:30px; width: 90px; font-size:15px; padding-left:7px; ">Stock Details</legend>
				<div class="row">
				
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Min Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="min" id="min" placeholder="Minimum Stock" value="">
								<input type="hidden" class="form-control" name="dat" value="<?php echo $today; ?>">
								<input type="hidden" class="form-control" name="time" value="<?php echo $current_time; ?>">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Max Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="max" id="max" placeholder="Maximum Stock" value="">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Op Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="opstock" id="opstock" placeholder="Opening Stock" >
							</div>
						</div>
					</div>
				</div>
			</fieldset>-->
			</div>
			<!--Stock-->
		</div>
		<!-- .secondry -->
		<div class="col-md-5 col-sm-6 text-left">
		<fieldset>
				<legend class="control-label" style="margin-left:30px; width: 90px; font-size:15px; padding-left:7px; ">Stock Details</legend>
				<div class="row">
					 <div class="col-md-12">
					  <div class="row">
				  		<div class="col-md-4 col-sm-6">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Gst Rate</label>
							<div class="col-12">
								<select class=" form-control select2" id="tax" name="tax" style="width: 100%; height:36px;">
									<option value="<?php echo $rows_product['tax_type']; ?>"><?php echo $rows_product['tax_type']; ?></option>
									 <?php
									$result =$db->prepare("SELECT * FROM  gst_tax WHERE company_tkn='$user_company'");
									$result->execute();
									while($row = $result->fetch()){
									?>
									<option value="<?php echo $row['gst_rate'];?>"><?php echo $row['gst_rate'];?>%</option>
									<?php } ?>
								</select>
							</div>
						</div>
					</div>
					 <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12">Selling Price</label>
								<div class="col-12">
									<input type="text" class="form-control" name="sellingprice" id="sellingprice" placeholder="Selling Price" value="<?php echo $rows_product['selling_price']; ?>">
								</div>
							</div>
						</div>
						  <div class="col-md-4 col-sm-6">
							<div class="form-group row">
								<label for="validationTooltip01" class="control-label col-12" style="font-size: 14px;">Purchase Rate</label>
								<div class="col-12">
									<input type="text" class="form-control" name="purchase_price" id="purchase_price" placeholder="Purchase Price" value="<?php echo $rows_product['purchase_price']; ?>">
								</div>
							</div>
						</div>
					  </div>
				  </div>
				  <div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Min Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="min" id="min" placeholder="Minimum Stock" value="<?php echo $rows_product['min_stock']; ?>">
								<input type="hidden" class="form-control" name="dat" value="<?php echo $today; ?>">
								<input type="hidden" class="form-control" name="time" value="<?php echo $current_time; ?>">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Max Stock</label>
							<div class="col-12">
								<input type="text" class="form-control" name="max" id="max" placeholder="Maximum Stock" value="<?php echo $rows_product['max_stock']; ?>">
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Op Stock*</label>
							<div class="col-12">
								<input type="text" class="form-control" name="opstock" id="opstock" placeholder="Opening Stock" value="<?php echo $rows_product['pr_qty']; ?>" >
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Unit Rate*</label>
							<div class="col-12">
								<input type="text" class="form-control" name="opunit" id="opunit" placeholder="op stock Unit Rate*" value="<?php echo $rows_product['purchase_price']; ?>" >
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 mb-2" id="total_text">
						<div class="form-group row">
							<label for="validationTooltip01" class="control-label  col-12">Total Value</label>
							<div class="col-12">
								<input type="text" class="form-control" name="total_value" id="total_value" value="<?php echo $rows_product['total_value']; ?>" readonly >
							</div>
						</div>
					</div>
				</div>
			</fieldset>
		 <fieldset>
	  <legend class="control-label" style="margin-left:30px; width: 74px; font-size:15px; padding-left:7px;">Ledger</legend>
				<div class="row">
					<div class="col-md-6"><label for="validationTooltip01" class="col-12" style="text-align: center;">Purchase Ledger</label></div>
					<div class="col-md-6 col-sm-6 mb-2">
                  	<input type="hidden" class="form-control" name="purch_token" id="purch_token" placeholder="CGST">
	                  	<select class="form-control select2" id="purch_ledger" name="purch_ledger" style="width: 100%; height:36px;">
										<option value="<?php echo $ledger_token_token ?>"><?php echo $ledger_name; ?></option>
										<?php
										$result_ledger = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company'  " );
										$result_ledger->execute();
										for ( $i = 0; $rows_ledger = $result_ledger->fetch(); $i++ ) {
											$sub_cat = $rows_ledger[ 'ledger_name' ];
											?>
										<option value="<?php echo $sub_cat; ?>"><?php echo $sub_cat; ?></option><?php } ?>
									</select>
					
					</div>
					<div class="col-md-6"><label for="validationTooltip01" class="col-12" style="text-align: center;">Sales Ledger</label></div>
					<div class="col-md-6 col-sm-6 mb-2">
					<input type="hidden" class="form-control" name="sal_ledger" id="sal_ledger" placeholder="CGST">
						<select class="form-control select2" id="sales_ledger" name="sales_ledger" style="width: 100%; height:36px;">
										<option value="<?php echo $sales_token; ?>"><?php echo $sales_ledger; ?></option>
										<?php
										$result_ledger = $db->prepare( "SELECT * FROM account_ledger WHERE company_tkn='$user_company' " );
										$result_ledger->execute();
										for ( $i = 0; $rows_ledger = $result_ledger->fetch(); $i++ ) {
											$sub_cat = $rows_ledger[ 'ledger_name' ];
											?>
										<option value="<?php echo $sub_cat; ?>"><?php echo $sub_cat; ?></option>
										<?php } ?>
									</select>
					</div>
				</div>
				</fieldset>
			<div class="col-md-12" style="margin: 22px 0px;">
				<input type="submit" name="insert" id="insert" class="btn btn-info btn-sm" style="float: right; margin-bottom: 20px;" value="Insert">
				<button type="button" id="close_fbx" class="btn btn-sm btn-danger mfp-close" style="float: right; margin-right: 8px; margin-bottom: 20px;">Cancel</button>
			</div>
			<div class="col-12"></div>
		</div>
		</div>
		<div class="successmsg" id="sa-close"></div>
			<script>
				//Opening Stock Calculation
				$( "#total_text" ).hide();
				$( "#opunit" ).keyup( function (){
				var opstock = $( "#opstock" ).val();
				var opunit = $( "#opunit" ).val();
					$( "#total_text" ).show();
				var totalvalue = $( "#total_value" ).val(opstock * opunit);
				} );
				
				
				$( "#subcatname" ).change( function () {
				var subcat = $( "#subcatname" ).val();
			    $.ajax( {
				type: 'POST',
				url: 'product-action/subcat_change.php',
				data: 'subcat=' + subcat,
				dataType: "JSON",
				success: function ( data ) {
					$('#cat_name').val( data.sub_cat);
					$('#unit').val( data.unit);
						}
					} );
				} );
				$( "#purch_ledger" ).change( function (){
				var ledger = $( "#purch_ledger" ).val();
			    $.ajax( {
				type: 'POST',
				url: 'product-action/ledger_change.php',
				data: 'ledger=' + ledger,
				dataType: "JSON",
				success: function ( data ) {
					$('#purch_token').val( data.purch_token);
						}
					} );
				} );
				$( "#sales_ledger" ).change( function () {
				var sales_ledger = $( "#sales_ledger" ).val();
			    $.ajax( {
				type: 'POST',
				url: 'product-action/sales_ledger_change.php',
				data: 'sales_ledger=' + sales_ledger,
				dataType: "JSON",
				success: function ( data ) {
					$('#sal_ledger').val( data.purch_token);
					}
					});
				});
				$( document ).ready( function (){
					
					$( "#name" ).focus();
					$( "#pr_code" ).keyup( function () {
						var pr_code = $( "#pr_code" ).val().trim();
						if ( pr_code != '' ) {
							$( "#uname_response" ).show();
							$.ajax( {
								url: 'product-action/product_exist_search/productsearch.php',
								type: 'post',
								data: {
									pr_code: pr_code
								},
								success: function ( response ){
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in use.</span>" );
										$.toast( {heading: 'Already In Use',text: '',position: 'top-left',loaderBg: '#F13109',icon: 'error',hideAfter: 3500,hideMethod: 'fadeOut'
										});
										var dis1 = document.getElementById("pr_code");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("name").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										$.toast({heading: 'Available',text: '',position: 'top-left',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1000,hideMethod: 'fadeOut'});
										var dis1 = document.getElementById("pr_code");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("name").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
				
					$( document ).on( 'keydown', '.taxtype', function () {

			var id = this.id;
			var splitid = id.split( '_' );
			var index = splitid[ 1 ];

			$( '#' + id ).autocomplete( {
				source: function ( request, response ) {
					$.ajax( {
						url: "product-action/autocomplete_product/taxfill.php",
						type: 'post',
						dataType: "json",
						data: {
							search: request.term,
							request: 1
						},
						success: function ( data ) {
							response( data );
						}
					} );
				},
				select: function ( event, ui ) {
					$( this ).val( ui.item.label ); // display the selected text
					var tax = ui.item.value;
					// selected id to input
					// AJAX
					$.ajax( {
						url: 'product-action/autocomplete_product/taxfill.php',
						type: 'post',
						data: {
							tax: tax,
							request: 2
						},
						dataType: 'json',
						success: function ( response ){

							var len = response.length;

							if ( len > 0 ) {
								var taxtrate = response[ 0 ][ 'tax_rate' ];
								var taxt_tkn = response[ 0 ][ 'tax_token' ];
								var tax_pref1 = response[ 0 ][ 'tax_pref1' ];
								var tax_pref2 = response[ 0 ][ 'tax_pref2' ];
								
								document.getElementById( 'taxrate_' + index ).value = taxtrate;
								document.getElementById( 'tax_tkn_' + index ).value = taxt_tkn;
								document.getElementById( 'tax_pref1_' + index ).value = tax_pref1;
								document.getElementById( 'tax_pref2_' + index ).value = tax_pref2;
							
							}
						}
					} );
					return false;
				}
			} );
		 });
				$( window ).keydown( function ( event ){
				if ( event.keyCode == 107 ) {

					event.preventDefault();
					var lastname_id = $( '.tr_input input[type=text]:nth-child(1)' ).last().attr( 'id' );
					var split_id = lastname_id.split( '_' );
					// New index
					var index = Number( split_id[ 1 ] ) + 1;
					// Create row with input elements
					var html = "<tr class='tr_input'><td><input type='text' class='form-control aslno' name='aslno[]' value=" + index + " id='aslno_" + index + "'></td><td><input type='text' class='form-control taxtype' name='taxtype[]'  id='taxtype_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_tkn' name='tax_tkn[]'  id='tax_tkn_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_pref1' name='tax_pref1[]'  id='tax_pref1_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_pref2' name='tax_pref2[]'  id='tax_pref2_" + index + "' placeholder='Tax Types'></td><td><input type='text' class='form-control taxrate' name='taxrate[]'  id='taxrate_" + index + "' placeholder='Tax Rate' readonly></td><td><input type='button' id='adelete_" + index + "' name='button' class='btn btn-sm btn-danger adelete' value='x'></button></td></tr>";
				$( '#sales' ).append( html ); document.getElementById('taxtype_' + index).focus();
					// Append data
				$( document ).on( 'click', '.adelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
				$( this ).closest( 'tr' ).remove();
			} );
			}
			//$( '#account_1' + index ).focus();
		});	
					
				$( '#salesaddmore' ).click( function () {
				var lastname_id = $( '.aslno' ).last().attr( 'id' );
				var split_id = lastname_id.split( '_' );
				var index = Number( split_id[ 1 ] ) + 1;
			    var html = "<tr class='tr_input'><td><input type='text' class='form-control aslno' name='aslno[]' value=" + index + " id='aslno_" + index + "'></td><td><input type='text' class='form-control taxtype' name='taxtype[]'  id='taxtype_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_tkn' name='tax_tkn[]'  id='tax_tkn_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_pref1' name='tax_pref1[]'  id='tax_pref1_" + index + "' placeholder='Tax Types'><input type='hidden' class='form-control tax_pref2' name='tax_pref2[]'  id='tax_pref2_" + index + "' placeholder='Tax Types'></td><td><input type='text' class='form-control taxrate' name='taxrate[]'  id='taxrate_" + index + "' placeholder='Tax Rate' readonly></td><td><input type='button' id='adelete_" + index + "' name='button' class='btn btn-sm btn-danger adelete' value='x'></button></td></tr>";
				$( '#sales' ).append( html ); document.getElementById('taxtype_' + index).focus();
			} );
			$( document ).on( 'click', '.adelete', function () {
				var id = this.id;
				var splitid = id.split( '_' );
				var index = splitid[ 1 ];
				$( this ).closest( 'tr' ).remove();
			} );
			</script>
		
			<script>
					$('#close_fbx').on('click', function(){ parent.jQuery.magnificPopup.close(); });
				$( '#insert_form' ).on( 'submit', function ( event ) {
					event.preventDefault();
					var error = '';
					var form_data = $( this ).serialize();
					
					var name = $("#name").val();
					var cat_name = $("#cat_name").val();
					var unit = $("#unit").val();
					var hsn = $("#hsn").val();
					var tax = $("#tax").val();
					var min = $("#min").val();
					var max = $("#max").val();
					var sales_ledger = $("#sales_ledger").val();
					var purch_ledger = $("#purch_ledger").val();
					
					if ( name == ''  ){
                      $.toast( {heading: 'Enter Product Name.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500 } );
                    }else if (  cat_name == '' ){
                      $.toast( {heading: 'Choose a Category.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500} );
                    }else if (  unit == '' ){
                      $.toast( {heading: 'Choose Unit.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500} );
                    }else if (  hsn == '' ){
                      $.toast( {heading: 'Please Provide HSN.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500} );
                    }else if (  tax == '' ){
                      $.toast( {heading: 'Select Tax Rate.',text: '',position: 'top-right',loaderBg: '#F13109',icon: 'error',hideAfter: 1500} );
					}else{
						$.ajax( {
							url: "product-action/edit_product.php",
							method: "POST",
							data: form_data,
							success: function ( data ) {
								if (data == 'ok') {
									$.toast( {heading: 'Updated Successfully',text: '',position: 'top-right',loaderBg: '#4AD55E',icon: 'success',hideAfter: 1500,hideMethod: 'fadeOut'});
									//$(".successmsg").click();
									// parent.jQuery.magnificPopup.close();
								window.location.href="product-all.php";
								} 
							}
						} );
				    }
				 });
			//Short Cut Keys 
		$( window ) . keydown( function ( event ) {
			if ( event . keyCode == 173 ) {
				parent . jQuery . magnificPopup . close();

				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "product-category-popup.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event . keyCode == 174 ) {
				parent . jQuery . magnificPopup . close();

				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "create-subcategory.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event . keyCode == 175 ) {
				parent . jQuery . magnificPopup . close();

				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "create-unit.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event . keyCode == 122 ) {
				parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "add-gst.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
			if ( event . keyCode == 123 ) {
				parent . jQuery . magnificPopup . close();
				event.preventDefault();
				// $( "#custom-content" ).hide();
				setTimeout( function () {
					$ . fancybox . open( {
						href: "add-tax.php",
						type: 'ajax',
						closeBtn: false, // hide close button
						closeClick: false, // prevents closing when clicking INSIDE fancybox
						helpers: {
							// prevents closing when clicking OUTSIDE fancybox
							overlay: {
								closeClick: false
							}
						},

					} );
				}, 200 );
			}
		} );

			</script>