<?php 
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
include('db-connect/db.php');
include("php_fn/basic.php");
include("datetime_creation/datetime_creation.php");
?>
<?php 
$result =$db->prepare("SELECT * FROM  customer ORDER BY id DESC LIMIT 1");
$result->execute();
$rows=$result->fetch();
$cus_no=$rows['cus_no'] + 1;
$result =$db->prepare("SELECT * FROM  date_mask WHERE addby='$userid' ORDER BY id DESC LIMIT 1");
$result->execute();
$rows=$result->fetch();
$dateformate=$rows['dateformate'];
?>
<style>
.not-exists {
	color:#FF4633;
	margin-top:20px;
}
.exists {
	color:#34D908;
	margin-top:20px;
}
ul, li{z-index:9999 !important;}
</style>
<link rel="stylesheet" href="js/auto_js/jquery-ui.min.css">
<script src="js/auto_js/jquery-ui.min.js"></script>
<div id="custom-content"  class="col-md-8 col-sm-6 col-xs-12" style="margin: 50px auto; width:600px; padding-top:20px; overflow: hidden;  background-color: #f2f2f2;">
<h3 class="text-center">Add Customer</h3><br>
<form method="post" action="" class="forms" name="insert_form" id="insert_form" autocomplete="off">
  <div class="form-row">
      <input type="hidden" class="form-control date-inputmask" id="date_" name="date_"  value="<?php echo $today;?>" required>
    <input type="hidden" class="form-control" id="cus_no" name="cus_no" value="<?php echo $cus_no;?>" readonly>
    <input type="hidden" class="form-control"  id="addby" name="addby" value="<?php echo $userid;?>" readonly>
    <input type="hidden" class="form-control"  id="cus_tkn" name="cus_tkn" value="<?php echo create_token();?>" readonly>
    <input type="hidden" class="form-control"  value="<?php echo $current_date_time;?>" name="datetym"  id="datetym" readonly>
    <div class="col-md-12"></div>
    <div class="col-md-4 col-sm-6 col-xs-12  mb-3">
      <label for="" class="control-label">Account Name</label>
      <input type="text" class="form-control acco_name" name="acco_name" id="acco_name" placeholder="Enter Account Name" autofocus>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Customer Name</label>
      <input type="text" class="form-control cus_name" id="cus_name" name="cus_name" placeholder="Enter Customer Name">
	   <input type="hidden" class="form-control aco_tkn" id="aco_tkn" name="aco_tkn" placeholder="Enter Customer Name">
      <div id="uname_response" class="response"></div>
    </div>
    <div class="col-md-12 col-sm-6 col-xs-12 mb-3">
	<div class="row">
	<div class="col-md-4">
      <label for="" class="control-label">Address</label>
      <textarea class="form-control" id="addres" rows="4" name="addres" placeholder="Required address" ></textarea>
	</div>
	<div class="col-md-8">
	<div class="row">
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Location</label>
      <input type="text" class="form-control" id="location" name="location"   placeholder="Enter Location">
    </div>
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">State</label>
      <input type="text" class="form-control" id="state" name="state"   placeholder="Enter State">
    </div>
	 <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Contact No 1</label>
      <input type="text" class="form-control" id="contact_no1" name="contact_no1"  placeholder="Enter Contact Number">
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
      <label for="" class="control-label">Contact No 2</label>
      <input type="text" class="form-control" id="contact_no2" name="contact_no2"  placeholder="Enter Contact Number">
    </div>
	</div>
	</div>
    </div>
	</div>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
      <label for="" class="control-label">Credit Limit</label>
      <input type="text" class="form-control" name="credit_limit" id="credit_limit"  placeholder="Enter Credit Limit">
    </div>
  </div>
  <div class="text-right" style="margin-bottom:20px;"> <a href="javascript: save_user()" class="btn btn-sm  btn-info">Submit</a>
    <button type="button" id="close_fbx" class="btn btn-sm btn-danger pull-right">CANCEL</button>
  </div>
</form>
<script>
$( document ).ready( function () {
  $( document ).on( 'keydown keyup', '.acco_name', function () {
	  $( '#acco_name' ).autocomplete( {
					source: function ( request, response ) {
						$.ajax( {
							url: "creation_actions/customer/autosearch_customer/customer.php",
							type: 'post',
							dataType: "json",
							data: {
								search: request.term,
							},
							success: function ( data ) {
								response( data );
							}
						} );
					},
										select: function ( event, ui ) {
						$(  '#cus_name' ).val( ui.item.label ); // display the selected text
						$(  '#aco_tkn' ).val( ui.item.tkn );
						var acco_name = ui.item.value; // selected id to input
						$( ".cus_name" ).keyup();
										}
             });
			 var advcan = document.getElementById('acco_name' ).value;
		     if(advcan=='')	{
			  	document.getElementById('cus_name').value='';
				$( "#uname_response" ).hide();
		    }
  });	
	
	
	

$( "#cus_name" ).keyup( function () {
var cus = $( "#cus_name" ).val().trim();
if ( cus != '' ) {
$( "#uname_response" ).show();
$.ajax( {
url: 'creation_actions/customer/cusnamesearch.php',
type: 'post',
data: {
cus: cus
},
								success: function ( response ) {
									if ( response > 0 ) {
										$( "#uname_response" ).html( "<span class='not-exists'>*  Already in Exit.</span>" );
										document.getElementById("location").disabled = true;
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										   document.getElementById( 'location' ).value = '';
										  document.getElementById("location").disabled = true;
									   }
									}
									} else {
										$( "#uname_response" ).html( "<span class='exists'>Available.</span>" );
										
										var dis1 = document.getElementById("cus_name");
										 dis1.onchange = function () {
									   if (this.value != "" || this.value.length > 0) {
										  document.getElementById("location").disabled = false;
									   }
									}
									}
								}
							} );
						} else {
							$( "#uname_response" ).hide();
						}
					} );
				} );
			</script> 
<script>
					  $( '#close_fbx' ).on( 'click', function () {
		           parent.jQuery.magnificPopup.close();
	                 } );
          function save_user(){
			var cus_no = $("#cus_no").val();
			var aco_tkn = $("#aco_tkn").val();
			var addby = $("#addby").val();
			var datetym = $("#datetym").val();
			var acco_name = $("#acco_name").val();
			var cus_name = $("#cus_name").val();
			var cus_tkn = $("#cus_tkn").val();
			var location = $("#location").val();
			var addres = $("#addres").val();
			var contact_no1 = $("#contact_no1").val();
			var contact_no2 = $("#contact_no2").val();
			var credit_limit = $("#credit_limit").val();
			var sate = $("#state").val();
			var date_ = $("#date_").val();
			if($("#cus_name").val() == ""){$.toast( {heading: 'Fill customer name.',	text: '',position: 'top-right', loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500} );
			} else if($("#location").val() == ""){	$.toast( {	heading: 'Fill Location.',	text: '',	position: 'top-right',loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#addres").val() == ""){	$.toast( {	heading: 'Fill Address.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',icon: 'error',hideAfter: 1500	} );
			} else if($("#contact_no1").val() == ""){$.toast( {	heading: 'Fill Contact Number.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#contact_no2").val() == ""){	$.toast( {	heading: 'Fill Contact Number.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else if($("#credit_limit").val() == ""){	$.toast( {	heading: 'Fill credit limit.',	text: '',	position: 'top-right',	loaderBg: '#ff6849',	icon: 'error',	hideAfter: 1500	} );
			} else {	$.ajax({
	            	type : 'POST',
					url  : 'creation_actions/customer/customer_save.php',
					data: "cus_no="+ cus_no + "&date_=" + date_ + "&addby=" + addby + "&datetym=" + datetym + "&acco_name=" + acco_name + "&cus_name=" + cus_name + "&location=" + location + "&contact_no1=" + contact_no1 + "&contact_no2=" + contact_no2 + "&credit_limit=" + credit_limit + "&addres=" + addres + "&cus_tkn=" + cus_tkn + "&aco_tkn=" + aco_tkn + "&sate=" + sate,
					success : function(r) {						
						$("#respond").html(r);
					}
				});
			/*	parent.jQuery.magnificPopup.close();*/  document.getElementById( "insert_form" ).reset(); $( "#uname_response" ).hide();
				
												$.toast( {
													heading: 'Customer Add Succeccfully.',
													text: '',
													position: 'top-right',
													loaderBg: '#1FDE13',
													icon: 'success',
													hideAfter: 1000
												} );
				return false;
			}
		}

</script>