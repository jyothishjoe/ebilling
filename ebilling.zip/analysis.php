<?php
include ('include/auth.php');
$userid = $_SESSION['SESS_USERID_AS'];
$user_company = $_SESSION['SESS_COMPANY_ID'];
include( 'db-connect/db.php' );
include("datetime_creation/datetime_creation.php");
if(isset ($_GET['startdate'], $_GET['enddate'], $_GET['type'],  $_GET['maintype'],  $_GET['Months'],  $_GET['years'])){
    $maintype = $_GET['maintype'];
	$type = $_GET['type'];
	$startdate = $_GET['startdate'];
	$enddate = $_GET['enddate']; 
	$Months = $_GET['Months']; 
	$years = $_GET['years']; 
	
}else{
	$type='Select';
	$maintype='Day';
    $startdate =$today;
    $enddate=$today;
    $Months =$month;
	$years =$year; 

}
if(isset ($_GET['mainreport'])){
    
	$mainreport = $_GET['mainreport']; 
}else{
	
	$mainreport ='Normal';
}
if(isset ($_GET['sea_year'], $_GET['sea_name'],$_GET['setype'])){
	$season_name=strtolower($_GET['sea_name']);
	$season_year= $_GET['sea_year']; $setype= $_GET['setype']; 
}else{
	$season_name='Select Season';
	$season_year='Select Year'; $setype= 'Select';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" oncontextmenu="return false;" href="assets/images/favicon.png">
<title>Analytics </title>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/colors/default-dark.css" id="theme" rel="stylesheet">
<link href="assets/auto/all.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="assets/plugins/datatables/media/css/dataTables.bootstrap4.css">
<style>
fieldset { margin-top:17px; border: 1px solid #999; font-size:12px; padding:0px 10px; }
legend { margin-left:20px; width: 89px; font-size:12px; padding-left:7px; }
.container { display: inline; position: relative; padding-left: 20px; margin-bottom: 12px; cursor: pointer; font-size: 12px; bottom:5px; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; cursor: pointer; }
.checkmark { position: absolute; top: 0; left: 0; height: 15px; width: 15px; border:1px solid #666; border-radius: 50%; }
.container input:checked ~ .checkmark { background-color: #2196F3; }
.checkmark:after { content: ""; position: absolute; display: none; }
.container input:checked ~ .checkmark:after { display: block; }
.container .checkmark:after { top: 3px; left: 3px; width: 7px; height: 7px; border-radius: 50%; background: white; }
p { font-size:15px !important; color:#000 !important; text-align:center; padding:0px !important; line-height: 0 !important; }
h6 { font-size:10px !important; text-align:center !important; color:#000; }
.ct-svg-chartct-bar-chart { position: relative; }
.ct-bar-chart .ct-series-a .ct-bar, .ct-bar-charta .ct-series-a .ct-bar, .ct-bar-chartb .ct-series-a .ct-bar, .ct-bar-chartc .ct-series-a .ct-bar, .ct-bar-chartd .ct-series-a .ct-bar, .ct-bar-charte .ct-series-a .ct-bar, .ct-bar-chartf .ct-series-a .ct-bar, .ct-bar-chartg .ct-series-a .ct-bar, .ct-bar-charth .ct-series-a .ct-bar, .ct-bar-charti .ct-series-a .ct-bar, .ct-bar-chartj .ct-series-a .ct-bar, .ct-bar-chartk .ct-series-a .ct-bar, .ct-bar-chartl .ct-series-a .ct-bar, .ct-bar-chartm .ct-series-a .ct-bar, .ct-bar-chartn .ct-series-a .ct-bar, .ct-bar-charto .ct-series-a .ct-bar, .ct-bar-chartp .ct-series-a .ct-bar, .ct-bar-chartq .ct-series-a .ct-bar, .ct-bar-chartr .ct-series-a .ct-bar, .ct-bar-charts .ct-series-a .ct-bar {
	stroke:#4682B4 !important; }
.ct-bar-chart .ct-series-b .ct-bar, .ct-bar-charta .ct-series-b .ct-bar, .ct-bar-chartb .ct-series-b .ct-bar, .ct-bar-chartc .ct-series-b .ct-bar, .ct-bar-chartd .ct-series-a .ct-bar, .ct-bar-charte .ct-series-a .ct-bar, .ct-bar-chartf .ct-series-a .ct-bar, .ct-bar-chartg, .ct-bar-charth .ct-series-a .ct-bar, .ct-bar-charti .ct-series-a .ct-bar, .ct-bar-chartj .ct-series-a .ct-bar, .ct-bar-chartk .ct-series-a .ct-bar, .ct-bar-chartl .ct-series-a .ct-bar, .ct-bar-chartm .ct-series-a .ct-bar, .ct-bar-chartn .ct-series-a .ct-bar, .ct-bar-charto .ct-series-a .ct-bar, .ct-bar-chartp .ct-series-a .ct-bar, .ct-bar-chartq .ct-series-a .ct-bar, .ct-bar-chartr .ct-series-a .ct-bar, .ct-bar-charts .ct-series-a .ct-bar {
	stroke: #E9967A;}
.purchas { color:#4682B4; }
.sales { color:#E9967A; }

@media print{
body{ margin:1.5em !important; overflow:hidden; font-size:18px !important;}
fieldset{width:98% !important; overflow:hidden !important;}
.ct-grid{stroke:rgba(0,0,0,.2)!important;stroke-width:1px;stroke-dasharray:2px;  fill:White !important;}
#print_pdf{width:initial;min-height:initial;box-shadow:initial;background:initial;page-break-after:always;visibility:visible;} }
</style>
</head>
<body class="fix-header card-no-border fix-sidebar">
<div class="preloader">
  <div class="loader">
    <div class="loader__figure"></div>
    <p class="loader__label"></p>
  </div>
</div>
<div id="main-wrapper">
  <?php include("include/topnave.php");?>
  <aside class="left-sidebar" id="navbar">
    <?php include("include/bottomnav.php");?>
  </aside>
  <div class="page-wrapper">
    <div class="container-fluid">
      <div class="row page-titles">
        <div class="col-md-5 align-self-center">
          <h4 class="text-themecolor" style="float: left;"> Analytics</h4>
        </div>
        <div class="col-md-7 align-self-center">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a oncontextmenu="return false;" href="index1.php">Home</a> </li>
            <li class="breadcrumb-item active">Analytics</li>
          </ol>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <div class="form-row">
                <div class="col-md-2" id="main_section">
                  <fieldset>
                    <legend class="control-label" style="margin-left:20px; width: 60px; font-size:15px; padding-left:7px;"> Reports</legend>
                    <label class="container">Normal
                      <input type="radio"  class="maininput" id="mreport_normal" name="mainreport" value="Normal" <?php if($mainreport == 'Normal') echo 'checked' ?>>
                      <span class="checkmark"></span> </label>
                    <label class="container">Season
                      <input type="radio"  class="maininput" id="mreport_season" name="mainreport" value="Season" <?php if($mainreport == 'Season') echo 'checked' ?>>
                      <span class="checkmark"></span> </label>
                  </fieldset>
                </div>
              </div>
              <div class="col-md-12"></div>
              <div id="normale">
                <form class="" name="addbilldetails" method="get" action="" id="insert_form" enctype="multipart/form-data">
                  <div class="form-row">
                    <div class="col-md-3">
                      <fieldset>
                        <legend class="control-label"> Report Type</legend>
                        <label class="container">Day
                          <input type="radio" id="main" class="day" name="maintype" value="Day" <?php if($maintype == 'Day') echo 'checked' ?>>
                          <span class="checkmark"></span> </label>
                        <label class="container">7 Days
                          <input type="radio" id="main" name="maintype" value="Week" <?php if($maintype == 'Week') echo 'checked' ?>>
                          <span class="checkmark"></span> </label>
                        <label class="container">Month
                          <input type="radio" id="main" name="maintype" value="Month" <?php if($maintype == 'Month') echo 'checked' ?>>
                          <span class="checkmark"></span> </label>
                        <label class="container">Year
                          <input type="radio" id="main" name="maintype" value="Year" <?php if($maintype == 'Year') echo 'checked' ?>>
                          <span class="checkmark"></span> </label>
                      </fieldset>
                    </div>
                    <?php 				  
					$result =$db->prepare("SELECT * FROM  date_mask WHERE company_tkn='$user_company' AND  addby='$userid' ORDER BY id DESC LIMIT 1");
					$result->execute();
					$rows=$result->fetch();
					$dateformate=$rows['dateformate'];?>
                    <?php if($dateformate == 'datechoos') { ?>
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1" id="d1">
                      <label for="" class="control-label" id="d">Day</label>
                      <label for="" class="control-label" id="w">Week 1</label>
                      <input type="date" class="form-control" id="startdate" name="startdate" value="<?php echo $startdate;?>" required>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1" id="d2">
                      <label for="" class="control-label">Week 2</label>
                      <input type="date" class="form-control" id="enddate" name="enddate" value="<?php echo $enddate;?>" required>
                    </div>
                    <?php }  else {
					  if($startdate==0 && $enddate==0){  $startdate='';  $enddate=''; }else {
					  $dates = date_create($startdate);
					  $startdate = date_format($dates,'d-m-Y');
					  $datee = date_create($enddate);
					  $enddate = date_format($datee,'d-m-Y');}
				    ?>
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1" id="d1">
                      <label for="" class="control-label" id="d">Day</label>
                      <label for="" class="control-label" id="w">Week 1</label>
                      <input type="text" class="form-control date-inputmask" id="startdate" value="<?php echo $startdate;?>" name="startdate" required>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1" id="d2">
                      <label for="" class="control-label">Week 2</label>
                      <input type="text" class="form-control date-inputmask" id="enddate" value="<?php echo $enddate;?>" name="enddate" required>
                    </div>
                    <?php } ?>
                    <div class="col-md-2 col-sm-6 col-xs-12" id="m">
                      <label for="" class="control-label">Month</label>
                      <select class="form-control" id="Months" name="Months" style="width: 100%; height:36px;" value="<?php echo $types;?>">
                        <option value="<?php echo $Months;?>"><?php echo $Months;?></option>
                        <option value="January">January</option>
                        <option value="February">February</option>
                        <option value="March">March</option>
                        <option value="April">April</option>
                        <option value="May">May</option>
                        <option value="June">June</option>
                        <option value="July">July</option>
                        <option value="August">August</option>
                        <option value="September">September</option>
                        <option value="October">October</option>
                        <option value="November">November</option>
                        <option value="December">December</option>
                      </select>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12" id="y">
                      <label for="" class="control-label">Year</label>
                      <input type="number" name="years" id="years" class="form-control" value="<?php echo $years;?>">
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12" id="c">
                      <label for="" class="control-label">Choose Type</label>
                      <select class="form-control" id="type" name="type" style="width: 100%; height:36px;" value="<?php echo $types;?>">
                        <option value="<?php echo $type;?>"><?php echo $type;?></option>

                        <option value="Supplier Wise">Supplier Wise</option>
                        <option value="Product Wise">Product Wise</option>
                        <option value="Category Wise">Category Wise</option>
                        <option value="Sub Category Wise">Sub Category Wise</option>
                      </select>
                    </div>
                    <input type="hidden" name="mainreport" id="" value="Normal">
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
                      <input type="submit" name="submits" id="search_id" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Show"/>
                    </div>
                  </div>
                </form>
                <?php
				$datea = date_create($startdate);
				$startdate = date_format($datea,'Y-m-d');
				$startdates = date_format($datea,'d-m-Y');
				$datead = date_create($today);
				$daydate = date_format($datead,'d-m-Y');
				?>
				<!-- day details -->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="day_details">
                <?php include("season-include/day_details.php");?>
                </div>
                <!-- week or 7 days  details-->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="week_details">
                 <?php include("season-include/week_details.php");?>
                </div>
                <!-- month detalis-->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="month_details">
                 <?php include("season-include/month_details.php");?>
                </div>
                <!-- YEAR details-->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="year_details">
                  <?php include("season-include/year_details.php");?>
                </div>
                <!-- catecory details -->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="cat_details">
                <?php include("season-include/normal_category.php");?>
                </div>
                <!--subcategory details-->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="sub_details">
                 <?php include("season-include/normal_subcategory.php");?>
                </div>
                <!--- product details-->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="product_details">
                  <?php include("season-include/normal_product.php");?>
                </div>
                <!-- Supplier details -->
                <div class="co-md-12 col-xs-12 col-sm-12" style="margin-top:10px;" id="supplier_details">
               <?php include("season-include/normal_supplier.php");?>
               </div>
			  <!--end normale detailse-->
			  </div>
              <!--- season Details-->
              <div id="season">
                <form class="" name="addbilldetails" method="get" action="" id="insert_formses" enctype="multipart/form-data">
                  <div class="form-row">
                    <div class="col-md-12"></div>
                    <div class="col-md-2 col-sm-6 col-xs-12">
                      <label for="" class="control-label">Season Name</label>
                      <select class="select2 form-control" name="sea_name" id="sea_name" style="width: 100%; height:36px;"  required>
                        <option value="<?php echo $season_name;?>"><?php echo $season_name;?></option>
                        <?php
							$result =$db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' GROUP BY season_name");
							$result->execute();
							while($row = $result->fetch()){
							?>
                        <option value="<?php echo $row['season_name'];?>"><?php echo ucfirst($row['season_name']);?></option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12">
                      <label for="" class="control-label">Year</label>
                      <input type="number" name="sea_year" id="sea_year" class="form-control" value="<?php echo $season_year;?>" required>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-12" id="c">
                      <label for="" class="control-label">Choose Type</label>
                      <select class="form-control" id="setype" name="setype" style="width: 100%; height:34px;" value="<?php echo $types;?>">
                        <option value="<?php echo $setype;?>"><?php echo $setype;?></option>
						<option value="Select">Select</option>
                        <option value="Supplier Wise">Supplier Wise</option>
                        <option value="Product Wise">Product Wise</option>
                        <option value="Category Wise">Category Wise</option>
                        <option value="Sub Category Wise">Sub Category Wise</option>
                      </select>
                    </div>
                    <input type="hidden" name="mainreport" id="" value="Season">
                    <div class="col-md-2 col-sm-6 col-xs-12 mb-1">
                      <input type="submit" name="season_submit" id="season_submit" class="btn btn-info btn-sm" style="margin-top:30px; font-size: 16px;" value="Show"/>
                    </div>
                  </div>
                </form>
				<div id="season_pdf">
                <?php 
			  
			   if(isset ($_GET['sea_name'], $_GET['sea_year'],$_GET['mainreport'],$_GET['setype'])){ 
			   $result_ceason = $db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND season_name='$season_name' AND season_year='$season_year'");
				$result_ceason->execute();	
				$name_count = $result_ceason->rowcount(); 
			   if($name_count!=0){?>
                <div class="col-md-12">
                  <fieldset>
                    <legend class="control-label" style="margin-left:30px; width:auto; font-size:18px; padding-left:7px;"><?php echo ucfirst($season_name);
					if($setype=='Supplier Wise' ){?> ( Supplier)
                    <?php } if($setype=='Product Wise' ){?>
                    ( Product)
                    <?php } if($setype=='Category Wise' ){?>
                    ( Category )
                    <?php } if($setype=='Sub Category Wise' ){?>
                    ( Sub Category )
                    <?php }?>
                    </legend>
                    <table class="table-bordered"  border="1" cellspacing="0" width="100%" style="margin:20px 0px;">
					 <tr style="text-align:center; display:none;" >
						 <td><?php echo ucfirst($season_name);
					if($setype=='Supplier Wise' ){?> Supplier<?php } if($setype=='Product Wise' ){?> Product<?php } if($setype=='Category Wise' ){?> Category <?php } if($setype=='Sub Category Wise' ){?> Sub Category<?php }?> Details </td>
						 </tr>
				 <tr style="text-align:center; display:none;" >
						 <th></th>
						 </tr>
                      <tr style="text-align:center;">
                        <?php if($setype=='Select' || $setype=='Supplier Wise' ){ ?><td rowspan="2"><b>Name</b></td><?php }  if($setype=='Supplier Wise'){ ?><td rowspan="2"><b>Location</b></td><?php }  if($setype=='Product Wise' ){ ?><td rowspan="3"><b>Product Name</b></td><?php } if($setype=='Sub Category Wise' ){ ?><td rowspan="3"><b>Sub Category</b></td><?php }  if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise' ){ ?><td rowspan="3"><b>Category</b></td><?php } ?><td colspan="6"><b>Quantity</b></td><td style="display:none;"></td><td style="display:none;"></td> <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><td style="display:none;"></td><td style="display:none;"></td><?php } ?><td colspan="6"><b>Amount</b></td>
                      </tr>
                      <?php 
				/*2rd and 3rd  year*/
				$pri_season_year=$season_year-1; 
				$last_season_year=$season_year-2; 
				/* season name row count*/
				$result_csesoncount = $db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND  season_name='$season_name' AND season_year='$season_year'");
				$result_csesoncount->execute();	
				$cur_season = $result_csesoncount->rowcount(); 
				
				$result_preseasncount = $db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND  season_name='$season_name' AND season_year='$pri_season_year'");
				$result_preseasncount->execute();	
				$pre_season = $result_preseasncount->rowcount(); 
				
				$result_lastseasncount = $db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND  season_name='$season_name' AND season_year='$last_season_year'");
				$result_lastseasncount->execute();	
				$last_season = $result_lastseasncount->rowcount(); 

				if($cur_season !=0){
				$result_season =$db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND season_name='$season_name' AND season_year='$season_year'");
				$result_season->execute();
				for($i=0; $row_seson = $result_season->fetch(); $i++){ 
				$season_startdate=$row_seson['start_date']; $season_enddate=$row_seson['end_date'];
				}
				} else {$season_startdate=''; $season_enddate='';}
				
				if($pre_season !=0){
				$result_pseason =$db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND season_name='$season_name' AND season_year='$pri_season_year'");
				$result_pseason->execute();
				for($i=0; $row_pseson = $result_pseason->fetch(); $i++){ 
				$pseason_startdate=$row_pseson['start_date']; $pseason_enddate=$row_pseson['end_date'];
				}
				} else {$pseason_startdate=''; $pseason_enddate='';}
				
				if($last_season !=0){
				$result_lseason =$db->prepare("SELECT * FROM  season WHERE company_tkn='$user_company' AND season_name='$season_name' AND season_year='$last_season_year'");
				$result_lseason->execute();
				for($i=0; $row_lseson = $result_lseason->fetch(); $i++){ 
				$lseason_startdate=$row_lseson['start_date']; $lseason_enddate=$row_lseson['end_date'];
				}
				} else { $lseason_startdate=''; $lseason_enddate='';}
				
				?>
                      <tr style="text-align:center;">
                       <?php if($setype=='Sub Category Wise' || $setype=='Supplier Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td style="display:none;"></td> <td colspan="2"><b><?php echo ucfirst($season_name)."-".$season_year;?></b><br>
                          <h6>
                            <?php if($cur_season !=0){?>
                            <?php echo date('d/ m/ Y', strtotime($season_startdate))."  - ".date('d/ m/ Y', strtotime($season_enddate));  } ?></h6></td>
                         <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td colspan="2"><b><?php echo ucfirst($season_name)."-".$pri_season_year;?></b><br>
                          <h6>
                            <?php if($pre_season !=0){ echo date('d/ m/ Y', strtotime($pseason_startdate))."  - ".date('d/ m/ Y', strtotime($pseason_enddate));  } ?>
                          </h6></td>
                         <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td colspan="2"><b><?php echo ucfirst($season_name)."-".$last_season_year;?></b><br>
                          <h6>
                            <?php if($last_season !=0){echo date('d/ m/ Y', strtotime($lseason_startdate))."  - ".date('d/ m/ Y', strtotime($lseason_enddate));  } ?>
                          </h6></td>
                         <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td colspan="2"><b><?php echo ucfirst($season_name)."-".$season_year;?></b><br>
                          <h6>
                            <?php if($cur_season !=0){ echo date('d/ m/ Y', strtotime($season_startdate))."  - ".date('d/ m/ Y', strtotime($season_enddate));  } ?>
                          </h6></td>
                         <?php if($setype=='Sub Category Wise'|| $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td colspan="2"><b><?php echo ucfirst($season_name)."-".$pri_season_year;?></b><br>
                          <h6>
                            <?php if($pre_season !=0){ echo date('d/ m/ Y', strtotime($pseason_startdate))."  - ".date('d/ m/ Y', strtotime($pseason_enddate));  } ?>
                          </h6></td>
                         <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?><td style="display:none;"></td><?php }?><td colspan="2"><b><?php echo ucfirst($season_name)."-".$last_season_year;?></b><br>
                          <h6>
                            <?php if($last_season !=0){ echo date('d/ m/ Y', strtotime($lseason_startdate))."  - ".date('d/ m/ Y', strtotime($lseason_enddate)); } ?>
                          </h6></td>
                      </tr>
                      <?php if($setype=='Sub Category Wise' || $setype=='Category Wise' || $setype=='Product Wise') { ?>
                      <tr style="text-align:center;" >
                       <?php if($setype=='Sub Category Wise' ||  $setype=='Product Wise') { ?><td style="display:none;"></td><?PHP }?><td style="display:none;"></td><td><b>Purchase</b></td>
                        <td><b>Sales </td>
                        <td><b>Purchase</b></td>
                        <td><b>Sales</b></td>
                        <td><b>Purchase </b></td>
                        <td><b>Sales</b></td>
                        <td><b>Purchase<b></td>
                        <td><b>Sales</b></td>
                        <td><b>Purchase</b></td>
                        <td><b>Sales</b></td>
                        <td><b>Purchase</b></td>
                        <td><b>Sales</b></td>
                      </tr>
                      <?php }
				 /*Season details*/
				if($setype=='Select'){
				include("season-include/season_details.php");?>
                <!-- Season supplier  details -->
                <?php } else if($setype=='Supplier Wise'){
				include("season-include/season_supplier.php");?>	
				 <!-- season category  details-->
                <?php } else if($setype=='Category Wise'){
				include("season-include/season_category.php");?>	
				 <!-- season subcategory  details-->
                <?php } else if($setype=='Sub Category Wise'){
				 include("season-include/season_subcategory.php");?>
				 <!-- season product  details-->
                <?php } else if($setype=='Product Wise'){
				 include("season-include/season_product.php");?>
        <?php } } } ?>
      </div>
	  </div>
	    <div class=" col-md-12 text-right" style="margin-top:40px;" >
				  <input type="button" id="season_btn" class="btn btn-info btn-sm" value="Export Pdf" />
				  <input type="button" id="season_print" class="btn btn-info btn-sm" value="Print" /> 
				  <button  class="btn btn-info btn-sm" id="season_csv">Export CSV</button>
				  </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
<div class="right-sidebar">
  <div class="slimscrollright">
    <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
    <div class="r-panel-body">
      <ul id="themecolors" class="m-t-20">
        <li><b>With Light sidebar</b> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default" class="default-theme">1</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green" class="green-theme">2</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red" class="red-theme">3</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a> </li>
        <li class="d-block m-t-30"><b>With Dark sidebar</b> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme working">7</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a> </li>
        <li><a oncontextmenu="return false;" href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a> </li>
      </ul>
     
    </div>
  </div>
</div>
</div>

</div>
</div>
<script src="assets/plugins/jquery/jquery.min.js"></script> 
<script src="assets/plugins/bootstrap/js/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
<script src="js/perfect-scrollbar.jquery.min.js"></script> 
<script src="js/waves.js"></script> 
<script src="js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script> 
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script> 
<script src="js/custom.min.js"></script> 
<script src="assets/plugins/datatables/datatables.min.js"></script> 
<script>
	var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
	   document.getElementById("navbar1").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-70px";
	  document.getElementById("navbar1").style.top = "-80px";
  }
  prevScrollpos = currentScrollPos;
}
            $(document).ready(function() {
				 var mainrpot = $("input[name='mainreport']:checked").val();  $('#season').hide();  $('#season_btn').hide();  $('#season_print').hide(); $('#season_csv').hide();
				 if (mainrpot == 'Normal'){ $('#normale').show();  $('#seson').hide();  $('#insert_formses').hide(); $('#season_btn').hide();  $('#season_print').hide(); $('#season_csv').hide();}
					else if(mainrpot == 'Season'){ $('#normale').hide();  $('#season').show();  $('#season_btn').show();  $('#season_print').show(); $('#season_csv').show();}
					<?php if(isset ($_GET['type'],  $_GET['maintype'])){ ?>
					var main = $("input[name='maintype']:checked").val();  
				    //var typ = $("#type :selected").val(); 
                    var typ = "<?php echo $type;?>";	
					$('#cat_details').hide();  $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
				    if (main == 'Day' && typ == 'Select'){ $('#week_details').hide();   $('#day_details').show(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide();  $('#sub_details').hide();    $('#cat_details').hide();  $('#product_details').hide();  $('#supplier_details').hide(); 
                    } else if(main == 'Day' && typ == 'Category Wise'){
						$('#week_details').hide();   $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').show();  $('#sub_details').hide();   $('#product_details').hide(); $('#supplier_details').hide(); 
					
					 } else if(main == 'Day' && typ == 'Sub Category Wise'){
						$('#week_details').hide();   $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').show();  $('#product_details').hide();  $('#supplier_details').hide(); 
					}
					else if(main == 'Day' && typ == 'Product Wise'){
						$('#week_details').hide();   $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').hide();   $('#sub_details').hide();  $('#product_details').show();  $('#supplier_details').hide(); 
					}
					else if(main == 'Day' && typ == 'Supplier Wise'){
						$('#week_details').hide();   $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();   $('#product_details').hide(); $('#supplier_details').show(); 
					}
                    else if (main == 'Week' && typ == 'Select'){ 
					    $('#week_details').show();  $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
                    } else if(main == 'Week' && typ == 'Category Wise'){
					    $('#week_details').hide();  $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').show(); 	 $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
					} else if(main == 'Week' && typ == 'Sub Category Wise'){
					    $('#week_details').hide();  $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').hide(); 	  $('#sub_details').show();   $('#product_details').hide();  $('#supplier_details').hide(); 
					} else if(main == 'Week' && typ == 'Product Wise'){
					    $('#week_details').hide();  $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').hide();   $('#sub_details').hide();  $('#product_details').show();  $('#supplier_details').hide(); 
					} else if(main == 'Week' && typ == 'Supplier Wise'){
					    $('#week_details').hide();  $('#day_details').hide(); $('#month_details').hide(); 
                        $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').hide();   $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').show(); 
					}
					else if (main == 'Month'  && typ == 'Select'){ 
                        $('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').show(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').hide(); $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
                    } else if(main == 'Month'  && typ == 'Category Wise'){
						$('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').hide(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').show();  $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
					}  else if(main == 'Month'  && typ == 'Sub Category Wise'){
						$('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').hide(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').show();   $('#product_details').hide(); $('#supplier_details').hide(); 
					}  else if(main == 'Month'  && typ == 'Product Wise'){
						$('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').hide(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();   $('#product_details').show();  $('#supplier_details').hide(); 
					} 
					else if(main == 'Month'  && typ == 'Supplier Wise'){
						$('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').hide(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').hide(); $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').show(); 
					} 
					else if (main == 'Year' && typ == 'Select'){ 
                        $('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').show();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').hide(); $('#weekcat_details').hide();  $('#sub_details').hide();  $('#product_details').hide();  $('#supplier_details').hide(); 
                    } else if(main == 'Year' && typ == 'Category Wise'){
						$('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').hide();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').show(); $('#weekcat_details').show();  $('#sub_details').hide();  $('#product_details').hide();  $('#supplier_details').hide(); 
					} else if(main == 'Year' && typ == 'Sub Category Wise'){
						$('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').hide();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').hide(); $('#weekcat_details').hide();  $('#sub_details').show(); $('#product_details').hide();  $('#supplier_details').hide(); 
					} else if(main == 'Year' && typ == 'Product Wise'){
						$('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').hide();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').hide();   $('#sub_details').hide();  $('#weeksubcate_details').hide(); $('#product_details').show();  $('#supplier_details').hide(); 
					} else if(main == 'Year' && typ == 'Supplier Wise'){
						$('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').hide();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').hide(); $('#weekcat_details').hide();  $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').show(); 
					}
					<?php } else { //$type='Select'; ?>
					document.getElementById( 'type' ).value = 'Select'; 
					 $('.day').prop("checked", true);
					$('#week_details').hide();   $('#day_details').show(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();    $('#product_details').hide();  $('#supplier_details').hide(); 
					<?php } ?>
                $('input[name="maintype"]').click(function() 
                {
                    // Hide 2 divs
                     $('#d2').hide(); $('#m').hide(); $('#y').hide(); $('#w').hide(); $('#week_details').hide(); $('#day_details').show(); $('#month_details').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
					 document.getElementById( 'type' ).value = 'Select'; 
					 <?php $type='Select'; $maintype='Day'; $startdate =$today; $enddate=$today; $Months =$month;$years =$year; ?>
                    // Show by current checkbox
                    var value = $(this).val();
                    if (value == 'Day'){ $('#week_details').hide();   $('#day_details').show(); $('#month_details').hide(); 
                        $('#d1').show();  $('#d2').hide();  $('#m').hide();  $('#y').hide();  $('#d').show();  $('#w').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();    $('#product_details').hide();  $('#supplier_details').hide(); 
					 <?php $type='Select'; $maintype='Day'; $startdate =$today; $enddate=$today; $Months =$month;$years =$year; ?>
                    }
                    else if (value == 'Week'){ 
					 $('#week_details').show();  $('#day_details').hide(); $('#month_details').hide(); 
                       $('#d1').show(); $('#d2').show();   $('#m').hide();  $('#y').hide(); $('#d').hide();  $('#w').show();  $('#year_details').hide(); $('#cat_details').hide(); $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
					  <?php $type='Select'; $maintype='Day'; $startdate =$today; $enddate=$today; $Months =$month;$years =$year; ?>
                    }
					else if (value == 'Month'){ 
                       $('#m').show(); $('#y').show(); $('#d1').hide(); $('#d2').hide(); $('#month_details').show(); $('#week_details').hide(); $('#day_details').hide();  $('#year_details').hide(); $('#cat_details').hide();  $('#sub_details').hide();   $('#product_details').hide();  $('#supplier_details').hide(); 
					  <?php $type='Select'; $maintype='Day'; $startdate =$today; $enddate=$today; $Months =$month;$years =$year; ?>
                    } else if (value == 'Year'){ 
                        $('#y').show(); $('#d1').hide(); $('#d2').hide();  $('#m').hide();  $('#year_details').show();  $('#month_details').hide(); $('#week_details').hide();  $('#day_details').hide(); $('#cat_details').hide(); $('#sub_details').hide();  $('#product_details').hide();  $('#supplier_details').hide(); 
					 <?php $type='Select'; $maintype='Day'; $startdate =$today; $enddate=$today; $Months =$month;$years =$year; ?>
                    }
                });
				
				$('input[name="mainreport"]').click(function() 
                {
                    $('#normale').show();  $('#season').hide(); $('#season_btn').hide();  $('#season_print').hide(); $('#season_csv').hide();
					 
                    var values = $(this).val();
                    if (values == 'Normal'){ $('#normale').show();  $('#seson').hide();  $('#season_btn').hide();  $('#season_csv').hide();  $('#season_print').hide();
                        
					}
					else if(values == 'Season'){ $('#normale').hide();  $('#season').show(); $('#insert_formses').show(); }
				});
				
				$('input[name="season_submit"]').click(function() 
                {
					 $('#normale').hide();  $('#season').show(); 
					 $("input[value='Season']").attr("id");  
				});
				 $(document).on('submit', '#insert_formses', function() {
                 $('#normale').hide();  $('#season').show();   
                });
	
            });
        </script>

<script src="assets/plugins/chartist-js/dist/chartist.min.js"></script> 
<script>
/* normale details diagram*/	
	/* day qty*/
	var dayqty = {
  labels: ["Current Date","Previous Date", "Last Year"],
  series: [
    [<?php echo $today_ptot_qty-$today_ret_pqty;?>, <?php echo $yes_ptot_qty-$yes_ret_pqty;?>, <?php echo $last_ptot_qty-$last_ret_pqty;?>],
    [<?php echo $today_stot_qty-$today_ret_sqty;?>, <?php echo $yes_stot_qty-$yes_ret_sqty;?>, <?php echo $last_stot_qty-$last_ret_sqty;?>]
  ]
};
/* day amount*/
var  dayamt= {
   labels: ["Current Date","Previous Date", "Last Year"],
  series: [
    [<?php echo  $today_pgrand_tot-$today_pdsc-$today_ret_ptotal;?>, <?php echo  $yes_pgrand_tot-$yes_pdsc-$yes_ret_ptotal;?>, <?php echo $last_pgrand_tot-$last_pdsc-$last_ret_ptotal;?>],
    [<?php echo $today_sgrand_tot-$today_disc_tot-$today_ret_stotal;?>, <?php echo $yes_sgrand_tot-$yes_disc_tot-$yes_ret_stotal;?>, <?php echo $last_sgrand_tot-$last_disc_tot-$last_ret_stotal;?>]
  ]
};
/* day qty average*/
var  dayqty_avg= {
  labels: ["Current Date","Previous Date", "Last Year"],
  series: [
    [<?php echo  $today_pqty_avg;?>, <?php echo  $yes_pqty_avg;?>, <?php echo $last_pqty_avg;?>],
    [<?php echo $today_sqty_avg;?>, <?php echo $yes_sqty_avg;?>, <?php echo $last_sqty_avg;?>]
  ]
};
/* day amount average*/
var  dayamt_avg= {
  labels: ["Current Date","Previous Date", "Last Year"],
  series: [
    [<?php echo  $today_pgrandtot_avg;?>, <?php echo  $yes_pgrandtot_avg;?>, <?php echo $last_pgrandtot_avg;?>],
    [<?php echo $today_sgrandtot_avg;?>, <?php echo $yes_sgrandtot_avg;?>, <?php echo $last_sgrandtot_avg;?>]
  ]
};

/* week qty*/
var weekqty = {
  labels: ['This Week','Previous Week / Week 1', 'Last Year / Week 2'],
  series: [
    [<?php echo $curweek_ptot_qty-$curweek_ret_pqty;?>, <?php echo $fweek_ptot_qty-$fweek_ret_pqty;?>, <?php echo $sweek_ptot_qty-$sweek_ret_pqty;?>],
    [<?php echo $curweek_stot_qty-$curweek_ret_sqty;?>, <?php echo $fweek_stot_qty-$fweek_ret_sqty;?>, <?php echo $sweek_stot_qty-$sweek_ret_sqty;?>]
  ]
};
/* week amount*/
var  weekamt= {
  labels: ['This Week','Previous Week / Week 1', 'Last Year / Week 2'],
  series: [
    [<?php echo  $curweek_pgrand_tot-$curweek_pdsc-$curweek_ret_ptotal;?>, <?php echo  $fweek_pgrand_tot-$fweek_pdsc-$fweek_ret_ptotal;?>, <?php echo $sweek_pgrand_tot-$sweek_pdsc-$sweek_ret_ptotal;?>],
    [<?php echo $curweek_sgrand_tot-$curweek_disc_tot-$curweek_ret_stotal;?>, <?php echo $fweek_sgrand_tot-$fweek_disc_tot-$fweek_ret_stotal;?>, <?php echo $sweek_sgrand_tot-$sweek_disc_tot-$sweek_ret_stotal;?>]
  ]
};
/* week qty average*/
var  weekqty_avg= {
  labels: ['This Week','Previous Week / Week 1', 'Last Year / Week 2'],
  series: [
    [<?php echo  $curweek_pqty_avg;?>, <?php echo  $fweek_pqty_avg;?>, <?php echo $sweek_pqty_avg;?>],
    [<?php echo $curweek_sqty_avg;?>, <?php echo $fweek_sqty_avg;?>, <?php echo $sweek_sqty_avg;?>]
  ]
};
/* week amount average*/
var  weekamt_avg= {
  labels: ['This Week','Previous Week / Week 1', 'Last Year / Week 2'],
  series: [
    [<?php echo  $curweek_pgrandtot_avg;?>, <?php echo  $fweek_pgrandtot_avg;?>, <?php echo $sweek_pgrandtot_avg;?>],
    [<?php echo $curweek_sgrandtot_avg;?>, <?php echo $fweek_sgrandtot_avg;?>, <?php echo $sweek_sgrandtot_avg;?>]
  ]
};

/* month qty*/
var monthqty = {
  labels: ["<?php echo $month.'-'.$year;?>","<?php echo $pmonth;?>", "<?php echo $Months. '-' .$lm_year;?>"],
  series: [
    [<?php echo $cumonth_ptot_qty-$cumonth_ret_pqty;?>, <?php echo $pm_ptot_qty-$pm_ret_pqty;?>, <?php echo $lm_ptot_qty-$lm_ret_pqty;?>],
    [<?php echo $cumonth_stot_qty-$cumonth_ret_sqty;?>, <?php echo $pm_stot_qty-$pm_ret_sqty;?>, <?php echo $lm_stot_qty-$lm_ret_sqty;?>]
  ]
};
/* month amount*/
var  monthamt= {
  labels: ["<?php echo $month.'-'.$year;?>","<?php echo $pmonth;?>", "<?php echo $Months. '-' .$lm_year;?>"],
  series: [
    [<?php echo  $cumonth_pgrand_tot-$cumonth_pdsc-$cumonth_ret_ptotal;?>, <?php echo  $pm_pgrand_tot-$pm_pdsc-$pm_ret_ptotal;?>, <?php echo $lm_pgrand_tot-$lm_pdsc-$lm_ret_ptotal;?>],
    [<?php echo $cumonth_sgrand_tot-$cumonth_disc_tot-$cumonth_ret_stotal;?>, <?php echo $pm_sgrand_tot-$pm_disc_tot-$pm_ret_stotal;?>, <?php echo $lm_sgrand_tot-$lm_disc_tot-$lm_ret_stotal;?>]
  ]
};
/* month qty average*/
var  monthqty_avg= {
 labels: ["<?php echo $month.'-'.$year;?>","<?php echo $pmonth;?>", "<?php echo $Months. '-' .$lm_year;?>"],
  series: [
    [<?php echo  $cumonth_pqty_avg;?>, <?php echo  $pm_pqty_avg;?>, <?php echo $lm_pqty_avg;?>],
    [<?php echo $cumonth_sqty_avg;?>, <?php echo $pm_sqty_avg;?>, <?php echo $lm_sqty_avg;?>]
  ]
};
/* month  amount average*/
var  monthamt_avg= {
  labels: ["<?php echo $month.'-'.$year;?>","<?php echo $pmonth;?>", "<?php echo $Months. '-' .$lm_year;?>"],
  series: [
    [<?php echo  $cumonth_pgrandtot_avg;?>, <?php echo  $pm_pgrandtot_avg;?>, <?php echo $lm_pgrandtot_avg;?>],
    [<?php echo $cumonth_sgrandtot_avg;?>, <?php echo $pm_sgrandtot_avg;?>, <?php echo $lm_sgrandtot_avg;?>]
  ]
};


/* year qty*/
var yearqty = {
  labels: ["<?php print($year); ?>","<?php echo $pyear;?>"],
  series: [
    [<?php echo $cy_ptot_qty-$cy_ret_pqty;?>, <?php echo $ly_ptot_qty-$ly_ret_pqty;?>],
    [<?php echo $cy_stot_qty-$cy_ret_sqty;?>, <?php echo $ly_stot_qty-$ly_ret_sqty;?>]
  ]
};
/* year amount*/
var  yearamt= {
  labels: ["<?php print($year); ?>","<?php echo $pyear;?>"],
  series: [
    [<?php echo  $cy_pgrand_tot-$cy_pdsc-$cy_ret_ptotal;?>, <?php echo  $ly_pgrand_tot-$ly_pdsc-$ly_ret_ptotal;?>],
    [<?php echo $cy_sgrand_tot-$cy_disc_tot-$cy_ret_stotal;?>, <?php echo $ly_sgrand_tot-$ly_disc_tot-$ly_ret_stotal;?>]
  ]
};
/* year qty average*/
var  yearqty_avg= {
  labels: ["<?php print($year); ?>","<?php echo $pyear;?>"],
  series: [
    [<?php echo  $cy_pqty_avg;?>, <?php echo  $ly_pqty_avg;?>],
    [<?php echo $cy_sqty_avg;?>, <?php echo $ly_sqty_avg;?>]
  ]
};
/* year amount average*/
var  yearamt_avg= {
  labels: ["<?php print($year); ?>","<?php echo $pyear;?>"],
  series: [
    [<?php echo  $cy_pgrandtot_avg;?>, <?php echo  $ly_pgrandtot_avg;?>],
    [<?php echo $cy_sgrandtot_avg;?>, <?php echo $ly_sgrandtot_avg;?>]
  ]
};

/* season detailse diagram*/
<?php if(isset ($_GET['sea_name'], $_GET['sea_year'], $_GET['setype'])){ 
if($name_count !=0 && $setype=='Select'){
?>
	/* season qty*/
var seasonqty = {
  labels: ["<?php echo ucfirst($season_name)."-".$season_year;?>","<?php echo ucfirst($season_name)."-".$pri_season_year;?>", "<?php echo ucfirst($season_name)."-".$last_season_year;?>"],
  series: [
    [<?php echo $fyear_pqty-$fyear_ret_tpqty;?>, <?php echo $syear_pqty-$syear_ret_ypqty;?>, <?php echo $lastyear_pqty-$lastyear_ret_lpqty;?>],
    [<?php echo $fyear_sqty-$fyear_ret_tsqty;?>, <?php echo $syear_sqty-$syear_ret_ysqty;?>, <?php echo $lastyear_sqty-$lastyear_ret_lsqty;?>]
  ]
};
/* season amount*/
var  seasonamt= {
   labels: ["<?php echo ucfirst($season_name)."-".$season_year;?>","<?php echo ucfirst($season_name)."-".$pri_season_year;?>", "<?php echo ucfirst($season_name)."-".$last_season_year;?>"],
  series: [
    [<?php echo   $fyear_ptotal-$fyear_ret_tptotal-$fyear_pdisc;?>, <?php echo  $syear_ptotal-$syear_ret_yptotal-$syear_pdisc;?>, <?php echo $lastyear_ptotal-$lastyear_ret_lptotal-$lastyear_pdisc ;?>],
    [<?php echo $fyear_stotal-$fyear_ret_tstotal-$fyear_sdisc;?>, <?php echo $syear_stotal- $syear_ret_ystotal-$syear_sdisc;?>, <?php echo $lastyear_stotal- $lastyear_ret_lstotal-$lastyear_sdisc ;?>]
  ]
};
/* season qty average*/
var  seasonqty_avg= {
 labels: ["<?php echo ucfirst($season_name)."-".$season_year;?>","<?php echo ucfirst($season_name)."-".$pri_season_year;?>", "<?php echo ucfirst($season_name)."-".$last_season_year;?>"],
  series: [
    [<?php echo  $fyear_pqty_avg;?>, <?php echo  $syear_pqty_avg;?>, <?php echo $lyear_pqty_avg;?>],
    [<?php echo $fyear_sqty_avg;?>, <?php echo $syear_sqty_avg;?>, <?php echo $lyear_sqty_avg;?>]
  ]
};
/*season amount average*/
var  seasonamt_avg= {
   labels: ["<?php echo ucfirst($season_name)."-".$season_year;?>","<?php echo ucfirst($season_name)."-".$pri_season_year;?>", "<?php echo ucfirst($season_name)."-".$last_season_year;?>"],
  series: [
    [<?php echo  $fyear_pgrandtot_avg;?>, <?php echo  $syear_pgrandtot_avg;?>, <?php echo $lyear_pgrandtot_avg;?>],
    [<?php echo $fyear_sgrandtot_avg;?>, <?php echo $syear_sgrandtot_avg;?>, <?php echo $lyear_sgrandtot_avg;?>]
  ]
};
<?php } } ?>
var options = {
  seriesBarDistance: 40 ,
  
};

var responsiveOptions = [
  ['screen and (max-width: 640px)', {
    seriesBarDistance: 5,

    axisX: {
      labelInterpolationFnc: function (value) {
        return value[0];
      }
    }
  }]
];
/* day*/
new Chartist.Bar('.ct-bar-chart', dayqty, options, responsiveOptions);
new Chartist.Bar('.ct-bar-charta', dayamt, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartb', dayqty_avg, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartc', dayamt_avg, options, responsiveOptions);
/* week*/
new Chartist.Bar('.ct-bar-chartd', weekqty, options, responsiveOptions);
new Chartist.Bar('.ct-bar-charte', weekamt, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartf', weekqty_avg, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartg', weekamt_avg, options, responsiveOptions);
/*month*/
new Chartist.Bar('.ct-bar-charth', monthqty, options, responsiveOptions);
new Chartist.Bar('.ct-bar-charti', monthamt, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartj', monthqty_avg, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartk', monthamt_avg, options, responsiveOptions);
/* year*/
new Chartist.Bar('.ct-bar-chartl', yearqty, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartm', yearamt, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartn', yearqty_avg, options, responsiveOptions);
new Chartist.Bar('.ct-bar-charto', yearamt_avg, options, responsiveOptions);
/* season*/
new Chartist.Bar('.ct-bar-chartp', seasonqty, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartq', seasonamt, options, responsiveOptions);
new Chartist.Bar('.ct-bar-chartr', seasonqty_avg, options, responsiveOptions);
new Chartist.Bar('.ct-bar-charts', seasonamt_avg, options, responsiveOptions);

chart.on('draw', function(data) {
  if(data.type === 'slice') {
    var pathLength = data.element._node.getTotalLength();
    data.element.attr({
      'stroke-dasharray': pathLength + 'px ' + pathLength + 'px'
    });
    var animationDefinition = {
      'stroke-dashoffset': {
        id: 'anim' + data.index,
        dur: 1000,
        from: -pathLength + 'px',
        to:  '0px',
        easing: Chartist.Svg.Easing.easeOutQuint,
        fill: 'freeze'
      }
    };
    if(data.index !== 0) {
      animationDefinition['stroke-dashoffset'].begin = 'anim' + (data.index - 1) + '.end';
    }
    data.element.attr({
      'stroke-dashoffset': -pathLength + 'px'
    });
    data.element.animate(animationDefinition, false);
  }
});
    </script> 
	
    <script type="text/javascript" src="assets/convert/pdfmake.min.js"></script>
    <script type="text/javascript" src="assets/convert/html2canvas.min.js"></script>
    <script type="text/javascript">
	/*day detailse pdf*/
        $("body").on("click", "#day_pdf", function () {
			 $('.non_pdf').hide(); 
            html2canvas($('#print_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Day_details.pdf");
                }
            }); 
     setTimeout(location.reload.bind(location), 1200);			
        }); $('.non_pdf').show(); 
		
		/*week detailse pdf*/
        $("body").on("click", "#week_btn", function () {
			 $('.non_pdf_week').hide(); 
            html2canvas($('#week_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Week_details.pdf"); 
                }
            }); 
     setTimeout(location.reload.bind(location), 1200);			
        }); $('.non_pdf_week').show(); 
		
		/*month detailse pdf*/
       $("body").on("click", "#month_btn", function () {
			 $('.non_pdf_month').hide(); 
            html2canvas($('#month_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Month_details.pdf");
                }
            }); 
     setTimeout(location.reload.bind(location), 1200);			
        }); $('.non_pdf_month').show(); 
		
		/*year detailse pdf*/
        $("body").on("click", "#year_btn", function () {
			 $('.non_pdf_year').hide(); 
            html2canvas($('#year_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Year_details_<?php echo date('d/m/Y', strtotime($today));?>.pdf");
                }
            }); 
     setTimeout(location.reload.bind(location), 1200);			
        }); $('.non_pdf_year').show(); 
		
		
		/*season detailse pdf*/
        $("body").on("click", "#season_btn", function () {
			 $('.non_pdf_season').hide(); 
            html2canvas($('#season_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
					<?php if($setype=='Select'){?>
                    pdfMake.createPdf(docDefinition).download("<?php echo ucfirst($season_name);?>_details.pdf");
					<?php } else if($setype=='Supplier Wise'){ ?>
					 pdfMake.createPdf(docDefinition).download("<?php echo ucfirst($season_name);?>_supplier_details.pdf");
					<?php } else if($setype=='Category Wise'){ ?>
					pdfMake.createPdf(docDefinition).download("<?php echo ucfirst($season_name);?>_category_details.pdf");
					<?php }  else if($setype=='Sub Category Wise'){?>
					pdfMake.createPdf(docDefinition).download("<?php echo ucfirst($season_name);?>_subcategory_details.pdf");
					 <?php } else if($setype=='Product Wise'){?>
					 pdfMake.createPdf(docDefinition).download("<?php echo ucfirst($season_name);?>_product_details.pdf");
					<?php } ?>
                }
            }); 
     //setTimeout(location.reload.bind(location), 1200);			
        }); 
	 
		/*normale product  detailse pdf*/
		   $("body").on("click", "#normaleproduct", function () {
			 
            html2canvas($('#nor_product_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Normal_product_details.pdf");
                }
            });
        });
		
		/*normale Category detailse pdf*/
		   $("body").on("click", "#normalcategory", function () {
			 
            html2canvas($('#nor_category_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Normal_category_details.pdf");
                }
            });
        });
		
		/*normale subCategory detailse pdf*/
		   $("body").on("click", "#normalsubcategory", function () {
			 
            html2canvas($('#nor_subcategory_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Normal_subcategory_details.pdf");
                }
            });
        });
		
		/*normale supplier detailse pdf*/
		   $("body").on("click", "#normalsupplier", function () {
			 
            html2canvas($('#nor_supplier_pdf')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("Normal_supplier_details.pdf");
                }
            });
        });
		
		
		/* day print*/
		/*function printData()
{
   var divToPrint=document.getElementById("print_pdf");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('#day_print').on('click',function(){
	$('.non_pdf').hide();  
printData();
 setTimeout(location.reload.bind(location), 1);			
})
$('.non_pdf').show();  

/* week print*/
/*function weekprint()
{
   var week=document.getElementById("week_pdf");
   newWin= window.open("");
   newWin.document.write(week.outerHTML);
   newWin.print();
   newWin.close();
}

$('#week_print').on('click',function(){
	$('.non_pdf_week').hide();  
weekprint();
 setTimeout(location.reload.bind(location), .1);			
})
$('.non_pdf_week').show();  
/* month print*/
/*function monthprint()
{
   var month=document.getElementById("month_pdf");
   newWin= window.open("");
   newWin.document.write(month.outerHTML);
   newWin.print();
   newWin.close();
}

$('#month_print').on('click',function(){
	$('.non_pdf_month').hide();  
monthprint();
 setTimeout(location.reload.bind(location), .1);			
})
$('.non_pdf_month').show();  

/* year print*/
/*function yearprint()
{
   var year=document.getElementById("year_pdf");
   newWin= window.open("");
   newWin.document.write(year.outerHTML);
   newWin.print();
   newWin.close();
}
$('#year_print').on('click',function(){
	$('.non_pdf_year').hide();  
yearprint();
 setTimeout(location.reload.bind(location), .1);			
})
$('.non_pdf_year').show();
 
/* normale subcategory print*/
 /*function subcateprint()
{
   var subcate=document.getElementById("nor_subcategory_pdf");
   newWin= window.open("");
   newWin.document.write(subcate.outerHTML);
   newWin.print();
   newWin.close();
}
$('#subcategory_print').on('click',function(){ 
subcateprint();			
})

/* normale category print*/
 /*function cateprint()
{
   var cate=document.getElementById("nor_category_pdf");
   newWin= window.open("");
   newWin.document.write(cate.outerHTML);
   newWin.print();
   newWin.close();
}
$('#category_print').on('click',function(){ 
cateprint();			
})

/* normale supplier print*/
 /*function supplierprint()
{
   var supplier=document.getElementById("nor_supplier_pdf");
   newWin= window.open("");
   newWin.document.write(supplier.outerHTML);
   newWin.print();
   newWin.close();
}
$('#supplier_print').on('click',function(){ 
supplierprint();			
})

/* normale product print*/
/* function productprint()
{
   var product=document.getElementById("nor_product_pdf");
   newWin= window.open("");
   newWin.document.write(product.outerHTML);
   newWin.print();
   newWin.close();
}
$('#product_print').on('click',function(){ 
productprint();			
})

/*season print*/
 /*function seasonprint()
{
   var season=document.getElementById("season_pdf");
   newWin= window.open("");
   newWin.document.write(season.outerHTML);
   newWin.print();
   newWin.close();
}
$('#season_print').on('click',function(){ 
$('.non_pdf_season').hide();  
seasonprint();
setTimeout(location.reload.bind(location), .1);			
})
$('.non_pdf_season').show();*/


document.getElementById("day_print").addEventListener("click", function() {
     var printContents = document.getElementById('print_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* week detailse  print*/
document.getElementById("week_print").addEventListener("click", function() {
     var printContents = document.getElementById('week_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* month detailse  print*/
document.getElementById("month_print").addEventListener("click", function() {
     var printContents = document.getElementById('month_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* year detailse  print*/
document.getElementById("year_print").addEventListener("click", function() {
     var printContents = document.getElementById('year_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* normale product detailse  print*/
document.getElementById("product_print").addEventListener("click", function() {
     var printContents = document.getElementById('nor_product_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* normale catecory detailse  print*/
document.getElementById("category_print").addEventListener("click", function() {
     var printContents = document.getElementById('nor_category_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* normale subcatecory detailse  print*/
document.getElementById("subcategory_print").addEventListener("click", function() {
     var printContents = document.getElementById('nor_subcategory_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 

/* normale supplier detailse  print*/
document.getElementById("supplier_print").addEventListener("click", function() {
     var printContents = document.getElementById('nor_supplier_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 
/*season print*/
document.getElementById("season_print").addEventListener("click", function() {
     var printContents = document.getElementById('season_pdf').innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
     setTimeout(location.reload.bind(location), .01);	
}); 
    </script>
	
<!-- export csv/excel-->
<script src="js/table2csv.js"></script>
<script>
  $('#day_csv').on('click',function(){
    $('#print_pdf').table2csv({
      file_name: 'Day_details.csv',
      header_body_space: 0
    });
  })
  
   $('#week_csv').on('click',function(){
    $('#week_pdf').table2csv({
      file_name: 'Week_details.csv',
      header_body_space: 0
    });
  })
   $('#month_csv').on('click',function(){
    $('#month_pdf').table2csv({
      file_name: 'Month_details.csv',
      header_body_space: 0
    });
  })
  
   $('#year_csv').on('click',function(){
    $('#year_pdf').table2csv({
      file_name: 'Year_details.csv',
      header_body_space: 0
    });
  })
   $('#product_csv').on('click',function(){
    $('#nor_product_pdf').table2csv({
      file_name: 'Normal_product_details.csv',
      header_body_space: 0
    });
  })
   $('#subcategory_csv').on('click',function(){
    $('#nor_subcategory_pdf').table2csv({
      file_name: 'Normal_subcategory_details.csv',
      header_body_space: 0
    });
  })
  
   $('#supplier_csv').on('click',function(){
    $('#nor_supplier_pdf').table2csv({
      file_name: 'Normal_supplier_details.csv',
      header_body_space: 0
    });
  })
  
   $('#category_csv').on('click',function(){
    $('#nor_category_pdf').table2csv({
      file_name: 'Normal_category_details.csv',
      header_body_space: 0
    });
  })
  
   $('#season_csv').on('click',function(){
    $('#season_pdf').table2csv({
		<?php if($setype=='Select'){?>
                     file_name: 'Season_details.csv',
					<?php } else if($setype=='Supplier Wise'){ ?>
					 file_name: 'Season_supplier_details.csv',
					<?php } else if($setype=='Category Wise'){ ?>
					 file_name: 'Season_category_details.csv',
					<?php }  else if($setype=='Sub Category Wise'){ ?>
					 file_name: 'Season_subcategory_details.csv',
					 <?php } else if($setype=='Product Wise'){ ?>
					 file_name: 'Season_product_details.csv',
					<?php } ?>
      header_body_space: 0
    });
  })
  </script>
 
	
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<?php include ('include/disable_fn.php'); ?>
</body>
</html>